import bpy, mathutils

mat = bpy.data.materials.new(name = "Stone Floor")
mat.use_nodes = True
#initialize Stone floor node group
def stone_floor_node_group():

    stone_floor = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Stone floor")
    
    #initialize stone_floor nodes
    #node Noise Texture
    noise_texture = stone_floor.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 9.699999809265137
    #Detail
    noise_texture.inputs[3].default_value = 8.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.6833333373069763
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix.001
    mix_001 = stone_floor.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'DODGE'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #B_Color
    mix_001.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp
    colorramp = stone_floor.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.4227272570133209
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.4363635778427124)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = stone_floor.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0237737949937582, 0.0237737949937582, 0.0237737949937582, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Noise Texture.002
    noise_texture_002 = stone_floor.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #Scale
    noise_texture_002.inputs[2].default_value = 3.0
    #Detail
    noise_texture_002.inputs[3].default_value = 2.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.5
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node ColorRamp.003
    colorramp_003 = stone_floor.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.35909098386764526
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.5318186283111572)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = stone_floor.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Reroute
    reroute = stone_floor.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Vector Math
    vector_math = stone_floor.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Reroute.001
    reroute_001 = stone_floor.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Mix
    mix = stone_floor.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'DODGE'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.0
    #B_Color
    mix.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp.004
    colorramp_004 = stone_floor.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.0
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.10000000149011612, 0.10000000149011612, 0.10000000149011612, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(1.0)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    
    #node Principled BSDF
    principled_bsdf = stone_floor.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = stone_floor.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #stone_floor outputs
    #output BSDF
    stone_floor.outputs.new('NodeSocketShader', "BSDF")
    stone_floor.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    stone_floor.outputs.new('NodeSocketColor', "Albedo")
    stone_floor.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    stone_floor.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    stone_floor.outputs.new('NodeSocketColor', "Mask")
    stone_floor.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    stone_floor.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Mix.005
    mix_005 = stone_floor.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MIX'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = stone_floor.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Mix.003
    mix_003 = stone_floor.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'LINEAR_LIGHT'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Noise Texture.001
    noise_texture_001 = stone_floor.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.625
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Mix.002
    mix_002 = stone_floor.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'BURN'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.8308331966400146
    
    #node Voronoi Texture
    voronoi_texture = stone_floor.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 5.0
    
    #node Group Input
    group_input = stone_floor.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #stone_floor inputs
    #input Scale
    stone_floor.inputs.new('NodeSocketFloat', "Scale")
    stone_floor.inputs[0].default_value = 1.0
    stone_floor.inputs[0].min_value = -10000.0
    stone_floor.inputs[0].max_value = 10000.0
    stone_floor.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    stone_floor.inputs.new('NodeSocketColor', "Color1")
    stone_floor.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    stone_floor.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    stone_floor.inputs.new('NodeSocketColor', "Color2")
    stone_floor.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    stone_floor.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    stone_floor.inputs.new('NodeSocketFloatFactor', "Roughness")
    stone_floor.inputs[3].default_value = 0.7772727608680725
    stone_floor.inputs[3].min_value = 0.0
    stone_floor.inputs[3].max_value = 1.0
    stone_floor.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Amount
    stone_floor.inputs.new('NodeSocketFloatFactor', "Noise Amount")
    stone_floor.inputs[4].default_value = 0.07499999552965164
    stone_floor.inputs[4].min_value = 0.0
    stone_floor.inputs[4].max_value = 1.0
    stone_floor.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    stone_floor.inputs.new('NodeSocketFloat', "Noise Scale")
    stone_floor.inputs[5].default_value = 5.0
    stone_floor.inputs[5].min_value = -1000.0
    stone_floor.inputs[5].max_value = 1000.0
    stone_floor.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Detail
    stone_floor.inputs.new('NodeSocketFloat', "Noise Detail")
    stone_floor.inputs[6].default_value = 8.0
    stone_floor.inputs[6].min_value = 0.0
    stone_floor.inputs[6].max_value = 15.0
    stone_floor.inputs[6].attribute_domain = 'POINT'
    
    #input Dark Rims Strength
    stone_floor.inputs.new('NodeSocketFloatFactor', "Dark Rims Strength")
    stone_floor.inputs[7].default_value = 0.9583333730697632
    stone_floor.inputs[7].min_value = 0.0
    stone_floor.inputs[7].max_value = 1.0
    stone_floor.inputs[7].attribute_domain = 'POINT'
    
    #input Randomness
    stone_floor.inputs.new('NodeSocketFloatFactor', "Randomness")
    stone_floor.inputs[8].default_value = 1.0
    stone_floor.inputs[8].min_value = 0.0
    stone_floor.inputs[8].max_value = 1.0
    stone_floor.inputs[8].attribute_domain = 'POINT'
    
    #input Bump Strength
    stone_floor.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    stone_floor.inputs[9].default_value = 1.0
    stone_floor.inputs[9].min_value = 0.0
    stone_floor.inputs[9].max_value = 1.0
    stone_floor.inputs[9].attribute_domain = 'POINT'
    
    #input Normal
    stone_floor.inputs.new('NodeSocketVector', "Normal")
    stone_floor.inputs[10].default_value = (0.0, 0.0, 0.0)
    stone_floor.inputs[10].min_value = -1.0
    stone_floor.inputs[10].max_value = 1.0
    stone_floor.inputs[10].attribute_domain = 'POINT'
    stone_floor.inputs[10].hide_value = True
    
    
    
    #node Mix.004
    mix_004 = stone_floor.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    
    
    #Set locations
    noise_texture.location = (-220.01600646972656, 130.0)
    mix_001.location = (179.98403930664062, 50.0)
    colorramp.location = (-0.0159912109375, 238.21063232421875)
    colorramp_002.location = (599.9840087890625, 109.3895263671875)
    noise_texture_002.location = (659.9840087890625, 330.0)
    colorramp_003.location = (878.999755859375, 244.65533447265625)
    bump.location = (679.98388671875, -270.0)
    reroute.location = (-713.7163696289062, -257.28668212890625)
    vector_math.location = (-1080.0159912109375, -150.0)
    reroute_001.location = (-540.0159301757812, 214.379150390625)
    mix.location = (179.98403930664062, -150.00003051757812)
    colorramp_004.location = (859.9840087890625, -70.00003051757812)
    principled_bsdf.location = (1540.0, 100.0)
    group_output.location = (1820.0, 20.0)
    mix_005.location = (1300.0, 100.0)
    texture_coordinate_001.location = (-1420.0159912109375, -230.0)
    mix_003.location = (-360.0159912109375, -146.8994140625)
    noise_texture_001.location = (-580.0160522460938, -290.0)
    mix_002.location = (379.9840393066406, 110.0)
    voronoi_texture.location = (-140.0159912109375, -210.0)
    group_input.location = (-1620.0159912109375, -0.0)
    mix_004.location = (1140.0, 120.0)
    
    #Set dimensions
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    
    #initialize stone_floor links
    #principled_bsdf.BSDF -> group_output.BSDF
    stone_floor.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #voronoi_texture.Distance -> mix.A
    stone_floor.links.new(voronoi_texture.outputs[0], mix.inputs[6])
    #mix.Result -> bump.Height
    stone_floor.links.new(mix.outputs[2], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    stone_floor.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Distance -> mix_001.A
    stone_floor.links.new(voronoi_texture.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> mix_002.A
    stone_floor.links.new(mix_001.outputs[2], mix_002.inputs[6])
    #colorramp.Color -> mix_002.B
    stone_floor.links.new(colorramp.outputs[0], mix_002.inputs[7])
    #noise_texture.Fac -> colorramp.Fac
    stone_floor.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #mix_005.Result -> principled_bsdf.Base Color
    stone_floor.links.new(mix_005.outputs[2], principled_bsdf.inputs[0])
    #mix_003.Result -> voronoi_texture.Vector
    stone_floor.links.new(mix_003.outputs[2], voronoi_texture.inputs[0])
    #reroute.Output -> noise_texture_001.Vector
    stone_floor.links.new(reroute.outputs[0], noise_texture_001.inputs[0])
    #reroute.Output -> mix_003.A
    stone_floor.links.new(reroute.outputs[0], mix_003.inputs[6])
    #noise_texture_001.Color -> mix_003.B
    stone_floor.links.new(noise_texture_001.outputs[1], mix_003.inputs[7])
    #colorramp_002.Color -> mix_004.A
    stone_floor.links.new(colorramp_002.outputs[0], mix_004.inputs[6])
    #mix_002.Result -> mix_004.B
    stone_floor.links.new(mix_002.outputs[2], mix_004.inputs[7])
    #colorramp_003.Color -> mix_004.Factor
    stone_floor.links.new(colorramp_003.outputs[0], mix_004.inputs[0])
    #noise_texture_002.Fac -> colorramp_003.Fac
    stone_floor.links.new(noise_texture_002.outputs[0], colorramp_003.inputs[0])
    #colorramp_004.Color -> principled_bsdf.Specular
    stone_floor.links.new(colorramp_004.outputs[0], principled_bsdf.inputs[7])
    #voronoi_texture.Distance -> colorramp_004.Fac
    stone_floor.links.new(voronoi_texture.outputs[0], colorramp_004.inputs[0])
    #texture_coordinate_001.Object -> vector_math.Vector
    stone_floor.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> reroute.Input
    stone_floor.links.new(vector_math.outputs[0], reroute.inputs[0])
    #reroute.Output -> noise_texture.Vector
    stone_floor.links.new(reroute.outputs[0], noise_texture.inputs[0])
    #reroute_001.Output -> noise_texture_002.Vector
    stone_floor.links.new(reroute_001.outputs[0], noise_texture_002.inputs[0])
    #vector_math.Vector -> reroute_001.Input
    stone_floor.links.new(vector_math.outputs[0], reroute_001.inputs[0])
    #mix.Result -> colorramp_002.Fac
    stone_floor.links.new(mix.outputs[2], colorramp_002.inputs[0])
    #group_input.Scale -> vector_math.Scale
    stone_floor.links.new(group_input.outputs[0], vector_math.inputs[3])
    #mix_004.Result -> mix_005.Factor
    stone_floor.links.new(mix_004.outputs[2], mix_005.inputs[0])
    #group_input.Color1 -> mix_005.A
    stone_floor.links.new(group_input.outputs[1], mix_005.inputs[6])
    #group_input.Color2 -> mix_005.B
    stone_floor.links.new(group_input.outputs[2], mix_005.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    stone_floor.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Noise Amount -> mix_003.Factor
    stone_floor.links.new(group_input.outputs[4], mix_003.inputs[0])
    #group_input.Noise Scale -> noise_texture_001.Scale
    stone_floor.links.new(group_input.outputs[5], noise_texture_001.inputs[2])
    #group_input.Dark Rims Strength -> mix_001.Factor
    stone_floor.links.new(group_input.outputs[7], mix_001.inputs[0])
    #group_input.Noise Detail -> noise_texture_001.Detail
    stone_floor.links.new(group_input.outputs[6], noise_texture_001.inputs[3])
    #group_input.Randomness -> voronoi_texture.Randomness
    stone_floor.links.new(group_input.outputs[8], voronoi_texture.inputs[5])
    #group_input.Bump Strength -> bump.Strength
    stone_floor.links.new(group_input.outputs[9], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    stone_floor.links.new(group_input.outputs[10], bump.inputs[3])
    #mix_004.Result -> group_output.Mask
    stone_floor.links.new(mix_004.outputs[2], group_output.inputs[2])
    #mix_005.Result -> group_output.Albedo
    stone_floor.links.new(mix_005.outputs[2], group_output.inputs[1])
    return stone_floor

stone_floor = stone_floor_node_group()

#initialize Stone Floor node group
def stone_floor_1_node_group():

    stone_floor_1 = mat.node_tree
    #start with a clean node tree
    for node in stone_floor_1.nodes:
        stone_floor_1.nodes.remove(node)
    #initialize stone_floor_1 nodes
    #node Material Output
    material_output = stone_floor_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Stone floor
    stone_floor_2 = stone_floor_1.nodes.new("ShaderNodeGroup")
    stone_floor_2.label = "Stone floor"
    stone_floor_2.name = "Stone floor"
    stone_floor_2.node_tree = stone_floor
    #Input_1
    stone_floor_2.inputs[0].default_value = 1.0
    #Input_2
    stone_floor_2.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_3
    stone_floor_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_5
    stone_floor_2.inputs[3].default_value = 0.7772727608680725
    #Input_6
    stone_floor_2.inputs[4].default_value = 0.07499999552965164
    #Input_7
    stone_floor_2.inputs[5].default_value = 5.0
    #Input_9
    stone_floor_2.inputs[6].default_value = 8.0
    #Input_8
    stone_floor_2.inputs[7].default_value = 0.9583333730697632
    #Input_10
    stone_floor_2.inputs[8].default_value = 1.0
    #Input_11
    stone_floor_2.inputs[9].default_value = 1.0
    #Input_12
    stone_floor_2.inputs[10].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (672.251953125, 101.66796875)
    stone_floor_2.location = (393.595703125, 101.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    stone_floor_2.width, stone_floor_2.height = 198.65673828125, 100.0
    
    #initialize stone_floor_1 links
    #stone_floor_2.BSDF -> material_output.Surface
    stone_floor_1.links.new(stone_floor_2.outputs[0], material_output.inputs[0])
    return stone_floor_1

stone_floor_1 = stone_floor_1_node_group()

