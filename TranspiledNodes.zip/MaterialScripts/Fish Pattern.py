import bpy, mathutils

mat = bpy.data.materials.new(name = "Fish Pattern")
mat.use_nodes = True
#initialize Fish pattern node group
def fish_pattern_node_group():

    fish_pattern = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Fish pattern")
    
    #initialize fish_pattern nodes
    #node ColorRamp.002
    colorramp_002 = fish_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.5000001192092896)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = fish_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.036363635212183
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.05000023543834686)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Vector Math.002
    vector_math_002 = fish_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'ADD'
    #Vector_001
    vector_math_002.inputs[1].default_value = (-0.003000000026077032, -0.0020000000949949026, 0.0)
    #Vector_002
    vector_math_002.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_002.inputs[3].default_value = 0.5
    
    #node ColorRamp.003
    colorramp_003 = fish_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.22322748601436615
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.2570682764053345)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_2 = colorramp_003.color_ramp.elements.new(0.30454540252685547)
    colorramp_003_cre_2.alpha = 1.0
    colorramp_003_cre_2.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_3 = colorramp_003.color_ramp.elements.new(0.3373640179634094)
    colorramp_003_cre_3.alpha = 1.0
    colorramp_003_cre_3.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.004
    colorramp_004 = fish_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.20454545319080353
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(0.21918226778507233)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Voronoi Texture.004
    voronoi_texture_004 = fish_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_004.name = "Voronoi Texture.004"
    voronoi_texture_004.distance = 'EUCLIDEAN'
    voronoi_texture_004.feature = 'F1'
    voronoi_texture_004.voronoi_dimensions = '3D'
    #W
    voronoi_texture_004.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture_004.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture_004.inputs[3].default_value = 0.0
    #Exponent
    voronoi_texture_004.inputs[4].default_value = 0.5799999237060547
    #Randomness
    voronoi_texture_004.inputs[5].default_value = 0.0
    
    #node Texture Coordinate
    texture_coordinate = fish_pattern.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Vector Math.003
    vector_math_003 = fish_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'ADD'
    #Vector_001
    vector_math_003.inputs[1].default_value = (-0.003000000026077032, -0.0020000000949949026, 0.0)
    #Vector_002
    vector_math_003.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_003.inputs[3].default_value = 0.5
    
    #node Vector Math.004
    vector_math_004 = fish_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math_004.name = "Vector Math.004"
    vector_math_004.operation = 'ADD'
    #Vector_002
    vector_math_004.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_004.inputs[3].default_value = 0.5
    
    #node Combine XYZ
    combine_xyz = fish_pattern.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"
    #Z
    combine_xyz.inputs[2].default_value = 0.0
    
    #node Math
    math = fish_pattern.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = -154.40298461914062
    #Value_001
    math.inputs[1].default_value = 9.999999747378752e-06
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Math.001
    math_001 = fish_pattern.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = -337.7029724121094
    #Value_001
    math_001.inputs[1].default_value = 9.999999747378752e-06
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    #node Mix.003
    mix_003 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'ADD'
    mix_003.clamp_factor = True
    mix_003.clamp_result = True
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_003.inputs[2].default_value = 0.0
    #B_Float
    mix_003.inputs[3].default_value = 0.0
    #A_Vector
    mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.001
    mix_001 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.6499999761581421
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Color
    mix_001.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.002
    mix_002 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.6499999761581421
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Voronoi Texture.002
    voronoi_texture_002 = fish_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_002.name = "Voronoi Texture.002"
    voronoi_texture_002.distance = 'EUCLIDEAN'
    voronoi_texture_002.feature = 'F1'
    voronoi_texture_002.voronoi_dimensions = '3D'
    #W
    voronoi_texture_002.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture_002.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture_002.inputs[3].default_value = 0.0
    #Exponent
    voronoi_texture_002.inputs[4].default_value = 0.5799999237060547
    #Randomness
    voronoi_texture_002.inputs[5].default_value = 0.0
    
    #node Voronoi Texture.003
    voronoi_texture_003 = fish_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_003.name = "Voronoi Texture.003"
    voronoi_texture_003.distance = 'EUCLIDEAN'
    voronoi_texture_003.feature = 'F1'
    voronoi_texture_003.voronoi_dimensions = '3D'
    #W
    voronoi_texture_003.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture_003.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture_003.inputs[3].default_value = 0.0
    #Exponent
    voronoi_texture_003.inputs[4].default_value = 0.5799999237060547
    #Randomness
    voronoi_texture_003.inputs[5].default_value = 0.0
    
    #node Voronoi Texture.001
    voronoi_texture_001 = fish_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'MINKOWSKI'
    voronoi_texture_001.feature = 'F1'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #W
    voronoi_texture_001.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture_001.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture_001.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture_001.inputs[4].default_value = 0.6799999475479126
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 0.0
    
    #node Wave Texture
    wave_texture = fish_pattern.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 200.0
    #Distortion
    wave_texture.inputs[2].default_value = 0.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Vector Math
    vector_math = fish_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Wave Texture.001
    wave_texture_001 = fish_pattern.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'Y'
    wave_texture_001.rings_direction = 'X'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Scale
    wave_texture_001.inputs[1].default_value = 200.0
    #Distortion
    wave_texture_001.inputs[2].default_value = 0.0
    #Detail
    wave_texture_001.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture_001.inputs[6].default_value = 0.0
    
    #node Bump
    bump = fish_pattern.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = fish_pattern.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Reroute
    reroute = fish_pattern.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Vector Math.001
    vector_math_001 = fish_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'ADD'
    #Vector_001
    vector_math_001.inputs[1].default_value = (0.007000000216066837, 0.007000000216066837, 0.0)
    #Vector_002
    vector_math_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_001.inputs[3].default_value = 1.0
    
    #node Vector Math.005
    vector_math_005 = fish_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math_005.name = "Vector Math.005"
    vector_math_005.operation = 'ADD'
    #Vector_002
    vector_math_005.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_005.inputs[3].default_value = 1.0
    
    #node Vector Rotate
    vector_rotate = fish_pattern.nodes.new("ShaderNodeVectorRotate")
    vector_rotate.name = "Vector Rotate"
    vector_rotate.invert = False
    vector_rotate.rotation_type = 'AXIS_ANGLE'
    #Center
    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Axis
    vector_rotate.inputs[2].default_value = (0.0, 0.6899999976158142, 1.0)
    #Rotation
    vector_rotate.inputs[4].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = fish_pattern.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #fish_pattern outputs
    #output BSDF
    fish_pattern.outputs.new('NodeSocketShader', "BSDF")
    fish_pattern.outputs[0].attribute_domain = 'POINT'
    
    #output Mask1
    fish_pattern.outputs.new('NodeSocketColor', "Mask1")
    fish_pattern.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    fish_pattern.outputs[1].attribute_domain = 'POINT'
    
    #output Mask2
    fish_pattern.outputs.new('NodeSocketColor', "Mask2")
    fish_pattern.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    fish_pattern.outputs[2].attribute_domain = 'POINT'
    
    #output Mask3
    fish_pattern.outputs.new('NodeSocketColor', "Mask3")
    fish_pattern.outputs[3].default_value = (0.0, 0.0, 0.0, 1.0)
    fish_pattern.outputs[3].attribute_domain = 'POINT'
    
    #output Albedo
    fish_pattern.outputs.new('NodeSocketColor', "Albedo")
    fish_pattern.outputs[4].default_value = (0.0, 0.0, 0.0, 1.0)
    fish_pattern.outputs[4].attribute_domain = 'POINT'
    
    
    
    #node Mix.008
    mix_008 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_008.name = "Mix.008"
    mix_008.blend_type = 'MIX'
    mix_008.clamp_factor = True
    mix_008.clamp_result = False
    mix_008.data_type = 'RGBA'
    mix_008.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_008.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_008.inputs[2].default_value = 0.0
    #B_Float
    mix_008.inputs[3].default_value = 0.0
    #A_Vector
    mix_008.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_008.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Voronoi Texture
    voronoi_texture = fish_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 0.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.5799999237060547
    #Randomness
    voronoi_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = fish_pattern.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #fish_pattern inputs
    #input Color1
    fish_pattern.inputs.new('NodeSocketColor', "Color1")
    fish_pattern.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    fish_pattern.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    fish_pattern.inputs.new('NodeSocketColor', "Color2")
    fish_pattern.inputs[1].default_value = (0.29038184881210327, 0.728374183177948, 1.0, 1.0)
    fish_pattern.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    fish_pattern.inputs.new('NodeSocketFloat', "Scale")
    fish_pattern.inputs[2].default_value = 0.5
    fish_pattern.inputs[2].min_value = -10000.0
    fish_pattern.inputs[2].max_value = 10000.0
    fish_pattern.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    fish_pattern.inputs.new('NodeSocketFloatFactor', "Specular")
    fish_pattern.inputs[3].default_value = 0.5
    fish_pattern.inputs[3].min_value = 0.0
    fish_pattern.inputs[3].max_value = 1.0
    fish_pattern.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    fish_pattern.inputs.new('NodeSocketFloatFactor', "Roughness")
    fish_pattern.inputs[4].default_value = 1.0
    fish_pattern.inputs[4].min_value = 0.0
    fish_pattern.inputs[4].max_value = 1.0
    fish_pattern.inputs[4].attribute_domain = 'POINT'
    
    #input Smiley Amount :)
    fish_pattern.inputs.new('NodeSocketFloatFactor', "Smiley Amount :)")
    fish_pattern.inputs[5].default_value = 0.1083332896232605
    fish_pattern.inputs[5].min_value = 0.0
    fish_pattern.inputs[5].max_value = 1.0
    fish_pattern.inputs[5].attribute_domain = 'POINT'
    
    #input Bump1 Strength
    fish_pattern.inputs.new('NodeSocketFloatFactor', "Bump1 Strength")
    fish_pattern.inputs[6].default_value = 1.0
    fish_pattern.inputs[6].min_value = 0.0
    fish_pattern.inputs[6].max_value = 1.0
    fish_pattern.inputs[6].attribute_domain = 'POINT'
    
    #input Bump2 Strength
    fish_pattern.inputs.new('NodeSocketFloatFactor', "Bump2 Strength")
    fish_pattern.inputs[7].default_value = 0.30000001192092896
    fish_pattern.inputs[7].min_value = 0.0
    fish_pattern.inputs[7].max_value = 1.0
    fish_pattern.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    fish_pattern.inputs.new('NodeSocketVector', "Normal")
    fish_pattern.inputs[8].default_value = (0.0, 0.0, 0.0)
    fish_pattern.inputs[8].min_value = -1.0
    fish_pattern.inputs[8].max_value = 1.0
    fish_pattern.inputs[8].attribute_domain = 'POINT'
    fish_pattern.inputs[8].hide_value = True
    
    
    
    #node Bump.001
    bump_001 = fish_pattern.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 0.10000000149011612
    
    #node Mix
    mix = fish_pattern.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.005
    mix_005 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MIX'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_005.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_005.inputs[2].default_value = 0.0
    #B_Float
    mix_005.inputs[3].default_value = 0.0
    #A_Vector
    mix_005.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_005.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_005.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.007
    mix_007 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_007.name = "Mix.007"
    mix_007.blend_type = 'BURN'
    mix_007.clamp_factor = True
    mix_007.clamp_result = False
    mix_007.data_type = 'RGBA'
    mix_007.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_007.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_007.inputs[2].default_value = 0.0
    #B_Float
    mix_007.inputs[3].default_value = 0.0
    #A_Vector
    mix_007.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_007.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_007.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.006
    mix_006 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'DODGE'
    mix_006.clamp_factor = True
    mix_006.clamp_result = False
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_006.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_006.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_006.inputs[2].default_value = 0.0
    #B_Float
    mix_006.inputs[3].default_value = 0.0
    #A_Vector
    mix_006.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_006.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_006.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp.005
    colorramp_005 = fish_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_005.name = "ColorRamp.005"
    colorramp_005.color_ramp.color_mode = 'RGB'
    colorramp_005.color_ramp.hue_interpolation = 'NEAR'
    colorramp_005.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_005.color_ramp.elements.remove(colorramp_005.color_ramp.elements[0])
    colorramp_005_cre_0 = colorramp_005.color_ramp.elements[0]
    colorramp_005_cre_0.position = 0.0
    colorramp_005_cre_0.alpha = 1.0
    colorramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_005_cre_1 = colorramp_005.color_ramp.elements.new(1.0)
    colorramp_005_cre_1.alpha = 1.0
    colorramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.004
    mix_004 = fish_pattern.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_004.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_004.inputs[2].default_value = 0.0
    #B_Float
    mix_004.inputs[3].default_value = 0.0
    #A_Vector
    mix_004.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_004.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Math.002
    math_002 = fish_pattern.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MAXIMUM'
    math_002.use_clamp = False
    #Value_002
    math_002.inputs[2].default_value = 0.5
    
    #node ColorRamp
    colorramp = fish_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.31363633275032043
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    
    #Set locations
    colorramp_002.location = (-90.0, -36.5679931640625)
    colorramp_001.location = (44.469482421875, 250.3594970703125)
    vector_math_002.location = (-410.0, -36.568023681640625)
    colorramp_003.location = (44.469482421875, 511.55560302734375)
    colorramp_004.location = (50.0, 743.4320068359375)
    voronoi_texture_004.location = (-270.0001220703125, 796.5679931640625)
    texture_coordinate.location = (-1170.0, -256.5679931640625)
    vector_math_003.location = (-450.45556640625, 287.48699951171875)
    vector_math_004.location = (-450.0, 563.4320068359375)
    combine_xyz.location = (-750.0, 503.4320068359375)
    math.location = (-1130.0, 623.4320068359375)
    math_001.location = (-1130.0, 463.4320068359375)
    mix_003.location = (388.598388671875, 522.4525756835938)
    mix_001.location = (470.0, 223.43197631835938)
    mix_002.location = (650.0, 203.43197631835938)
    voronoi_texture_002.location = (-270.000244140625, 272.43548583984375)
    voronoi_texture_003.location = (-270.0, 523.4320068359375)
    voronoi_texture_001.location = (-270.0, -496.5679931640625)
    wave_texture.location = (190.0, -416.5679626464844)
    vector_math.location = (-950.0, -256.5679931640625)
    wave_texture_001.location = (190.0, -736.5679931640625)
    bump.location = (1009.9998779296875, -616.5679931640625)
    principled_bsdf.location = (1170.0, -116.5679931640625)
    reroute.location = (88.5927734375, -726.7236328125)
    vector_math_001.location = (-447.5467529296875, -465.6806640625)
    vector_math_005.location = (-210.0, -796.5679931640625)
    vector_rotate.location = (-29.18212890625, -744.5394897460938)
    group_output.location = (1460.0, -0.0)
    mix_008.location = (190.0, -236.5679931640625)
    voronoi_texture.location = (-270.0, -216.5679931640625)
    group_input.location = (-1370.0, -0.0)
    bump_001.location = (790.0, -756.5679931640625)
    mix.location = (450.0, 43.432037353515625)
    mix_005.location = (810.0, 203.43203735351562)
    mix_007.location = (454.514892578125, -123.70114135742188)
    mix_006.location = (641.6259765625, -79.77127075195312)
    colorramp_005.location = (820.0000610351562, -160.0)
    mix_004.location = (870.0, 23.432037353515625)
    math_002.location = (458.2771911621094, -476.82598876953125)
    colorramp.location = (716.1847534179688, -373.721435546875)
    
    #Set dimensions
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    voronoi_texture_004.width, voronoi_texture_004.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    vector_math_003.width, vector_math_003.height = 140.0, 100.0
    vector_math_004.width, vector_math_004.height = 140.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    voronoi_texture_002.width, voronoi_texture_002.height = 140.0, 100.0
    voronoi_texture_003.width, voronoi_texture_003.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    vector_math_001.width, vector_math_001.height = 140.0, 100.0
    vector_math_005.width, vector_math_005.height = 140.0, 100.0
    vector_rotate.width, vector_rotate.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_008.width, mix_008.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    mix_007.width, mix_007.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    colorramp_005.width, colorramp_005.height = 240.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    
    #initialize fish_pattern links
    #principled_bsdf.BSDF -> group_output.BSDF
    fish_pattern.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    fish_pattern.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #texture_coordinate.UV -> vector_math.Vector
    fish_pattern.links.new(texture_coordinate.outputs[2], vector_math.inputs[0])
    #vector_math_001.Vector -> voronoi_texture_001.Vector
    fish_pattern.links.new(vector_math_001.outputs[0], voronoi_texture_001.inputs[0])
    #vector_math.Vector -> vector_math_001.Vector
    fish_pattern.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
    #voronoi_texture.Color -> mix_008.A
    fish_pattern.links.new(voronoi_texture.outputs[1], mix_008.inputs[6])
    #colorramp_002.Color -> mix_008.Factor
    fish_pattern.links.new(colorramp_002.outputs[0], mix_008.inputs[0])
    #voronoi_texture_001.Color -> mix_008.B
    fish_pattern.links.new(voronoi_texture_001.outputs[1], mix_008.inputs[7])
    #voronoi_texture_001.Distance -> colorramp_002.Fac
    fish_pattern.links.new(voronoi_texture_001.outputs[0], colorramp_002.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    fish_pattern.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix_008.Result -> mix.Factor
    fish_pattern.links.new(mix_008.outputs[2], mix.inputs[0])
    #mix_008.Result -> bump.Height
    fish_pattern.links.new(mix_008.outputs[2], bump.inputs[2])
    #mix_004.Result -> principled_bsdf.Base Color
    fish_pattern.links.new(mix_004.outputs[2], principled_bsdf.inputs[0])
    #vector_math_002.Vector -> voronoi_texture_002.Vector
    fish_pattern.links.new(vector_math_002.outputs[0], voronoi_texture_002.inputs[0])
    #colorramp_001.Color -> mix_001.B
    fish_pattern.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #voronoi_texture_002.Distance -> colorramp_001.Fac
    fish_pattern.links.new(voronoi_texture_002.outputs[0], colorramp_001.inputs[0])
    #vector_math.Vector -> vector_math_002.Vector
    fish_pattern.links.new(vector_math.outputs[0], vector_math_002.inputs[0])
    #vector_math_003.Vector -> voronoi_texture_003.Vector
    fish_pattern.links.new(vector_math_003.outputs[0], voronoi_texture_003.inputs[0])
    #voronoi_texture_003.Distance -> colorramp_003.Fac
    fish_pattern.links.new(voronoi_texture_003.outputs[0], colorramp_003.inputs[0])
    #mix_001.Result -> mix_002.A
    fish_pattern.links.new(mix_001.outputs[2], mix_002.inputs[6])
    #mix_003.Result -> mix_002.B
    fish_pattern.links.new(mix_003.outputs[2], mix_002.inputs[7])
    #vector_math.Vector -> vector_math_003.Vector
    fish_pattern.links.new(vector_math.outputs[0], vector_math_003.inputs[0])
    #colorramp_003.Color -> mix_003.A
    fish_pattern.links.new(colorramp_003.outputs[0], mix_003.inputs[6])
    #voronoi_texture_004.Distance -> colorramp_004.Fac
    fish_pattern.links.new(voronoi_texture_004.outputs[0], colorramp_004.inputs[0])
    #colorramp_004.Color -> mix_003.B
    fish_pattern.links.new(colorramp_004.outputs[0], mix_003.inputs[7])
    #vector_math.Vector -> vector_math_004.Vector
    fish_pattern.links.new(vector_math.outputs[0], vector_math_004.inputs[0])
    #vector_math_004.Vector -> voronoi_texture_004.Vector
    fish_pattern.links.new(vector_math_004.outputs[0], voronoi_texture_004.inputs[0])
    #combine_xyz.Vector -> vector_math_004.Vector
    fish_pattern.links.new(combine_xyz.outputs[0], vector_math_004.inputs[1])
    #math.Value -> combine_xyz.X
    fish_pattern.links.new(math.outputs[0], combine_xyz.inputs[0])
    #math_001.Value -> combine_xyz.Y
    fish_pattern.links.new(math_001.outputs[0], combine_xyz.inputs[1])
    #mix.Result -> mix_004.B
    fish_pattern.links.new(mix.outputs[2], mix_004.inputs[7])
    #mix_002.Result -> mix_005.A
    fish_pattern.links.new(mix_002.outputs[2], mix_005.inputs[6])
    #mix_005.Result -> mix_004.A
    fish_pattern.links.new(mix_005.outputs[2], mix_004.inputs[6])
    #mix_006.Result -> mix_005.Factor
    fish_pattern.links.new(mix_006.outputs[2], mix_005.inputs[0])
    #mix_007.Result -> mix_006.A
    fish_pattern.links.new(mix_007.outputs[2], mix_006.inputs[6])
    #mix_008.Result -> mix_007.A
    fish_pattern.links.new(mix_008.outputs[2], mix_007.inputs[6])
    #reroute.Output -> wave_texture.Vector
    fish_pattern.links.new(reroute.outputs[0], wave_texture.inputs[0])
    #reroute.Output -> wave_texture_001.Vector
    fish_pattern.links.new(reroute.outputs[0], wave_texture_001.inputs[0])
    #math_002.Value -> colorramp.Fac
    fish_pattern.links.new(math_002.outputs[0], colorramp.inputs[0])
    #wave_texture.Color -> math_002.Value
    fish_pattern.links.new(wave_texture.outputs[0], math_002.inputs[0])
    #wave_texture_001.Color -> math_002.Value
    fish_pattern.links.new(wave_texture_001.outputs[0], math_002.inputs[1])
    #colorramp.Color -> bump_001.Height
    fish_pattern.links.new(colorramp.outputs[0], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    fish_pattern.links.new(bump_001.outputs[0], bump.inputs[3])
    #vector_rotate.Vector -> reroute.Input
    fish_pattern.links.new(vector_rotate.outputs[0], reroute.inputs[0])
    #vector_math.Vector -> vector_math_005.Vector
    fish_pattern.links.new(vector_math.outputs[0], vector_math_005.inputs[0])
    #mix_008.Result -> vector_math_005.Vector
    fish_pattern.links.new(mix_008.outputs[2], vector_math_005.inputs[1])
    #vector_math_005.Vector -> vector_rotate.Vector
    fish_pattern.links.new(vector_math_005.outputs[0], vector_rotate.inputs[0])
    #mix_008.Result -> vector_rotate.Angle
    fish_pattern.links.new(mix_008.outputs[2], vector_rotate.inputs[3])
    #group_input.Color1 -> mix.A
    fish_pattern.links.new(group_input.outputs[0], mix.inputs[6])
    #group_input.Color2 -> mix.B
    fish_pattern.links.new(group_input.outputs[1], mix.inputs[7])
    #group_input.Scale -> vector_math.Scale
    fish_pattern.links.new(group_input.outputs[2], vector_math.inputs[3])
    #group_input.Specular -> principled_bsdf.Specular
    fish_pattern.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    fish_pattern.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Smiley Amount :) -> mix_007.Factor
    fish_pattern.links.new(group_input.outputs[5], mix_007.inputs[0])
    #group_input.Bump1 Strength -> bump.Strength
    fish_pattern.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Bump2 Strength -> bump_001.Strength
    fish_pattern.links.new(group_input.outputs[7], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    fish_pattern.links.new(group_input.outputs[8], bump_001.inputs[3])
    #mix_005.Result -> group_output.Mask1
    fish_pattern.links.new(mix_005.outputs[2], group_output.inputs[1])
    #colorramp_005.Color -> group_output.Mask2
    fish_pattern.links.new(colorramp_005.outputs[0], group_output.inputs[2])
    #mix_006.Result -> colorramp_005.Fac
    fish_pattern.links.new(mix_006.outputs[2], colorramp_005.inputs[0])
    #mix_004.Result -> group_output.Albedo
    fish_pattern.links.new(mix_004.outputs[2], group_output.inputs[4])
    #colorramp.Color -> group_output.Mask3
    fish_pattern.links.new(colorramp.outputs[0], group_output.inputs[3])
    return fish_pattern

fish_pattern = fish_pattern_node_group()

#initialize Fish Pattern node group
def fish_pattern_1_node_group():

    fish_pattern_1 = mat.node_tree
    #start with a clean node tree
    for node in fish_pattern_1.nodes:
        fish_pattern_1.nodes.remove(node)
    #initialize fish_pattern_1 nodes
    #node Material Output
    material_output = fish_pattern_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Fish pattern
    fish_pattern_2 = fish_pattern_1.nodes.new("ShaderNodeGroup")
    fish_pattern_2.label = "Fish pattern"
    fish_pattern_2.name = "Fish pattern"
    fish_pattern_2.node_tree = fish_pattern
    #Input_1
    fish_pattern_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_2
    fish_pattern_2.inputs[1].default_value = (0.017393050715327263, 0.11685982346534729, 0.17331352829933167, 1.0)
    #Input_3
    fish_pattern_2.inputs[2].default_value = 0.20000000298023224
    #Input_4
    fish_pattern_2.inputs[3].default_value = 0.5
    #Input_5
    fish_pattern_2.inputs[4].default_value = 1.0
    #Input_6
    fish_pattern_2.inputs[5].default_value = 0.1083332896232605
    #Input_7
    fish_pattern_2.inputs[6].default_value = 1.0
    #Input_8
    fish_pattern_2.inputs[7].default_value = 0.30000001192092896
    #Input_9
    fish_pattern_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (620.0, 100.0)
    fish_pattern_2.location = (380.0, 120.0)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    fish_pattern_2.width, fish_pattern_2.height = 184.142333984375, 100.0
    
    #initialize fish_pattern_1 links
    #fish_pattern_2.BSDF -> material_output.Surface
    fish_pattern_1.links.new(fish_pattern_2.outputs[0], material_output.inputs[0])
    return fish_pattern_1

fish_pattern_1 = fish_pattern_1_node_group()

