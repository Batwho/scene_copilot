import bpy, mathutils

mat = bpy.data.materials.new(name = "Sand")
mat.use_nodes = True
#initialize Sand node group
def sand_node_group():

    sand = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Sand")
    
    #initialize sand nodes
    #node Group Output
    group_output = sand.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #sand outputs
    #output BSDF
    sand.outputs.new('NodeSocketShader', "BSDF")
    sand.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    sand.outputs.new('NodeSocketColor', "Albedo")
    sand.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    sand.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    sand.outputs.new('NodeSocketColor', "Mask")
    sand.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    sand.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node ColorRamp
    colorramp = sand.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.2499999850988388
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5045459270477295)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.30662801861763, 0.07996957749128342, 0.025615572929382324, 1.0)

    
    #node Wave Texture.001
    wave_texture_001 = sand.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'X'
    wave_texture_001.rings_direction = 'X'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Scale
    wave_texture_001.inputs[1].default_value = 1.5
    #Distortion
    wave_texture_001.inputs[2].default_value = 4.119999885559082
    #Detail
    wave_texture_001.inputs[3].default_value = 1.2999999523162842
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 1.0299999713897705
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    
    #node Texture Coordinate.001
    texture_coordinate_001 = sand.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math.018
    vector_math_018 = sand.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Hue Saturation Value
    hue_saturation_value = sand.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Math
    math = sand.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Invert
    invert = sand.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Bump.001
    bump_001 = sand.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = sand.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.20000000298023224
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = sand.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #sand inputs
    #input Scale
    sand.inputs.new('NodeSocketFloat', "Scale")
    sand.inputs[0].default_value = 1.0
    sand.inputs[0].min_value = -10000.0
    sand.inputs[0].max_value = 10000.0
    sand.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    sand.inputs.new('NodeSocketFloatFactor', "Color Hue")
    sand.inputs[1].default_value = 1.0
    sand.inputs[1].min_value = 0.0
    sand.inputs[1].max_value = 1.0
    sand.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    sand.inputs.new('NodeSocketFloatFactor', "Roughness")
    sand.inputs[2].default_value = 0.6454545259475708
    sand.inputs[2].min_value = 0.0
    sand.inputs[2].max_value = 1.0
    sand.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    sand.inputs.new('NodeSocketFloat', "Saturation")
    sand.inputs[3].default_value = 1.0
    sand.inputs[3].min_value = 0.0
    sand.inputs[3].max_value = 2.0
    sand.inputs[3].attribute_domain = 'POINT'
    
    #input Brightness
    sand.inputs.new('NodeSocketFloat', "Brightness")
    sand.inputs[4].default_value = 1.0
    sand.inputs[4].min_value = 0.0
    sand.inputs[4].max_value = 2.0
    sand.inputs[4].attribute_domain = 'POINT'
    
    #input Phase Offset
    sand.inputs.new('NodeSocketFloat', "Phase Offset")
    sand.inputs[5].default_value = 3.9200000762939453
    sand.inputs[5].min_value = -1000.0
    sand.inputs[5].max_value = 1000.0
    sand.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    sand.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    sand.inputs[6].default_value = 1.0
    sand.inputs[6].min_value = 0.0
    sand.inputs[6].max_value = 1.0
    sand.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    sand.inputs.new('NodeSocketVector', "Normal")
    sand.inputs[7].default_value = (0.0, 0.0, 0.0)
    sand.inputs[7].min_value = -1.0
    sand.inputs[7].max_value = 1.0
    sand.inputs[7].attribute_domain = 'POINT'
    sand.inputs[7].hide_value = True
    
    
    
    #node Wave Texture
    wave_texture = sand.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 1.5
    #Distortion
    wave_texture.inputs[2].default_value = 1.8799999952316284
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    
    #node Bump
    bump = sand.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Map Range
    map_range = sand.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = 0.0
    #From Max
    map_range.inputs[2].default_value = 1.0
    #To Min
    map_range.inputs[3].default_value = 0.0
    #To Max
    map_range.inputs[4].default_value = 1.0699999332427979
    
    #node Noise Texture
    noise_texture = sand.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 3.6199986934661865
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 1.0
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix
    mix = sand.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Mix.002
    mix_002 = sand.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    
    #node Mix.001
    mix_001 = sand.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.0
    #B_Color
    mix_001.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    
    
    #Set locations
    group_output.location = (1105.4847412109375, -0.0)
    colorramp.location = (200.0, 200.00006103515625)
    wave_texture_001.location = (-500.0, 80.0)
    texture_coordinate_001.location = (-1120.0, -80.0)
    vector_math_018.location = (-780.0, 0.0)
    hue_saturation_value.location = (480.0, 240.0)
    math.location = (80.0, 379.99993896484375)
    invert.location = (-211.44140625, 354.01800537109375)
    bump_001.location = (20.0, -280.0)
    principled_bsdf.location = (815.4847412109375, 250.0)
    group_input.location = (-1320.0, -40.0)
    wave_texture.location = (-306.4271240234375, 95.468994140625)
    bump.location = (600.0, -180.0)
    map_range.location = (200.00006103515625, -20.0)
    noise_texture.location = (-320.0, -239.99996948242188)
    mix.location = (-100.0, 100.0)
    mix_002.location = (280.0, -300.0)
    mix_001.location = (660.0, 240.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    math.width, math.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    
    #initialize sand links
    #principled_bsdf.BSDF -> group_output.BSDF
    sand.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #map_range.Result -> bump.Height
    sand.links.new(map_range.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    sand.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #wave_texture.Color -> mix.A
    sand.links.new(wave_texture.outputs[0], mix.inputs[6])
    #wave_texture_001.Color -> mix.B
    sand.links.new(wave_texture_001.outputs[0], mix.inputs[7])
    #mix.Result -> map_range.Value
    sand.links.new(mix.outputs[2], map_range.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    sand.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> hue_saturation_value.Color
    sand.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #noise_texture.Fac -> bump_001.Height
    sand.links.new(noise_texture.outputs[0], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    sand.links.new(bump_001.outputs[0], bump.inputs[3])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    sand.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> wave_texture_001.Vector
    sand.links.new(vector_math_018.outputs[0], wave_texture_001.inputs[0])
    #vector_math_018.Vector -> wave_texture.Vector
    sand.links.new(vector_math_018.outputs[0], wave_texture.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    sand.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    sand.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #hue_saturation_value.Color -> mix_001.A
    sand.links.new(hue_saturation_value.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> principled_bsdf.Base Color
    sand.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #mix_001.Result -> principled_bsdf.Subsurface Color
    sand.links.new(mix_001.outputs[2], principled_bsdf.inputs[3])
    #group_input.Color Hue -> invert.Fac
    sand.links.new(group_input.outputs[1], invert.inputs[0])
    #invert.Color -> math.Value
    sand.links.new(invert.outputs[0], math.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    sand.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Phase Offset -> wave_texture_001.Phase Offset
    sand.links.new(group_input.outputs[5], wave_texture_001.inputs[6])
    #group_input.Phase Offset -> wave_texture.Phase Offset
    sand.links.new(group_input.outputs[5], wave_texture.inputs[6])
    #group_input.Bump Strength -> bump.Strength
    sand.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Bump Strength -> bump_001.Strength
    sand.links.new(group_input.outputs[6], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    sand.links.new(group_input.outputs[7], bump_001.inputs[3])
    #group_input.Saturation -> hue_saturation_value.Saturation
    sand.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    sand.links.new(group_input.outputs[4], hue_saturation_value.inputs[2])
    #group_input.Roughness -> principled_bsdf.Roughness
    sand.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #mix.Result -> mix_002.A
    sand.links.new(mix.outputs[2], mix_002.inputs[6])
    #noise_texture.Fac -> mix_002.B
    sand.links.new(noise_texture.outputs[0], mix_002.inputs[7])
    #mix_002.Result -> group_output.Mask
    sand.links.new(mix_002.outputs[2], group_output.inputs[2])
    #mix_001.Result -> group_output.Albedo
    sand.links.new(mix_001.outputs[2], group_output.inputs[1])
    return sand

sand = sand_node_group()

#initialize Sand node group
def sand_1_node_group():

    sand_1 = mat.node_tree
    #start with a clean node tree
    for node in sand_1.nodes:
        sand_1.nodes.remove(node)
    #initialize sand_1 nodes
    #node Material Output
    material_output = sand_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Sand
    sand_2 = sand_1.nodes.new("ShaderNodeGroup")
    sand_2.label = "Sand"
    sand_2.name = "Sand"
    sand_2.node_tree = sand
    #Input_1
    sand_2.inputs[0].default_value = 1.0
    #Input_2
    sand_2.inputs[1].default_value = 0.0
    #Input_16
    sand_2.inputs[2].default_value = 0.6454545259475708
    #Input_14
    sand_2.inputs[3].default_value = 1.0199999809265137
    #Input_15
    sand_2.inputs[4].default_value = 1.0
    #Input_3
    sand_2.inputs[5].default_value = 0.0
    #Input_12
    sand_2.inputs[6].default_value = 1.0
    #Input_13
    sand_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (651.732421875, 112.064697265625)
    sand_2.location = (380.7626953125, 112.064697265625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    sand_2.width, sand_2.height = 164.08395385742188, 100.0
    
    #initialize sand_1 links
    #sand_2.BSDF -> material_output.Surface
    sand_1.links.new(sand_2.outputs[0], material_output.inputs[0])
    return sand_1

sand_1 = sand_1_node_group()

