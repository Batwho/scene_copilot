import bpy, mathutils

mat = bpy.data.materials.new(name = "Road")
mat.use_nodes = True
#initialize Road node group
def road_node_group():

    road = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Road")
    
    #initialize road nodes
    #node Noise Texture
    noise_texture = road.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Scale
    noise_texture.inputs[2].default_value = 100.0
    #Detail
    noise_texture.inputs[3].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node ColorRamp.001
    colorramp_001 = road.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.699999988079071, 0.699999988079071, 0.699999988079071, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = road.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.011250304989516735
    
    #node ColorRamp.002
    colorramp_002 = road.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.12300097197294235, 0.12300097197294235, 0.12300097197294235, 1.0)

    
    #node Noise Texture.001
    noise_texture_001 = road.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 5.0
    #Detail
    noise_texture_001.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.9583333134651184
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node ColorRamp.003
    colorramp_003 = road.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.381818026304245
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.6954548358917236)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.004
    mix_004 = road.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MIX'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #B_Color
    mix_004.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node ColorRamp
    colorramp = road.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.4045453667640686
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Mix.001
    mix_001 = road.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'ADD'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    
    #node Bump
    bump = road.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = road.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.003
    mix_003 = road.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'ADD'
    mix_003.clamp_factor = True
    mix_003.clamp_result = True
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    
    #node Texture Coordinate.001
    texture_coordinate_001 = road.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = road.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #road outputs
    #output BSDF
    road.outputs.new('NodeSocketShader', "BSDF")
    road.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    road.outputs.new('NodeSocketColor', "Mask")
    road.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    road.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Vector Math.018
    vector_math_018 = road.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Mix.002
    mix_002 = road.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'ADD'
    mix_002.clamp_factor = True
    mix_002.clamp_result = True
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    
    #node Invert
    invert = road.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.006
    mix_006 = road.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'MULTIPLY'
    mix_006.clamp_factor = True
    mix_006.clamp_result = True
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    #B_Color
    mix_006.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node ColorRamp.004
    colorramp_004 = road.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.0
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(1.0)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (0.4000000059604645, 0.4000000059604645, 0.4000000059604645, 1.0)

    
    #node Group Input
    group_input = road.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #road inputs
    #input Base Color
    road.inputs.new('NodeSocketColor', "Base Color")
    road.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    road.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    road.inputs.new('NodeSocketFloat', "Scale")
    road.inputs[1].default_value = 1.0
    road.inputs[1].min_value = -10000.0
    road.inputs[1].max_value = 10000.0
    road.inputs[1].attribute_domain = 'POINT'
    
    #input Tire Stripes Scale
    road.inputs.new('NodeSocketFloat', "Tire Stripes Scale")
    road.inputs[2].default_value = 1.0
    road.inputs[2].min_value = -1000.0
    road.inputs[2].max_value = 1000.0
    road.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    road.inputs.new('NodeSocketFloatFactor', "Roughness")
    road.inputs[3].default_value = 1.0
    road.inputs[3].min_value = 0.0
    road.inputs[3].max_value = 1.0
    road.inputs[3].attribute_domain = 'POINT'
    
    #input Bump Strength
    road.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    road.inputs[4].default_value = 1.0
    road.inputs[4].min_value = 0.0
    road.inputs[4].max_value = 1.0
    road.inputs[4].attribute_domain = 'POINT'
    
    #input Normal
    road.inputs.new('NodeSocketVector', "Normal")
    road.inputs[5].default_value = (0.0, 0.0, 0.0)
    road.inputs[5].min_value = -1.0
    road.inputs[5].max_value = 1.0
    road.inputs[5].attribute_domain = 'POINT'
    road.inputs[5].hide_value = True
    
    
    
    #node Wave Texture
    wave_texture = road.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Distortion
    wave_texture.inputs[2].default_value = 3.5
    #Detail
    wave_texture.inputs[3].default_value = 6.599999904632568
    #Detail Scale
    wave_texture.inputs[4].default_value = 7.399999618530273
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.607692301273346
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = road.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 200.0
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Mix.005
    mix_005 = road.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'ADD'
    mix_005.clamp_factor = True
    mix_005.clamp_result = True
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_005.inputs[0].default_value = 1.0
    
    #node Mix.007
    mix_007 = road.nodes.new("ShaderNodeMix")
    mix_007.name = "Mix.007"
    mix_007.blend_type = 'ADD'
    mix_007.clamp_factor = True
    mix_007.clamp_result = True
    mix_007.data_type = 'RGBA'
    mix_007.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_007.inputs[0].default_value = 1.0
    
    
    #Set locations
    noise_texture.location = (-682.6047973632812, -228.0111083984375)
    colorramp_001.location = (437.3951416015625, 151.98892211914062)
    mix.location = (-482.6048583984375, 31.988876342773438)
    colorramp_002.location = (-22.6048583984375, -299.7735595703125)
    noise_texture_001.location = (-562.6048583984375, 291.9888916015625)
    colorramp_003.location = (-342.60491943359375, 251.9888916015625)
    mix_004.location = (-2.6048583984375, -82.21394348144531)
    colorramp.location = (217.39512634277344, -68.01112365722656)
    mix_001.location = (537.3951416015625, -192.896240234375)
    bump.location = (757.3951416015625, -188.0111083984375)
    principled_bsdf.location = (1150.0, 299.7735595703125)
    mix_003.location = (254.36077880859375, 117.12691497802734)
    texture_coordinate_001.location = (-1150.0, 139.7735595703125)
    group_output.location = (1440.0, -0.0)
    vector_math_018.location = (-810.0, 219.77359008789062)
    mix_002.location = (834.090576171875, 31.06896209716797)
    invert.location = (100.0001220703125, 380.0)
    mix_006.location = (1000.0000610351562, 40.0)
    colorramp_004.location = (720.0, 260.0)
    group_input.location = (-1350.0, -0.0)
    wave_texture.location = (-262.6048583984375, -248.0111083984375)
    voronoi_texture.location = (-242.6048583984375, 11.988876342773438)
    mix_005.location = (59.4617919921875, 211.43304443359375)
    mix_007.location = (319.69122314453125, 278.037353515625)
    
    #Set dimensions
    noise_texture.width, noise_texture.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    mix_007.width, mix_007.height = 140.0, 100.0
    
    #initialize road links
    #principled_bsdf.BSDF -> group_output.BSDF
    road.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    road.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> voronoi_texture.Vector
    road.links.new(mix.outputs[2], voronoi_texture.inputs[0])
    #noise_texture.Color -> mix.B
    road.links.new(noise_texture.outputs[1], mix.inputs[7])
    #mix_001.Result -> bump.Height
    road.links.new(mix_001.outputs[2], bump.inputs[2])
    #mix_002.Result -> mix_006.A
    road.links.new(mix_002.outputs[2], mix_006.inputs[6])
    #mix_003.Result -> colorramp_001.Fac
    road.links.new(mix_003.outputs[2], colorramp_001.inputs[0])
    #colorramp.Color -> mix_001.A
    road.links.new(colorramp.outputs[0], mix_001.inputs[6])
    #colorramp_002.Color -> mix_001.B
    road.links.new(colorramp_002.outputs[0], mix_001.inputs[7])
    #wave_texture.Color -> colorramp_002.Fac
    road.links.new(wave_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_001.Color -> mix_002.A
    road.links.new(colorramp_001.outputs[0], mix_002.inputs[6])
    #colorramp_002.Color -> mix_002.B
    road.links.new(colorramp_002.outputs[0], mix_002.inputs[7])
    #voronoi_texture.Color -> mix_003.A
    road.links.new(voronoi_texture.outputs[1], mix_003.inputs[6])
    #noise_texture_001.Fac -> colorramp_003.Fac
    road.links.new(noise_texture_001.outputs[0], colorramp_003.inputs[0])
    #mix_004.Result -> colorramp.Fac
    road.links.new(mix_004.outputs[2], colorramp.inputs[0])
    #voronoi_texture.Distance -> mix_004.A
    road.links.new(voronoi_texture.outputs[0], mix_004.inputs[6])
    #colorramp_003.Color -> mix_004.Factor
    road.links.new(colorramp_003.outputs[0], mix_004.inputs[0])
    #colorramp_003.Color -> mix_005.B
    road.links.new(colorramp_003.outputs[0], mix_005.inputs[7])
    #voronoi_texture.Distance -> mix_005.A
    road.links.new(voronoi_texture.outputs[0], mix_005.inputs[6])
    #colorramp_003.Color -> mix_003.B
    road.links.new(colorramp_003.outputs[0], mix_003.inputs[7])
    #mix_005.Result -> colorramp_004.Fac
    road.links.new(mix_005.outputs[2], colorramp_004.inputs[0])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    road.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> noise_texture_001.Vector
    road.links.new(vector_math_018.outputs[0], noise_texture_001.inputs[0])
    #vector_math_018.Vector -> mix.A
    road.links.new(vector_math_018.outputs[0], mix.inputs[6])
    #vector_math_018.Vector -> wave_texture.Vector
    road.links.new(vector_math_018.outputs[0], wave_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    road.links.new(group_input.outputs[1], vector_math_018.inputs[3])
    #colorramp_004.Color -> principled_bsdf.Specular
    road.links.new(colorramp_004.outputs[0], principled_bsdf.inputs[7])
    #mix_006.Result -> principled_bsdf.Roughness
    road.links.new(mix_006.outputs[2], principled_bsdf.inputs[9])
    #group_input.Roughness -> invert.Fac
    road.links.new(group_input.outputs[3], invert.inputs[0])
    #invert.Color -> mix_006.Factor
    road.links.new(invert.outputs[0], mix_006.inputs[0])
    #group_input.Base Color -> principled_bsdf.Base Color
    road.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Bump Strength -> bump.Strength
    road.links.new(group_input.outputs[4], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    road.links.new(group_input.outputs[5], bump.inputs[3])
    #group_input.Tire Stripes Scale -> wave_texture.Scale
    road.links.new(group_input.outputs[2], wave_texture.inputs[1])
    #mix_005.Result -> mix_007.A
    road.links.new(mix_005.outputs[2], mix_007.inputs[6])
    #wave_texture.Color -> mix_007.B
    road.links.new(wave_texture.outputs[0], mix_007.inputs[7])
    #mix_007.Result -> group_output.Mask
    road.links.new(mix_007.outputs[2], group_output.inputs[1])
    return road

road = road_node_group()

#initialize Road node group
def road_1_node_group():

    road_1 = mat.node_tree
    #start with a clean node tree
    for node in road_1.nodes:
        road_1.nodes.remove(node)
    #initialize road_1 nodes
    #node Material Output
    material_output = road_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Road
    road_2 = road_1.nodes.new("ShaderNodeGroup")
    road_2.label = "Road"
    road_2.name = "Road"
    road_2.node_tree = road
    #Input_4
    road_2.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_1
    road_2.inputs[1].default_value = 1.0
    #Input_7
    road_2.inputs[2].default_value = 1.0
    #Input_3
    road_2.inputs[3].default_value = 1.0
    #Input_5
    road_2.inputs[4].default_value = 1.0
    #Input_6
    road_2.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (683.34521484375, 67.440673828125)
    road_2.location = (409.02880859375, 72.064697265625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    road_2.width, road_2.height = 174.1962890625, 100.0
    
    #initialize road_1 links
    #road_2.BSDF -> material_output.Surface
    road_1.links.new(road_2.outputs[0], material_output.inputs[0])
    return road_1

road_1 = road_1_node_group()

