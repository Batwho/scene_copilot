import bpy, mathutils

mat = bpy.data.materials.new(name = "Stylized1")
mat.use_nodes = True
#initialize Scifi_Rings node group
def scifi_rings_node_group():

    scifi_rings = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Scifi_Rings")
    
    #initialize scifi_rings nodes
    #node Bump
    bump = scifi_rings.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Bump.001
    bump_001 = scifi_rings.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Vector Math
    vector_math = scifi_rings.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = scifi_rings.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = scifi_rings.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #scifi_rings outputs
    #output BSDF
    scifi_rings.outputs.new('NodeSocketShader', "BSDF")
    scifi_rings.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    scifi_rings.outputs.new('NodeSocketColor', "Albedo")
    scifi_rings.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    scifi_rings.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    scifi_rings.outputs.new('NodeSocketColor', "Mask")
    scifi_rings.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    scifi_rings.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node ColorRamp
    colorramp = scifi_rings.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.5181818604469299
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.014258396811783314, 0.0008301589405164123, 0.03124697506427765, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.7954546809196472)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.9002040028572083, 0.6463212966918945, 1.0, 1.0)

    
    #node Hue Saturation Value
    hue_saturation_value = scifi_rings.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = scifi_rings.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = scifi_rings.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Principled BSDF
    principled_bsdf = scifi_rings.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.4070702791213989, 0.06148352846503258, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = scifi_rings.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #scifi_rings inputs
    #input Scale
    scifi_rings.inputs.new('NodeSocketFloat', "Scale")
    scifi_rings.inputs[0].default_value = 1.0
    scifi_rings.inputs[0].min_value = -10000.0
    scifi_rings.inputs[0].max_value = 10000.0
    scifi_rings.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    scifi_rings.inputs.new('NodeSocketFloatFactor', "Color Hue")
    scifi_rings.inputs[1].default_value = 1.0
    scifi_rings.inputs[1].min_value = 0.0
    scifi_rings.inputs[1].max_value = 1.0
    scifi_rings.inputs[1].attribute_domain = 'POINT'
    
    #input Subsurface
    scifi_rings.inputs.new('NodeSocketFloatFactor', "Subsurface")
    scifi_rings.inputs[2].default_value = 0.22272729873657227
    scifi_rings.inputs[2].min_value = 0.0
    scifi_rings.inputs[2].max_value = 1.0
    scifi_rings.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    scifi_rings.inputs.new('NodeSocketFloat', "Saturation")
    scifi_rings.inputs[3].default_value = 1.0
    scifi_rings.inputs[3].min_value = 0.0
    scifi_rings.inputs[3].max_value = 2.0
    scifi_rings.inputs[3].attribute_domain = 'POINT'
    
    #input Specular
    scifi_rings.inputs.new('NodeSocketFloatFactor', "Specular")
    scifi_rings.inputs[4].default_value = 0.054545462131500244
    scifi_rings.inputs[4].min_value = 0.0
    scifi_rings.inputs[4].max_value = 1.0
    scifi_rings.inputs[4].attribute_domain = 'POINT'
    
    #input Roughness
    scifi_rings.inputs.new('NodeSocketFloatFactor', "Roughness")
    scifi_rings.inputs[5].default_value = 0.30000001192092896
    scifi_rings.inputs[5].min_value = 0.0
    scifi_rings.inputs[5].max_value = 1.0
    scifi_rings.inputs[5].attribute_domain = 'POINT'
    
    #input Detail
    scifi_rings.inputs.new('NodeSocketFloat', "Detail")
    scifi_rings.inputs[6].default_value = 15.0
    scifi_rings.inputs[6].min_value = 0.0
    scifi_rings.inputs[6].max_value = 15.0
    scifi_rings.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    scifi_rings.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    scifi_rings.inputs[7].default_value = 0.5
    scifi_rings.inputs[7].min_value = 0.0
    scifi_rings.inputs[7].max_value = 1.0
    scifi_rings.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    scifi_rings.inputs.new('NodeSocketVector', "Normal")
    scifi_rings.inputs[8].default_value = (0.0, 0.0, 0.0)
    scifi_rings.inputs[8].min_value = -1.0
    scifi_rings.inputs[8].max_value = 1.0
    scifi_rings.inputs[8].attribute_domain = 'POINT'
    scifi_rings.inputs[8].hide_value = True
    
    
    
    #node Noise Texture
    noise_texture = scifi_rings.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 2.5
    #Detail
    noise_texture.inputs[3].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Wave Texture
    wave_texture = scifi_rings.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 2.5
    #Distortion
    wave_texture.inputs[2].default_value = 10.630000114440918
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Mix
    mix = scifi_rings.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    
    #Set locations
    bump.location = (466.173583984375, -161.57809448242188)
    bump_001.location = (267.3341064453125, -281.5780944824219)
    vector_math.location = (-372.6658935546875, 118.42190551757812)
    texture_coordinate_001.location = (-712.6658935546875, 38.421905517578125)
    group_output.location = (1015.2718505859375, -1.578094482421875)
    colorramp.location = (220.0, 200.0)
    hue_saturation_value.location = (500.00006103515625, 200.00001525878906)
    invert.location = (-40.0, 300.0)
    math.location = (220.0, 380.0)
    principled_bsdf.location = (725.27197265625, 278.4219055175781)
    group_input.location = (-912.6658935546875, -1.578094482421875)
    noise_texture.location = (27.3341064453125, 38.421905517578125)
    wave_texture.location = (47.3341064453125, -201.57809448242188)
    mix.location = (500.0000915527344, -351.0898742675781)
    
    #Set dimensions
    bump.width, bump.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    
    #initialize scifi_rings links
    #principled_bsdf.BSDF -> group_output.BSDF
    scifi_rings.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    scifi_rings.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    scifi_rings.links.new(noise_texture.outputs[0], bump.inputs[2])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    scifi_rings.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #wave_texture.Color -> bump_001.Height
    scifi_rings.links.new(wave_texture.outputs[0], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    scifi_rings.links.new(bump_001.outputs[0], bump.inputs[3])
    #wave_texture.Color -> colorramp.Fac
    scifi_rings.links.new(wave_texture.outputs[0], colorramp.inputs[0])
    #texture_coordinate_001.Object -> vector_math.Vector
    scifi_rings.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    scifi_rings.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #vector_math.Vector -> wave_texture.Vector
    scifi_rings.links.new(vector_math.outputs[0], wave_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    scifi_rings.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> hue_saturation_value.Color
    scifi_rings.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #hue_saturation_value.Color -> principled_bsdf.Subsurface Color
    scifi_rings.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[3])
    #group_input.Color Hue -> invert.Fac
    scifi_rings.links.new(group_input.outputs[1], invert.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    scifi_rings.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math.Value
    scifi_rings.links.new(invert.outputs[0], math.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    scifi_rings.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Specular -> principled_bsdf.Specular
    scifi_rings.links.new(group_input.outputs[4], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    scifi_rings.links.new(group_input.outputs[5], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    scifi_rings.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Bump Strength -> bump_001.Strength
    scifi_rings.links.new(group_input.outputs[7], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    scifi_rings.links.new(group_input.outputs[8], bump_001.inputs[3])
    #group_input.Detail -> wave_texture.Detail
    scifi_rings.links.new(group_input.outputs[6], wave_texture.inputs[3])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    scifi_rings.links.new(group_input.outputs[2], principled_bsdf.inputs[1])
    #noise_texture.Fac -> mix.A
    scifi_rings.links.new(noise_texture.outputs[0], mix.inputs[6])
    #wave_texture.Color -> mix.B
    scifi_rings.links.new(wave_texture.outputs[0], mix.inputs[7])
    #mix.Result -> group_output.Mask
    scifi_rings.links.new(mix.outputs[2], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    scifi_rings.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return scifi_rings

scifi_rings = scifi_rings_node_group()

#initialize Stylized1 node group
def stylized1_node_group():

    stylized1 = mat.node_tree
    #start with a clean node tree
    for node in stylized1.nodes:
        stylized1.nodes.remove(node)
    #initialize stylized1 nodes
    #node Material Output
    material_output = stylized1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Scifi_Rings
    scifi_rings_1 = stylized1.nodes.new("ShaderNodeGroup")
    scifi_rings_1.label = "Scifi_Rings"
    scifi_rings_1.name = "Scifi_Rings"
    scifi_rings_1.node_tree = scifi_rings
    #Input_1
    scifi_rings_1.inputs[0].default_value = 1.0
    #Input_2
    scifi_rings_1.inputs[1].default_value = 0.0
    #Input_9
    scifi_rings_1.inputs[2].default_value = 0.22272729873657227
    #Input_3
    scifi_rings_1.inputs[3].default_value = 1.0
    #Input_4
    scifi_rings_1.inputs[4].default_value = 0.10000000149011612
    #Input_5
    scifi_rings_1.inputs[5].default_value = 0.30000001192092896
    #Input_8
    scifi_rings_1.inputs[6].default_value = 15.0
    #Input_6
    scifi_rings_1.inputs[7].default_value = 0.5
    #Input_7
    scifi_rings_1.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (691.57861328125, 70.4775390625)
    scifi_rings_1.location = (407.75830078125, 70.4775390625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    scifi_rings_1.width, scifi_rings_1.height = 186.243408203125, 100.0
    
    #initialize stylized1 links
    #scifi_rings_1.BSDF -> material_output.Surface
    stylized1.links.new(scifi_rings_1.outputs[0], material_output.inputs[0])
    return stylized1

stylized1 = stylized1_node_group()

