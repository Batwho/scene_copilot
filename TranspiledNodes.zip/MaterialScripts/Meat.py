import bpy, mathutils

mat = bpy.data.materials.new(name = "Meat")
mat.use_nodes = True
#initialize Meat node group
def meat_node_group():

    meat = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Meat")
    
    #initialize meat nodes
    #node ColorRamp.001
    colorramp_001 = meat.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.07272717356681824)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.06101306527853012, 0.06101306527853012, 0.06101306527853012, 1.0)

    
    #node Add Shader
    add_shader = meat.nodes.new("ShaderNodeAddShader")
    add_shader.name = "Add Shader"
    
    #node Translucent BSDF
    translucent_bsdf = meat.nodes.new("ShaderNodeBsdfTranslucent")
    translucent_bsdf.name = "Translucent BSDF"
    #Normal
    translucent_bsdf.inputs[1].default_value = (0.0, 0.0, 0.0)
    
    #node Mix
    mix = meat.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.2858337461948395
    
    #node ColorRamp.002
    colorramp_002 = meat.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.040909137576818466)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Noise Texture.002
    noise_texture_002 = meat.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #Scale
    noise_texture_002.inputs[2].default_value = 6.5
    #Detail
    noise_texture_002.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.7666666507720947
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node ColorRamp.003
    colorramp_003 = meat.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.0
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.7818179726600647)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.004
    colorramp_004 = meat.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.0181818176060915
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(0.03636369854211807)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp
    colorramp = meat.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.004545449744910002
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 0.26323673129081726, 0.1836584508419037, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.8772728443145752)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.13494983315467834, 0.010399426333606243, 0.004898522514849901, 1.0)

    
    #node Voronoi Texture
    voronoi_texture = meat.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 3.0
    #Randomness
    voronoi_texture.inputs[5].default_value = 0.44999998807907104
    
    #node Principled BSDF
    principled_bsdf = meat.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.009999999776482582
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 1.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = meat.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math
    vector_math = meat.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Group Output
    group_output = meat.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #meat outputs
    #output Shader
    meat.outputs.new('NodeSocketShader', "Shader")
    meat.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    meat.outputs.new('NodeSocketColor', "Albedo")
    meat.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    meat.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    meat.outputs.new('NodeSocketColor', "Mask")
    meat.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    meat.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Math
    math = meat.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Voronoi Texture.001
    voronoi_texture_001 = meat.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'EUCLIDEAN'
    voronoi_texture_001.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 1.0
    
    #node Noise Texture
    noise_texture = meat.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 1.7000000476837158
    #Detail
    noise_texture.inputs[3].default_value = 5.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Hue Saturation Value
    hue_saturation_value = meat.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Mix.003
    mix_003 = meat.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MULTIPLY'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #B_Color
    mix_003.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Invert
    invert = meat.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Invert.001
    invert_001 = meat.nodes.new("ShaderNodeInvert")
    invert_001.name = "Invert.001"
    #Fac
    invert_001.inputs[0].default_value = 1.0
    
    #node Map Range
    map_range = meat.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = 0.0
    #From Max
    map_range.inputs[2].default_value = 0.30999982357025146
    #To Min
    map_range.inputs[3].default_value = 0.009999999776482582
    #To Max
    map_range.inputs[4].default_value = 0.10000023245811462
    
    #node Bump
    bump = meat.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 0.05000000074505806
    
    #node Bump.001
    bump_001 = meat.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = True
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Math.001
    math_001 = meat.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    
    #node Group Input
    group_input = meat.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #meat inputs
    #input Color hue
    meat.inputs.new('NodeSocketFloatFactor', "Color hue")
    meat.inputs[0].default_value = 1.0
    meat.inputs[0].min_value = 0.0
    meat.inputs[0].max_value = 1.0
    meat.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    meat.inputs.new('NodeSocketFloat', "Scale")
    meat.inputs[1].default_value = 1.0
    meat.inputs[1].min_value = -10000.0
    meat.inputs[1].max_value = 10000.0
    meat.inputs[1].attribute_domain = 'POINT'
    
    #input Subsurface
    meat.inputs.new('NodeSocketFloatFactor', "Subsurface")
    meat.inputs[2].default_value = 0.699999988079071
    meat.inputs[2].min_value = 0.0
    meat.inputs[2].max_value = 1.0
    meat.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    meat.inputs.new('NodeSocketFloatFactor', "Roughness")
    meat.inputs[3].default_value = 0.0
    meat.inputs[3].min_value = 0.0
    meat.inputs[3].max_value = 1.0
    meat.inputs[3].attribute_domain = 'POINT'
    
    #input Inner Texture Scale
    meat.inputs.new('NodeSocketFloat', "Inner Texture Scale")
    meat.inputs[4].default_value = 11.339999198913574
    meat.inputs[4].min_value = -1000.0
    meat.inputs[4].max_value = 1000.0
    meat.inputs[4].attribute_domain = 'POINT'
    
    #input Inner Texture Strength
    meat.inputs.new('NodeSocketFloatFactor', "Inner Texture Strength")
    meat.inputs[5].default_value = 1.0
    meat.inputs[5].min_value = 0.0
    meat.inputs[5].max_value = 1.0
    meat.inputs[5].attribute_domain = 'POINT'
    
    #input Saturation
    meat.inputs.new('NodeSocketFloat', "Saturation")
    meat.inputs[6].default_value = 1.0
    meat.inputs[6].min_value = 0.0
    meat.inputs[6].max_value = 2.0
    meat.inputs[6].attribute_domain = 'POINT'
    
    #input Translucency
    meat.inputs.new('NodeSocketFloatFactor', "Translucency")
    meat.inputs[7].default_value = 0.800000011920929
    meat.inputs[7].min_value = 0.0
    meat.inputs[7].max_value = 1.0
    meat.inputs[7].attribute_domain = 'POINT'
    
    #input Bump Strength
    meat.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    meat.inputs[8].default_value = 1.0
    meat.inputs[8].min_value = 0.0
    meat.inputs[8].max_value = 1.0
    meat.inputs[8].attribute_domain = 'POINT'
    
    #input Normal
    meat.inputs.new('NodeSocketVector', "Normal")
    meat.inputs[9].default_value = (0.0, 0.0, 0.0)
    meat.inputs[9].min_value = -1.0
    meat.inputs[9].max_value = 1.0
    meat.inputs[9].attribute_domain = 'POINT'
    meat.inputs[9].hide_value = True
    
    
    
    #node Mix Shader
    mix_shader = meat.nodes.new("ShaderNodeMixShader")
    mix_shader.name = "Mix Shader"
    
    #node Mix.002
    mix_002 = meat.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #B_Color
    mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.001
    mix_001 = meat.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Noise Texture.001
    noise_texture_001 = meat.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 22.0
    #Detail
    noise_texture_001.inputs[3].default_value = 8.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.5
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Voronoi Texture.002
    voronoi_texture_002 = meat.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_002.name = "Voronoi Texture.002"
    voronoi_texture_002.distance = 'EUCLIDEAN'
    voronoi_texture_002.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture_002.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture_002.inputs[2].default_value = 25.0
    #Randomness
    voronoi_texture_002.inputs[5].default_value = 1.0
    
    #node Mix.004
    mix_004 = meat.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 0.7583333253860474
    
    #node Mix.005
    mix_005 = meat.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MULTIPLY'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_005.inputs[0].default_value = 0.9416666626930237
    
    
    #Set locations
    colorramp_001.location = (614.0, -7.4695587158203125)
    add_shader.location = (1426.478271484375, 308.73968505859375)
    translucent_bsdf.location = (1014.0, 294.45489501953125)
    mix.location = (-886.0, 14.45489501953125)
    colorramp_002.location = (-446.0, 267.43890380859375)
    noise_texture_002.location = (-666.0, 434.45489501953125)
    colorramp_003.location = (-446.0, 518.1771240234375)
    colorramp_004.location = (-378.756591796875, 31.185134887695312)
    colorramp.location = (329.47705078125, 90.5501708984375)
    voronoi_texture.location = (-666.0, 14.45489501953125)
    principled_bsdf.location = (1120.937744140625, 194.45489501953125)
    texture_coordinate_001.location = (-1646.0, -45.54510498046875)
    vector_math.location = (-1306.0, 34.45489501953125)
    group_output.location = (1836.0, -0.0)
    math.location = (442.1881408691406, 283.6701965332031)
    voronoi_texture_001.location = (-666.0, 194.45489501953125)
    noise_texture.location = (-1126.0, -185.54510498046875)
    hue_saturation_value.location = (646.656982421875, 187.7799072265625)
    mix_003.location = (909.3995971679688, 8.976470947265625)
    invert.location = (220.0, 240.00001525878906)
    invert_001.location = (-160.0, -200.0)
    map_range.location = (58.582763671875, -273.15728759765625)
    bump.location = (313.642822265625, -239.60824584960938)
    bump_001.location = (274.0, -425.54510498046875)
    math_001.location = (-640.0, -460.0)
    group_input.location = (-1846.0, -0.0)
    mix_shader.location = (1646.0, 364.2658996582031)
    mix_002.location = (-126.0, 241.965576171875)
    mix_001.location = (94.0, 29.030685424804688)
    noise_texture_001.location = (54.0, -518.1771240234375)
    voronoi_texture_002.location = (-226.0, -325.54510498046875)
    mix_004.location = (500.0, -360.0)
    mix_005.location = (714.1276245117188, -345.1417236328125)
    
    #Set dimensions
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    add_shader.width, add_shader.height = 140.0, 100.0
    translucent_bsdf.width, translucent_bsdf.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    invert_001.width, invert_001.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_shader.width, mix_shader.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    voronoi_texture_002.width, voronoi_texture_002.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    
    #initialize meat links
    #mix_shader.Shader -> group_output.Shader
    meat.links.new(mix_shader.outputs[0], group_output.inputs[0])
    #mix.Result -> voronoi_texture.Vector
    meat.links.new(mix.outputs[2], voronoi_texture.inputs[0])
    #noise_texture.Fac -> mix.B
    meat.links.new(noise_texture.outputs[0], mix.inputs[7])
    #bump.Normal -> principled_bsdf.Normal
    meat.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix_001.Result -> colorramp_001.Fac
    meat.links.new(mix_001.outputs[2], colorramp_001.inputs[0])
    #mix_003.Result -> principled_bsdf.Roughness
    meat.links.new(mix_003.outputs[2], principled_bsdf.inputs[9])
    #translucent_bsdf.BSDF -> add_shader.Shader
    meat.links.new(translucent_bsdf.outputs[0], add_shader.inputs[0])
    #principled_bsdf.BSDF -> add_shader.Shader
    meat.links.new(principled_bsdf.outputs[0], add_shader.inputs[1])
    #hue_saturation_value.Color -> translucent_bsdf.Color
    meat.links.new(hue_saturation_value.outputs[0], translucent_bsdf.inputs[0])
    #add_shader.Shader -> mix_shader.Shader
    meat.links.new(add_shader.outputs[0], mix_shader.inputs[2])
    #mix_001.Result -> colorramp.Fac
    meat.links.new(mix_001.outputs[2], colorramp.inputs[0])
    #mix.Result -> voronoi_texture_001.Vector
    meat.links.new(mix.outputs[2], voronoi_texture_001.inputs[0])
    #mix_002.Result -> mix_001.B
    meat.links.new(mix_002.outputs[2], mix_001.inputs[7])
    #colorramp_004.Color -> mix_001.A
    meat.links.new(colorramp_004.outputs[0], mix_001.inputs[6])
    #voronoi_texture_001.Distance -> colorramp_002.Fac
    meat.links.new(voronoi_texture_001.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix_002.A
    meat.links.new(colorramp_002.outputs[0], mix_002.inputs[6])
    #colorramp_003.Color -> mix_002.Factor
    meat.links.new(colorramp_003.outputs[0], mix_002.inputs[0])
    #noise_texture_002.Fac -> colorramp_003.Fac
    meat.links.new(noise_texture_002.outputs[0], colorramp_003.inputs[0])
    #voronoi_texture.Distance -> colorramp_004.Fac
    meat.links.new(voronoi_texture.outputs[0], colorramp_004.inputs[0])
    #map_range.Result -> bump.Height
    meat.links.new(map_range.outputs[0], bump.inputs[2])
    #voronoi_texture_002.Distance -> map_range.Value
    meat.links.new(voronoi_texture_002.outputs[0], map_range.inputs[0])
    #bump_001.Normal -> bump.Normal
    meat.links.new(bump_001.outputs[0], bump.inputs[3])
    #noise_texture_001.Color -> bump_001.Height
    meat.links.new(noise_texture_001.outputs[1], bump_001.inputs[2])
    #texture_coordinate_001.Object -> vector_math.Vector
    meat.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> voronoi_texture_002.Vector
    meat.links.new(vector_math.outputs[0], voronoi_texture_002.inputs[0])
    #vector_math.Vector -> mix.A
    meat.links.new(vector_math.outputs[0], mix.inputs[6])
    #vector_math.Vector -> noise_texture.Vector
    meat.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #vector_math.Vector -> noise_texture_001.Vector
    meat.links.new(vector_math.outputs[0], noise_texture_001.inputs[0])
    #vector_math.Vector -> noise_texture_002.Vector
    meat.links.new(vector_math.outputs[0], noise_texture_002.inputs[0])
    #group_input.Scale -> vector_math.Scale
    meat.links.new(group_input.outputs[1], vector_math.inputs[3])
    #colorramp.Color -> hue_saturation_value.Color
    meat.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    meat.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Subsurface Color
    meat.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[3])
    #math.Value -> hue_saturation_value.Hue
    meat.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math.Value
    meat.links.new(invert.outputs[0], math.inputs[0])
    #group_input.Color hue -> invert.Fac
    meat.links.new(group_input.outputs[0], invert.inputs[0])
    #group_input.Inner Texture Scale -> voronoi_texture_001.Scale
    meat.links.new(group_input.outputs[4], voronoi_texture_001.inputs[2])
    #group_input.Inner Texture Strength -> mix_001.Factor
    meat.links.new(group_input.outputs[5], mix_001.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    meat.links.new(group_input.outputs[6], hue_saturation_value.inputs[1])
    #group_input.Translucency -> mix_shader.Fac
    meat.links.new(group_input.outputs[7], mix_shader.inputs[0])
    #colorramp_001.Color -> mix_003.A
    meat.links.new(colorramp_001.outputs[0], mix_003.inputs[6])
    #invert_001.Color -> mix_003.Factor
    meat.links.new(invert_001.outputs[0], mix_003.inputs[0])
    #group_input.Roughness -> invert_001.Color
    meat.links.new(group_input.outputs[3], invert_001.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    meat.links.new(group_input.outputs[8], bump.inputs[0])
    #group_input.Bump Strength -> math_001.Value
    meat.links.new(group_input.outputs[8], math_001.inputs[0])
    #math_001.Value -> bump_001.Strength
    meat.links.new(math_001.outputs[0], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    meat.links.new(group_input.outputs[9], bump_001.inputs[3])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    meat.links.new(group_input.outputs[2], principled_bsdf.inputs[1])
    #principled_bsdf.BSDF -> mix_shader.Shader
    meat.links.new(principled_bsdf.outputs[0], mix_shader.inputs[1])
    #hue_saturation_value.Color -> group_output.Albedo
    meat.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    #mix_005.Result -> group_output.Mask
    meat.links.new(mix_005.outputs[2], group_output.inputs[2])
    #voronoi_texture_002.Distance -> mix_004.B
    meat.links.new(voronoi_texture_002.outputs[0], mix_004.inputs[7])
    #noise_texture_001.Fac -> mix_004.A
    meat.links.new(noise_texture_001.outputs[0], mix_004.inputs[6])
    #mix_004.Result -> mix_005.B
    meat.links.new(mix_004.outputs[2], mix_005.inputs[7])
    #mix_001.Result -> mix_005.A
    meat.links.new(mix_001.outputs[2], mix_005.inputs[6])
    return meat

meat = meat_node_group()

#initialize Meat node group
def meat_1_node_group():

    meat_1 = mat.node_tree
    #start with a clean node tree
    for node in meat_1.nodes:
        meat_1.nodes.remove(node)
    #initialize meat_1 nodes
    #node Material Output
    material_output = meat_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Meat
    meat_2 = meat_1.nodes.new("ShaderNodeGroup")
    meat_2.label = "Meat"
    meat_2.name = "Meat"
    meat_2.node_tree = meat
    #Input_2
    meat_2.inputs[0].default_value = 0.0
    #Input_1
    meat_2.inputs[1].default_value = 1.0
    #Input_17
    meat_2.inputs[2].default_value = 0.699999988079071
    #Input_7
    meat_2.inputs[3].default_value = 0.0
    #Input_3
    meat_2.inputs[4].default_value = 11.339999198913574
    #Input_4
    meat_2.inputs[5].default_value = 1.0
    #Input_5
    meat_2.inputs[6].default_value = 1.0
    #Input_6
    meat_2.inputs[7].default_value = 0.800000011920929
    #Input_14
    meat_2.inputs[8].default_value = 0.1764705777168274
    #Input_16
    meat_2.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (660.62939453125, 101.66796875)
    meat_2.location = (389.63427734375, 101.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    meat_2.width, meat_2.height = 224.41748046875, 100.0
    
    #initialize meat_1 links
    #meat_2.Shader -> material_output.Surface
    meat_1.links.new(meat_2.outputs[0], material_output.inputs[0])
    return meat_1

meat_1 = meat_1_node_group()

