import bpy, mathutils

mat = bpy.data.materials.new(name = "Scifi")
mat.use_nodes = True
#initialize Scifi node group
def scifi_node_group():

    scifi = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Scifi")
    
    #initialize scifi nodes
    #node ColorRamp.001
    colorramp_001 = scifi.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.43636345863342285
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.654545783996582)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = scifi.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Vector Math.018
    vector_math_018 = scifi.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = scifi.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Mix.001
    mix_001 = scifi.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.9700000286102295
    
    #node ColorRamp.002
    colorramp_002 = scifi.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.18636363744735718
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.9227273464202881)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = scifi.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Wave Texture
    wave_texture = scifi.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 2.5
    #Distortion
    wave_texture.inputs[2].default_value = 0.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Musgrave Texture
    musgrave_texture = scifi.nodes.new("ShaderNodeTexMusgrave")
    musgrave_texture.name = "Musgrave Texture"
    musgrave_texture.musgrave_dimensions = '3D'
    musgrave_texture.musgrave_type = 'RIDGED_MULTIFRACTAL'
    #Scale
    musgrave_texture.inputs[2].default_value = 3.1999998092651367
    #Detail
    musgrave_texture.inputs[3].default_value = 5.859999656677246
    #Dimension
    musgrave_texture.inputs[4].default_value = 0.0
    #Lacunarity
    musgrave_texture.inputs[5].default_value = 6.579999923706055
    #Gain
    musgrave_texture.inputs[7].default_value = 2.299999952316284
    
    #node Mix.002
    mix_002 = scifi.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node Reroute
    reroute = scifi.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Reroute.001
    reroute_001 = scifi.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Mix.005
    mix_005 = scifi.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'COLOR'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_005.inputs[0].default_value = 1.0
    #A_Color
    mix_005.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.004
    mix_004 = scifi.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'COLOR'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    #A_Color
    mix_004.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp
    colorramp = scifi.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Reroute.002
    reroute_002 = scifi.nodes.new("NodeReroute")
    reroute_002.name = "Reroute.002"
    #node Math
    math = scifi.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    
    #node Principled BSDF
    principled_bsdf = scifi.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.5909090638160706
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.003
    mix_003 = scifi.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Mix.006
    mix_006 = scifi.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'COLOR'
    mix_006.clamp_factor = True
    mix_006.clamp_result = False
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_006.inputs[0].default_value = 1.0
    
    #node Group Output
    group_output = scifi.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #scifi outputs
    #output BSDF
    scifi.outputs.new('NodeSocketShader', "BSDF")
    scifi.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    scifi.outputs.new('NodeSocketColor', "Albedo")
    scifi.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    scifi.outputs[1].attribute_domain = 'POINT'
    
    #output Mask 1
    scifi.outputs.new('NodeSocketColor', "Mask 1")
    scifi.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    scifi.outputs[2].attribute_domain = 'POINT'
    
    #output Mask 2
    scifi.outputs.new('NodeSocketFloat', "Mask 2")
    scifi.outputs[3].default_value = 0.0
    scifi.outputs[3].min_value = -3.4028234663852886e+38
    scifi.outputs[3].max_value = 3.4028234663852886e+38
    scifi.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Mix.007
    mix_007 = scifi.nodes.new("ShaderNodeMix")
    mix_007.name = "Mix.007"
    mix_007.blend_type = 'COLOR'
    mix_007.clamp_factor = True
    mix_007.clamp_result = False
    mix_007.data_type = 'RGBA'
    mix_007.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_007.inputs[0].default_value = 1.0
    
    #node Group Input
    group_input = scifi.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #scifi inputs
    #input Scale
    scifi.inputs.new('NodeSocketFloat', "Scale")
    scifi.inputs[0].default_value = 1.0
    scifi.inputs[0].min_value = -10000.0
    scifi.inputs[0].max_value = 10000.0
    scifi.inputs[0].attribute_domain = 'POINT'
    
    #input Metall Color1
    scifi.inputs.new('NodeSocketColor', "Metall Color1")
    scifi.inputs[1].default_value = (0.5, 0.5, 0.5, 1.0)
    scifi.inputs[1].attribute_domain = 'POINT'
    
    #input Metall Color2
    scifi.inputs.new('NodeSocketColor', "Metall Color2")
    scifi.inputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    scifi.inputs[2].attribute_domain = 'POINT'
    
    #input Emission Color
    scifi.inputs.new('NodeSocketColor', "Emission Color")
    scifi.inputs[3].default_value = (0.32327327132225037, 0.7885132431983948, 1.0, 1.0)
    scifi.inputs[3].attribute_domain = 'POINT'
    
    #input Emission Strength
    scifi.inputs.new('NodeSocketFloat', "Emission Strength")
    scifi.inputs[4].default_value = 20.0
    scifi.inputs[4].min_value = -10000.0
    scifi.inputs[4].max_value = 10000.0
    scifi.inputs[4].attribute_domain = 'POINT'
    
    #input Roughness
    scifi.inputs.new('NodeSocketFloatFactor', "Roughness")
    scifi.inputs[5].default_value = 0.20000000298023224
    scifi.inputs[5].min_value = 0.0
    scifi.inputs[5].max_value = 1.0
    scifi.inputs[5].attribute_domain = 'POINT'
    
    #input Effect Mask
    scifi.inputs.new('NodeSocketFloat', "Effect Mask")
    scifi.inputs[6].default_value = 0.559999942779541
    scifi.inputs[6].min_value = -1000.0
    scifi.inputs[6].max_value = 1000.0
    scifi.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    scifi.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    scifi.inputs[7].default_value = 1.0
    scifi.inputs[7].min_value = 0.0
    scifi.inputs[7].max_value = 1.0
    scifi.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    scifi.inputs.new('NodeSocketVector', "Normal")
    scifi.inputs[8].default_value = (0.0, 0.0, 0.0)
    scifi.inputs[8].min_value = -1.0
    scifi.inputs[8].max_value = 1.0
    scifi.inputs[8].attribute_domain = 'POINT'
    scifi.inputs[8].hide_value = True
    
    
    
    
    #Set locations
    colorramp_001.location = (235.1795654296875, -180.0)
    bump.location = (535.1796875, -280.0)
    vector_math_018.location = (-764.8204345703125, -40.0)
    texture_coordinate_001.location = (-1104.8204345703125, -119.99993896484375)
    mix_001.location = (-200.7218017578125, -95.47178649902344)
    colorramp_002.location = (300.0, 40.0)
    mix.location = (665.1326904296875, 25.3511962890625)
    wave_texture.location = (-444.8204345703125, 60.0)
    musgrave_texture.location = (40.0, -140.0)
    mix_002.location = (660.0, 259.9999694824219)
    reroute.location = (473.214111328125, 121.69745635986328)
    reroute_001.location = (479.4583435058594, 100.07965850830078)
    mix_005.location = (660.0, 580.0)
    mix_004.location = (640.0, 766.5194091796875)
    colorramp.location = (-80.0, 315.53515625)
    reroute_002.location = (596.988037109375, -235.96975708007812)
    math.location = (885.1795654296875, -57.1158447265625)
    principled_bsdf.location = (1104.8204345703125, 280.0)
    mix_003.location = (860.0000610351562, 740.0)
    mix_006.location = (860.0, 500.0)
    group_output.location = (1394.8204345703125, -0.0)
    mix_007.location = (1060.0, 740.0)
    group_input.location = (-1304.8204345703125, -0.0)
    
    #Set dimensions
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    musgrave_texture.width, musgrave_texture.height = 150.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    reroute_002.width, reroute_002.height = 16.0, 100.0
    math.width, math.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_007.width, mix_007.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize scifi links
    #principled_bsdf.BSDF -> group_output.BSDF
    scifi.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #wave_texture.Color -> colorramp.Fac
    scifi.links.new(wave_texture.outputs[0], colorramp.inputs[0])
    #wave_texture.Color -> colorramp_001.Fac
    scifi.links.new(wave_texture.outputs[0], colorramp_001.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    scifi.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #musgrave_texture.Fac -> colorramp_002.Fac
    scifi.links.new(musgrave_texture.outputs[0], colorramp_002.inputs[0])
    #math.Value -> principled_bsdf.Emission Strength
    scifi.links.new(math.outputs[0], principled_bsdf.inputs[20])
    #colorramp_002.Color -> mix.A
    scifi.links.new(colorramp_002.outputs[0], mix.inputs[6])
    #colorramp.Color -> mix.Factor
    scifi.links.new(colorramp.outputs[0], mix.inputs[0])
    #mix_001.Result -> musgrave_texture.Vector
    scifi.links.new(mix_001.outputs[2], musgrave_texture.inputs[0])
    #wave_texture.Color -> mix_001.A
    scifi.links.new(wave_texture.outputs[0], mix_001.inputs[6])
    #colorramp_001.Color -> bump.Height
    scifi.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #mix.Result -> math.Value
    scifi.links.new(mix.outputs[2], math.inputs[0])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    scifi.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> wave_texture.Vector
    scifi.links.new(vector_math_018.outputs[0], wave_texture.inputs[0])
    #vector_math_018.Vector -> mix_001.B
    scifi.links.new(vector_math_018.outputs[0], mix_001.inputs[7])
    #group_input.Scale -> vector_math_018.Scale
    scifi.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #mix_002.Result -> principled_bsdf.Base Color
    scifi.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #colorramp.Color -> mix_002.Factor
    scifi.links.new(colorramp.outputs[0], mix_002.inputs[0])
    #reroute.Output -> mix_002.A
    scifi.links.new(reroute.outputs[0], mix_002.inputs[6])
    #reroute_001.Output -> mix_002.B
    scifi.links.new(reroute_001.outputs[0], mix_002.inputs[7])
    #reroute_002.Output -> principled_bsdf.Emission
    scifi.links.new(reroute_002.outputs[0], principled_bsdf.inputs[19])
    #group_input.Emission Strength -> math.Value
    scifi.links.new(group_input.outputs[4], math.inputs[1])
    #group_input.Roughness -> principled_bsdf.Roughness
    scifi.links.new(group_input.outputs[5], principled_bsdf.inputs[9])
    #group_input.Effect Mask -> musgrave_texture.Offset
    scifi.links.new(group_input.outputs[6], musgrave_texture.inputs[6])
    #group_input.Bump Strength -> bump.Strength
    scifi.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    scifi.links.new(group_input.outputs[8], bump.inputs[3])
    #wave_texture.Color -> group_output.Mask 1
    scifi.links.new(wave_texture.outputs[0], group_output.inputs[2])
    #musgrave_texture.Fac -> group_output.Mask 2
    scifi.links.new(musgrave_texture.outputs[0], group_output.inputs[3])
    #group_input.Metall Color1 -> reroute.Input
    scifi.links.new(group_input.outputs[1], reroute.inputs[0])
    #group_input.Metall Color2 -> reroute_001.Input
    scifi.links.new(group_input.outputs[2], reroute_001.inputs[0])
    #reroute_001.Output -> mix_005.B
    scifi.links.new(reroute_001.outputs[0], mix_005.inputs[7])
    #reroute.Output -> mix_004.B
    scifi.links.new(reroute.outputs[0], mix_004.inputs[7])
    #mix_004.Result -> mix_003.A
    scifi.links.new(mix_004.outputs[2], mix_003.inputs[6])
    #mix_005.Result -> mix_003.B
    scifi.links.new(mix_005.outputs[2], mix_003.inputs[7])
    #colorramp.Color -> mix_003.Factor
    scifi.links.new(colorramp.outputs[0], mix_003.inputs[0])
    #group_input.Emission Color -> reroute_002.Input
    scifi.links.new(group_input.outputs[3], reroute_002.inputs[0])
    #reroute_002.Output -> mix_006.B
    scifi.links.new(reroute_002.outputs[0], mix_006.inputs[7])
    #mix_003.Result -> mix_007.A
    scifi.links.new(mix_003.outputs[2], mix_007.inputs[6])
    #math.Value -> mix_006.A
    scifi.links.new(math.outputs[0], mix_006.inputs[6])
    #mix_006.Result -> mix_007.B
    scifi.links.new(mix_006.outputs[2], mix_007.inputs[7])
    #mix_007.Result -> group_output.Albedo
    scifi.links.new(mix_007.outputs[2], group_output.inputs[1])
    return scifi

scifi = scifi_node_group()

#initialize Scifi node group
def scifi_1_node_group():

    scifi_1 = mat.node_tree
    #start with a clean node tree
    for node in scifi_1.nodes:
        scifi_1.nodes.remove(node)
    #initialize scifi_1 nodes
    #node Material Output
    material_output = scifi_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Scifi
    scifi_2 = scifi_1.nodes.new("ShaderNodeGroup")
    scifi_2.label = "Scifi"
    scifi_2.name = "Scifi"
    scifi_2.node_tree = scifi
    #Input_1
    scifi_2.inputs[0].default_value = 1.0
    #Input_2
    scifi_2.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_3
    scifi_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    scifi_2.inputs[3].default_value = (0.2920670211315155, 0.6964672803878784, 1.0, 1.0)
    #Input_5
    scifi_2.inputs[4].default_value = 20.0
    #Input_6
    scifi_2.inputs[5].default_value = 0.20000000298023224
    #Input_7
    scifi_2.inputs[6].default_value = 0.559999942779541
    #Input_9
    scifi_2.inputs[7].default_value = 1.0
    #Input_10
    scifi_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (701.85791015625, 80.874267578125)
    scifi_2.location = (372.68408203125, 78.25341796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    scifi_2.width, scifi_2.height = 236.85498046875, 100.0
    
    #initialize scifi_1 links
    #scifi_2.BSDF -> material_output.Surface
    scifi_1.links.new(scifi_2.outputs[0], material_output.inputs[0])
    return scifi_1

scifi_1 = scifi_1_node_group()

