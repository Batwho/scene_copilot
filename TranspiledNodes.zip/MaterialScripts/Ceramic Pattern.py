import bpy, mathutils

mat = bpy.data.materials.new(name = "Ceramic Pattern")
mat.use_nodes = True
#initialize Ceramic Pattern node group
def ceramic_pattern_node_group():

    ceramic_pattern = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Ceramic Pattern")
    
    #initialize ceramic_pattern nodes
    #node Principled BSDF
    principled_bsdf = ceramic_pattern.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = ceramic_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.5
    
    #node ColorRamp
    colorramp = ceramic_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5272728800773621)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = ceramic_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.4090907573699951
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5545452237129211)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(0.6272727847099304)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_3 = colorramp_001.color_ramp.elements.new(0.7772724628448486)
    colorramp_001_cre_3.alpha = 1.0
    colorramp_001_cre_3.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = ceramic_pattern.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Math.014
    math_014 = ceramic_pattern.nodes.new("ShaderNodeMath")
    math_014.name = "Math.014"
    math_014.operation = 'MULTIPLY'
    math_014.use_clamp = False
    #Value
    math_014.inputs[0].default_value = 5.0
    #Value_002
    math_014.inputs[2].default_value = 0.5
    
    #node Group Output
    group_output = ceramic_pattern.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #ceramic_pattern outputs
    #output BSDF
    ceramic_pattern.outputs.new('NodeSocketShader', "BSDF")
    ceramic_pattern.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    ceramic_pattern.outputs.new('NodeSocketColor', "Albedo")
    ceramic_pattern.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    ceramic_pattern.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    ceramic_pattern.outputs.new('NodeSocketFloat', "Mask")
    ceramic_pattern.outputs[2].default_value = 0.0
    ceramic_pattern.outputs[2].min_value = -3.4028234663852886e+38
    ceramic_pattern.outputs[2].max_value = 3.4028234663852886e+38
    ceramic_pattern.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Math.015
    math_015 = ceramic_pattern.nodes.new("ShaderNodeMath")
    math_015.name = "Math.015"
    math_015.operation = 'MULTIPLY'
    math_015.use_clamp = False
    #Value
    math_015.inputs[0].default_value = 2.0
    #Value_002
    math_015.inputs[2].default_value = 0.5
    
    #node Math.016
    math_016 = ceramic_pattern.nodes.new("ShaderNodeMath")
    math_016.name = "Math.016"
    math_016.operation = 'MULTIPLY'
    math_016.use_clamp = False
    #Value_002
    math_016.inputs[2].default_value = 0.5
    
    #node Group Input
    group_input = ceramic_pattern.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #ceramic_pattern inputs
    #input Color
    ceramic_pattern.inputs.new('NodeSocketColor', "Color")
    ceramic_pattern.inputs[0].default_value = (0.5, 0.5, 0.5, 1.0)
    ceramic_pattern.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    ceramic_pattern.inputs.new('NodeSocketFloat', "Scale")
    ceramic_pattern.inputs[1].default_value = 0.5
    ceramic_pattern.inputs[1].min_value = -10000.0
    ceramic_pattern.inputs[1].max_value = 10000.0
    ceramic_pattern.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    ceramic_pattern.inputs.new('NodeSocketFloatFactor', "Roughness")
    ceramic_pattern.inputs[2].default_value = 0.0
    ceramic_pattern.inputs[2].min_value = 0.0
    ceramic_pattern.inputs[2].max_value = 1.0
    ceramic_pattern.inputs[2].attribute_domain = 'POINT'
    
    #input Rings amount
    ceramic_pattern.inputs.new('NodeSocketFloat', "Rings amount")
    ceramic_pattern.inputs[3].default_value = 0.5
    ceramic_pattern.inputs[3].min_value = -10000.0
    ceramic_pattern.inputs[3].max_value = 10000.0
    ceramic_pattern.inputs[3].attribute_domain = 'POINT'
    
    #input Randomness
    ceramic_pattern.inputs.new('NodeSocketFloatFactor', "Randomness")
    ceramic_pattern.inputs[4].default_value = 0.0
    ceramic_pattern.inputs[4].min_value = 0.0
    ceramic_pattern.inputs[4].max_value = 1.0
    ceramic_pattern.inputs[4].attribute_domain = 'POINT'
    
    #input Phase Offset
    ceramic_pattern.inputs.new('NodeSocketFloat', "Phase Offset")
    ceramic_pattern.inputs[5].default_value = 0.0
    ceramic_pattern.inputs[5].min_value = -1000.0
    ceramic_pattern.inputs[5].max_value = 1000.0
    ceramic_pattern.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    ceramic_pattern.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    ceramic_pattern.inputs[6].default_value = 1.0
    ceramic_pattern.inputs[6].min_value = 0.0
    ceramic_pattern.inputs[6].max_value = 1.0
    ceramic_pattern.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    ceramic_pattern.inputs.new('NodeSocketVector', "Normal")
    ceramic_pattern.inputs[7].default_value = (0.0, 0.0, 0.0)
    ceramic_pattern.inputs[7].min_value = -1.0
    ceramic_pattern.inputs[7].max_value = 1.0
    ceramic_pattern.inputs[7].attribute_domain = 'POINT'
    ceramic_pattern.inputs[7].hide_value = True
    
    
    
    #node Wave Texture
    wave_texture = ceramic_pattern.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Distortion
    wave_texture.inputs[2].default_value = 0.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    
    #node Mix
    mix = ceramic_pattern.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'COLOR'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    principled_bsdf.location = (692.7447509765625, 190.0)
    voronoi_texture.location = (-416.79754638671875, 90.00003051757812)
    colorramp.location = (183.2025146484375, 190.00003051757812)
    colorramp_001.location = (153.3643798828125, -56.25819396972656)
    bump.location = (423.2025146484375, -270.0)
    math_014.location = (-692.7447509765625, 101.202392578125)
    group_output.location = (982.7447509765625, -0.0)
    math_015.location = (-676.7974853515625, 270.0)
    math_016.location = (-488.29315185546875, 270.0)
    group_input.location = (-892.7447509765625, -0.0)
    wave_texture.location = (-96.7974853515625, 150.00003051757812)
    mix.location = (501.9595947265625, 208.40567016601562)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    math_014.width, math_014.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    math_015.width, math_015.height = 140.0, 100.0
    math_016.width, math_016.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    
    #initialize ceramic_pattern links
    #principled_bsdf.BSDF -> group_output.BSDF
    ceramic_pattern.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #voronoi_texture.Distance -> wave_texture.Vector
    ceramic_pattern.links.new(voronoi_texture.outputs[0], wave_texture.inputs[0])
    #wave_texture.Color -> colorramp.Fac
    ceramic_pattern.links.new(wave_texture.outputs[0], colorramp.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    ceramic_pattern.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> principled_bsdf.Base Color
    ceramic_pattern.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #wave_texture.Color -> colorramp_001.Fac
    ceramic_pattern.links.new(wave_texture.outputs[0], colorramp_001.inputs[0])
    #colorramp_001.Color -> bump.Height
    ceramic_pattern.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #math_014.Value -> voronoi_texture.Scale
    ceramic_pattern.links.new(math_014.outputs[0], voronoi_texture.inputs[2])
    #math_016.Value -> wave_texture.Scale
    ceramic_pattern.links.new(math_016.outputs[0], wave_texture.inputs[1])
    #group_input.Scale -> math_014.Value
    ceramic_pattern.links.new(group_input.outputs[1], math_014.inputs[1])
    #group_input.Scale -> math_015.Value
    ceramic_pattern.links.new(group_input.outputs[1], math_015.inputs[1])
    #colorramp.Color -> mix.A
    ceramic_pattern.links.new(colorramp.outputs[0], mix.inputs[6])
    #group_input.Color -> mix.B
    ceramic_pattern.links.new(group_input.outputs[0], mix.inputs[7])
    #math_015.Value -> math_016.Value
    ceramic_pattern.links.new(math_015.outputs[0], math_016.inputs[0])
    #group_input.Rings amount -> math_016.Value
    ceramic_pattern.links.new(group_input.outputs[3], math_016.inputs[1])
    #group_input.Randomness -> voronoi_texture.Randomness
    ceramic_pattern.links.new(group_input.outputs[4], voronoi_texture.inputs[5])
    #group_input.Phase Offset -> wave_texture.Phase Offset
    ceramic_pattern.links.new(group_input.outputs[5], wave_texture.inputs[6])
    #group_input.Roughness -> principled_bsdf.Roughness
    ceramic_pattern.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    ceramic_pattern.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    ceramic_pattern.links.new(group_input.outputs[7], bump.inputs[3])
    #wave_texture.Fac -> group_output.Mask
    ceramic_pattern.links.new(wave_texture.outputs[1], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    ceramic_pattern.links.new(mix.outputs[2], group_output.inputs[1])
    return ceramic_pattern

ceramic_pattern = ceramic_pattern_node_group()

#initialize Ceramic Pattern node group
def ceramic_pattern_1_node_group():

    ceramic_pattern_1 = mat.node_tree
    #start with a clean node tree
    for node in ceramic_pattern_1.nodes:
        ceramic_pattern_1.nodes.remove(node)
    #initialize ceramic_pattern_1 nodes
    #node Material Output
    material_output = ceramic_pattern_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Ceramic Pattern
    ceramic_pattern_2 = ceramic_pattern_1.nodes.new("ShaderNodeGroup")
    ceramic_pattern_2.label = "Ceramic Pattern"
    ceramic_pattern_2.name = "Ceramic Pattern"
    ceramic_pattern_2.use_custom_color = True
    ceramic_pattern_2.color = (0.11935313791036606, 0.11935313791036606, 0.11935313791036606)
    ceramic_pattern_2.node_tree = ceramic_pattern
    #Input_2
    ceramic_pattern_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_1
    ceramic_pattern_2.inputs[1].default_value = 1.2799999713897705
    #Input_6
    ceramic_pattern_2.inputs[2].default_value = 0.0
    #Input_3
    ceramic_pattern_2.inputs[3].default_value = 1.0
    #Input_4
    ceramic_pattern_2.inputs[4].default_value = 1.0
    #Input_5
    ceramic_pattern_2.inputs[5].default_value = 0.0
    #Input_7
    ceramic_pattern_2.inputs[6].default_value = 0.5
    #Input_8
    ceramic_pattern_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (659.125, 70.4775390625)
    ceramic_pattern_2.location = (419.58251953125, 70.4775390625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    ceramic_pattern_2.width, ceramic_pattern_2.height = 163.9127197265625, 100.0
    
    #initialize ceramic_pattern_1 links
    #ceramic_pattern_2.BSDF -> material_output.Surface
    ceramic_pattern_1.links.new(ceramic_pattern_2.outputs[0], material_output.inputs[0])
    return ceramic_pattern_1

ceramic_pattern_1 = ceramic_pattern_1_node_group()

