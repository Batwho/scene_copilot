import bpy, mathutils

mat = bpy.data.materials.new(name = "Half Gras")
mat.use_nodes = True
#initialize Half_gras node group
def half_gras_node_group():

    half_gras = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Half_gras")
    
    #initialize half_gras nodes
    #node Bump
    bump = half_gras.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp.003
    colorramp_003 = half_gras.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.3772726356983185
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.46818166971206665)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (0.6000000238418579, 0.6000000238418579, 0.6000000238418579, 1.0)

    colorramp_003_cre_2 = colorramp_003.color_ramp.elements.new(0.5045459270477295)
    colorramp_003_cre_2.alpha = 1.0
    colorramp_003_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp
    colorramp = half_gras.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.18636363744735718
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.27467650175094604, 0.12024731189012527, 0.05111989378929138, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.4590908885002136)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.035499170422554016, 0.015474604442715645, 0.005509661044925451, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.6181821823120117)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.05145469307899475, 0.3464507758617401, 0.018778247758746147, 1.0)

    
    #node Texture Coordinate.001
    texture_coordinate_001 = half_gras.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math.018
    vector_math_018 = half_gras.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node ColorRamp.001
    colorramp_001 = half_gras.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.26727306842803955
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.2845126986503601, 0.2845126986503601, 0.2845126986503601, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.7045456767082214)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Principled BSDF
    principled_bsdf = half_gras.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.20000000298023224
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.002
    colorramp_002 = half_gras.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.44090908765792847)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_2 = colorramp_002.color_ramp.elements.new(0.6727275848388672)
    colorramp_002_cre_2.alpha = 1.0
    colorramp_002_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Group Output
    group_output = half_gras.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #half_gras outputs
    #output BSDF
    half_gras.outputs.new('NodeSocketShader', "BSDF")
    half_gras.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    half_gras.outputs.new('NodeSocketColor', "Albedo")
    half_gras.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    half_gras.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    half_gras.outputs.new('NodeSocketColor', "Mask")
    half_gras.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    half_gras.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Hue Saturation Value
    hue_saturation_value = half_gras.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = half_gras.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = half_gras.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Group Input
    group_input = half_gras.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #half_gras inputs
    #input Scale
    half_gras.inputs.new('NodeSocketFloat', "Scale")
    half_gras.inputs[0].default_value = 1.0
    half_gras.inputs[0].min_value = -10000.0
    half_gras.inputs[0].max_value = 10000.0
    half_gras.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    half_gras.inputs.new('NodeSocketFloatFactor', "Color Hue")
    half_gras.inputs[1].default_value = 1.0
    half_gras.inputs[1].min_value = 0.0
    half_gras.inputs[1].max_value = 1.0
    half_gras.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    half_gras.inputs.new('NodeSocketFloat', "Saturation")
    half_gras.inputs[2].default_value = 1.0
    half_gras.inputs[2].min_value = 0.0
    half_gras.inputs[2].max_value = 2.0
    half_gras.inputs[2].attribute_domain = 'POINT'
    
    #input Brightness
    half_gras.inputs.new('NodeSocketFloat', "Brightness")
    half_gras.inputs[3].default_value = 1.0
    half_gras.inputs[3].min_value = 0.0
    half_gras.inputs[3].max_value = 2.0
    half_gras.inputs[3].attribute_domain = 'POINT'
    
    #input Detail
    half_gras.inputs.new('NodeSocketFloat', "Detail")
    half_gras.inputs[4].default_value = 8.0
    half_gras.inputs[4].min_value = 0.0
    half_gras.inputs[4].max_value = 15.0
    half_gras.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    half_gras.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    half_gras.inputs[5].default_value = 1.0
    half_gras.inputs[5].min_value = 0.0
    half_gras.inputs[5].max_value = 1.0
    half_gras.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    half_gras.inputs.new('NodeSocketVector', "Normal")
    half_gras.inputs[6].default_value = (0.0, 0.0, 0.0)
    half_gras.inputs[6].min_value = -1.0
    half_gras.inputs[6].max_value = 1.0
    half_gras.inputs[6].attribute_domain = 'POINT'
    half_gras.inputs[6].hide_value = True
    
    
    
    #node Mix.001
    mix_001 = half_gras.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.0
    #B_Color
    mix_001.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.002
    mix_002 = half_gras.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = True
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.0
    #B_Color
    mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix
    mix = half_gras.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = half_gras.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5983335375785828
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Noise Texture.001
    noise_texture_001 = half_gras.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 100.0
    #Detail
    noise_texture_001.inputs[3].default_value = 6.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.9250000715255737
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Mix.003
    mix_003 = half_gras.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MULTIPLY'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    
    
    #Set locations
    bump.location = (650.2289428710938, -227.5411834716797)
    colorramp_003.location = (270.2288818359375, -327.54119873046875)
    colorramp.location = (-29.7711181640625, 52.45881652832031)
    texture_coordinate_001.location = (-849.7711181640625, -147.5411834716797)
    vector_math_018.location = (-509.7711181640625, -67.54118347167969)
    colorramp_001.location = (270.2288818359375, -96.91999816894531)
    principled_bsdf.location = (849.7711181640625, 212.4588165283203)
    colorramp_002.location = (-29.771148681640625, 272.45880126953125)
    group_output.location = (1139.7711181640625, -0.0)
    hue_saturation_value.location = (607.433349609375, 136.5799560546875)
    invert.location = (-300.0, 260.0)
    math.location = (20.0, 460.0)
    group_input.location = (-1049.7711181640625, -0.0)
    mix_001.location = (433.4911804199219, 327.54119873046875)
    mix_002.location = (620.0001220703125, 342.3073425292969)
    mix.location = (370.2288818359375, 132.4588165283203)
    noise_texture.location = (-249.7711181640625, -27.541183471679688)
    noise_texture_001.location = (-252.24905395507812, -263.5696716308594)
    mix_003.location = (-40.0, -340.0)
    
    #Set dimensions
    bump.width, bump.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    
    #initialize half_gras links
    #principled_bsdf.BSDF -> group_output.BSDF
    half_gras.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    half_gras.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> hue_saturation_value.Color
    half_gras.links.new(mix.outputs[2], hue_saturation_value.inputs[4])
    #colorramp.Color -> mix.A
    half_gras.links.new(colorramp.outputs[0], mix.inputs[6])
    #colorramp_001.Color -> mix.B
    half_gras.links.new(colorramp_001.outputs[0], mix.inputs[7])
    #noise_texture_001.Fac -> colorramp_001.Fac
    half_gras.links.new(noise_texture_001.outputs[0], colorramp_001.inputs[0])
    #noise_texture.Fac -> colorramp_002.Fac
    half_gras.links.new(noise_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix.Factor
    half_gras.links.new(colorramp_002.outputs[0], mix.inputs[0])
    #mix.Result -> bump.Height
    half_gras.links.new(mix.outputs[2], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    half_gras.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> colorramp_003.Fac
    half_gras.links.new(noise_texture.outputs[0], colorramp_003.inputs[0])
    #colorramp_003.Color -> principled_bsdf.Roughness
    half_gras.links.new(colorramp_003.outputs[0], principled_bsdf.inputs[9])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    half_gras.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    half_gras.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #vector_math_018.Vector -> noise_texture_001.Vector
    half_gras.links.new(vector_math_018.outputs[0], noise_texture_001.inputs[0])
    #colorramp_002.Color -> mix_001.A
    half_gras.links.new(colorramp_002.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> principled_bsdf.Subsurface
    half_gras.links.new(mix_001.outputs[2], principled_bsdf.inputs[1])
    #group_input.Scale -> vector_math_018.Scale
    half_gras.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #hue_saturation_value.Color -> mix_002.A
    half_gras.links.new(hue_saturation_value.outputs[0], mix_002.inputs[6])
    #group_input.Color Hue -> invert.Fac
    half_gras.links.new(group_input.outputs[1], invert.inputs[0])
    #invert.Color -> math.Value
    half_gras.links.new(invert.outputs[0], math.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    half_gras.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    half_gras.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    half_gras.links.new(group_input.outputs[3], hue_saturation_value.inputs[2])
    #group_input.Detail -> noise_texture.Detail
    half_gras.links.new(group_input.outputs[4], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    half_gras.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    half_gras.links.new(group_input.outputs[6], bump.inputs[3])
    #mix_002.Result -> principled_bsdf.Base Color
    half_gras.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #mix_002.Result -> principled_bsdf.Subsurface Color
    half_gras.links.new(mix_002.outputs[2], principled_bsdf.inputs[3])
    #noise_texture.Fac -> mix_003.A
    half_gras.links.new(noise_texture.outputs[0], mix_003.inputs[6])
    #noise_texture_001.Fac -> mix_003.B
    half_gras.links.new(noise_texture_001.outputs[0], mix_003.inputs[7])
    #mix_003.Result -> group_output.Mask
    half_gras.links.new(mix_003.outputs[2], group_output.inputs[2])
    #mix_002.Result -> group_output.Albedo
    half_gras.links.new(mix_002.outputs[2], group_output.inputs[1])
    return half_gras

half_gras = half_gras_node_group()

#initialize Half Gras node group
def half_gras_1_node_group():

    half_gras_1 = mat.node_tree
    #start with a clean node tree
    for node in half_gras_1.nodes:
        half_gras_1.nodes.remove(node)
    #initialize half_gras_1 nodes
    #node Material Output
    material_output = half_gras_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Half_gras
    half_gras_2 = half_gras_1.nodes.new("ShaderNodeGroup")
    half_gras_2.label = "Half_gras"
    half_gras_2.name = "Half_gras"
    half_gras_2.node_tree = half_gras
    #Input_1
    half_gras_2.inputs[0].default_value = 1.0
    #Input_2
    half_gras_2.inputs[1].default_value = 0.0
    #Input_3
    half_gras_2.inputs[2].default_value = 1.0
    #Input_4
    half_gras_2.inputs[3].default_value = 1.0
    #Input_5
    half_gras_2.inputs[4].default_value = 8.0
    #Input_6
    half_gras_2.inputs[5].default_value = 1.0
    #Input_7
    half_gras_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (682.2978515625, 143.2548828125)
    half_gras_2.location = (442.7548828125, 143.2548828125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    half_gras_2.width, half_gras_2.height = 140.0, 100.0
    
    #initialize half_gras_1 links
    #half_gras_2.BSDF -> material_output.Surface
    half_gras_1.links.new(half_gras_2.outputs[0], material_output.inputs[0])
    return half_gras_1

half_gras_1 = half_gras_1_node_group()

