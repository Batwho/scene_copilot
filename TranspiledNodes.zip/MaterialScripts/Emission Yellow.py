import bpy, mathutils

mat = bpy.data.materials.new(name = "Emission Yellow")
mat.use_nodes = True
#initialize Emission_ yellow node group
def emission__yellow_node_group():

    emission__yellow = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Emission_ yellow")
    
    #initialize emission__yellow nodes
    #node Principled BSDF
    principled_bsdf = emission__yellow.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Group Output
    group_output = emission__yellow.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #emission__yellow outputs
    #output BSDF
    emission__yellow.outputs.new('NodeSocketShader', "BSDF")
    emission__yellow.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Group Input
    group_input = emission__yellow.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #emission__yellow inputs
    #input Emission
    emission__yellow.inputs.new('NodeSocketColor', "Emission")
    emission__yellow.inputs[0].default_value = (1.0, 0.44432228803634644, 0.0, 1.0)
    emission__yellow.inputs[0].attribute_domain = 'POINT'
    
    #input Emission Strength
    emission__yellow.inputs.new('NodeSocketFloat', "Emission Strength")
    emission__yellow.inputs[1].default_value = 4.0
    emission__yellow.inputs[1].min_value = 0.0
    emission__yellow.inputs[1].max_value = 1000000.0
    emission__yellow.inputs[1].attribute_domain = 'POINT'
    
    #input Base Color
    emission__yellow.inputs.new('NodeSocketColor', "Base Color")
    emission__yellow.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    emission__yellow.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    emission__yellow.inputs.new('NodeSocketFloatFactor', "Roughness")
    emission__yellow.inputs[3].default_value = 0.20000000298023224
    emission__yellow.inputs[3].min_value = 0.0
    emission__yellow.inputs[3].max_value = 1.0
    emission__yellow.inputs[3].attribute_domain = 'POINT'
    
    #input Normal
    emission__yellow.inputs.new('NodeSocketVector', "Normal")
    emission__yellow.inputs[4].default_value = (0.0, 0.0, 0.0)
    emission__yellow.inputs[4].min_value = -3.4028234663852886e+38
    emission__yellow.inputs[4].max_value = 3.4028234663852886e+38
    emission__yellow.inputs[4].attribute_domain = 'POINT'
    emission__yellow.inputs[4].hide_value = True
    
    
    
    
    #Set locations
    principled_bsdf.location = (88.22991943359375, 24.99188232421875)
    group_output.location = (378.22991943359375, -0.0)
    group_input.location = (-280.0, -40.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize emission__yellow links
    #principled_bsdf.BSDF -> group_output.BSDF
    emission__yellow.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #group_input.Emission -> principled_bsdf.Emission
    emission__yellow.links.new(group_input.outputs[0], principled_bsdf.inputs[19])
    #group_input.Emission Strength -> principled_bsdf.Emission Strength
    emission__yellow.links.new(group_input.outputs[1], principled_bsdf.inputs[20])
    #group_input.Base Color -> principled_bsdf.Base Color
    emission__yellow.links.new(group_input.outputs[2], principled_bsdf.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    emission__yellow.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    emission__yellow.links.new(group_input.outputs[4], principled_bsdf.inputs[22])
    return emission__yellow

emission__yellow = emission__yellow_node_group()

#initialize Emission Yellow node group
def emission_yellow_node_group():

    emission_yellow = mat.node_tree
    #start with a clean node tree
    for node in emission_yellow.nodes:
        emission_yellow.nodes.remove(node)
    #initialize emission_yellow nodes
    #node Material Output
    material_output = emission_yellow.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Emission_ yellow
    emission__yellow_1 = emission_yellow.nodes.new("ShaderNodeGroup")
    emission__yellow_1.label = "Emission_ yellow"
    emission__yellow_1.name = "Emission_ yellow"
    emission__yellow_1.node_tree = emission__yellow
    #Input_1
    emission__yellow_1.inputs[0].default_value = (1.0, 0.44432228803634644, 0.0, 1.0)
    #Input_2
    emission__yellow_1.inputs[1].default_value = 4.0
    #Input_3
    emission__yellow_1.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    emission__yellow_1.inputs[3].default_value = 0.20000000298023224
    #Input_5
    emission__yellow_1.inputs[4].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (674.9521484375, 108.4649658203125)
    emission__yellow_1.location = (397.9521484375, 108.4649658203125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    emission__yellow_1.width, emission__yellow_1.height = 200.16009521484375, 100.0
    
    #initialize emission_yellow links
    #emission__yellow_1.BSDF -> material_output.Surface
    emission_yellow.links.new(emission__yellow_1.outputs[0], material_output.inputs[0])
    return emission_yellow

emission_yellow = emission_yellow_node_group()

