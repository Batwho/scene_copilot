import bpy, mathutils

mat = bpy.data.materials.new(name = "Metall Anisatrophic 90°")
mat.use_nodes = True
#initialize Metall anisatrophic 90° node group
def metall_anisatrophic_90__node_group():

    metall_anisatrophic_90_ = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Metall anisatrophic 90°")
    
    #initialize metall_anisatrophic_90_ nodes
    #node Group Output
    group_output = metall_anisatrophic_90_.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #metall_anisatrophic_90_ outputs
    #output BSDF
    metall_anisatrophic_90_.outputs.new('NodeSocketShader', "BSDF")
    metall_anisatrophic_90_.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = metall_anisatrophic_90_.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = metall_anisatrophic_90_.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #metall_anisatrophic_90_ inputs
    #input Base Color
    metall_anisatrophic_90_.inputs.new('NodeSocketColor', "Base Color")
    metall_anisatrophic_90_.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    metall_anisatrophic_90_.inputs[0].attribute_domain = 'POINT'
    
    #input Roughness
    metall_anisatrophic_90_.inputs.new('NodeSocketFloatFactor', "Roughness")
    metall_anisatrophic_90_.inputs[1].default_value = 0.15000000596046448
    metall_anisatrophic_90_.inputs[1].min_value = 0.0
    metall_anisatrophic_90_.inputs[1].max_value = 1.0
    metall_anisatrophic_90_.inputs[1].attribute_domain = 'POINT'
    
    #input Anisotropic
    metall_anisatrophic_90_.inputs.new('NodeSocketFloatFactor', "Anisotropic")
    metall_anisatrophic_90_.inputs[2].default_value = 1.0
    metall_anisatrophic_90_.inputs[2].min_value = 0.0
    metall_anisatrophic_90_.inputs[2].max_value = 1.0
    metall_anisatrophic_90_.inputs[2].attribute_domain = 'POINT'
    
    #input Anisotropic Rotation
    metall_anisatrophic_90_.inputs.new('NodeSocketFloatFactor', "Anisotropic Rotation")
    metall_anisatrophic_90_.inputs[3].default_value = 0.25
    metall_anisatrophic_90_.inputs[3].min_value = 0.0
    metall_anisatrophic_90_.inputs[3].max_value = 1.0
    metall_anisatrophic_90_.inputs[3].attribute_domain = 'POINT'
    
    #input Normal
    metall_anisatrophic_90_.inputs.new('NodeSocketVector', "Normal")
    metall_anisatrophic_90_.inputs[4].default_value = (0.0, 0.0, 0.0)
    metall_anisatrophic_90_.inputs[4].min_value = -3.4028234663852886e+38
    metall_anisatrophic_90_.inputs[4].max_value = 3.4028234663852886e+38
    metall_anisatrophic_90_.inputs[4].attribute_domain = 'POINT'
    metall_anisatrophic_90_.inputs[4].hide_value = True
    
    #input Tangent
    metall_anisatrophic_90_.inputs.new('NodeSocketVector', "Tangent")
    metall_anisatrophic_90_.inputs[5].default_value = (0.0, 0.0, 0.0)
    metall_anisatrophic_90_.inputs[5].min_value = -3.4028234663852886e+38
    metall_anisatrophic_90_.inputs[5].max_value = 3.4028234663852886e+38
    metall_anisatrophic_90_.inputs[5].attribute_domain = 'POINT'
    metall_anisatrophic_90_.inputs[5].hide_value = True
    
    
    
    
    #Set locations
    group_output.location = (264.8352355957031, -0.0)
    principled_bsdf.location = (-25.164764404296875, 88.43867492675781)
    group_input.location = (-225.16476440429688, -0.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize metall_anisatrophic_90_ links
    #principled_bsdf.BSDF -> group_output.BSDF
    metall_anisatrophic_90_.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #group_input.Base Color -> principled_bsdf.Base Color
    metall_anisatrophic_90_.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    metall_anisatrophic_90_.links.new(group_input.outputs[1], principled_bsdf.inputs[9])
    #group_input.Anisotropic -> principled_bsdf.Anisotropic
    metall_anisatrophic_90_.links.new(group_input.outputs[2], principled_bsdf.inputs[10])
    #group_input.Anisotropic Rotation -> principled_bsdf.Anisotropic Rotation
    metall_anisatrophic_90_.links.new(group_input.outputs[3], principled_bsdf.inputs[11])
    #group_input.Normal -> principled_bsdf.Normal
    metall_anisatrophic_90_.links.new(group_input.outputs[4], principled_bsdf.inputs[22])
    #group_input.Tangent -> principled_bsdf.Tangent
    metall_anisatrophic_90_.links.new(group_input.outputs[5], principled_bsdf.inputs[24])
    return metall_anisatrophic_90_

metall_anisatrophic_90_ = metall_anisatrophic_90__node_group()

#initialize Metall Anisatrophic 90° node group
def metall_anisatrophic_90__1_node_group():

    metall_anisatrophic_90__1 = mat.node_tree
    #start with a clean node tree
    for node in metall_anisatrophic_90__1.nodes:
        metall_anisatrophic_90__1.nodes.remove(node)
    #initialize metall_anisatrophic_90__1 nodes
    #node Material Output
    material_output = metall_anisatrophic_90__1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Metall anisatrophic 90°
    metall_anisatrophic_90__2 = metall_anisatrophic_90__1.nodes.new("ShaderNodeGroup")
    metall_anisatrophic_90__2.label = "Metall anisatrophic 90°"
    metall_anisatrophic_90__2.name = "Metall anisatrophic 90°"
    metall_anisatrophic_90__2.node_tree = metall_anisatrophic_90_
    #Input_1
    metall_anisatrophic_90__2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_2
    metall_anisatrophic_90__2.inputs[1].default_value = 0.15000000596046448
    #Input_3
    metall_anisatrophic_90__2.inputs[2].default_value = 1.0
    #Input_4
    metall_anisatrophic_90__2.inputs[3].default_value = 0.25
    #Input_5
    metall_anisatrophic_90__2.inputs[4].default_value = (0.0, 0.0, 0.0)
    #Input_6
    metall_anisatrophic_90__2.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (679.58251953125, 80.874267578125)
    metall_anisatrophic_90__2.location = (416.25390625, 80.874267578125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    metall_anisatrophic_90__2.width, metall_anisatrophic_90__2.height = 186.32904052734375, 100.0
    
    #initialize metall_anisatrophic_90__1 links
    #metall_anisatrophic_90__2.BSDF -> material_output.Surface
    metall_anisatrophic_90__1.links.new(metall_anisatrophic_90__2.outputs[0], material_output.inputs[0])
    return metall_anisatrophic_90__1

metall_anisatrophic_90__1 = metall_anisatrophic_90__1_node_group()

