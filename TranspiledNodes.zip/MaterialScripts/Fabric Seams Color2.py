import bpy, mathutils

mat = bpy.data.materials.new(name = "Fabric Seams Color2")
mat.use_nodes = True
#initialize Fabric Seams color2 node group
def fabric_seams_color2_node_group():

    fabric_seams_color2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Fabric Seams color2")
    
    #initialize fabric_seams_color2 nodes
    #node Separate XYZ
    separate_xyz = fabric_seams_color2.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"
    
    #node Math
    math = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'SINE'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Math.001
    math_001 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'SINE'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    #node Vector Math
    vector_math = fabric_seams_color2.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Separate XYZ.001
    separate_xyz_001 = fabric_seams_color2.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz_001.name = "Separate XYZ.001"
    
    #node Math.003
    math_003 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'SINE'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 0.5
    #Value_002
    math_003.inputs[2].default_value = 0.5
    
    #node Math.004
    math_004 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MAXIMUM'
    math_004.use_clamp = False
    #Value_002
    math_004.inputs[2].default_value = 0.5
    
    #node Math.005
    math_005 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_005.name = "Math.005"
    math_005.operation = 'SINE'
    math_005.use_clamp = False
    #Value_001
    math_005.inputs[1].default_value = 0.5
    #Value_002
    math_005.inputs[2].default_value = 0.5
    
    #node Vector Math.001
    vector_math_001 = fabric_seams_color2.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'SCALE'
    #Vector_001
    vector_math_001.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Map Range.001
    map_range_001 = fabric_seams_color2.nodes.new("ShaderNodeMapRange")
    map_range_001.name = "Map Range.001"
    map_range_001.clamp = True
    map_range_001.data_type = 'FLOAT'
    map_range_001.interpolation_type = 'LINEAR'
    #From Min
    map_range_001.inputs[1].default_value = -1.0
    #From Max
    map_range_001.inputs[2].default_value = 1.0
    #To Min
    map_range_001.inputs[3].default_value = 0.0
    #Steps
    map_range_001.inputs[5].default_value = 4.0
    #Vector
    map_range_001.inputs[6].default_value = (0.0, 0.0, 0.0)
    #From_Min_FLOAT3
    map_range_001.inputs[7].default_value = (0.0, 0.0, 0.0)
    #From_Max_FLOAT3
    map_range_001.inputs[8].default_value = (1.0, 1.0, 1.0)
    #To_Min_FLOAT3
    map_range_001.inputs[9].default_value = (0.0, 0.0, 0.0)
    #To_Max_FLOAT3
    map_range_001.inputs[10].default_value = (1.0, 1.0, 1.0)
    #Steps_FLOAT3
    map_range_001.inputs[11].default_value = (4.0, 4.0, 4.0)
    
    #node Math.002
    math_002 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MAXIMUM'
    math_002.use_clamp = False
    #Value_002
    math_002.inputs[2].default_value = 0.5
    
    #node ColorRamp
    colorramp = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.7545450329780579
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.003
    colorramp_003 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.8954542875289917
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.9772727489471436)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.2454545795917511
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.968181848526001)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Wave Texture.001
    wave_texture_001 = fabric_seams_color2.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'Y'
    wave_texture_001.rings_direction = 'X'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Distortion
    wave_texture_001.inputs[2].default_value = 1.5
    #Detail
    wave_texture_001.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 1.6200000047683716
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture_001.inputs[6].default_value = 0.0
    
    #node Noise Texture.001
    noise_texture_001 = fabric_seams_color2.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #W
    noise_texture_001.inputs[1].default_value = 0.0
    #Detail
    noise_texture_001.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node ColorRamp.004
    colorramp_004 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.30909088253974915
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(0.9045455455780029)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.006
    colorramp_006 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_006.name = "ColorRamp.006"
    colorramp_006.color_ramp.color_mode = 'RGB'
    colorramp_006.color_ramp.hue_interpolation = 'NEAR'
    colorramp_006.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_006.color_ramp.elements.remove(colorramp_006.color_ramp.elements[0])
    colorramp_006_cre_0 = colorramp_006.color_ramp.elements[0]
    colorramp_006_cre_0.position = 0.29545459151268005
    colorramp_006_cre_0.alpha = 1.0
    colorramp_006_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_006_cre_1 = colorramp_006.color_ramp.elements.new(0.6818183660507202)
    colorramp_006_cre_1.alpha = 1.0
    colorramp_006_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Wave Texture
    wave_texture = fabric_seams_color2.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Distortion
    wave_texture.inputs[2].default_value = 1.5
    #Detail
    wave_texture.inputs[3].default_value = 1.2000000476837158
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node ColorRamp.005
    colorramp_005 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_005.name = "ColorRamp.005"
    colorramp_005.color_ramp.color_mode = 'RGB'
    colorramp_005.color_ramp.hue_interpolation = 'NEAR'
    colorramp_005.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_005.color_ramp.elements.remove(colorramp_005.color_ramp.elements[0])
    colorramp_005_cre_0 = colorramp_005.color_ramp.elements[0]
    colorramp_005_cre_0.position = 0.24090909957885742
    colorramp_005_cre_0.alpha = 1.0
    colorramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_005_cre_1 = colorramp_005.color_ramp.elements.new(0.6636365652084351)
    colorramp_005_cre_1.alpha = 1.0
    colorramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = fabric_seams_color2.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 2.0
    
    #node Texture Coordinate.002
    texture_coordinate_002 = fabric_seams_color2.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_002.name = "Texture Coordinate.002"
    texture_coordinate_002.from_instancer = False
    
    #node Group Output
    group_output = fabric_seams_color2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #fabric_seams_color2 outputs
    #output BSDF
    fabric_seams_color2.outputs.new('NodeSocketShader', "BSDF")
    fabric_seams_color2.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    fabric_seams_color2.outputs.new('NodeSocketColor', "Albedo")
    fabric_seams_color2.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    fabric_seams_color2.outputs[1].attribute_domain = 'POINT'
    
    #output Mask 1
    fabric_seams_color2.outputs.new('NodeSocketColor', "Mask 1")
    fabric_seams_color2.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    fabric_seams_color2.outputs[2].attribute_domain = 'POINT'
    
    #output Mask 2
    fabric_seams_color2.outputs.new('NodeSocketColor', "Mask 2")
    fabric_seams_color2.outputs[3].default_value = (0.0, 0.0, 0.0, 1.0)
    fabric_seams_color2.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Map Range
    map_range = fabric_seams_color2.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = -1.0
    #From Max
    map_range.inputs[2].default_value = 1.0
    #To Min
    map_range.inputs[3].default_value = 0.0
    #Steps
    map_range.inputs[5].default_value = 4.0
    #Vector
    map_range.inputs[6].default_value = (0.0, 0.0, 0.0)
    #From_Min_FLOAT3
    map_range.inputs[7].default_value = (0.0, 0.0, 0.0)
    #From_Max_FLOAT3
    map_range.inputs[8].default_value = (1.0, 1.0, 1.0)
    #To_Min_FLOAT3
    map_range.inputs[9].default_value = (0.0, 0.0, 0.0)
    #To_Max_FLOAT3
    map_range.inputs[10].default_value = (1.0, 1.0, 1.0)
    #Steps_FLOAT3
    map_range.inputs[11].default_value = (4.0, 4.0, 4.0)
    
    #node Math.007
    math_007 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_007.name = "Math.007"
    math_007.operation = 'MULTIPLY'
    math_007.use_clamp = False
    #Value_001
    math_007.inputs[1].default_value = 500.0
    #Value_002
    math_007.inputs[2].default_value = 0.5
    
    #node Math.008
    math_008 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_008.name = "Math.008"
    math_008.operation = 'MULTIPLY'
    math_008.use_clamp = False
    #Value_001
    math_008.inputs[1].default_value = 100.0
    #Value_002
    math_008.inputs[2].default_value = 0.5
    
    #node Noise Texture.002
    noise_texture_002 = fabric_seams_color2.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #W
    noise_texture_002.inputs[1].default_value = 0.0
    #Detail
    noise_texture_002.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node Vector Math.002
    vector_math_002 = fabric_seams_color2.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SCALE'
    #Vector_001
    vector_math_002.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math_002.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Math.009
    math_009 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_009.name = "Math.009"
    math_009.operation = 'MULTIPLY'
    math_009.use_clamp = False
    #Value_001
    math_009.inputs[1].default_value = 8.0
    #Value_002
    math_009.inputs[2].default_value = 0.5
    
    #node Math.010
    math_010 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_010.name = "Math.010"
    math_010.operation = 'MULTIPLY'
    math_010.use_clamp = False
    #Value_001
    math_010.inputs[1].default_value = 8.9399995803833
    #Value_002
    math_010.inputs[2].default_value = 0.5
    
    #node Bump.002
    bump_002 = fabric_seams_color2.nodes.new("ShaderNodeBump")
    bump_002.name = "Bump.002"
    bump_002.invert = False
    #Distance
    bump_002.inputs[1].default_value = 1.0
    
    #node Mix.007
    mix_007 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_007.name = "Mix.007"
    mix_007.blend_type = 'MIX'
    mix_007.clamp_factor = True
    mix_007.clamp_result = False
    mix_007.data_type = 'RGBA'
    mix_007.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_007.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_007.inputs[2].default_value = 0.0
    #B_Float
    mix_007.inputs[3].default_value = 0.0
    #A_Vector
    mix_007.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_007.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_007.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Reroute
    reroute = fabric_seams_color2.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Mix.003
    mix_003 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MULTIPLY'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_003.inputs[2].default_value = 0.0
    #B_Float
    mix_003.inputs[3].default_value = 0.0
    #A_Vector
    mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.001
    mix_001 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'ADD'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.009
    mix_009 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_009.name = "Mix.009"
    mix_009.blend_type = 'MULTIPLY'
    mix_009.clamp_factor = True
    mix_009.clamp_result = True
    mix_009.data_type = 'RGBA'
    mix_009.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_009.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_009.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_009.inputs[2].default_value = 0.0
    #B_Float
    mix_009.inputs[3].default_value = 0.0
    #A_Vector
    mix_009.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_009.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.010
    mix_010 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_010.name = "Mix.010"
    mix_010.blend_type = 'BURN'
    mix_010.clamp_factor = True
    mix_010.clamp_result = False
    mix_010.data_type = 'RGBA'
    mix_010.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_010.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_010.inputs[2].default_value = 0.0
    #B_Float
    mix_010.inputs[3].default_value = 0.0
    #A_Vector
    mix_010.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_010.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_010.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.006
    mix_006 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'MIX'
    mix_006.clamp_factor = True
    mix_006.clamp_result = False
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_006.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_006.inputs[2].default_value = 0.0
    #B_Float
    mix_006.inputs[3].default_value = 0.0
    #A_Vector
    mix_006.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_006.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.001
    colorramp_001 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Principled BSDF
    principled_bsdf = fabric_seams_color2.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 1.5
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Group Input
    group_input = fabric_seams_color2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #fabric_seams_color2 inputs
    #input Scale
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Scale")
    fabric_seams_color2.inputs[0].default_value = 1.0
    fabric_seams_color2.inputs[0].min_value = -10000.0
    fabric_seams_color2.inputs[0].max_value = 10000.0
    fabric_seams_color2.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    fabric_seams_color2.inputs.new('NodeSocketColor', "Color1")
    fabric_seams_color2.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    fabric_seams_color2.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    fabric_seams_color2.inputs.new('NodeSocketColor', "Color2")
    fabric_seams_color2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    fabric_seams_color2.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    fabric_seams_color2.inputs.new('NodeSocketFloatFactor', "Specular")
    fabric_seams_color2.inputs[3].default_value = 0.5
    fabric_seams_color2.inputs[3].min_value = 0.0
    fabric_seams_color2.inputs[3].max_value = 1.0
    fabric_seams_color2.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    fabric_seams_color2.inputs.new('NodeSocketFloatFactor', "Roughness")
    fabric_seams_color2.inputs[4].default_value = 0.800000011920929
    fabric_seams_color2.inputs[4].min_value = 0.0
    fabric_seams_color2.inputs[4].max_value = 1.0
    fabric_seams_color2.inputs[4].attribute_domain = 'POINT'
    
    #input Seams Thickness
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Seams Thickness")
    fabric_seams_color2.inputs[5].default_value = 1.0
    fabric_seams_color2.inputs[5].min_value = -10000.0
    fabric_seams_color2.inputs[5].max_value = 10000.0
    fabric_seams_color2.inputs[5].attribute_domain = 'POINT'
    
    #input Seams Length
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Seams Length")
    fabric_seams_color2.inputs[6].default_value = 1.0
    fabric_seams_color2.inputs[6].min_value = -10000.0
    fabric_seams_color2.inputs[6].max_value = 10000.0
    fabric_seams_color2.inputs[6].attribute_domain = 'POINT'
    
    #input Seams Scale
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Seams Scale")
    fabric_seams_color2.inputs[7].default_value = 0.5
    fabric_seams_color2.inputs[7].min_value = -10000.0
    fabric_seams_color2.inputs[7].max_value = 10000.0
    fabric_seams_color2.inputs[7].attribute_domain = 'POINT'
    
    #input Seams noise Strength
    fabric_seams_color2.inputs.new('NodeSocketFloatFactor', "Seams noise Strength")
    fabric_seams_color2.inputs[8].default_value = 0.0
    fabric_seams_color2.inputs[8].min_value = 0.0
    fabric_seams_color2.inputs[8].max_value = 1.0
    fabric_seams_color2.inputs[8].attribute_domain = 'POINT'
    
    #input Seams Noise Threshold
    fabric_seams_color2.inputs.new('NodeSocketFloatFactor', "Seams Noise Threshold")
    fabric_seams_color2.inputs[9].default_value = 0.28333336114883423
    fabric_seams_color2.inputs[9].min_value = 0.0
    fabric_seams_color2.inputs[9].max_value = 1.0
    fabric_seams_color2.inputs[9].attribute_domain = 'POINT'
    
    #input Fabric Scale
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Fabric Scale")
    fabric_seams_color2.inputs[10].default_value = 200.0
    fabric_seams_color2.inputs[10].min_value = -1000.0
    fabric_seams_color2.inputs[10].max_value = 1000.0
    fabric_seams_color2.inputs[10].attribute_domain = 'POINT'
    
    #input Fabric Detail Strength
    fabric_seams_color2.inputs.new('NodeSocketFloatFactor', "Fabric Detail Strength")
    fabric_seams_color2.inputs[11].default_value = 1.0
    fabric_seams_color2.inputs[11].min_value = 0.0
    fabric_seams_color2.inputs[11].max_value = 1.0
    fabric_seams_color2.inputs[11].attribute_domain = 'POINT'
    
    #input Noise Scale
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Noise Scale")
    fabric_seams_color2.inputs[12].default_value = 0.5
    fabric_seams_color2.inputs[12].min_value = -10000.0
    fabric_seams_color2.inputs[12].max_value = 10000.0
    fabric_seams_color2.inputs[12].attribute_domain = 'POINT'
    
    #input Seams Bump Strength
    fabric_seams_color2.inputs.new('NodeSocketFloatFactor', "Seams Bump Strength")
    fabric_seams_color2.inputs[13].default_value = 0.5
    fabric_seams_color2.inputs[13].min_value = 0.0
    fabric_seams_color2.inputs[13].max_value = 1.0
    fabric_seams_color2.inputs[13].attribute_domain = 'POINT'
    
    #input Fabric Bump 
    fabric_seams_color2.inputs.new('NodeSocketFloat', "Fabric Bump ")
    fabric_seams_color2.inputs[14].default_value = 1.0
    fabric_seams_color2.inputs[14].min_value = 0.0
    fabric_seams_color2.inputs[14].max_value = 1000.0
    fabric_seams_color2.inputs[14].attribute_domain = 'POINT'
    
    #input Normal
    fabric_seams_color2.inputs.new('NodeSocketVector', "Normal")
    fabric_seams_color2.inputs[15].default_value = (0.0, 0.0, 0.0)
    fabric_seams_color2.inputs[15].min_value = -1.0
    fabric_seams_color2.inputs[15].max_value = 1.0
    fabric_seams_color2.inputs[15].attribute_domain = 'POINT'
    fabric_seams_color2.inputs[15].hide_value = True
    
    
    
    #node ColorRamp.007
    colorramp_007 = fabric_seams_color2.nodes.new("ShaderNodeValToRGB")
    colorramp_007.name = "ColorRamp.007"
    colorramp_007.color_ramp.color_mode = 'RGB'
    colorramp_007.color_ramp.hue_interpolation = 'NEAR'
    colorramp_007.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_007.color_ramp.elements.remove(colorramp_007.color_ramp.elements[0])
    colorramp_007_cre_0 = colorramp_007.color_ramp.elements[0]
    colorramp_007_cre_0.position = 0.0
    colorramp_007_cre_0.alpha = 1.0
    colorramp_007_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_007_cre_1 = colorramp_007.color_ramp.elements.new(1.0)
    colorramp_007_cre_1.alpha = 1.0
    colorramp_007_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Math.006
    math_006 = fabric_seams_color2.nodes.new("ShaderNodeMath")
    math_006.name = "Math.006"
    math_006.operation = 'MULTIPLY'
    math_006.use_clamp = False
    #Value_002
    math_006.inputs[2].default_value = 0.5
    
    #node Mix.011
    mix_011 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_011.name = "Mix.011"
    mix_011.blend_type = 'MULTIPLY'
    mix_011.clamp_factor = True
    mix_011.clamp_result = False
    mix_011.data_type = 'RGBA'
    mix_011.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_011.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_011.inputs[2].default_value = 0.0
    #B_Float
    mix_011.inputs[3].default_value = 0.0
    #A_Vector
    mix_011.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_011.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.008
    mix_008 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_008.name = "Mix.008"
    mix_008.blend_type = 'MULTIPLY'
    mix_008.clamp_factor = True
    mix_008.clamp_result = False
    mix_008.data_type = 'RGBA'
    mix_008.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_008.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_008.inputs[2].default_value = 0.0
    #B_Float
    mix_008.inputs[3].default_value = 0.0
    #A_Vector
    mix_008.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_008.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.004
    mix_004 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_004.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_004.inputs[2].default_value = 0.0
    #B_Float
    mix_004.inputs[3].default_value = 0.0
    #A_Vector
    mix_004.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_004.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.005
    mix_005 = fabric_seams_color2.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MULTIPLY'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_005.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_005.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_005.inputs[2].default_value = 0.0
    #B_Float
    mix_005.inputs[3].default_value = 0.0
    #A_Vector
    mix_005.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_005.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Color
    mix_005.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    
    
    #Set locations
    separate_xyz.location = (-332.14892578125, 328.7381896972656)
    math.location = (-112.14892578125, 448.7381896972656)
    math_001.location = (-152.14892578125, 248.73818969726562)
    vector_math.location = (-552.14892578125, 408.7381896972656)
    separate_xyz_001.location = (-292.1494140625, 671.26171875)
    math_003.location = (-72.1494140625, 791.2618408203125)
    math_004.location = (147.850830078125, 811.2618408203125)
    math_005.location = (-112.149169921875, 591.26171875)
    vector_math_001.location = (-512.1492919921875, 751.26171875)
    map_range_001.location = (367.850830078125, 791.2618408203125)
    math_002.location = (107.85107421875, 468.7381896972656)
    colorramp.location = (549.369873046875, 470.7672424316406)
    colorramp_003.location = (547.85107421875, 748.7381591796875)
    colorramp_002.location = (-1132.14892578125, -71.26181030273438)
    wave_texture_001.location = (-1712.1490478515625, -411.2618103027344)
    noise_texture_001.location = (-1132.14892578125, -591.2618408203125)
    colorramp_004.location = (-1132.14892578125, -311.2618103027344)
    colorramp_006.location = (-872.14892578125, -771.2618408203125)
    wave_texture.location = (-1352.14892578125, -71.26181030273438)
    colorramp_005.location = (-872.14892578125, -551.2618408203125)
    mix.location = (-72.14892578125, -51.261810302734375)
    bump.location = (2221.052734375, 408.7381591796875)
    texture_coordinate_002.location = (-2589.976806640625, 352.9377746582031)
    group_output.location = (2879.9765625, -0.0)
    map_range.location = (327.85107421875, 448.7381896972656)
    math_007.location = (-880.6033325195312, 607.6775512695312)
    math_008.location = (-720.0, 520.0)
    noise_texture_002.location = (-1117.96875, -787.5927734375)
    vector_math_002.location = (-2160.0, 320.0)
    math_009.location = (-1580.0, -740.0)
    math_010.location = (-1580.0, -900.0)
    bump_002.location = (1660.8310546875, -75.312255859375)
    mix_007.location = (1928.0625, 67.57809448242188)
    reroute.location = (1380.0, 620.0)
    mix_003.location = (427.85107421875, -11.261810302734375)
    mix_001.location = (-72.14892578125, -231.26181030273438)
    mix_009.location = (-159.9998779296875, -460.0)
    mix_010.location = (833.414306640625, 367.04156494140625)
    mix_006.location = (1957.273193359375, 678.0325927734375)
    colorramp_001.location = (647.85107421875, 28.738189697265625)
    principled_bsdf.location = (2589.9765625, 650.65478515625)
    group_input.location = (-2800.0, -20.0)
    colorramp_007.location = (1560.0, 160.0)
    math_006.location = (880.0, 660.0)
    mix_011.location = (2144.035400390625, 684.7606811523438)
    mix_008.location = (1156.8978271484375, 679.998779296875)
    mix_004.location = (147.85107421875, -331.2616882324219)
    mix_005.location = (367.85107421875, -311.2618103027344)
    
    #Set dimensions
    separate_xyz.width, separate_xyz.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    vector_math_001.width, vector_math_001.height = 140.0, 100.0
    map_range_001.width, map_range_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    colorramp_006.width, colorramp_006.height = 240.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    colorramp_005.width, colorramp_005.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    math_007.width, math_007.height = 140.0, 100.0
    math_008.width, math_008.height = 140.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    math_009.width, math_009.height = 140.0, 100.0
    math_010.width, math_010.height = 140.0, 100.0
    bump_002.width, bump_002.height = 140.0, 100.0
    mix_007.width, mix_007.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_009.width, mix_009.height = 140.0, 100.0
    mix_010.width, mix_010.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    colorramp_007.width, colorramp_007.height = 240.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    mix_011.width, mix_011.height = 140.0, 100.0
    mix_008.width, mix_008.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    
    #initialize fabric_seams_color2 links
    #principled_bsdf.BSDF -> group_output.BSDF
    fabric_seams_color2.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> separate_xyz.Vector
    fabric_seams_color2.links.new(vector_math.outputs[0], separate_xyz.inputs[0])
    #separate_xyz.X -> math.Value
    fabric_seams_color2.links.new(separate_xyz.outputs[0], math.inputs[0])
    #separate_xyz.Y -> math_001.Value
    fabric_seams_color2.links.new(separate_xyz.outputs[1], math_001.inputs[0])
    #math.Value -> math_002.Value
    fabric_seams_color2.links.new(math.outputs[0], math_002.inputs[0])
    #math_001.Value -> math_002.Value
    fabric_seams_color2.links.new(math_001.outputs[0], math_002.inputs[1])
    #math_002.Value -> map_range.Value
    fabric_seams_color2.links.new(math_002.outputs[0], map_range.inputs[0])
    #map_range.Result -> colorramp.Fac
    fabric_seams_color2.links.new(map_range.outputs[0], colorramp.inputs[0])
    #vector_math_001.Vector -> separate_xyz_001.Vector
    fabric_seams_color2.links.new(vector_math_001.outputs[0], separate_xyz_001.inputs[0])
    #separate_xyz_001.X -> math_003.Value
    fabric_seams_color2.links.new(separate_xyz_001.outputs[0], math_003.inputs[0])
    #separate_xyz_001.Y -> math_005.Value
    fabric_seams_color2.links.new(separate_xyz_001.outputs[1], math_005.inputs[0])
    #math_003.Value -> math_004.Value
    fabric_seams_color2.links.new(math_003.outputs[0], math_004.inputs[0])
    #math_005.Value -> math_004.Value
    fabric_seams_color2.links.new(math_005.outputs[0], math_004.inputs[1])
    #math_004.Value -> map_range_001.Value
    fabric_seams_color2.links.new(math_004.outputs[0], map_range_001.inputs[0])
    #map_range_001.Result -> colorramp_003.Fac
    fabric_seams_color2.links.new(map_range_001.outputs[0], colorramp_003.inputs[0])
    #colorramp_003.Color -> math_006.Value
    fabric_seams_color2.links.new(colorramp_003.outputs[0], math_006.inputs[0])
    #colorramp.Color -> math_006.Value
    fabric_seams_color2.links.new(colorramp.outputs[0], math_006.inputs[1])
    #mix_011.Result -> principled_bsdf.Base Color
    fabric_seams_color2.links.new(mix_011.outputs[2], principled_bsdf.inputs[0])
    #reroute.Output -> bump.Height
    fabric_seams_color2.links.new(reroute.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    fabric_seams_color2.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #wave_texture_001.Color -> colorramp_004.Fac
    fabric_seams_color2.links.new(wave_texture_001.outputs[0], colorramp_004.inputs[0])
    #wave_texture.Color -> colorramp_002.Fac
    fabric_seams_color2.links.new(wave_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix.A
    fabric_seams_color2.links.new(colorramp_002.outputs[0], mix.inputs[6])
    #colorramp_005.Color -> mix.B
    fabric_seams_color2.links.new(colorramp_005.outputs[0], mix.inputs[7])
    #noise_texture_001.Fac -> colorramp_005.Fac
    fabric_seams_color2.links.new(noise_texture_001.outputs[0], colorramp_005.inputs[0])
    #colorramp_004.Color -> mix_001.A
    fabric_seams_color2.links.new(colorramp_004.outputs[0], mix_001.inputs[6])
    #colorramp_006.Color -> mix_001.B
    fabric_seams_color2.links.new(colorramp_006.outputs[0], mix_001.inputs[7])
    #noise_texture_002.Fac -> colorramp_006.Fac
    fabric_seams_color2.links.new(noise_texture_002.outputs[0], colorramp_006.inputs[0])
    #mix_005.Result -> bump_002.Height
    fabric_seams_color2.links.new(mix_005.outputs[2], bump_002.inputs[2])
    #mix.Result -> mix_004.A
    fabric_seams_color2.links.new(mix.outputs[2], mix_004.inputs[6])
    #mix_001.Result -> mix_004.B
    fabric_seams_color2.links.new(mix_001.outputs[2], mix_004.inputs[7])
    #mix_004.Result -> mix_005.B
    fabric_seams_color2.links.new(mix_004.outputs[2], mix_005.inputs[7])
    #mix.Result -> mix_003.A
    fabric_seams_color2.links.new(mix.outputs[2], mix_003.inputs[6])
    #mix_001.Result -> mix_003.B
    fabric_seams_color2.links.new(mix_001.outputs[2], mix_003.inputs[7])
    #mix_003.Result -> colorramp_001.Fac
    fabric_seams_color2.links.new(mix_003.outputs[2], colorramp_001.inputs[0])
    #mix_007.Result -> bump.Normal
    fabric_seams_color2.links.new(mix_007.outputs[2], bump.inputs[3])
    #texture_coordinate_002.UV -> vector_math_002.Vector
    fabric_seams_color2.links.new(texture_coordinate_002.outputs[2], vector_math_002.inputs[0])
    #vector_math_002.Vector -> vector_math.Vector
    fabric_seams_color2.links.new(vector_math_002.outputs[0], vector_math.inputs[0])
    #vector_math_002.Vector -> vector_math_001.Vector
    fabric_seams_color2.links.new(vector_math_002.outputs[0], vector_math_001.inputs[0])
    #vector_math_002.Vector -> wave_texture.Vector
    fabric_seams_color2.links.new(vector_math_002.outputs[0], wave_texture.inputs[0])
    #vector_math_002.Vector -> wave_texture_001.Vector
    fabric_seams_color2.links.new(vector_math_002.outputs[0], wave_texture_001.inputs[0])
    #group_input.Scale -> vector_math_002.Scale
    fabric_seams_color2.links.new(group_input.outputs[0], vector_math_002.inputs[3])
    #group_input.Color1 -> mix_006.A
    fabric_seams_color2.links.new(group_input.outputs[1], mix_006.inputs[6])
    #group_input.Color2 -> mix_006.B
    fabric_seams_color2.links.new(group_input.outputs[2], mix_006.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    fabric_seams_color2.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    fabric_seams_color2.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Seams Thickness -> map_range_001.To Max
    fabric_seams_color2.links.new(group_input.outputs[5], map_range_001.inputs[4])
    #group_input.Seams Length -> map_range.To Max
    fabric_seams_color2.links.new(group_input.outputs[6], map_range.inputs[4])
    #math_007.Value -> vector_math_001.Scale
    fabric_seams_color2.links.new(math_007.outputs[0], vector_math_001.inputs[3])
    #group_input.Seams Scale -> math_007.Value
    fabric_seams_color2.links.new(group_input.outputs[7], math_007.inputs[0])
    #group_input.Seams Scale -> math_008.Value
    fabric_seams_color2.links.new(group_input.outputs[7], math_008.inputs[0])
    #math_008.Value -> vector_math.Scale
    fabric_seams_color2.links.new(math_008.outputs[0], vector_math.inputs[3])
    #vector_math_002.Vector -> noise_texture_001.Vector
    fabric_seams_color2.links.new(vector_math_002.outputs[0], noise_texture_001.inputs[0])
    #vector_math_002.Vector -> noise_texture_002.Vector
    fabric_seams_color2.links.new(vector_math_002.outputs[0], noise_texture_002.inputs[0])
    #group_input.Fabric Scale -> wave_texture_001.Scale
    fabric_seams_color2.links.new(group_input.outputs[10], wave_texture_001.inputs[1])
    #group_input.Fabric Scale -> wave_texture.Scale
    fabric_seams_color2.links.new(group_input.outputs[10], wave_texture.inputs[1])
    #group_input.Noise Scale -> math_009.Value
    fabric_seams_color2.links.new(group_input.outputs[12], math_009.inputs[0])
    #math_009.Value -> noise_texture_001.Scale
    fabric_seams_color2.links.new(math_009.outputs[0], noise_texture_001.inputs[2])
    #math_010.Value -> noise_texture_002.Scale
    fabric_seams_color2.links.new(math_010.outputs[0], noise_texture_002.inputs[2])
    #group_input.Noise Scale -> math_010.Value
    fabric_seams_color2.links.new(group_input.outputs[12], math_010.inputs[0])
    #group_input.Seams Bump Strength -> bump.Strength
    fabric_seams_color2.links.new(group_input.outputs[13], bump.inputs[0])
    #group_input.Normal -> bump_002.Normal
    fabric_seams_color2.links.new(group_input.outputs[15], bump_002.inputs[3])
    #bump_002.Normal -> mix_007.A
    fabric_seams_color2.links.new(bump_002.outputs[0], mix_007.inputs[6])
    #colorramp_007.Color -> mix_007.Factor
    fabric_seams_color2.links.new(colorramp_007.outputs[0], mix_007.inputs[0])
    #group_input.Fabric Bump  -> bump_002.Strength
    fabric_seams_color2.links.new(group_input.outputs[14], bump_002.inputs[0])
    #mix_008.Result -> reroute.Input
    fabric_seams_color2.links.new(mix_008.outputs[2], reroute.inputs[0])
    #math_006.Value -> mix_008.A
    fabric_seams_color2.links.new(math_006.outputs[0], mix_008.inputs[6])
    #colorramp_005.Color -> mix_009.A
    fabric_seams_color2.links.new(colorramp_005.outputs[0], mix_009.inputs[6])
    #colorramp_006.Color -> mix_009.B
    fabric_seams_color2.links.new(colorramp_006.outputs[0], mix_009.inputs[7])
    #mix_010.Result -> mix_008.B
    fabric_seams_color2.links.new(mix_010.outputs[2], mix_008.inputs[7])
    #group_input.Seams noise Strength -> mix_008.Factor
    fabric_seams_color2.links.new(group_input.outputs[8], mix_008.inputs[0])
    #mix_009.Result -> mix_010.A
    fabric_seams_color2.links.new(mix_009.outputs[2], mix_010.inputs[6])
    #group_input.Seams Noise Threshold -> mix_010.Factor
    fabric_seams_color2.links.new(group_input.outputs[9], mix_010.inputs[0])
    #mix_008.Result -> mix_006.Factor
    fabric_seams_color2.links.new(mix_008.outputs[2], mix_006.inputs[0])
    #mix_006.Result -> mix_011.A
    fabric_seams_color2.links.new(mix_006.outputs[2], mix_011.inputs[6])
    #colorramp_001.Color -> mix_011.B
    fabric_seams_color2.links.new(colorramp_001.outputs[0], mix_011.inputs[7])
    #group_input.Fabric Detail Strength -> mix_011.Factor
    fabric_seams_color2.links.new(group_input.outputs[11], mix_011.inputs[0])
    #reroute.Output -> colorramp_007.Fac
    fabric_seams_color2.links.new(reroute.outputs[0], colorramp_007.inputs[0])
    #mix_011.Result -> group_output.Albedo
    fabric_seams_color2.links.new(mix_011.outputs[2], group_output.inputs[1])
    #mix_008.Result -> group_output.Mask 1
    fabric_seams_color2.links.new(mix_008.outputs[2], group_output.inputs[2])
    #mix_004.Result -> group_output.Mask 2
    fabric_seams_color2.links.new(mix_004.outputs[2], group_output.inputs[3])
    return fabric_seams_color2

fabric_seams_color2 = fabric_seams_color2_node_group()

#initialize Fabric Seams Color2 node group
def fabric_seams_color2_1_node_group():

    fabric_seams_color2_1 = mat.node_tree
    #start with a clean node tree
    for node in fabric_seams_color2_1.nodes:
        fabric_seams_color2_1.nodes.remove(node)
    #initialize fabric_seams_color2_1 nodes
    #node Material Output
    material_output = fabric_seams_color2_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Fabric Seams color2
    fabric_seams_color2_2 = fabric_seams_color2_1.nodes.new("ShaderNodeGroup")
    fabric_seams_color2_2.label = "Fabric Seams color2"
    fabric_seams_color2_2.name = "Fabric Seams color2"
    fabric_seams_color2_2.node_tree = fabric_seams_color2
    #Input_1
    fabric_seams_color2_2.inputs[0].default_value = 1.0
    #Input_2
    fabric_seams_color2_2.inputs[1].default_value = (0.0009256616467610002, 0.0037976789753884077, 0.02496154233813286, 1.0)
    #Input_3
    fabric_seams_color2_2.inputs[2].default_value = (1.0, 0.40399497747421265, 0.03135290369391441, 1.0)
    #Input_4
    fabric_seams_color2_2.inputs[3].default_value = 0.5
    #Input_5
    fabric_seams_color2_2.inputs[4].default_value = 0.800000011920929
    #Input_6
    fabric_seams_color2_2.inputs[5].default_value = 1.0
    #Input_7
    fabric_seams_color2_2.inputs[6].default_value = 1.0
    #Input_8
    fabric_seams_color2_2.inputs[7].default_value = 1.0
    #Input_14
    fabric_seams_color2_2.inputs[8].default_value = 1.0
    #Input_15
    fabric_seams_color2_2.inputs[9].default_value = 0.15000000596046448
    #Input_9
    fabric_seams_color2_2.inputs[10].default_value = 200.0
    #Input_23
    fabric_seams_color2_2.inputs[11].default_value = 1.0
    #Input_10
    fabric_seams_color2_2.inputs[12].default_value = 1.0
    #Input_11
    fabric_seams_color2_2.inputs[13].default_value = 0.5
    #Input_12
    fabric_seams_color2_2.inputs[14].default_value = 1.0
    #Input_13
    fabric_seams_color2_2.inputs[15].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (693.30615234375, 117.619384765625)
    fabric_seams_color2_2.location = (369.822265625, 117.619384765625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    fabric_seams_color2_2.width, fabric_seams_color2_2.height = 240.8134765625, 100.0
    
    #initialize fabric_seams_color2_1 links
    #fabric_seams_color2_2.BSDF -> material_output.Surface
    fabric_seams_color2_1.links.new(fabric_seams_color2_2.outputs[0], material_output.inputs[0])
    return fabric_seams_color2_1

fabric_seams_color2_1 = fabric_seams_color2_1_node_group()

