import bpy, mathutils

mat = bpy.data.materials.new(name = "Black Hair")
mat.use_nodes = True
#initialize Black Hair node group
def black_hair_node_group():

    black_hair = mat.node_tree
    #start with a clean node tree
    for node in black_hair.nodes:
        black_hair.nodes.remove(node)
    #initialize black_hair nodes
    #node Mix
    mix = black_hair.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Color
    mix.inputs[6].default_value = (0.11398208886384964, 0.11398208886384964, 0.11398208886384964, 1.0)
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Attribute.001
    attribute_001 = black_hair.nodes.new("ShaderNodeAttribute")
    attribute_001.name = "Attribute.001"
    attribute_001.attribute_name = "Prox"
    attribute_001.attribute_type = 'GEOMETRY'
    
    #node ColorRamp.001
    colorramp_001 = black_hair.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.8181819915771484)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Attribute
    attribute = black_hair.nodes.new("ShaderNodeAttribute")
    attribute.name = "Attribute"
    attribute.attribute_name = "Rand"
    attribute.attribute_type = 'GEOMETRY'
    
    #node ColorRamp
    colorramp = black_hair.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.7090907692909241
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Glossy BSDF
    glossy_bsdf = black_hair.nodes.new("ShaderNodeBsdfGlossy")
    glossy_bsdf.name = "Glossy BSDF"
    glossy_bsdf.distribution = 'GGX'
    #Roughness
    glossy_bsdf.inputs[1].default_value = 0.20000000298023224
    #Normal
    glossy_bsdf.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Weight
    glossy_bsdf.inputs[3].default_value = 0.0
    
    #node Hair BSDF
    hair_bsdf = black_hair.nodes.new("ShaderNodeBsdfHair")
    hair_bsdf.name = "Hair BSDF"
    hair_bsdf.component = 'Transmission'
    #Offset
    hair_bsdf.inputs[1].default_value = 0.0
    #RoughnessU
    hair_bsdf.inputs[2].default_value = 0.10000000149011612
    #RoughnessV
    hair_bsdf.inputs[3].default_value = 1.0
    #Tangent
    hair_bsdf.inputs[4].default_value = (0.0, 0.0, 0.0)
    #Weight
    hair_bsdf.inputs[5].default_value = 0.0
    
    #node Add Shader.001
    add_shader_001 = black_hair.nodes.new("ShaderNodeAddShader")
    add_shader_001.name = "Add Shader.001"
    
    #node Mix.001
    mix_001 = black_hair.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Color
    mix_001.inputs[6].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.002
    mix_002 = black_hair.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'SCREEN'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_002.inputs[7].default_value = (0.009039043448865414, 0.009039043448865414, 0.009039043448865414, 1.0)
    
    #node Mix.003
    mix_003 = black_hair.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'SCREEN'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_003.inputs[2].default_value = 0.0
    #B_Float
    mix_003.inputs[3].default_value = 0.0
    #A_Vector
    mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_003.inputs[7].default_value = (0.005613791290670633, 0.005613791290670633, 0.005613791290670633, 1.0)
    
    #node Add Shader
    add_shader = black_hair.nodes.new("ShaderNodeAddShader")
    add_shader.name = "Add Shader"
    
    #node Add Shader.002
    add_shader_002 = black_hair.nodes.new("ShaderNodeAddShader")
    add_shader_002.name = "Add Shader.002"
    
    #node Material Output
    material_output = black_hair.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = False
    material_output.target = 'EEVEE'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Material Output.001
    material_output_001 = black_hair.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = True
    material_output_001.target = 'CYCLES'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output_001.inputs[3].default_value = 0.0
    
    #node Hair BSDF.001
    hair_bsdf_001 = black_hair.nodes.new("ShaderNodeBsdfHair")
    hair_bsdf_001.name = "Hair BSDF.001"
    hair_bsdf_001.component = 'Reflection'
    #Offset
    hair_bsdf_001.inputs[1].default_value = 0.0
    #RoughnessU
    hair_bsdf_001.inputs[2].default_value = 0.06923077255487442
    #RoughnessV
    hair_bsdf_001.inputs[3].default_value = 1.0
    #Tangent
    hair_bsdf_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #Weight
    hair_bsdf_001.inputs[5].default_value = 0.0
    
    #node Diffuse BSDF
    diffuse_bsdf = black_hair.nodes.new("ShaderNodeBsdfDiffuse")
    diffuse_bsdf.name = "Diffuse BSDF"
    #Roughness
    diffuse_bsdf.inputs[1].default_value = 0.0
    #Normal
    diffuse_bsdf.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Weight
    diffuse_bsdf.inputs[3].default_value = 0.0
    
    
    #Set locations
    mix.location = (-1120.0, 200.00003051757812)
    attribute_001.location = (-1660.0, 140.00003051757812)
    colorramp_001.location = (-1440.0, 120.00003051757812)
    attribute.location = (-1420.0, 340.0000305175781)
    colorramp.location = (-1000.0, 479.9999694824219)
    glossy_bsdf.location = (-240.0, 160.00003051757812)
    hair_bsdf.location = (-200.0, 640.0)
    add_shader_001.location = (260.0, 500.0000305175781)
    mix_001.location = (-860.0, 240.00003051757812)
    mix_002.location = (-640.0, 260.0000305175781)
    mix_003.location = (-420.0, 326.326171875)
    add_shader.location = (20.0, 300.0000305175781)
    add_shader_002.location = (480.0, 523.7575073242188)
    material_output.location = (300.0, 300.0)
    material_output_001.location = (700.000244140625, 560.6710205078125)
    hair_bsdf_001.location = (-200.0, 480.0)
    diffuse_bsdf.location = (-200.0, 300.0000305175781)
    
    #Set dimensions
    mix.width, mix.height = 140.0, 100.0
    attribute_001.width, attribute_001.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    attribute.width, attribute.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    glossy_bsdf.width, glossy_bsdf.height = 150.0, 100.0
    hair_bsdf.width, hair_bsdf.height = 150.0, 100.0
    add_shader_001.width, add_shader_001.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    add_shader.width, add_shader.height = 140.0, 100.0
    add_shader_002.width, add_shader_002.height = 140.0, 100.0
    material_output.width, material_output.height = 140.0, 100.0
    material_output_001.width, material_output_001.height = 140.0, 100.0
    hair_bsdf_001.width, hair_bsdf_001.height = 150.0, 100.0
    diffuse_bsdf.width, diffuse_bsdf.height = 150.0, 100.0
    
    #initialize black_hair links
    #mix_002.Result -> diffuse_bsdf.Color
    black_hair.links.new(mix_002.outputs[2], diffuse_bsdf.inputs[0])
    #colorramp_001.Color -> mix.Factor
    black_hair.links.new(colorramp_001.outputs[0], mix.inputs[0])
    #attribute.Color -> mix_001.Factor
    black_hair.links.new(attribute.outputs[0], mix_001.inputs[0])
    #mix.Result -> mix_001.B
    black_hair.links.new(mix.outputs[2], mix_001.inputs[7])
    #mix_001.Result -> mix_002.A
    black_hair.links.new(mix_001.outputs[2], mix_002.inputs[6])
    #attribute.Color -> colorramp.Fac
    black_hair.links.new(attribute.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> mix_002.Factor
    black_hair.links.new(colorramp.outputs[0], mix_002.inputs[0])
    #diffuse_bsdf.BSDF -> add_shader.Shader
    black_hair.links.new(diffuse_bsdf.outputs[0], add_shader.inputs[0])
    #glossy_bsdf.BSDF -> add_shader.Shader
    black_hair.links.new(glossy_bsdf.outputs[0], add_shader.inputs[1])
    #attribute_001.Color -> colorramp_001.Fac
    black_hair.links.new(attribute_001.outputs[0], colorramp_001.inputs[0])
    #mix_002.Result -> hair_bsdf.Color
    black_hair.links.new(mix_002.outputs[2], hair_bsdf.inputs[0])
    #hair_bsdf.BSDF -> add_shader_001.Shader
    black_hair.links.new(hair_bsdf.outputs[0], add_shader_001.inputs[0])
    #mix_003.Result -> hair_bsdf_001.Color
    black_hair.links.new(mix_003.outputs[2], hair_bsdf_001.inputs[0])
    #hair_bsdf_001.BSDF -> add_shader_001.Shader
    black_hair.links.new(hair_bsdf_001.outputs[0], add_shader_001.inputs[1])
    #mix_002.Result -> glossy_bsdf.Color
    black_hair.links.new(mix_002.outputs[2], glossy_bsdf.inputs[0])
    #add_shader.Shader -> material_output.Surface
    black_hair.links.new(add_shader.outputs[0], material_output.inputs[0])
    #add_shader_002.Shader -> material_output_001.Surface
    black_hair.links.new(add_shader_002.outputs[0], material_output_001.inputs[0])
    #mix_002.Result -> mix_003.A
    black_hair.links.new(mix_002.outputs[2], mix_003.inputs[6])
    #add_shader_001.Shader -> add_shader_002.Shader
    black_hair.links.new(add_shader_001.outputs[0], add_shader_002.inputs[0])
    return black_hair

black_hair = black_hair_node_group()

