import bpy, mathutils

mat = bpy.data.materials.new(name = "Scifi Stars White")
mat.use_nodes = True
#initialize Scifi_Stars_White node group
def scifi_stars_white_node_group():

    scifi_stars_white = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Scifi_Stars_White")
    
    #initialize scifi_stars_white nodes
    #node ColorRamp
    colorramp = scifi_stars_white.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.7636359333992004)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Bump
    bump = scifi_stars_white.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp.001
    colorramp_001 = scifi_stars_white.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Texture Coordinate.001
    texture_coordinate_001 = scifi_stars_white.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math.018
    vector_math_018 = scifi_stars_white.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node ColorRamp.002
    colorramp_002 = scifi_stars_white.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.13395129144191742, 0.13395129144191742, 0.13395129144191742, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = scifi_stars_white.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Invert
    invert = scifi_stars_white.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Voronoi Texture
    voronoi_texture = scifi_stars_white.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    
    #node Group Output
    group_output = scifi_stars_white.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #scifi_stars_white outputs
    #output BSDF
    scifi_stars_white.outputs.new('NodeSocketShader', "BSDF")
    scifi_stars_white.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    scifi_stars_white.outputs.new('NodeSocketColor', "Albedo")
    scifi_stars_white.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    scifi_stars_white.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    scifi_stars_white.outputs.new('NodeSocketFloat', "Mask")
    scifi_stars_white.outputs[2].default_value = 0.0
    scifi_stars_white.outputs[2].min_value = -3.4028234663852886e+38
    scifi_stars_white.outputs[2].max_value = 3.4028234663852886e+38
    scifi_stars_white.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = scifi_stars_white.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Reroute
    reroute = scifi_stars_white.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Reroute.001
    reroute_001 = scifi_stars_white.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Math
    math = scifi_stars_white.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    
    #node Mix.001
    mix_001 = scifi_stars_white.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = scifi_stars_white.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 4.0
    #Detail
    noise_texture.inputs[3].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = scifi_stars_white.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #scifi_stars_white inputs
    #input Metall Color
    scifi_stars_white.inputs.new('NodeSocketColor', "Metall Color")
    scifi_stars_white.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    scifi_stars_white.inputs[0].attribute_domain = 'POINT'
    
    #input Star Color
    scifi_stars_white.inputs.new('NodeSocketColor', "Star Color")
    scifi_stars_white.inputs[1].default_value = (0.4070702791213989, 0.06148352846503258, 1.0, 1.0)
    scifi_stars_white.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    scifi_stars_white.inputs.new('NodeSocketFloat', "Scale")
    scifi_stars_white.inputs[2].default_value = 1.0
    scifi_stars_white.inputs[2].min_value = -10000.0
    scifi_stars_white.inputs[2].max_value = 10000.0
    scifi_stars_white.inputs[2].attribute_domain = 'POINT'
    
    #input Scale only Stars
    scifi_stars_white.inputs.new('NodeSocketFloat', "Scale only Stars")
    scifi_stars_white.inputs[3].default_value = 10.0
    scifi_stars_white.inputs[3].min_value = -1000.0
    scifi_stars_white.inputs[3].max_value = 1000.0
    scifi_stars_white.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    scifi_stars_white.inputs.new('NodeSocketFloatFactor', "Roughness")
    scifi_stars_white.inputs[4].default_value = 1.0
    scifi_stars_white.inputs[4].min_value = 0.0
    scifi_stars_white.inputs[4].max_value = 1.0
    scifi_stars_white.inputs[4].attribute_domain = 'POINT'
    
    #input Randomness
    scifi_stars_white.inputs.new('NodeSocketFloatFactor', "Randomness")
    scifi_stars_white.inputs[5].default_value = 1.0
    scifi_stars_white.inputs[5].min_value = 0.0
    scifi_stars_white.inputs[5].max_value = 1.0
    scifi_stars_white.inputs[5].attribute_domain = 'POINT'
    
    #input Emission Strength
    scifi_stars_white.inputs.new('NodeSocketFloat', "Emission Strength")
    scifi_stars_white.inputs[6].default_value = 9.399999618530273
    scifi_stars_white.inputs[6].min_value = -10000.0
    scifi_stars_white.inputs[6].max_value = 10000.0
    scifi_stars_white.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    scifi_stars_white.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    scifi_stars_white.inputs[7].default_value = 0.5
    scifi_stars_white.inputs[7].min_value = 0.0
    scifi_stars_white.inputs[7].max_value = 1.0
    scifi_stars_white.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    scifi_stars_white.inputs.new('NodeSocketVector', "Normal")
    scifi_stars_white.inputs[8].default_value = (0.0, 0.0, 0.0)
    scifi_stars_white.inputs[8].min_value = -1.0
    scifi_stars_white.inputs[8].max_value = 1.0
    scifi_stars_white.inputs[8].attribute_domain = 'POINT'
    scifi_stars_white.inputs[8].hide_value = True
    
    
    
    
    #Set locations
    colorramp.location = (455.7393798828125, 190.62301635742188)
    bump.location = (804.3973388671875, -250.0)
    colorramp_001.location = (484.3973388671875, -86.28701782226562)
    texture_coordinate_001.location = (-1139.549072265625, -109.99993896484375)
    vector_math_018.location = (-799.549072265625, -30.0)
    colorramp_002.location = (767.53759765625, 202.1576385498047)
    mix.location = (1025.8814697265625, 164.04931640625)
    invert.location = (-700.0, 99.99996948242188)
    voronoi_texture.location = (220.450927734375, 170.0)
    group_output.location = (1539.9998779296875, 0.0)
    principled_bsdf.location = (1260.0, 240.0)
    reroute.location = (-53.45185089111328, 36.06505584716797)
    reroute_001.location = (241.81451416015625, -208.14141845703125)
    math.location = (775.450927734375, -34.452056884765625)
    mix_001.location = (580.0, 360.70245361328125)
    noise_texture.location = (-119.549072265625, -10.0)
    group_input.location = (-1339.549072265625, -0.0)
    
    #Set dimensions
    colorramp.width, colorramp.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    math.width, math.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize scifi_stars_white links
    #principled_bsdf.BSDF -> group_output.BSDF
    scifi_stars_white.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #voronoi_texture.Distance -> colorramp.Fac
    scifi_stars_white.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #math.Value -> principled_bsdf.Emission Strength
    scifi_stars_white.links.new(math.outputs[0], principled_bsdf.inputs[20])
    #bump.Normal -> principled_bsdf.Normal
    scifi_stars_white.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp_001.Color -> bump.Height
    scifi_stars_white.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #colorramp.Color -> math.Value
    scifi_stars_white.links.new(colorramp.outputs[0], math.inputs[0])
    #voronoi_texture.Distance -> colorramp_001.Fac
    scifi_stars_white.links.new(voronoi_texture.outputs[0], colorramp_001.inputs[0])
    #mix.Result -> principled_bsdf.Roughness
    scifi_stars_white.links.new(mix.outputs[2], principled_bsdf.inputs[9])
    #voronoi_texture.Color -> colorramp_002.Fac
    scifi_stars_white.links.new(voronoi_texture.outputs[1], colorramp_002.inputs[0])
    #noise_texture.Fac -> voronoi_texture.Exponent
    scifi_stars_white.links.new(noise_texture.outputs[0], voronoi_texture.inputs[4])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    scifi_stars_white.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> voronoi_texture.Vector
    scifi_stars_white.links.new(vector_math_018.outputs[0], voronoi_texture.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    scifi_stars_white.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    scifi_stars_white.links.new(group_input.outputs[2], vector_math_018.inputs[3])
    #group_input.Scale only Stars -> voronoi_texture.Scale
    scifi_stars_white.links.new(group_input.outputs[3], voronoi_texture.inputs[2])
    #colorramp_002.Color -> mix.A
    scifi_stars_white.links.new(colorramp_002.outputs[0], mix.inputs[6])
    #invert.Color -> mix.Factor
    scifi_stars_white.links.new(invert.outputs[0], mix.inputs[0])
    #group_input.Roughness -> invert.Color
    scifi_stars_white.links.new(group_input.outputs[4], invert.inputs[1])
    #group_input.Randomness -> voronoi_texture.Randomness
    scifi_stars_white.links.new(group_input.outputs[5], voronoi_texture.inputs[5])
    #group_input.Emission Strength -> math.Value
    scifi_stars_white.links.new(group_input.outputs[6], math.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    scifi_stars_white.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    scifi_stars_white.links.new(group_input.outputs[8], bump.inputs[3])
    #reroute_001.Output -> principled_bsdf.Emission
    scifi_stars_white.links.new(reroute_001.outputs[0], principled_bsdf.inputs[19])
    #reroute.Output -> principled_bsdf.Base Color
    scifi_stars_white.links.new(reroute.outputs[0], principled_bsdf.inputs[0])
    #voronoi_texture.Distance -> group_output.Mask
    scifi_stars_white.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #group_input.Metall Color -> reroute.Input
    scifi_stars_white.links.new(group_input.outputs[0], reroute.inputs[0])
    #reroute.Output -> mix_001.A
    scifi_stars_white.links.new(reroute.outputs[0], mix_001.inputs[6])
    #group_input.Star Color -> reroute_001.Input
    scifi_stars_white.links.new(group_input.outputs[1], reroute_001.inputs[0])
    #reroute_001.Output -> mix_001.B
    scifi_stars_white.links.new(reroute_001.outputs[0], mix_001.inputs[7])
    #math.Value -> mix_001.Factor
    scifi_stars_white.links.new(math.outputs[0], mix_001.inputs[0])
    #mix_001.Result -> group_output.Albedo
    scifi_stars_white.links.new(mix_001.outputs[2], group_output.inputs[1])
    return scifi_stars_white

scifi_stars_white = scifi_stars_white_node_group()

#initialize Scifi Stars White node group
def scifi_stars_white_1_node_group():

    scifi_stars_white_1 = mat.node_tree
    #start with a clean node tree
    for node in scifi_stars_white_1.nodes:
        scifi_stars_white_1.nodes.remove(node)
    #initialize scifi_stars_white_1 nodes
    #node Material Output
    material_output = scifi_stars_white_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Scifi_Stars_White
    scifi_stars_white_2 = scifi_stars_white_1.nodes.new("ShaderNodeGroup")
    scifi_stars_white_2.label = "Scifi_Stars_White"
    scifi_stars_white_2.name = "Scifi_Stars_White"
    scifi_stars_white_2.node_tree = scifi_stars_white
    #Input_9
    scifi_stars_white_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_8
    scifi_stars_white_2.inputs[1].default_value = (0.4070702791213989, 0.06148352846503258, 1.0, 1.0)
    #Input_1
    scifi_stars_white_2.inputs[2].default_value = 1.0
    #Input_2
    scifi_stars_white_2.inputs[3].default_value = 10.0
    #Input_3
    scifi_stars_white_2.inputs[4].default_value = 1.0
    #Input_4
    scifi_stars_white_2.inputs[5].default_value = 1.0
    #Input_5
    scifi_stars_white_2.inputs[6].default_value = 9.399999618530273
    #Input_6
    scifi_stars_white_2.inputs[7].default_value = 0.5
    #Input_7
    scifi_stars_white_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (667.6962890625, 60.080810546875)
    scifi_stars_white_2.location = (380.6396484375, 60.080810546875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    scifi_stars_white_2.width, scifi_stars_white_2.height = 208.318603515625, 100.0
    
    #initialize scifi_stars_white_1 links
    #scifi_stars_white_2.BSDF -> material_output.Surface
    scifi_stars_white_1.links.new(scifi_stars_white_2.outputs[0], material_output.inputs[0])
    return scifi_stars_white_1

scifi_stars_white_1 = scifi_stars_white_1_node_group()

