import bpy
import os
import math
import sys
import pandas as pd
import google.generativeai as genai
import numpy as np
from pathlib import Path

def clear_scene():
    """
    Removes all mesh and text objects from the scene.
    """
    bpy.ops.object.select_all(action='DESELECT')
    
    # Delete all mesh objects
    bpy.ops.object.select_by_type(type='MESH')
    bpy.ops.object.delete()
    
    # Delete all text objects
    bpy.ops.object.select_by_type(type='FONT')
    bpy.ops.object.delete()
    
    # Delete all cameras
    bpy.ops.object.select_by_type(type='CAMERA')
    bpy.ops.object.delete()
    
    # Delete all lights
    bpy.ops.object.select_by_type(type='LIGHT')
    bpy.ops.object.delete()

def create_cube():
    """
    Creates a cube in the scene.
    """
    bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 0))
    cube = bpy.context.active_object
    cube.name = "Material_Cube"
    return cube

def setup_camera():
    """
    Adds a camera to the scene and positions it to point at the cube.
    """
    bpy.ops.object.camera_add(location=(5, -5, 5), rotation=(math.radians(60), 0, math.radians(45)))
    camera = bpy.context.active_object
    bpy.context.scene.camera = camera

def setup_light():
    """
    Adds a light source to illuminate the cube.
    """
    bpy.ops.object.light_add(type='POINT', location=(4, -4, 6))
    light = bpy.context.active_object
    light.data.energy = 1000

def render_material(cube, material, output_path):
    """
    Applies a material to the cube, renders the scene, and saves the image.
    """
    # Apply the material to the cube
    if cube.data.materials:
        cube.data.materials[0] = material
    else:
        cube.data.materials.append(material)

    # Set render settings
    bpy.context.scene.render.filepath = output_path
    bpy.context.scene.render.resolution_x = 1024
    bpy.context.scene.render.resolution_y = 1024
    bpy.context.scene.render.image_settings.file_format = 'PNG'

    # Render and save image
    bpy.ops.render.render(write_still=True)
    print(f"Rendered {material.name} and saved to {output_path}")

def main():
    bpy.ops.wm.open_mainfile(filepath="Material Pack Simple v1.3 (copy).blend")

    # Path to save each render
    output_path = os.path.join(os.path.expanduser("~"), "temp.png")

    # Clear scene of any existing objects
    clear_scene()

    # Create a cube object
    cube = create_cube()
    
    # prepare model
    model = genai.GenerativeModel("gemini-1.5-flash")
    genai.configure(api_key=os.environ['GEM_KEY'])

    # outfile
    res = ''
    
    # Set up camera and light for visibility
    setup_camera()
    setup_light()

    # Cycle through each material in the .blend file
    for material in bpy.data.materials:
        render_material(cube, material, output_path)
        
        # upload image to gemini and get a response
        img = genai.upload_file(f'/home/omega/temp.png')
        response = model.generate_content(img, f'Please briefly describe the material shown in the image for a RAG dataset. You may use the name of the material, {material.name} as a hint but note it might be misleading.')

        print(material.name + ":" + response.text)

        # clear files from gemini
        for f in genai.list_files():
            f.delete()
        
        res = res + '\n' + material.name + ":" + response.text
    
    with Path('outfile.txt').open("w") as f:
        f.write(res)
        
        

if __name__ == "__main__":
    main()
