import bpy, mathutils

mat = bpy.data.materials.new(name = "Panel1")
mat.use_nodes = True
#initialize Panel1 node group
def panel1_node_group():

    panel1 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Panel1")
    
    #initialize panel1 nodes
    #node Voronoi Texture
    voronoi_texture = panel1.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 72.69999694824219
    #Randomness
    voronoi_texture.inputs[5].default_value = 0.0
    
    #node Bump
    bump = panel1.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = panel1.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = panel1.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math
    vector_math = panel1.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Group Output
    group_output = panel1.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #panel1 outputs
    #output BSDF
    panel1.outputs.new('NodeSocketShader', "BSDF")
    panel1.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    panel1.outputs.new('NodeSocketFloat', "Mask")
    panel1.outputs[1].default_value = 0.0
    panel1.outputs[1].min_value = -3.4028234663852886e+38
    panel1.outputs[1].max_value = 3.4028234663852886e+38
    panel1.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Mix
    mix = panel1.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'DODGE'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Group Input
    group_input = panel1.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #panel1 inputs
    #input Scale
    panel1.inputs.new('NodeSocketFloat', "Scale")
    panel1.inputs[0].default_value = 1.0
    panel1.inputs[0].min_value = -10000.0
    panel1.inputs[0].max_value = 10000.0
    panel1.inputs[0].attribute_domain = 'POINT'
    
    #input Base Color
    panel1.inputs.new('NodeSocketColor', "Base Color")
    panel1.inputs[1].default_value = (0.07728829234838486, 0.11064540594816208, 0.12903021275997162, 1.0)
    panel1.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    panel1.inputs.new('NodeSocketFloatFactor', "Roughness")
    panel1.inputs[2].default_value = 0.5
    panel1.inputs[2].min_value = 0.0
    panel1.inputs[2].max_value = 1.0
    panel1.inputs[2].attribute_domain = 'POINT'
    
    #input Dot Scale
    panel1.inputs.new('NodeSocketFloatFactor', "Dot Scale")
    panel1.inputs[3].default_value = 0.8333333730697632
    panel1.inputs[3].min_value = 0.0
    panel1.inputs[3].max_value = 1.0
    panel1.inputs[3].attribute_domain = 'POINT'
    
    #input Bump Strength
    panel1.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    panel1.inputs[4].default_value = 1.0
    panel1.inputs[4].min_value = 0.0
    panel1.inputs[4].max_value = 1.0
    panel1.inputs[4].attribute_domain = 'POINT'
    
    #input Normal
    panel1.inputs.new('NodeSocketVector', "Normal")
    panel1.inputs[5].default_value = (0.0, 0.0, 0.0)
    panel1.inputs[5].min_value = -1.0
    panel1.inputs[5].max_value = 1.0
    panel1.inputs[5].attribute_domain = 'POINT'
    panel1.inputs[5].hide_value = True
    
    
    
    #node Invert
    invert = panel1.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    
    #Set locations
    voronoi_texture.location = (-138.5, 70.00001525878906)
    bump.location = (721.5, -150.00001525878906)
    principled_bsdf.location = (938.5, 90.00001525878906)
    texture_coordinate_001.location = (-938.5, 70.00001525878906)
    vector_math.location = (-598.5, 150.00001525878906)
    group_output.location = (1228.5, -0.0)
    mix.location = (220.96063232421875, -55.006317138671875)
    group_input.location = (-1138.5, -0.0)
    invert.location = (-360.0, -60.0)
    
    #Set dimensions
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    
    #initialize panel1 links
    #principled_bsdf.BSDF -> group_output.BSDF
    panel1.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #voronoi_texture.Distance -> mix.A
    panel1.links.new(voronoi_texture.outputs[0], mix.inputs[6])
    #bump.Normal -> principled_bsdf.Normal
    panel1.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #texture_coordinate_001.UV -> vector_math.Vector
    panel1.links.new(texture_coordinate_001.outputs[2], vector_math.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    panel1.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    panel1.links.new(group_input.outputs[0], vector_math.inputs[3])
    #mix.Result -> bump.Height
    panel1.links.new(mix.outputs[2], bump.inputs[2])
    #group_input.Base Color -> principled_bsdf.Base Color
    panel1.links.new(group_input.outputs[1], principled_bsdf.inputs[0])
    #group_input.Dot Scale -> invert.Color
    panel1.links.new(group_input.outputs[3], invert.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    panel1.links.new(group_input.outputs[4], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    panel1.links.new(group_input.outputs[5], bump.inputs[3])
    #group_input.Roughness -> principled_bsdf.Roughness
    panel1.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #invert.Color -> mix.Factor
    panel1.links.new(invert.outputs[0], mix.inputs[0])
    #voronoi_texture.Distance -> group_output.Mask
    panel1.links.new(voronoi_texture.outputs[0], group_output.inputs[1])
    return panel1

panel1 = panel1_node_group()

#initialize Panel1 node group
def panel1_1_node_group():

    panel1_1 = mat.node_tree
    #start with a clean node tree
    for node in panel1_1.nodes:
        panel1_1.nodes.remove(node)
    #initialize panel1_1 nodes
    #node Material Output
    material_output = panel1_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Panel1
    panel1_2 = panel1_1.nodes.new("ShaderNodeGroup")
    panel1_2.label = "Panel1"
    panel1_2.name = "Panel1"
    panel1_2.node_tree = panel1
    #Input_1
    panel1_2.inputs[0].default_value = 1.0
    #Input_2
    panel1_2.inputs[1].default_value = (0.07728829234838486, 0.11064540594816208, 0.12903021275997162, 1.0)
    #Input_4
    panel1_2.inputs[2].default_value = 0.5
    #Input_3
    panel1_2.inputs[3].default_value = 0.1205945760011673
    #Input_5
    panel1_2.inputs[4].default_value = 1.0
    #Input_6
    panel1_2.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (671.1943359375, 70.4775390625)
    panel1_2.location = (417.00830078125, 70.4775390625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    panel1_2.width, panel1_2.height = 177.18649291992188, 100.0
    
    #initialize panel1_1 links
    #panel1_2.BSDF -> material_output.Surface
    panel1_1.links.new(panel1_2.outputs[0], material_output.inputs[0])
    return panel1_1

panel1_1 = panel1_1_node_group()

