import bpy, mathutils

mat = bpy.data.materials.new(name = "Clover Pattern")
mat.use_nodes = True
#initialize Clover pattern node group
def clover_pattern_node_group():

    clover_pattern = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Clover pattern")
    
    #initialize clover_pattern nodes
    #node ColorRamp.002
    colorramp_002 = clover_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.44090908765792847
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.5)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Texture Coordinate
    texture_coordinate = clover_pattern.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Vector Math
    vector_math = clover_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Voronoi Texture.001
    voronoi_texture_001 = clover_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'MINKOWSKI'
    voronoi_texture_001.feature = 'F1'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #W
    voronoi_texture_001.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture_001.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture_001.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture_001.inputs[4].default_value = 0.6799999475479126
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = clover_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture.inputs[2].default_value = 70.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 0.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.4999999403953552
    #Randomness
    voronoi_texture.inputs[5].default_value = 0.0
    
    #node Mix.008
    mix_008 = clover_pattern.nodes.new("ShaderNodeMix")
    mix_008.name = "Mix.008"
    mix_008.blend_type = 'MIX'
    mix_008.clamp_factor = True
    mix_008.clamp_result = False
    mix_008.data_type = 'RGBA'
    mix_008.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_008.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_008.inputs[2].default_value = 0.0
    #B_Float
    mix_008.inputs[3].default_value = 0.0
    #A_Vector
    mix_008.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_008.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.001
    mix_001 = clover_pattern.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'BURN'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_001.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Output
    group_output = clover_pattern.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #clover_pattern outputs
    #output BSDF
    clover_pattern.outputs.new('NodeSocketShader', "BSDF")
    clover_pattern.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    clover_pattern.outputs.new('NodeSocketColor', "Mask")
    clover_pattern.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    clover_pattern.outputs[1].attribute_domain = 'POINT'
    
    #output Soft Mask
    clover_pattern.outputs.new('NodeSocketColor', "Soft Mask")
    clover_pattern.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    clover_pattern.outputs[2].attribute_domain = 'POINT'
    
    #output Albedo
    clover_pattern.outputs.new('NodeSocketColor', "Albedo")
    clover_pattern.outputs[3].default_value = (0.0, 0.0, 0.0, 0.0)
    clover_pattern.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Bump
    bump = clover_pattern.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = clover_pattern.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #clover_pattern inputs
    #input Color1
    clover_pattern.inputs.new('NodeSocketColor', "Color1")
    clover_pattern.inputs[0].default_value = (0.3329702317714691, 0.3329702317714691, 0.3329702317714691, 1.0)
    clover_pattern.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    clover_pattern.inputs.new('NodeSocketColor', "Color2")
    clover_pattern.inputs[1].default_value = (0.1691574603319168, 1.0, 0.053085558116436005, 1.0)
    clover_pattern.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    clover_pattern.inputs.new('NodeSocketFloat', "Scale")
    clover_pattern.inputs[2].default_value = 0.5
    clover_pattern.inputs[2].min_value = -10000.0
    clover_pattern.inputs[2].max_value = 10000.0
    clover_pattern.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    clover_pattern.inputs.new('NodeSocketFloatFactor', "Roughness")
    clover_pattern.inputs[3].default_value = 0.5
    clover_pattern.inputs[3].min_value = 0.0
    clover_pattern.inputs[3].max_value = 1.0
    clover_pattern.inputs[3].attribute_domain = 'POINT'
    
    #input Mix
    clover_pattern.inputs.new('NodeSocketFloatFactor', "Mix")
    clover_pattern.inputs[4].default_value = 0.7749999761581421
    clover_pattern.inputs[4].min_value = 0.0
    clover_pattern.inputs[4].max_value = 1.0
    clover_pattern.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    clover_pattern.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    clover_pattern.inputs[5].default_value = 1.0
    clover_pattern.inputs[5].min_value = 0.0
    clover_pattern.inputs[5].max_value = 1.0
    clover_pattern.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    clover_pattern.inputs.new('NodeSocketVector', "Normal")
    clover_pattern.inputs[6].default_value = (0.0, 0.0, 0.0)
    clover_pattern.inputs[6].min_value = -1.0
    clover_pattern.inputs[6].max_value = 1.0
    clover_pattern.inputs[6].attribute_domain = 'POINT'
    clover_pattern.inputs[6].hide_value = True
    
    
    
    #node Principled BSDF
    principled_bsdf = clover_pattern.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Vector Math.001
    vector_math_001 = clover_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'ADD'
    #Vector_001
    vector_math_001.inputs[1].default_value = (0.007000000216066837, 0.007000000216066837, 0.0)
    #Vector_002
    vector_math_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_001.inputs[3].default_value = 1.0
    
    #node Mix.009
    mix_009 = clover_pattern.nodes.new("ShaderNodeMix")
    mix_009.name = "Mix.009"
    mix_009.blend_type = 'SCREEN'
    mix_009.clamp_factor = True
    mix_009.clamp_result = False
    mix_009.data_type = 'RGBA'
    mix_009.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_009.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_009.inputs[2].default_value = 0.0
    #B_Float
    mix_009.inputs[3].default_value = 0.0
    #A_Vector
    mix_009.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_009.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.002
    mix_002 = clover_pattern.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'DODGE'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.8166666626930237
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix
    mix = clover_pattern.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    colorramp_002.location = (-490.0, 267.8146667480469)
    texture_coordinate.location = (-990.0, -27.814666748046875)
    vector_math.location = (-770.0, -27.814666748046875)
    voronoi_texture_001.location = (-450.0, -227.81466674804688)
    voronoi_texture.location = (-450.0, 52.185333251953125)
    mix_008.location = (-211.3099365234375, 175.05270385742188)
    mix_001.location = (142.8900146484375, -7.687713623046875)
    group_output.location = (1280.0, -0.0)
    bump.location = (630.0, -267.8146667480469)
    group_input.location = (-1190.0, -0.0)
    principled_bsdf.location = (990.0, 152.18536376953125)
    vector_math_001.location = (-620.0, -160.0)
    mix_009.location = (-30.0, -7.814697265625)
    mix_002.location = (340.7484130859375, 15.02508544921875)
    mix.location = (710.0, 112.18533325195312)
    
    #Set dimensions
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    mix_008.width, mix_008.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    vector_math_001.width, vector_math_001.height = 140.0, 100.0
    mix_009.width, mix_009.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    
    #initialize clover_pattern links
    #principled_bsdf.BSDF -> group_output.BSDF
    clover_pattern.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    clover_pattern.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #texture_coordinate.UV -> vector_math.Vector
    clover_pattern.links.new(texture_coordinate.outputs[2], vector_math.inputs[0])
    #vector_math_001.Vector -> voronoi_texture_001.Vector
    clover_pattern.links.new(vector_math_001.outputs[0], voronoi_texture_001.inputs[0])
    #vector_math.Vector -> vector_math_001.Vector
    clover_pattern.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
    #voronoi_texture.Color -> mix_008.A
    clover_pattern.links.new(voronoi_texture.outputs[1], mix_008.inputs[6])
    #colorramp_002.Color -> mix_008.Factor
    clover_pattern.links.new(colorramp_002.outputs[0], mix_008.inputs[0])
    #voronoi_texture_001.Color -> mix_008.B
    clover_pattern.links.new(voronoi_texture_001.outputs[1], mix_008.inputs[7])
    #voronoi_texture_001.Distance -> colorramp_002.Fac
    clover_pattern.links.new(voronoi_texture_001.outputs[0], colorramp_002.inputs[0])
    #mix_008.Result -> mix_009.Factor
    clover_pattern.links.new(mix_008.outputs[2], mix_009.inputs[0])
    #voronoi_texture.Distance -> mix_009.A
    clover_pattern.links.new(voronoi_texture.outputs[0], mix_009.inputs[6])
    #voronoi_texture_001.Distance -> mix_009.B
    clover_pattern.links.new(voronoi_texture_001.outputs[0], mix_009.inputs[7])
    #bump.Normal -> principled_bsdf.Normal
    clover_pattern.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix_002.Result -> mix.Factor
    clover_pattern.links.new(mix_002.outputs[2], mix.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    clover_pattern.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #mix_009.Result -> mix_001.A
    clover_pattern.links.new(mix_009.outputs[2], mix_001.inputs[6])
    #mix_001.Result -> mix_002.A
    clover_pattern.links.new(mix_001.outputs[2], mix_002.inputs[6])
    #mix_002.Result -> bump.Height
    clover_pattern.links.new(mix_002.outputs[2], bump.inputs[2])
    #group_input.Color1 -> mix.A
    clover_pattern.links.new(group_input.outputs[0], mix.inputs[6])
    #group_input.Color2 -> mix.B
    clover_pattern.links.new(group_input.outputs[1], mix.inputs[7])
    #group_input.Scale -> vector_math.Scale
    clover_pattern.links.new(group_input.outputs[2], vector_math.inputs[3])
    #group_input.Mix -> mix_001.Factor
    clover_pattern.links.new(group_input.outputs[4], mix_001.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    clover_pattern.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    clover_pattern.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    clover_pattern.links.new(group_input.outputs[6], bump.inputs[3])
    #mix_009.Result -> group_output.Soft Mask
    clover_pattern.links.new(mix_009.outputs[2], group_output.inputs[2])
    #mix_002.Result -> group_output.Mask
    clover_pattern.links.new(mix_002.outputs[2], group_output.inputs[1])
    #mix.Result -> group_output.Albedo
    clover_pattern.links.new(mix.outputs[2], group_output.inputs[3])
    return clover_pattern

clover_pattern = clover_pattern_node_group()

#initialize Clover Pattern node group
def clover_pattern_1_node_group():

    clover_pattern_1 = mat.node_tree
    #start with a clean node tree
    for node in clover_pattern_1.nodes:
        clover_pattern_1.nodes.remove(node)
    #initialize clover_pattern_1 nodes
    #node Material Output
    material_output = clover_pattern_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Clover pattern
    clover_pattern_2 = clover_pattern_1.nodes.new("ShaderNodeGroup")
    clover_pattern_2.label = "Clover pattern"
    clover_pattern_2.name = "Clover pattern"
    clover_pattern_2.node_tree = clover_pattern
    #Input_1
    clover_pattern_2.inputs[0].default_value = (0.27009642124176025, 0.27009642124176025, 0.27009642124176025, 1.0)
    #Input_2
    clover_pattern_2.inputs[1].default_value = (0.1691574603319168, 1.0, 0.053085558116436005, 1.0)
    #Input_3
    clover_pattern_2.inputs[2].default_value = 0.5
    #Input_5
    clover_pattern_2.inputs[3].default_value = 0.4000000059604645
    #Input_4
    clover_pattern_2.inputs[4].default_value = 0.7749999761581421
    #Input_6
    clover_pattern_2.inputs[5].default_value = 1.0
    #Input_7
    clover_pattern_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (672.251953125, 101.66796875)
    clover_pattern_2.location = (466.3966064453125, 100.0)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    clover_pattern_2.width, clover_pattern_2.height = 173.6033935546875, 100.0
    
    #initialize clover_pattern_1 links
    #clover_pattern_2.BSDF -> material_output.Surface
    clover_pattern_1.links.new(clover_pattern_2.outputs[0], material_output.inputs[0])
    return clover_pattern_1

clover_pattern_1 = clover_pattern_1_node_group()

