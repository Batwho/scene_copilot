import bpy, mathutils

mat = bpy.data.materials.new(name = "2Step White Texture1")
mat.use_nodes = True
#initialize 2step_white_texture1 node group
def _2step_white_texture1_node_group():

    _2step_white_texture1 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "2step_white_texture1")
    
    #initialize _2step_white_texture1 nodes
    #node Principled BSDF
    principled_bsdf = _2step_white_texture1.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Shader to RGB
    shader_to_rgb = _2step_white_texture1.nodes.new("ShaderNodeShaderToRGB")
    shader_to_rgb.name = "Shader to RGB"
    
    #node ColorRamp
    colorramp = _2step_white_texture1.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.004545455798506737)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.6318185329437256)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.001
    mix_001 = _2step_white_texture1.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'DODGE'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Mix.002
    mix_002 = _2step_white_texture1.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'BURN'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node ColorRamp.001
    colorramp_001 = _2step_white_texture1.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.2090909481048584
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.8409093618392944)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = _2step_white_texture1.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Output
    group_output = _2step_white_texture1.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #_2step_white_texture1 outputs
    #output Color
    _2step_white_texture1.outputs.new('NodeSocketColor', "Color")
    _2step_white_texture1.outputs[0].default_value = (0.0, 0.0, 0.0, 0.0)
    _2step_white_texture1.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Mix.003
    mix_003 = _2step_white_texture1.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'COLOR'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = _2step_white_texture1.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = _2step_white_texture1.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #_2step_white_texture1 inputs
    #input Color
    _2step_white_texture1.inputs.new('NodeSocketColor', "Color")
    _2step_white_texture1.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    _2step_white_texture1.inputs[0].attribute_domain = 'POINT'
    
    #input Saturation
    _2step_white_texture1.inputs.new('NodeSocketFloatFactor', "Saturation")
    _2step_white_texture1.inputs[1].default_value = 1.0
    _2step_white_texture1.inputs[1].min_value = 0.0
    _2step_white_texture1.inputs[1].max_value = 1.0
    _2step_white_texture1.inputs[1].attribute_domain = 'POINT'
    
    #input Darkening
    _2step_white_texture1.inputs.new('NodeSocketFloatFactor', "Darkening")
    _2step_white_texture1.inputs[2].default_value = 1.0
    _2step_white_texture1.inputs[2].min_value = 0.0
    _2step_white_texture1.inputs[2].max_value = 1.0
    _2step_white_texture1.inputs[2].attribute_domain = 'POINT'
    
    #input Light Threshold
    _2step_white_texture1.inputs.new('NodeSocketFloat', "Light Threshold")
    _2step_white_texture1.inputs[3].default_value = 1.0
    _2step_white_texture1.inputs[3].min_value = 0.0
    _2step_white_texture1.inputs[3].max_value = 1000.0
    _2step_white_texture1.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Scale
    _2step_white_texture1.inputs.new('NodeSocketFloat', "Noise Scale")
    _2step_white_texture1.inputs[4].default_value = 10.0
    _2step_white_texture1.inputs[4].min_value = -1000.0
    _2step_white_texture1.inputs[4].max_value = 1000.0
    _2step_white_texture1.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Detail
    _2step_white_texture1.inputs.new('NodeSocketFloat', "Noise Detail")
    _2step_white_texture1.inputs[5].default_value = 1.03000009059906
    _2step_white_texture1.inputs[5].min_value = 0.0
    _2step_white_texture1.inputs[5].max_value = 15.0
    _2step_white_texture1.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Dodge
    _2step_white_texture1.inputs.new('NodeSocketFloatFactor', "Noise Dodge")
    _2step_white_texture1.inputs[6].default_value = 0.30000001192092896
    _2step_white_texture1.inputs[6].min_value = 0.0
    _2step_white_texture1.inputs[6].max_value = 1.0
    _2step_white_texture1.inputs[6].attribute_domain = 'POINT'
    
    #input Noise Burn
    _2step_white_texture1.inputs.new('NodeSocketFloatFactor', "Noise Burn")
    _2step_white_texture1.inputs[7].default_value = 0.05000000074505806
    _2step_white_texture1.inputs[7].min_value = 0.0
    _2step_white_texture1.inputs[7].max_value = 1.0
    _2step_white_texture1.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    _2step_white_texture1.inputs.new('NodeSocketVector', "Normal")
    _2step_white_texture1.inputs[8].default_value = (0.0, 0.0, 0.0)
    _2step_white_texture1.inputs[8].min_value = -3.4028234663852886e+38
    _2step_white_texture1.inputs[8].max_value = 3.4028234663852886e+38
    _2step_white_texture1.inputs[8].attribute_domain = 'POINT'
    _2step_white_texture1.inputs[8].hide_value = True
    
    
    
    
    #Set locations
    principled_bsdf.location = (-762.1961669921875, 62.18096923828125)
    shader_to_rgb.location = (-462.1961669921875, 82.18096923828125)
    colorramp.location = (497.8038330078125, 122.18096923828125)
    mix_001.location = (57.8038330078125, 2.18096923828125)
    mix_002.location = (277.8038330078125, 22.18096923828125)
    colorramp_001.location = (-262.1961669921875, -177.81903076171875)
    mix.location = (1137.8037109375, 129.3482666015625)
    group_output.location = (1327.8037109375, -23.510467529296875)
    mix_003.location = (888.80712890625, 130.798095703125)
    noise_texture.location = (-482.1961669921875, -177.81903076171875)
    group_input.location = (-1360.0, 80.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize _2step_white_texture1 links
    #mix.Result -> group_output.Color
    _2step_white_texture1.links.new(mix.outputs[2], group_output.inputs[0])
    #principled_bsdf.BSDF -> shader_to_rgb.Shader
    _2step_white_texture1.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
    #mix_002.Result -> colorramp.Fac
    _2step_white_texture1.links.new(mix_002.outputs[2], colorramp.inputs[0])
    #mix_003.Result -> mix.A
    _2step_white_texture1.links.new(mix_003.outputs[2], mix.inputs[6])
    #shader_to_rgb.Color -> mix_001.A
    _2step_white_texture1.links.new(shader_to_rgb.outputs[0], mix_001.inputs[6])
    #colorramp_001.Color -> mix_001.B
    _2step_white_texture1.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #noise_texture.Fac -> colorramp_001.Fac
    _2step_white_texture1.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #mix_001.Result -> mix_002.A
    _2step_white_texture1.links.new(mix_001.outputs[2], mix_002.inputs[6])
    #colorramp_001.Color -> mix_002.B
    _2step_white_texture1.links.new(colorramp_001.outputs[0], mix_002.inputs[7])
    #colorramp.Color -> mix_003.A
    _2step_white_texture1.links.new(colorramp.outputs[0], mix_003.inputs[6])
    #group_input.Color -> mix_003.B
    _2step_white_texture1.links.new(group_input.outputs[0], mix_003.inputs[7])
    #group_input.Saturation -> mix_003.Factor
    _2step_white_texture1.links.new(group_input.outputs[1], mix_003.inputs[0])
    #group_input.Darkening -> mix.Factor
    _2step_white_texture1.links.new(group_input.outputs[2], mix.inputs[0])
    #group_input.Light Threshold -> principled_bsdf.Base Color
    _2step_white_texture1.links.new(group_input.outputs[3], principled_bsdf.inputs[0])
    #group_input.Noise Dodge -> mix_001.Factor
    _2step_white_texture1.links.new(group_input.outputs[6], mix_001.inputs[0])
    #group_input.Noise Burn -> mix_002.Factor
    _2step_white_texture1.links.new(group_input.outputs[7], mix_002.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    _2step_white_texture1.links.new(group_input.outputs[4], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    _2step_white_texture1.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #group_input.Normal -> principled_bsdf.Normal
    _2step_white_texture1.links.new(group_input.outputs[8], principled_bsdf.inputs[22])
    #group_input.Light Threshold -> principled_bsdf.Specular
    _2step_white_texture1.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    return _2step_white_texture1

_2step_white_texture1 = _2step_white_texture1_node_group()

#initialize 2Step White Texture1 node group
def _2step_white_texture1_1_node_group():

    _2step_white_texture1_1 = mat.node_tree
    #start with a clean node tree
    for node in _2step_white_texture1_1.nodes:
        _2step_white_texture1_1.nodes.remove(node)
    #initialize _2step_white_texture1_1 nodes
    #node Material Output
    material_output = _2step_white_texture1_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node 2step_white_texture1
    _2step_white_texture1_2 = _2step_white_texture1_1.nodes.new("ShaderNodeGroup")
    _2step_white_texture1_2.label = "2step_white_texture1"
    _2step_white_texture1_2.name = "2step_white_texture1"
    _2step_white_texture1_2.node_tree = _2step_white_texture1
    #Input_1
    _2step_white_texture1_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_2
    _2step_white_texture1_2.inputs[1].default_value = 1.0
    #Input_3
    _2step_white_texture1_2.inputs[2].default_value = 0.0
    #Input_4
    _2step_white_texture1_2.inputs[3].default_value = 1.0
    #Input_7
    _2step_white_texture1_2.inputs[4].default_value = 10.0
    #Input_8
    _2step_white_texture1_2.inputs[5].default_value = 1.03000009059906
    #Input_5
    _2step_white_texture1_2.inputs[6].default_value = 0.30000001192092896
    #Input_6
    _2step_white_texture1_2.inputs[7].default_value = 0.05000000074505806
    #Input_9
    _2step_white_texture1_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (671.826171875, 91.719482421875)
    _2step_white_texture1_2.location = (392.2470703125, 91.719482421875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    _2step_white_texture1_2.width, _2step_white_texture1_2.height = 187.923828125, 100.0
    
    #initialize _2step_white_texture1_1 links
    #_2step_white_texture1_2.Color -> material_output.Surface
    _2step_white_texture1_1.links.new(_2step_white_texture1_2.outputs[0], material_output.inputs[0])
    return _2step_white_texture1_1

_2step_white_texture1_1 = _2step_white_texture1_1_node_group()

