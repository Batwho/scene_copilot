import bpy, mathutils

mat = bpy.data.materials.new(name = "Lava")
mat.use_nodes = True
#initialize Lava node group
def lava_node_group():

    lava = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Lava")
    
    #initialize lava nodes
    #node Principled BSDF
    principled_bsdf = lava.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = lava.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp
    colorramp = lava.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.21818165481090546
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.09263043105602264, 0.020465407520532608, 0.008863605558872223, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = lava.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.5863633751869202
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.85909104347229)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = lava.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.6409088373184204
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (1.0, 0.0, 0.0016513625159859657, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.8863632678985596)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 0.8954322934150696, 0.17887185513973236, 1.0)

    colorramp_002_cre_2 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_2.alpha = 1.0
    colorramp_002_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.003
    colorramp_003 = lava.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.004545369651168585
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.6590912342071533)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = lava.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.7583333253860474
    
    #node Mix.001
    mix_001 = lava.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'ADD'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.7749999761581421
    
    #node Noise Texture
    noise_texture = lava.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 4.360000133514404
    #Roughness
    noise_texture.inputs[4].default_value = 0.6916666626930237
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Texture Coordinate.001
    texture_coordinate_001 = lava.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math
    vector_math = lava.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Group Output
    group_output = lava.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #lava outputs
    #output BSDF
    lava.outputs.new('NodeSocketShader', "BSDF")
    lava.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    lava.outputs.new('NodeSocketColor', "Albedo")
    lava.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    lava.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    lava.outputs.new('NodeSocketColor', "Mask")
    lava.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    lava.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Hue Saturation Value.001
    hue_saturation_value_001 = lava.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value_001.name = "Hue Saturation Value.001"
    #Fac
    hue_saturation_value_001.inputs[3].default_value = 1.0
    
    #node Invert
    invert = lava.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.001
    math_001 = lava.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    
    #node Voronoi Texture
    voronoi_texture = lava.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Hue Saturation Value
    hue_saturation_value = lava.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Math
    math = lava.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    
    #node Mix.002
    mix_002 = lava.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node Noise Texture.001
    noise_texture_001 = lava.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 1.4600002765655518
    #Detail
    noise_texture_001.inputs[3].default_value = 2.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.6916666626930237
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = lava.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #lava inputs
    #input Scale
    lava.inputs.new('NodeSocketFloat', "Scale")
    lava.inputs[0].default_value = 1.0
    lava.inputs[0].min_value = -10000.0
    lava.inputs[0].max_value = 10000.0
    lava.inputs[0].attribute_domain = 'POINT'
    
    #input Rings Amount
    lava.inputs.new('NodeSocketFloat', "Rings Amount")
    lava.inputs[1].default_value = 4.110000133514404
    lava.inputs[1].min_value = -1000.0
    lava.inputs[1].max_value = 1000.0
    lava.inputs[1].attribute_domain = 'POINT'
    
    #input Color hue
    lava.inputs.new('NodeSocketFloatFactor', "Color hue")
    lava.inputs[2].default_value = 1.0
    lava.inputs[2].min_value = 0.0
    lava.inputs[2].max_value = 1.0
    lava.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    lava.inputs.new('NodeSocketFloat', "Saturation")
    lava.inputs[3].default_value = 1.0
    lava.inputs[3].min_value = 0.0
    lava.inputs[3].max_value = 2.0
    lava.inputs[3].attribute_domain = 'POINT'
    
    #input Brightness
    lava.inputs.new('NodeSocketFloat', "Brightness")
    lava.inputs[4].default_value = 1.0
    lava.inputs[4].min_value = 0.0
    lava.inputs[4].max_value = 2.0
    lava.inputs[4].attribute_domain = 'POINT'
    
    #input Specular
    lava.inputs.new('NodeSocketFloatFactor', "Specular")
    lava.inputs[5].default_value = 0.054545462131500244
    lava.inputs[5].min_value = 0.0
    lava.inputs[5].max_value = 1.0
    lava.inputs[5].attribute_domain = 'POINT'
    
    #input Roughness
    lava.inputs.new('NodeSocketFloatFactor', "Roughness")
    lava.inputs[6].default_value = 0.6863636374473572
    lava.inputs[6].min_value = 0.0
    lava.inputs[6].max_value = 1.0
    lava.inputs[6].attribute_domain = 'POINT'
    
    #input Detail
    lava.inputs.new('NodeSocketFloat', "Detail")
    lava.inputs[7].default_value = 8.0
    lava.inputs[7].min_value = 0.0
    lava.inputs[7].max_value = 15.0
    lava.inputs[7].attribute_domain = 'POINT'
    
    #input Emission
    lava.inputs.new('NodeSocketFloat', "Emission")
    lava.inputs[8].default_value = 12.499999046325684
    lava.inputs[8].min_value = -10000.0
    lava.inputs[8].max_value = 10000.0
    lava.inputs[8].attribute_domain = 'POINT'
    
    #input Bump Strength
    lava.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    lava.inputs[9].default_value = 1.0
    lava.inputs[9].min_value = 0.0
    lava.inputs[9].max_value = 1.0
    lava.inputs[9].attribute_domain = 'POINT'
    
    #input Normal
    lava.inputs.new('NodeSocketVector', "Normal")
    lava.inputs[10].default_value = (0.0, 0.0, 0.0)
    lava.inputs[10].min_value = -1.0
    lava.inputs[10].max_value = 1.0
    lava.inputs[10].attribute_domain = 'POINT'
    lava.inputs[10].hide_value = True
    
    
    
    
    #Set locations
    principled_bsdf.location = (1170.0159912109375, 260.21038818359375)
    bump.location = (609.9840087890625, -239.7895965576172)
    colorramp.location = (289.9840393066406, 220.21038818359375)
    colorramp_001.location = (389.9840393066406, -19.78961181640625)
    colorramp_002.location = (44.410308837890625, -57.254241943359375)
    colorramp_003.location = (289.9840393066406, -260.21038818359375)
    mix.location = (-370.0159606933594, 120.21038818359375)
    mix_001.location = (-150.01596069335938, 120.21038818359375)
    noise_texture.location = (-630.0159912109375, -99.78959655761719)
    texture_coordinate_001.location = (-1170.0159912109375, 40.21038818359375)
    vector_math.location = (-830.0159912109375, 120.2103271484375)
    group_output.location = (1460.0159912109375, -0.0)
    hue_saturation_value_001.location = (906.9466552734375, 236.989990234375)
    invert.location = (360.0, 360.0)
    math_001.location = (543.5709228515625, 394.71417236328125)
    voronoi_texture.location = (69.98403930664062, 220.21038818359375)
    hue_saturation_value.location = (920.0, -100.0)
    math.location = (709.9840087890625, -71.9337158203125)
    mix_002.location = (1180.0, 445.6367492675781)
    noise_texture_001.location = (-370.0159606933594, -79.78961181640625)
    group_input.location = (-1370.0159912109375, -0.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    hue_saturation_value_001.width, hue_saturation_value_001.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    math.width, math.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize lava links
    #principled_bsdf.BSDF -> group_output.BSDF
    lava.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #hue_saturation_value_001.Color -> principled_bsdf.Base Color
    lava.links.new(hue_saturation_value_001.outputs[0], principled_bsdf.inputs[0])
    #voronoi_texture.Distance -> colorramp.Fac
    lava.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #mix_001.Result -> voronoi_texture.Vector
    lava.links.new(mix_001.outputs[2], voronoi_texture.inputs[0])
    #noise_texture.Fac -> mix.B
    lava.links.new(noise_texture.outputs[0], mix.inputs[7])
    #bump.Normal -> principled_bsdf.Normal
    lava.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp_003.Color -> bump.Height
    lava.links.new(colorramp_003.outputs[0], bump.inputs[2])
    #math.Value -> principled_bsdf.Emission Strength
    lava.links.new(math.outputs[0], principled_bsdf.inputs[20])
    #voronoi_texture.Distance -> colorramp_001.Fac
    lava.links.new(voronoi_texture.outputs[0], colorramp_001.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Emission
    lava.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[19])
    #voronoi_texture.Distance -> colorramp_002.Fac
    lava.links.new(voronoi_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_001.Color -> math.Value
    lava.links.new(colorramp_001.outputs[0], math.inputs[0])
    #voronoi_texture.Distance -> colorramp_003.Fac
    lava.links.new(voronoi_texture.outputs[0], colorramp_003.inputs[0])
    #mix.Result -> mix_001.A
    lava.links.new(mix.outputs[2], mix_001.inputs[6])
    #noise_texture_001.Color -> mix_001.B
    lava.links.new(noise_texture_001.outputs[1], mix_001.inputs[7])
    #texture_coordinate_001.Object -> vector_math.Vector
    lava.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mix.A
    lava.links.new(vector_math.outputs[0], mix.inputs[6])
    #vector_math.Vector -> noise_texture.Vector
    lava.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #vector_math.Vector -> noise_texture_001.Vector
    lava.links.new(vector_math.outputs[0], noise_texture_001.inputs[0])
    #group_input.Scale -> vector_math.Scale
    lava.links.new(group_input.outputs[0], vector_math.inputs[3])
    #group_input.Rings Amount -> voronoi_texture.Scale
    lava.links.new(group_input.outputs[1], voronoi_texture.inputs[2])
    #colorramp_002.Color -> hue_saturation_value.Color
    lava.links.new(colorramp_002.outputs[0], hue_saturation_value.inputs[4])
    #colorramp.Color -> hue_saturation_value_001.Color
    lava.links.new(colorramp.outputs[0], hue_saturation_value_001.inputs[4])
    #group_input.Color hue -> invert.Fac
    lava.links.new(group_input.outputs[2], invert.inputs[0])
    #math_001.Value -> hue_saturation_value_001.Hue
    lava.links.new(math_001.outputs[0], hue_saturation_value_001.inputs[0])
    #invert.Color -> math_001.Value
    lava.links.new(invert.outputs[0], math_001.inputs[0])
    #math_001.Value -> hue_saturation_value.Hue
    lava.links.new(math_001.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Saturation -> hue_saturation_value_001.Saturation
    lava.links.new(group_input.outputs[3], hue_saturation_value_001.inputs[1])
    #group_input.Saturation -> hue_saturation_value.Saturation
    lava.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value_001.Value
    lava.links.new(group_input.outputs[4], hue_saturation_value_001.inputs[2])
    #group_input.Brightness -> hue_saturation_value.Value
    lava.links.new(group_input.outputs[4], hue_saturation_value.inputs[2])
    #group_input.Specular -> principled_bsdf.Specular
    lava.links.new(group_input.outputs[5], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    lava.links.new(group_input.outputs[6], principled_bsdf.inputs[9])
    #group_input.Emission -> math.Value
    lava.links.new(group_input.outputs[8], math.inputs[1])
    #group_input.Detail -> noise_texture.Detail
    lava.links.new(group_input.outputs[7], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    lava.links.new(group_input.outputs[9], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    lava.links.new(group_input.outputs[10], bump.inputs[3])
    #voronoi_texture.Distance -> group_output.Mask
    lava.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value_001.Color -> mix_002.A
    lava.links.new(hue_saturation_value_001.outputs[0], mix_002.inputs[6])
    #hue_saturation_value.Color -> mix_002.B
    lava.links.new(hue_saturation_value.outputs[0], mix_002.inputs[7])
    #math.Value -> mix_002.Factor
    lava.links.new(math.outputs[0], mix_002.inputs[0])
    #mix_002.Result -> group_output.Albedo
    lava.links.new(mix_002.outputs[2], group_output.inputs[1])
    return lava

lava = lava_node_group()

#initialize Lava node group
def lava_1_node_group():

    lava_1 = mat.node_tree
    #start with a clean node tree
    for node in lava_1.nodes:
        lava_1.nodes.remove(node)
    #initialize lava_1 nodes
    #node Material Output
    material_output = lava_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Lava
    lava_2 = lava_1.nodes.new("ShaderNodeGroup")
    lava_2.label = "Lava"
    lava_2.name = "Lava"
    lava_2.use_custom_color = True
    lava_2.color = (0.19598843157291412, 0.020353423431515694, 0.018947787582874298)
    lava_2.node_tree = lava
    #Input_1
    lava_2.inputs[0].default_value = 1.0
    #Input_2
    lava_2.inputs[1].default_value = 4.0
    #Input_3
    lava_2.inputs[2].default_value = 0.0
    #Input_4
    lava_2.inputs[3].default_value = 1.0
    #Input_5
    lava_2.inputs[4].default_value = 1.0
    #Input_6
    lava_2.inputs[5].default_value = 0.10000000149011612
    #Input_7
    lava_2.inputs[6].default_value = 0.6863636374473572
    #Input_9
    lava_2.inputs[7].default_value = 8.0
    #Input_8
    lava_2.inputs[8].default_value = 10.0
    #Input_11
    lava_2.inputs[9].default_value = 1.0
    #Input_12
    lava_2.inputs[10].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (695.16162109375, 122.46142578125)
    lava_2.location = (417.11669921875, 122.46142578125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    lava_2.width, lava_2.height = 198.01287841796875, 100.0
    
    #initialize lava_1 links
    #lava_2.BSDF -> material_output.Surface
    lava_1.links.new(lava_2.outputs[0], material_output.inputs[0])
    return lava_1

lava_1 = lava_1_node_group()

