import bpy, mathutils

mat = bpy.data.materials.new(name = "Blue Fresnel")
mat.use_nodes = True
#initialize blue_fresnel node group
def blue_fresnel_node_group():

    blue_fresnel = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "blue_fresnel")
    
    #initialize blue_fresnel nodes
    #node Group Output
    group_output = blue_fresnel.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #blue_fresnel outputs
    #output BSDF
    blue_fresnel.outputs.new('NodeSocketShader', "BSDF")
    blue_fresnel.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    blue_fresnel.outputs.new('NodeSocketFloat', "Mask")
    blue_fresnel.outputs[1].default_value = 0.0
    blue_fresnel.outputs[1].min_value = -3.4028234663852886e+38
    blue_fresnel.outputs[1].max_value = 3.4028234663852886e+38
    blue_fresnel.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = blue_fresnel.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.20000000298023224
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Texture Coordinate
    texture_coordinate = blue_fresnel.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = blue_fresnel.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'LINEAR_LIGHT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Noise Texture
    noise_texture = blue_fresnel.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = blue_fresnel.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #blue_fresnel inputs
    #input Emission Color
    blue_fresnel.inputs.new('NodeSocketColor', "Emission Color")
    blue_fresnel.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    blue_fresnel.inputs[0].attribute_domain = 'POINT'
    
    #input Emission Strength
    blue_fresnel.inputs.new('NodeSocketFloat', "Emission Strength")
    blue_fresnel.inputs[1].default_value = 4.0
    blue_fresnel.inputs[1].min_value = 0.0
    blue_fresnel.inputs[1].max_value = 1000000.0
    blue_fresnel.inputs[1].attribute_domain = 'POINT'
    
    #input Base Color
    blue_fresnel.inputs.new('NodeSocketColor', "Base Color")
    blue_fresnel.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    blue_fresnel.inputs[2].attribute_domain = 'POINT'
    
    #input Blend
    blue_fresnel.inputs.new('NodeSocketFloat', "Blend")
    blue_fresnel.inputs[3].default_value = 0.050000011920928955
    blue_fresnel.inputs[3].min_value = 0.0
    blue_fresnel.inputs[3].max_value = 1.0
    blue_fresnel.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Amount
    blue_fresnel.inputs.new('NodeSocketFloatFactor', "Noise Amount")
    blue_fresnel.inputs[4].default_value = 0.0
    blue_fresnel.inputs[4].min_value = 0.0
    blue_fresnel.inputs[4].max_value = 1.0
    blue_fresnel.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    blue_fresnel.inputs.new('NodeSocketFloat', "Noise Scale")
    blue_fresnel.inputs[5].default_value = 5.0
    blue_fresnel.inputs[5].min_value = -1000.0
    blue_fresnel.inputs[5].max_value = 1000.0
    blue_fresnel.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Detail
    blue_fresnel.inputs.new('NodeSocketFloat', "Noise Detail")
    blue_fresnel.inputs[6].default_value = 2.0
    blue_fresnel.inputs[6].min_value = 0.0
    blue_fresnel.inputs[6].max_value = 15.0
    blue_fresnel.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    blue_fresnel.inputs.new('NodeSocketVector', "Normal")
    blue_fresnel.inputs[7].default_value = (0.0, 0.0, 0.0)
    blue_fresnel.inputs[7].min_value = -3.4028234663852886e+38
    blue_fresnel.inputs[7].max_value = 3.4028234663852886e+38
    blue_fresnel.inputs[7].attribute_domain = 'POINT'
    blue_fresnel.inputs[7].hide_value = True
    
    
    
    #node Layer Weight
    layer_weight = blue_fresnel.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    
    
    #Set locations
    group_output.location = (500.00006103515625, -0.0)
    principled_bsdf.location = (210.00006103515625, 190.0)
    texture_coordinate.location = (-620.0, -220.0)
    mix.location = (-326.79571533203125, -193.56521606445312)
    noise_texture.location = (-620.0001220703125, -462.7740173339844)
    group_input.location = (-820.0, -120.0)
    layer_weight.location = (-140.0, -140.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    layer_weight.width, layer_weight.height = 140.0, 100.0
    
    #initialize blue_fresnel links
    #principled_bsdf.BSDF -> group_output.BSDF
    blue_fresnel.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #layer_weight.Fresnel -> principled_bsdf.Alpha
    blue_fresnel.links.new(layer_weight.outputs[0], principled_bsdf.inputs[21])
    #mix.Result -> layer_weight.Normal
    blue_fresnel.links.new(mix.outputs[2], layer_weight.inputs[1])
    #texture_coordinate.Object -> mix.A
    blue_fresnel.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Color -> mix.B
    blue_fresnel.links.new(noise_texture.outputs[1], mix.inputs[7])
    #group_input.Base Color -> principled_bsdf.Base Color
    blue_fresnel.links.new(group_input.outputs[2], principled_bsdf.inputs[0])
    #group_input.Blend -> layer_weight.Blend
    blue_fresnel.links.new(group_input.outputs[3], layer_weight.inputs[0])
    #group_input.Emission Strength -> principled_bsdf.Emission Strength
    blue_fresnel.links.new(group_input.outputs[1], principled_bsdf.inputs[20])
    #group_input.Noise Amount -> mix.Factor
    blue_fresnel.links.new(group_input.outputs[4], mix.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    blue_fresnel.links.new(group_input.outputs[5], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    blue_fresnel.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Normal -> principled_bsdf.Normal
    blue_fresnel.links.new(group_input.outputs[7], principled_bsdf.inputs[22])
    #group_input.Emission Color -> principled_bsdf.Emission
    blue_fresnel.links.new(group_input.outputs[0], principled_bsdf.inputs[19])
    #layer_weight.Fresnel -> group_output.Mask
    blue_fresnel.links.new(layer_weight.outputs[0], group_output.inputs[1])
    return blue_fresnel

blue_fresnel = blue_fresnel_node_group()

#initialize Blue Fresnel node group
def blue_fresnel_1_node_group():

    blue_fresnel_1 = mat.node_tree
    #start with a clean node tree
    for node in blue_fresnel_1.nodes:
        blue_fresnel_1.nodes.remove(node)
    #initialize blue_fresnel_1 nodes
    #node Material Output.001
    material_output_001 = blue_fresnel_1.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = True
    material_output_001.target = 'ALL'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output_001.inputs[3].default_value = 0.0
    
    #node blue_fresnel
    blue_fresnel_2 = blue_fresnel_1.nodes.new("ShaderNodeGroup")
    blue_fresnel_2.label = "blue_fresnel"
    blue_fresnel_2.name = "blue_fresnel"
    blue_fresnel_2.node_tree = blue_fresnel
    #Input_1
    blue_fresnel_2.inputs[0].default_value = (0.0, 0.7990638613700867, 1.0, 1.0)
    #Input_4
    blue_fresnel_2.inputs[1].default_value = 4.0
    #Input_2
    blue_fresnel_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_3
    blue_fresnel_2.inputs[3].default_value = 0.050000011920928955
    #Input_5
    blue_fresnel_2.inputs[4].default_value = 0.2550000250339508
    #Input_6
    blue_fresnel_2.inputs[5].default_value = 5.0
    #Input_7
    blue_fresnel_2.inputs[6].default_value = 2.0
    #Input_8
    blue_fresnel_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output_001.location = (680.0, 100.0)
    blue_fresnel_2.location = (380.000244140625, 100.0)
    
    #Set dimensions
    material_output_001.width, material_output_001.height = 140.0, 100.0
    blue_fresnel_2.width, blue_fresnel_2.height = 230.94464111328125, 100.0
    
    #initialize blue_fresnel_1 links
    #blue_fresnel_2.BSDF -> material_output_001.Surface
    blue_fresnel_1.links.new(blue_fresnel_2.outputs[0], material_output_001.inputs[0])
    return blue_fresnel_1

blue_fresnel_1 = blue_fresnel_1_node_group()

