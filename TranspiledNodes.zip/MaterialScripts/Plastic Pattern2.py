import bpy, mathutils

mat = bpy.data.materials.new(name = "Plastic Pattern2")
mat.use_nodes = True
#initialize Plastic_Pattern2 node group
def plastic_pattern2_node_group():

    plastic_pattern2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Plastic_Pattern2")
    
    #initialize plastic_pattern2 nodes
    #node Texture Coordinate
    texture_coordinate = plastic_pattern2.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Noise Texture
    noise_texture = plastic_pattern2.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.6166666746139526
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node ColorRamp.001
    colorramp_001 = plastic_pattern2.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.25
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.2818182706832886)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Mix.001
    mix_001 = plastic_pattern2.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Principled BSDF
    principled_bsdf = plastic_pattern2.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp
    colorramp = plastic_pattern2.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.25
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 0.23617109656333923, 0.20371337234973907, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.2818182706832886)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0851944237947464, 0.012826009653508663, 0.013049193657934666, 1.0)

    
    #node Math
    math = plastic_pattern2.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 5.0
    
    #node Math.001
    math_001 = plastic_pattern2.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = 14.5
    
    #node Group Output
    group_output = plastic_pattern2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #plastic_pattern2 outputs
    #output BSDF
    plastic_pattern2.outputs.new('NodeSocketShader', "BSDF")
    plastic_pattern2.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    plastic_pattern2.outputs.new('NodeSocketColor', "Albedo")
    plastic_pattern2.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    plastic_pattern2.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    plastic_pattern2.outputs.new('NodeSocketFloat', "Mask")
    plastic_pattern2.outputs[2].default_value = 0.0
    plastic_pattern2.outputs[2].min_value = -3.4028234663852886e+38
    plastic_pattern2.outputs[2].max_value = 3.4028234663852886e+38
    plastic_pattern2.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Invert
    invert = plastic_pattern2.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.002
    math_002 = plastic_pattern2.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.5
    
    #node Mix
    mix = plastic_pattern2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Group Input
    group_input = plastic_pattern2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #plastic_pattern2 inputs
    #input Scale
    plastic_pattern2.inputs.new('NodeSocketFloat', "Scale")
    plastic_pattern2.inputs[0].default_value = 0.5
    plastic_pattern2.inputs[0].min_value = -10000.0
    plastic_pattern2.inputs[0].max_value = 10000.0
    plastic_pattern2.inputs[0].attribute_domain = 'POINT'
    
    #input Roughness
    plastic_pattern2.inputs.new('NodeSocketFloatFactor', "Roughness")
    plastic_pattern2.inputs[1].default_value = 0.6000000238418579
    plastic_pattern2.inputs[1].min_value = 0.0
    plastic_pattern2.inputs[1].max_value = 1.0
    plastic_pattern2.inputs[1].attribute_domain = 'POINT'
    
    #input Color Hue
    plastic_pattern2.inputs.new('NodeSocketFloatFactor', "Color Hue")
    plastic_pattern2.inputs[2].default_value = 1.0
    plastic_pattern2.inputs[2].min_value = 0.0
    plastic_pattern2.inputs[2].max_value = 1.0
    plastic_pattern2.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    plastic_pattern2.inputs.new('NodeSocketFloat', "Saturation")
    plastic_pattern2.inputs[3].default_value = 1.0
    plastic_pattern2.inputs[3].min_value = 0.0
    plastic_pattern2.inputs[3].max_value = 2.0
    plastic_pattern2.inputs[3].attribute_domain = 'POINT'
    
    #input Brightness
    plastic_pattern2.inputs.new('NodeSocketFloat', "Brightness")
    plastic_pattern2.inputs[4].default_value = 1.0
    plastic_pattern2.inputs[4].min_value = 0.0
    plastic_pattern2.inputs[4].max_value = 2.0
    plastic_pattern2.inputs[4].attribute_domain = 'POINT'
    
    #input Mix Effect
    plastic_pattern2.inputs.new('NodeSocketFloatFactor', "Mix Effect")
    plastic_pattern2.inputs[5].default_value = 0.18416671454906464
    plastic_pattern2.inputs[5].min_value = 0.0
    plastic_pattern2.inputs[5].max_value = 1.0
    plastic_pattern2.inputs[5].attribute_domain = 'POINT'
    
    #input Dark Mask
    plastic_pattern2.inputs.new('NodeSocketFloatFactor', "Dark Mask")
    plastic_pattern2.inputs[6].default_value = 0.25
    plastic_pattern2.inputs[6].min_value = 0.0
    plastic_pattern2.inputs[6].max_value = 1.0
    plastic_pattern2.inputs[6].attribute_domain = 'POINT'
    
    #input Detail
    plastic_pattern2.inputs.new('NodeSocketFloat', "Detail")
    plastic_pattern2.inputs[7].default_value = 5.0
    plastic_pattern2.inputs[7].min_value = 0.0
    plastic_pattern2.inputs[7].max_value = 15.0
    plastic_pattern2.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    plastic_pattern2.inputs.new('NodeSocketVector', "Normal")
    plastic_pattern2.inputs[8].default_value = (0.0, 0.0, 0.0)
    plastic_pattern2.inputs[8].min_value = -3.4028234663852886e+38
    plastic_pattern2.inputs[8].max_value = 3.4028234663852886e+38
    plastic_pattern2.inputs[8].attribute_domain = 'POINT'
    plastic_pattern2.inputs[8].hide_value = True
    
    
    
    #node Voronoi Texture
    voronoi_texture = plastic_pattern2.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Hue Saturation Value
    hue_saturation_value = plastic_pattern2.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    
    #Set locations
    texture_coordinate.location = (-369.7711181640625, 77.43992614746094)
    noise_texture.location = (-369.7711181640625, -177.43991088867188)
    colorramp_001.location = (290.2288818359375, -101.68753051757812)
    mix_001.location = (610.2288818359375, 137.47569274902344)
    principled_bsdf.location = (1059.7711181640625, 137.43992614746094)
    colorramp.location = (290.2288818359375, 111.46983337402344)
    math.location = (-829.7711181640625, -2.5600738525390625)
    math_001.location = (-729.7711181640625, 177.4398956298828)
    group_output.location = (1349.7711181640625, -0.0)
    invert.location = (-260.0, 239.99996948242188)
    math_002.location = (200.0, 279.9999694824219)
    mix.location = (-140.0, 20.0)
    group_input.location = (-1029.7711181640625, -0.0)
    voronoi_texture.location = (70.2288818359375, 57.43994140625)
    hue_saturation_value.location = (830.0, 114.04840087890625)
    
    #Set dimensions
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    
    #initialize plastic_pattern2 links
    #principled_bsdf.BSDF -> group_output.BSDF
    plastic_pattern2.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    plastic_pattern2.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #mix.Result -> voronoi_texture.Vector
    plastic_pattern2.links.new(mix.outputs[2], voronoi_texture.inputs[0])
    #texture_coordinate.Object -> mix.A
    plastic_pattern2.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Color -> mix.B
    plastic_pattern2.links.new(noise_texture.outputs[1], mix.inputs[7])
    #voronoi_texture.Distance -> colorramp.Fac
    plastic_pattern2.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #voronoi_texture.Color -> colorramp_001.Fac
    plastic_pattern2.links.new(voronoi_texture.outputs[1], colorramp_001.inputs[0])
    #colorramp.Color -> mix_001.A
    plastic_pattern2.links.new(colorramp.outputs[0], mix_001.inputs[6])
    #colorramp_001.Color -> mix_001.B
    plastic_pattern2.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #math_001.Value -> voronoi_texture.Scale
    plastic_pattern2.links.new(math_001.outputs[0], voronoi_texture.inputs[2])
    #math.Value -> noise_texture.Scale
    plastic_pattern2.links.new(math.outputs[0], noise_texture.inputs[2])
    #mix_001.Result -> hue_saturation_value.Color
    plastic_pattern2.links.new(mix_001.outputs[2], hue_saturation_value.inputs[4])
    #group_input.Color Hue -> invert.Fac
    plastic_pattern2.links.new(group_input.outputs[2], invert.inputs[0])
    #math_002.Value -> hue_saturation_value.Hue
    plastic_pattern2.links.new(math_002.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math_002.Value
    plastic_pattern2.links.new(invert.outputs[0], math_002.inputs[0])
    #group_input.Scale -> math_001.Value
    plastic_pattern2.links.new(group_input.outputs[0], math_001.inputs[1])
    #group_input.Scale -> math.Value
    plastic_pattern2.links.new(group_input.outputs[0], math.inputs[1])
    #group_input.Mix Effect -> mix.Factor
    plastic_pattern2.links.new(group_input.outputs[5], mix.inputs[0])
    #group_input.Detail -> noise_texture.Detail
    plastic_pattern2.links.new(group_input.outputs[7], noise_texture.inputs[3])
    #group_input.Saturation -> hue_saturation_value.Saturation
    plastic_pattern2.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    plastic_pattern2.links.new(group_input.outputs[4], hue_saturation_value.inputs[2])
    #group_input.Roughness -> principled_bsdf.Roughness
    plastic_pattern2.links.new(group_input.outputs[1], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    plastic_pattern2.links.new(group_input.outputs[8], principled_bsdf.inputs[22])
    #group_input.Dark Mask -> mix_001.Factor
    plastic_pattern2.links.new(group_input.outputs[6], mix_001.inputs[0])
    #voronoi_texture.Distance -> group_output.Mask
    plastic_pattern2.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    plastic_pattern2.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return plastic_pattern2

plastic_pattern2 = plastic_pattern2_node_group()

#initialize Plastic Pattern2 node group
def plastic_pattern2_1_node_group():

    plastic_pattern2_1 = mat.node_tree
    #start with a clean node tree
    for node in plastic_pattern2_1.nodes:
        plastic_pattern2_1.nodes.remove(node)
    #initialize plastic_pattern2_1 nodes
    #node Material Output
    material_output = plastic_pattern2_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Plastic_Pattern2
    plastic_pattern2_2 = plastic_pattern2_1.nodes.new("ShaderNodeGroup")
    plastic_pattern2_2.label = "Plastic_Pattern2"
    plastic_pattern2_2.name = "Plastic_Pattern2"
    plastic_pattern2_2.use_custom_color = True
    plastic_pattern2_2.color = (0.10247385501861572, 0.10247385501861572, 0.10247385501861572)
    plastic_pattern2_2.node_tree = plastic_pattern2
    #Input_2
    plastic_pattern2_2.inputs[0].default_value = 1.0
    #Input_7
    plastic_pattern2_2.inputs[1].default_value = 0.6000000238418579
    #Input_1
    plastic_pattern2_2.inputs[2].default_value = 0.0
    #Input_5
    plastic_pattern2_2.inputs[3].default_value = 1.0
    #Input_6
    plastic_pattern2_2.inputs[4].default_value = 1.0
    #Input_3
    plastic_pattern2_2.inputs[5].default_value = 0.18416671454906464
    #Input_9
    plastic_pattern2_2.inputs[6].default_value = 0.25
    #Input_4
    plastic_pattern2_2.inputs[7].default_value = 5.0
    #Input_8
    plastic_pattern2_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (698.84033203125, 57.313232421875)
    plastic_pattern2_2.location = (438.84033203125, 57.313232421875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    plastic_pattern2_2.width, plastic_pattern2_2.height = 140.0, 100.0
    
    #initialize plastic_pattern2_1 links
    #plastic_pattern2_2.BSDF -> material_output.Surface
    plastic_pattern2_1.links.new(plastic_pattern2_2.outputs[0], material_output.inputs[0])
    return plastic_pattern2_1

plastic_pattern2_1 = plastic_pattern2_1_node_group()

