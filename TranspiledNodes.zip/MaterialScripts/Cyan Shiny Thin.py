import bpy, mathutils

mat = bpy.data.materials.new(name = "Cyan Shiny Thin")
mat.use_nodes = True
#initialize Cyan shiny thin node group
def cyan_shiny_thin_node_group():

    cyan_shiny_thin = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Cyan shiny thin")
    
    #initialize cyan_shiny_thin nodes
    #node Principled BSDF
    principled_bsdf = cyan_shiny_thin.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Group Input
    group_input = cyan_shiny_thin.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #cyan_shiny_thin inputs
    #input Base Color
    cyan_shiny_thin.inputs.new('NodeSocketColor', "Base Color")
    cyan_shiny_thin.inputs[0].default_value = (0.0, 0.6000000238418579, 1.0, 1.0)
    cyan_shiny_thin.inputs[0].attribute_domain = 'POINT'
    
    #input Subsurface
    cyan_shiny_thin.inputs.new('NodeSocketFloatFactor', "Subsurface")
    cyan_shiny_thin.inputs[1].default_value = 0.800000011920929
    cyan_shiny_thin.inputs[1].min_value = 0.0
    cyan_shiny_thin.inputs[1].max_value = 1.0
    cyan_shiny_thin.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    cyan_shiny_thin.inputs.new('NodeSocketFloatFactor', "Roughness")
    cyan_shiny_thin.inputs[2].default_value = 0.15000000596046448
    cyan_shiny_thin.inputs[2].min_value = 0.0
    cyan_shiny_thin.inputs[2].max_value = 1.0
    cyan_shiny_thin.inputs[2].attribute_domain = 'POINT'
    
    #input Normal
    cyan_shiny_thin.inputs.new('NodeSocketVector', "Normal")
    cyan_shiny_thin.inputs[3].default_value = (0.0, 0.0, 0.0)
    cyan_shiny_thin.inputs[3].min_value = -3.4028234663852886e+38
    cyan_shiny_thin.inputs[3].max_value = 3.4028234663852886e+38
    cyan_shiny_thin.inputs[3].attribute_domain = 'POINT'
    cyan_shiny_thin.inputs[3].hide_value = True
    
    
    
    #node Group Output
    group_output = cyan_shiny_thin.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #cyan_shiny_thin outputs
    #output BSDF
    cyan_shiny_thin.outputs.new('NodeSocketShader', "BSDF")
    cyan_shiny_thin.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node RGB
    rgb = cyan_shiny_thin.nodes.new("ShaderNodeRGB")
    rgb.name = "RGB"
    
    rgb.outputs[0].default_value = (0.0, 0.6000000238418579, 1.0, 1.0)
    
    #Set locations
    principled_bsdf.location = (152.5121612548828, 25.803985595703125)
    group_input.location = (-352.51214599609375, -0.0)
    group_output.location = (442.51214599609375, -0.0)
    rgb.location = (-152.5121612548828, -25.803985595703125)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    rgb.width, rgb.height = 140.0, 100.0
    
    #initialize cyan_shiny_thin links
    #principled_bsdf.BSDF -> group_output.BSDF
    cyan_shiny_thin.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #group_input.Base Color -> principled_bsdf.Base Color
    cyan_shiny_thin.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Base Color -> principled_bsdf.Subsurface Radius
    cyan_shiny_thin.links.new(group_input.outputs[0], principled_bsdf.inputs[2])
    #group_input.Base Color -> principled_bsdf.Subsurface Color
    cyan_shiny_thin.links.new(group_input.outputs[0], principled_bsdf.inputs[3])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    cyan_shiny_thin.links.new(group_input.outputs[1], principled_bsdf.inputs[1])
    #group_input.Roughness -> principled_bsdf.Roughness
    cyan_shiny_thin.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    cyan_shiny_thin.links.new(group_input.outputs[3], principled_bsdf.inputs[22])
    return cyan_shiny_thin

cyan_shiny_thin = cyan_shiny_thin_node_group()

#initialize Cyan Shiny Thin node group
def cyan_shiny_thin_1_node_group():

    cyan_shiny_thin_1 = mat.node_tree
    #start with a clean node tree
    for node in cyan_shiny_thin_1.nodes:
        cyan_shiny_thin_1.nodes.remove(node)
    #initialize cyan_shiny_thin_1 nodes
    #node Material Output
    material_output = cyan_shiny_thin_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Cyan shiny thin
    cyan_shiny_thin_2 = cyan_shiny_thin_1.nodes.new("ShaderNodeGroup")
    cyan_shiny_thin_2.label = "Cyan shiny thin"
    cyan_shiny_thin_2.name = "Cyan shiny thin"
    cyan_shiny_thin_2.use_custom_color = True
    cyan_shiny_thin_2.color = (0.10247385501861572, 0.10247385501861572, 0.10247385501861572)
    cyan_shiny_thin_2.node_tree = cyan_shiny_thin
    #Input_1
    cyan_shiny_thin_2.inputs[0].default_value = (0.0, 0.6000000238418579, 1.0, 1.0)
    #Input_2
    cyan_shiny_thin_2.inputs[1].default_value = 0.800000011920929
    #Input_3
    cyan_shiny_thin_2.inputs[2].default_value = 0.15000000596046448
    #Input_4
    cyan_shiny_thin_2.inputs[3].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (692.32861328125, 101.66796875)
    cyan_shiny_thin_2.location = (402.78662109375, 101.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    cyan_shiny_thin_2.width, cyan_shiny_thin_2.height = 179.83514404296875, 100.0
    
    #initialize cyan_shiny_thin_1 links
    #cyan_shiny_thin_2.BSDF -> material_output.Surface
    cyan_shiny_thin_1.links.new(cyan_shiny_thin_2.outputs[0], material_output.inputs[0])
    return cyan_shiny_thin_1

cyan_shiny_thin_1 = cyan_shiny_thin_1_node_group()

