import bpy, mathutils

mat = bpy.data.materials.new(name = "Yellow Mat Thin")
mat.use_nodes = True
#initialize plastic yellow mat thin node group
def plastic_yellow_mat_thin_node_group():

    plastic_yellow_mat_thin = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "plastic yellow mat thin")
    
    #initialize plastic_yellow_mat_thin nodes
    #node RGB
    rgb = plastic_yellow_mat_thin.nodes.new("ShaderNodeRGB")
    rgb.name = "RGB"
    
    rgb.outputs[0].default_value = (1.0, 1.0, 0.0, 1.0)
    #node Group Input
    group_input = plastic_yellow_mat_thin.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #plastic_yellow_mat_thin inputs
    #input Base Color
    plastic_yellow_mat_thin.inputs.new('NodeSocketColor', "Base Color")
    plastic_yellow_mat_thin.inputs[0].default_value = (1.0, 1.0, 0.0, 1.0)
    plastic_yellow_mat_thin.inputs[0].attribute_domain = 'POINT'
    
    #input Subsurface
    plastic_yellow_mat_thin.inputs.new('NodeSocketFloatFactor', "Subsurface")
    plastic_yellow_mat_thin.inputs[1].default_value = 0.800000011920929
    plastic_yellow_mat_thin.inputs[1].min_value = 0.0
    plastic_yellow_mat_thin.inputs[1].max_value = 1.0
    plastic_yellow_mat_thin.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    plastic_yellow_mat_thin.inputs.new('NodeSocketFloatFactor', "Roughness")
    plastic_yellow_mat_thin.inputs[2].default_value = 0.5
    plastic_yellow_mat_thin.inputs[2].min_value = 0.0
    plastic_yellow_mat_thin.inputs[2].max_value = 1.0
    plastic_yellow_mat_thin.inputs[2].attribute_domain = 'POINT'
    
    #input Normal
    plastic_yellow_mat_thin.inputs.new('NodeSocketVector', "Normal")
    plastic_yellow_mat_thin.inputs[3].default_value = (0.0, 0.0, 0.0)
    plastic_yellow_mat_thin.inputs[3].min_value = -3.4028234663852886e+38
    plastic_yellow_mat_thin.inputs[3].max_value = 3.4028234663852886e+38
    plastic_yellow_mat_thin.inputs[3].attribute_domain = 'POINT'
    plastic_yellow_mat_thin.inputs[3].hide_value = True
    
    
    
    #node Group Output
    group_output = plastic_yellow_mat_thin.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #plastic_yellow_mat_thin outputs
    #output BSDF
    plastic_yellow_mat_thin.outputs.new('NodeSocketShader', "BSDF")
    plastic_yellow_mat_thin.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = plastic_yellow_mat_thin.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    rgb.location = (-99.7711181640625, -39.99998474121094)
    group_input.location = (-299.7711181640625, -0.0)
    group_output.location = (389.7711181640625, -0.0)
    principled_bsdf.location = (99.7711181640625, 40.0)
    
    #Set dimensions
    rgb.width, rgb.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    
    #initialize plastic_yellow_mat_thin links
    #principled_bsdf.BSDF -> group_output.BSDF
    plastic_yellow_mat_thin.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #group_input.Base Color -> principled_bsdf.Base Color
    plastic_yellow_mat_thin.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Base Color -> principled_bsdf.Subsurface Radius
    plastic_yellow_mat_thin.links.new(group_input.outputs[0], principled_bsdf.inputs[2])
    #group_input.Base Color -> principled_bsdf.Subsurface Color
    plastic_yellow_mat_thin.links.new(group_input.outputs[0], principled_bsdf.inputs[3])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    plastic_yellow_mat_thin.links.new(group_input.outputs[1], principled_bsdf.inputs[1])
    #group_input.Roughness -> principled_bsdf.Roughness
    plastic_yellow_mat_thin.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    plastic_yellow_mat_thin.links.new(group_input.outputs[3], principled_bsdf.inputs[22])
    return plastic_yellow_mat_thin

plastic_yellow_mat_thin = plastic_yellow_mat_thin_node_group()

#initialize Yellow Mat Thin node group
def yellow_mat_thin_node_group():

    yellow_mat_thin = mat.node_tree
    #start with a clean node tree
    for node in yellow_mat_thin.nodes:
        yellow_mat_thin.nodes.remove(node)
    #initialize yellow_mat_thin nodes
    #node Material Output
    material_output = yellow_mat_thin.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node plastic yellow mat thin
    plastic_yellow_mat_thin_1 = yellow_mat_thin.nodes.new("ShaderNodeGroup")
    plastic_yellow_mat_thin_1.label = "plastic yellow mat thin"
    plastic_yellow_mat_thin_1.name = "plastic yellow mat thin"
    plastic_yellow_mat_thin_1.use_custom_color = True
    plastic_yellow_mat_thin_1.color = (0.13758397102355957, 0.13758397102355957, 0.13758397102355957)
    plastic_yellow_mat_thin_1.node_tree = plastic_yellow_mat_thin
    #Input_1
    plastic_yellow_mat_thin_1.inputs[0].default_value = (1.0, 1.0, 0.0, 1.0)
    #Input_2
    plastic_yellow_mat_thin_1.inputs[1].default_value = 0.800000011920929
    #Input_3
    plastic_yellow_mat_thin_1.inputs[2].default_value = 0.5
    #Input_4
    plastic_yellow_mat_thin_1.inputs[3].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (703.005859375, 78.780029296875)
    plastic_yellow_mat_thin_1.location = (403.46337890625, 78.780029296875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    plastic_yellow_mat_thin_1.width, plastic_yellow_mat_thin_1.height = 183.46038818359375, 100.0
    
    #initialize yellow_mat_thin links
    #plastic_yellow_mat_thin_1.BSDF -> material_output.Surface
    yellow_mat_thin.links.new(plastic_yellow_mat_thin_1.outputs[0], material_output.inputs[0])
    return yellow_mat_thin

yellow_mat_thin = yellow_mat_thin_node_group()

