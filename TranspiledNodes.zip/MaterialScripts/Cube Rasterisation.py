import bpy, mathutils

mat = bpy.data.materials.new(name = "Cube Rasterisation")
mat.use_nodes = True
#initialize Cube Rasterisation node group
def cube_rasterisation_node_group():

    cube_rasterisation = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Cube Rasterisation")
    
    #initialize cube_rasterisation nodes
    #node Emission
    emission = cube_rasterisation.nodes.new("ShaderNodeEmission")
    emission.name = "Emission"
    #Weight
    emission.inputs[2].default_value = 0.0
    
    #node Group Output
    group_output = cube_rasterisation.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #cube_rasterisation outputs
    #output Emission
    cube_rasterisation.outputs.new('NodeSocketShader', "Emission")
    cube_rasterisation.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Mix.001
    mix_001 = cube_rasterisation.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'DODGE'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_001.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp.001
    colorramp_001 = cube_rasterisation.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 0.0006907314527779818, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.3454546332359314)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.005066565703600645, 1.0, 0.0, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(0.6636362671852112)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (0.0053344308398664, 0.0, 0.5025332570075989, 1.0)

    colorramp_001_cre_3 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_3.alpha = 1.0
    colorramp_001_cre_3.color = (1.0, 0.0013560152146965265, 0.0, 1.0)

    
    #node Hue Saturation Value
    hue_saturation_value = cube_rasterisation.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = cube_rasterisation.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.001
    math_001 = cube_rasterisation.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    #node Math
    math = cube_rasterisation.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Voronoi Texture
    voronoi_texture = cube_rasterisation.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.5
    
    #node Mix
    mix = cube_rasterisation.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'BURN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Voronoi Texture.001
    voronoi_texture_001 = cube_rasterisation.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'EUCLIDEAN'
    voronoi_texture_001.feature = 'F1'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture_001.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture_001.inputs[1].default_value = 1.1999999284744263
    #Smoothness
    voronoi_texture_001.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture_001.inputs[4].default_value = 0.5
    
    #node Mix.002
    mix_002 = cube_rasterisation.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'ADD'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = cube_rasterisation.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #cube_rasterisation inputs
    #input Scale
    cube_rasterisation.inputs.new('NodeSocketFloat', "Scale")
    cube_rasterisation.inputs[0].default_value = 5.0
    cube_rasterisation.inputs[0].min_value = -1000.0
    cube_rasterisation.inputs[0].max_value = 1000.0
    cube_rasterisation.inputs[0].attribute_domain = 'POINT'
    
    #input Randomness
    cube_rasterisation.inputs.new('NodeSocketFloatFactor', "Randomness")
    cube_rasterisation.inputs[1].default_value = 0.0
    cube_rasterisation.inputs[1].min_value = 0.0
    cube_rasterisation.inputs[1].max_value = 1.0
    cube_rasterisation.inputs[1].attribute_domain = 'POINT'
    
    #input Scale Pieces
    cube_rasterisation.inputs.new('NodeSocketFloatFactor', "Scale Pieces")
    cube_rasterisation.inputs[2].default_value = 0.4416666626930237
    cube_rasterisation.inputs[2].min_value = 0.0
    cube_rasterisation.inputs[2].max_value = 1.0
    cube_rasterisation.inputs[2].attribute_domain = 'POINT'
    
    #input Randomize Piece Scale
    cube_rasterisation.inputs.new('NodeSocketFloatFactor', "Randomize Piece Scale")
    cube_rasterisation.inputs[3].default_value = 0.0
    cube_rasterisation.inputs[3].min_value = 0.0
    cube_rasterisation.inputs[3].max_value = 1.0
    cube_rasterisation.inputs[3].attribute_domain = 'POINT'
    
    #input Color Hue
    cube_rasterisation.inputs.new('NodeSocketFloatFactor', "Color Hue")
    cube_rasterisation.inputs[4].default_value = 1.0
    cube_rasterisation.inputs[4].min_value = 0.0
    cube_rasterisation.inputs[4].max_value = 1.0
    cube_rasterisation.inputs[4].attribute_domain = 'POINT'
    
    #input Saturation
    cube_rasterisation.inputs.new('NodeSocketFloat', "Saturation")
    cube_rasterisation.inputs[5].default_value = 1.0
    cube_rasterisation.inputs[5].min_value = 0.0
    cube_rasterisation.inputs[5].max_value = 2.0
    cube_rasterisation.inputs[5].attribute_domain = 'POINT'
    
    #input Brightnes
    cube_rasterisation.inputs.new('NodeSocketFloat', "Brightnes")
    cube_rasterisation.inputs[6].default_value = 50.0
    cube_rasterisation.inputs[6].min_value = -10000.0
    cube_rasterisation.inputs[6].max_value = 10000.0
    cube_rasterisation.inputs[6].attribute_domain = 'POINT'
    
    
    
    #node Voronoi Texture.002
    voronoi_texture_002 = cube_rasterisation.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_002.name = "Voronoi Texture.002"
    voronoi_texture_002.distance = 'EUCLIDEAN'
    voronoi_texture_002.feature = 'F1'
    voronoi_texture_002.voronoi_dimensions = '4D'
    #Vector
    voronoi_texture_002.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture_002.inputs[1].default_value = 1.5
    #Smoothness
    voronoi_texture_002.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture_002.inputs[4].default_value = 0.5
    
    
    #Set locations
    emission.location = (420.0, 110.0)
    group_output.location = (610.0, -0.0)
    mix_001.location = (-46.94073486328125, 126.53799438476562)
    colorramp_001.location = (-180.0, -220.0)
    hue_saturation_value.location = (160.00006103515625, -200.0)
    invert.location = (-140.0, -80.0)
    math_001.location = (35.64825439453125, -67.21603393554688)
    math.location = (122.81109619140625, 126.43296813964844)
    voronoi_texture.location = (-740.0, 60.000030517578125)
    mix.location = (-220.0, 200.0)
    voronoi_texture_001.location = (-740.0, -120.0)
    mix_002.location = (-399.99993896484375, 220.0)
    group_input.location = (-1120.0, 19.999969482421875)
    voronoi_texture_002.location = (-740.0, -375.631103515625)
    
    #Set dimensions
    emission.width, emission.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    voronoi_texture_002.width, voronoi_texture_002.height = 140.0, 100.0
    
    #initialize cube_rasterisation links
    #emission.Emission -> group_output.Emission
    cube_rasterisation.links.new(emission.outputs[0], group_output.inputs[0])
    #math.Value -> emission.Strength
    cube_rasterisation.links.new(math.outputs[0], emission.inputs[1])
    #hue_saturation_value.Color -> emission.Color
    cube_rasterisation.links.new(hue_saturation_value.outputs[0], emission.inputs[0])
    #group_input.Scale -> voronoi_texture.Scale
    cube_rasterisation.links.new(group_input.outputs[0], voronoi_texture.inputs[2])
    #group_input.Scale -> voronoi_texture_001.Scale
    cube_rasterisation.links.new(group_input.outputs[0], voronoi_texture_001.inputs[2])
    #mix_001.Result -> math.Value
    cube_rasterisation.links.new(mix_001.outputs[2], math.inputs[0])
    #voronoi_texture_001.Color -> colorramp_001.Fac
    cube_rasterisation.links.new(voronoi_texture_001.outputs[1], colorramp_001.inputs[0])
    #voronoi_texture.Distance -> mix.A
    cube_rasterisation.links.new(voronoi_texture.outputs[0], mix.inputs[6])
    #mix.Result -> mix_001.A
    cube_rasterisation.links.new(mix.outputs[2], mix_001.inputs[6])
    #group_input.Randomness -> voronoi_texture.Randomness
    cube_rasterisation.links.new(group_input.outputs[1], voronoi_texture.inputs[5])
    #group_input.Randomness -> voronoi_texture_001.Randomness
    cube_rasterisation.links.new(group_input.outputs[1], voronoi_texture_001.inputs[5])
    #colorramp_001.Color -> hue_saturation_value.Color
    cube_rasterisation.links.new(colorramp_001.outputs[0], hue_saturation_value.inputs[4])
    #group_input.Color Hue -> invert.Fac
    cube_rasterisation.links.new(group_input.outputs[4], invert.inputs[0])
    #math_001.Value -> hue_saturation_value.Hue
    cube_rasterisation.links.new(math_001.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math_001.Value
    cube_rasterisation.links.new(invert.outputs[0], math_001.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    cube_rasterisation.links.new(group_input.outputs[5], hue_saturation_value.inputs[1])
    #group_input.Brightnes -> math.Value
    cube_rasterisation.links.new(group_input.outputs[6], math.inputs[1])
    #mix_002.Result -> mix.Factor
    cube_rasterisation.links.new(mix_002.outputs[2], mix.inputs[0])
    #group_input.Scale Pieces -> mix_002.A
    cube_rasterisation.links.new(group_input.outputs[2], mix_002.inputs[6])
    #group_input.Scale -> voronoi_texture_002.Scale
    cube_rasterisation.links.new(group_input.outputs[0], voronoi_texture_002.inputs[2])
    #group_input.Randomness -> voronoi_texture_002.Randomness
    cube_rasterisation.links.new(group_input.outputs[1], voronoi_texture_002.inputs[5])
    #voronoi_texture_002.Color -> mix_002.B
    cube_rasterisation.links.new(voronoi_texture_002.outputs[1], mix_002.inputs[7])
    #group_input.Randomize Piece Scale -> mix_002.Factor
    cube_rasterisation.links.new(group_input.outputs[3], mix_002.inputs[0])
    return cube_rasterisation

cube_rasterisation = cube_rasterisation_node_group()

#initialize Cube Rasterisation node group
def cube_rasterisation_1_node_group():

    cube_rasterisation_1 = mat.node_tree
    #start with a clean node tree
    for node in cube_rasterisation_1.nodes:
        cube_rasterisation_1.nodes.remove(node)
    #initialize cube_rasterisation_1 nodes
    #node Material Output
    material_output = cube_rasterisation_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Cube Rasterisation
    cube_rasterisation_2 = cube_rasterisation_1.nodes.new("ShaderNodeGroup")
    cube_rasterisation_2.label = "Cube Rasterisation"
    cube_rasterisation_2.name = "Cube Rasterisation"
    cube_rasterisation_2.node_tree = cube_rasterisation
    #Input_1
    cube_rasterisation_2.inputs[0].default_value = 20.0
    #Input_2
    cube_rasterisation_2.inputs[1].default_value = 0.0
    #Input_6
    cube_rasterisation_2.inputs[2].default_value = 0.4416666626930237
    #Input_7
    cube_rasterisation_2.inputs[3].default_value = 0.0
    #Input_3
    cube_rasterisation_2.inputs[4].default_value = 0.3083333373069763
    #Input_4
    cube_rasterisation_2.inputs[5].default_value = 2.0
    #Input_5
    cube_rasterisation_2.inputs[6].default_value = 200.0
    
    
    #Set locations
    material_output.location = (657.412109375, 195.23876953125)
    cube_rasterisation_2.location = (460.0000305175781, 200.0)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    cube_rasterisation_2.width, cube_rasterisation_2.height = 140.0, 100.0
    
    #initialize cube_rasterisation_1 links
    #cube_rasterisation_2.Emission -> material_output.Volume
    cube_rasterisation_1.links.new(cube_rasterisation_2.outputs[0], material_output.inputs[1])
    return cube_rasterisation_1

cube_rasterisation_1 = cube_rasterisation_1_node_group()

