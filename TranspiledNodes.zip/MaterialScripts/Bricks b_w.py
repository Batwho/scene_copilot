import bpy, mathutils

mat = bpy.data.materials.new(name = "Bricks b/w")
mat.use_nodes = True
#initialize Bricks_bw node group
def bricks_bw_node_group():

    bricks_bw = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Bricks_bw")
    
    #initialize bricks_bw nodes
    #node Shader to RGB
    shader_to_rgb = bricks_bw.nodes.new("ShaderNodeShaderToRGB")
    shader_to_rgb.name = "Shader to RGB"
    
    #node ColorRamp
    colorramp = bricks_bw.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.13181816041469574)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.034212928265333176, 0.034212928265333176, 0.034212928265333176, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.4318182170391083)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mapping
    mapping = bricks_bw.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    mapping.inputs[3].default_value = (3.0, 3.0, 3.0)
    
    #node Vector Math.018
    vector_math_018 = bricks_bw.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    #Scale
    vector_math_018.inputs[3].default_value = 1.0
    
    #node Texture Coordinate.001
    texture_coordinate_001 = bricks_bw.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Mix
    mix = bricks_bw.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Principled BSDF
    principled_bsdf = bricks_bw.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 1.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.002
    mix_002 = bricks_bw.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    
    #node Bump
    bump = bricks_bw.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Hue Saturation Value
    hue_saturation_value = bricks_bw.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Hue
    hue_saturation_value.inputs[0].default_value = 0.5
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Mix.001
    mix_001 = bricks_bw.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #B_Color
    mix_001.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Output
    group_output = bricks_bw.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #bricks_bw outputs
    #output Color
    bricks_bw.outputs.new('NodeSocketColor', "Color")
    bricks_bw.outputs[0].default_value = (0.0, 0.0, 0.0, 0.0)
    bricks_bw.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Brick Texture
    brick_texture = bricks_bw.nodes.new("ShaderNodeTexBrick")
    brick_texture.name = "Brick Texture"
    brick_texture.offset = 0.5
    brick_texture.offset_frequency = 2
    brick_texture.squash = 1.0
    brick_texture.squash_frequency = 2
    #Color1
    brick_texture.inputs[1].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Color2
    brick_texture.inputs[2].default_value = (0.5, 0.5, 0.5, 1.0)
    #Mortar
    brick_texture.inputs[3].default_value = (0.0, 0.0, 0.0, 1.0)
    #Scale
    brick_texture.inputs[4].default_value = 5.0
    #Mortar Smooth
    brick_texture.inputs[6].default_value = 0.10000000149011612
    
    #node ColorRamp.001
    colorramp_001 = bricks_bw.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.504545271396637
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.003
    mix_003 = bricks_bw.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MULTIPLY'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Group Input
    group_input = bricks_bw.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #bricks_bw inputs
    #input Color1
    bricks_bw.inputs.new('NodeSocketColor', "Color1")
    bricks_bw.inputs[0].default_value = (0.5, 0.5, 0.5, 1.0)
    bricks_bw.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    bricks_bw.inputs.new('NodeSocketColor', "Color2")
    bricks_bw.inputs[1].default_value = (0.5, 0.5, 0.5, 1.0)
    bricks_bw.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    bricks_bw.inputs.new('NodeSocketFloat', "Saturation")
    bricks_bw.inputs[2].default_value = 1.0
    bricks_bw.inputs[2].min_value = 0.0
    bricks_bw.inputs[2].max_value = 2.0
    bricks_bw.inputs[2].attribute_domain = 'POINT'
    
    #input Darkening
    bricks_bw.inputs.new('NodeSocketFloatFactor', "Darkening")
    bricks_bw.inputs[3].default_value = 0.5
    bricks_bw.inputs[3].min_value = 0.0
    bricks_bw.inputs[3].max_value = 1.0
    bricks_bw.inputs[3].attribute_domain = 'POINT'
    
    #input Darkening Randomization
    bricks_bw.inputs.new('NodeSocketFloatFactor', "Darkening Randomization")
    bricks_bw.inputs[4].default_value = 1.0
    bricks_bw.inputs[4].min_value = 0.0
    bricks_bw.inputs[4].max_value = 1.0
    bricks_bw.inputs[4].attribute_domain = 'POINT'
    
    #input Distance
    bricks_bw.inputs.new('NodeSocketFloat', "Distance")
    bricks_bw.inputs[5].default_value = 1.0
    bricks_bw.inputs[5].min_value = 0.0
    bricks_bw.inputs[5].max_value = 1000.0
    bricks_bw.inputs[5].attribute_domain = 'POINT'
    
    #input Mortar Size
    bricks_bw.inputs.new('NodeSocketFloat', "Mortar Size")
    bricks_bw.inputs[6].default_value = 0.019999999552965164
    bricks_bw.inputs[6].min_value = 0.0
    bricks_bw.inputs[6].max_value = 0.125
    bricks_bw.inputs[6].attribute_domain = 'POINT'
    
    #input Bias
    bricks_bw.inputs.new('NodeSocketFloat', "Bias")
    bricks_bw.inputs[7].default_value = 0.0
    bricks_bw.inputs[7].min_value = -1.0
    bricks_bw.inputs[7].max_value = 1.0
    bricks_bw.inputs[7].attribute_domain = 'POINT'
    
    #input Brick Width
    bricks_bw.inputs.new('NodeSocketFloat', "Brick Width")
    bricks_bw.inputs[8].default_value = 0.5
    bricks_bw.inputs[8].min_value = 0.009999999776482582
    bricks_bw.inputs[8].max_value = 100.0
    bricks_bw.inputs[8].attribute_domain = 'POINT'
    
    #input Row Height
    bricks_bw.inputs.new('NodeSocketFloat', "Row Height")
    bricks_bw.inputs[9].default_value = 0.25
    bricks_bw.inputs[9].min_value = 0.009999999776482582
    bricks_bw.inputs[9].max_value = 100.0
    bricks_bw.inputs[9].attribute_domain = 'POINT'
    
    #input Bump Strength
    bricks_bw.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    bricks_bw.inputs[10].default_value = 1.0
    bricks_bw.inputs[10].min_value = 0.0
    bricks_bw.inputs[10].max_value = 1.0
    bricks_bw.inputs[10].attribute_domain = 'POINT'
    
    #input Normal
    bricks_bw.inputs.new('NodeSocketVector', "Normal")
    bricks_bw.inputs[11].default_value = (0.0, 0.0, 0.0)
    bricks_bw.inputs[11].min_value = -1.0
    bricks_bw.inputs[11].max_value = 1.0
    bricks_bw.inputs[11].attribute_domain = 'POINT'
    bricks_bw.inputs[11].hide_value = True
    
    
    
    
    #Set locations
    shader_to_rgb.location = (654.33642578125, 99.42147827148438)
    colorramp.location = (968.492919921875, 159.77761840820312)
    mapping.location = (-408.492919921875, -33.025421142578125)
    vector_math_018.location = (-628.492919921875, -79.777587890625)
    texture_coordinate_001.location = (-968.492919921875, -159.777587890625)
    mix.location = (1253.0968017578125, 148.31515502929688)
    principled_bsdf.location = (260.0, 160.0)
    mix_002.location = (20.0001220703125, 175.34664916992188)
    bump.location = (31.507080078125, -139.777587890625)
    hue_saturation_value.location = (1444.249755859375, 178.24136352539062)
    mix_001.location = (1640.0, 160.00001525878906)
    group_output.location = (2000.0, 120.00001525878906)
    brick_texture.location = (-188.492919921875, 0.222381591796875)
    colorramp_001.location = (1500.0, -20.0)
    mix_003.location = (1815.5771484375, 173.3790283203125)
    group_input.location = (-1168.492919921875, -0.0)
    
    #Set dimensions
    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mapping.width, mapping.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    brick_texture.width, brick_texture.height = 150.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize bricks_bw links
    #mix_003.Result -> group_output.Color
    bricks_bw.links.new(mix_003.outputs[2], group_output.inputs[0])
    #principled_bsdf.BSDF -> shader_to_rgb.Shader
    bricks_bw.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
    #mix_002.Result -> principled_bsdf.Base Color
    bricks_bw.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #brick_texture.Color -> bump.Height
    bricks_bw.links.new(brick_texture.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    bricks_bw.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #shader_to_rgb.Color -> colorramp.Fac
    bricks_bw.links.new(shader_to_rgb.outputs[0], colorramp.inputs[0])
    #mapping.Vector -> brick_texture.Vector
    bricks_bw.links.new(mapping.outputs[0], brick_texture.inputs[0])
    #texture_coordinate_001.UV -> vector_math_018.Vector
    bricks_bw.links.new(texture_coordinate_001.outputs[2], vector_math_018.inputs[0])
    #vector_math_018.Vector -> mapping.Vector
    bricks_bw.links.new(vector_math_018.outputs[0], mapping.inputs[0])
    #colorramp.Color -> mix.Factor
    bricks_bw.links.new(colorramp.outputs[0], mix.inputs[0])
    #group_input.Color1 -> mix.A
    bricks_bw.links.new(group_input.outputs[0], mix.inputs[6])
    #group_input.Color2 -> mix.B
    bricks_bw.links.new(group_input.outputs[1], mix.inputs[7])
    #mix.Result -> hue_saturation_value.Color
    bricks_bw.links.new(mix.outputs[2], hue_saturation_value.inputs[4])
    #group_input.Saturation -> hue_saturation_value.Saturation
    bricks_bw.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    #hue_saturation_value.Color -> mix_001.A
    bricks_bw.links.new(hue_saturation_value.outputs[0], mix_001.inputs[6])
    #group_input.Darkening -> mix_001.Factor
    bricks_bw.links.new(group_input.outputs[3], mix_001.inputs[0])
    #group_input.Distance -> principled_bsdf.Specular
    bricks_bw.links.new(group_input.outputs[5], principled_bsdf.inputs[7])
    #brick_texture.Color -> mix_002.A
    bricks_bw.links.new(brick_texture.outputs[0], mix_002.inputs[6])
    #group_input.Distance -> mix_002.B
    bricks_bw.links.new(group_input.outputs[5], mix_002.inputs[7])
    #group_input.Mortar Size -> brick_texture.Mortar Size
    bricks_bw.links.new(group_input.outputs[6], brick_texture.inputs[5])
    #group_input.Bias -> brick_texture.Bias
    bricks_bw.links.new(group_input.outputs[7], brick_texture.inputs[7])
    #group_input.Brick Width -> brick_texture.Brick Width
    bricks_bw.links.new(group_input.outputs[8], brick_texture.inputs[8])
    #group_input.Row Height -> brick_texture.Row Height
    bricks_bw.links.new(group_input.outputs[9], brick_texture.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    bricks_bw.links.new(group_input.outputs[10], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    bricks_bw.links.new(group_input.outputs[11], bump.inputs[3])
    #mix_001.Result -> mix_003.A
    bricks_bw.links.new(mix_001.outputs[2], mix_003.inputs[6])
    #colorramp_001.Color -> mix_003.B
    bricks_bw.links.new(colorramp_001.outputs[0], mix_003.inputs[7])
    #brick_texture.Color -> colorramp_001.Fac
    bricks_bw.links.new(brick_texture.outputs[0], colorramp_001.inputs[0])
    #group_input.Darkening Randomization -> mix_003.Factor
    bricks_bw.links.new(group_input.outputs[4], mix_003.inputs[0])
    return bricks_bw

bricks_bw = bricks_bw_node_group()

#initialize Bricks b/w node group
def bricks_b_w_node_group():

    bricks_b_w = mat.node_tree
    #start with a clean node tree
    for node in bricks_b_w.nodes:
        bricks_b_w.nodes.remove(node)
    #initialize bricks_b_w nodes
    #node Material Output
    material_output = bricks_b_w.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Bricks_bw
    bricks_bw_1 = bricks_b_w.nodes.new("ShaderNodeGroup")
    bricks_bw_1.label = "Bricks_bw"
    bricks_bw_1.name = "Bricks_bw"
    bricks_bw_1.node_tree = bricks_bw
    #Input_1
    bricks_bw_1.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_2
    bricks_bw_1.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_3
    bricks_bw_1.inputs[2].default_value = 1.0
    #Input_4
    bricks_bw_1.inputs[3].default_value = 0.0
    #Input_17
    bricks_bw_1.inputs[4].default_value = 0.8647058606147766
    #Input_5
    bricks_bw_1.inputs[5].default_value = 1.0
    #Input_6
    bricks_bw_1.inputs[6].default_value = 0.009999999776482582
    #Input_7
    bricks_bw_1.inputs[7].default_value = 0.0
    #Input_8
    bricks_bw_1.inputs[8].default_value = 0.5
    #Input_9
    bricks_bw_1.inputs[9].default_value = 0.25
    #Input_11
    bricks_bw_1.inputs[10].default_value = 0.5
    #Input_12
    bricks_bw_1.inputs[11].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (686.24169921875, 93.484375)
    bricks_bw_1.location = (404.54345703125, 93.2620849609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    bricks_bw_1.width, bricks_bw_1.height = 190.191162109375, 100.0
    
    #initialize bricks_b_w links
    #bricks_bw_1.Color -> material_output.Surface
    bricks_b_w.links.new(bricks_bw_1.outputs[0], material_output.inputs[0])
    return bricks_b_w

bricks_b_w = bricks_b_w_node_group()

