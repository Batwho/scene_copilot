import bpy, mathutils

mat = bpy.data.materials.new(name = "Metall Rust Big")
mat.use_nodes = True
#initialize Metall big Rust node group
def metall_big_rust_node_group():

    metall_big_rust = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Metall big Rust")
    
    #initialize metall_big_rust nodes
    #node Principled BSDF
    principled_bsdf = metall_big_rust.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp
    colorramp = metall_big_rust.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.3147728145122528
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.404545396566391)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.06520315259695053, 0.019889704883098602, 0.00808311253786087, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.534091055393219)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.23163679242134094, 0.1127728819847107, 0.04844745248556137, 1.0)

    colorramp_cre_3 = colorramp.color_ramp.elements.new(0.6443180441856384)
    colorramp_cre_3.alpha = 1.0
    colorramp_cre_3.color = (0.9081652164459229, 0.826914370059967, 0.6679834127426147, 1.0)

    colorramp_cre_4 = colorramp.color_ramp.elements.new(0.7272729873657227)
    colorramp_cre_4.alpha = 1.0
    colorramp_cre_4.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = metall_big_rust.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp.001
    colorramp_001 = metall_big_rust.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.33172738552093506
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.35909080505371094)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(0.3603639006614685)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_3 = colorramp_001.color_ramp.elements.new(0.3727278709411621)
    colorramp_001_cre_3.alpha = 1.0
    colorramp_001_cre_3.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_4 = colorramp_001.color_ramp.elements.new(0.6006366610527039)
    colorramp_001_cre_4.alpha = 1.0
    colorramp_001_cre_4.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Texture Coordinate.001
    texture_coordinate_001 = metall_big_rust.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math
    vector_math = metall_big_rust.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Group Output
    group_output = metall_big_rust.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #metall_big_rust outputs
    #output BSDF
    metall_big_rust.outputs.new('NodeSocketShader', "BSDF")
    metall_big_rust.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    metall_big_rust.outputs.new('NodeSocketColor', "Albedo")
    metall_big_rust.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    metall_big_rust.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    metall_big_rust.outputs.new('NodeSocketFloat', "Mask")
    metall_big_rust.outputs[2].default_value = 0.0
    metall_big_rust.outputs[2].min_value = -3.4028234663852886e+38
    metall_big_rust.outputs[2].max_value = 3.4028234663852886e+38
    metall_big_rust.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Invert
    invert = metall_big_rust.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = metall_big_rust.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Hue Saturation Value
    hue_saturation_value = metall_big_rust.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node ColorRamp.002
    colorramp_002 = metall_big_rust.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.47727251052856445
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.566016435623169, 0.566016435623169, 0.566016435623169, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.6545450687408447)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Invert.001
    invert_001 = metall_big_rust.nodes.new("ShaderNodeInvert")
    invert_001.name = "Invert.001"
    #Fac
    invert_001.inputs[0].default_value = 1.0
    
    #node Mix
    mix = metall_big_rust.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Input
    group_input = metall_big_rust.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #metall_big_rust inputs
    #input Scale
    metall_big_rust.inputs.new('NodeSocketFloat', "Scale")
    metall_big_rust.inputs[0].default_value = 1.0
    metall_big_rust.inputs[0].min_value = -10000.0
    metall_big_rust.inputs[0].max_value = 10000.0
    metall_big_rust.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    metall_big_rust.inputs.new('NodeSocketFloatFactor', "Color Hue")
    metall_big_rust.inputs[1].default_value = 1.0
    metall_big_rust.inputs[1].min_value = 0.0
    metall_big_rust.inputs[1].max_value = 1.0
    metall_big_rust.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    metall_big_rust.inputs.new('NodeSocketFloat', "Saturation")
    metall_big_rust.inputs[2].default_value = 1.0
    metall_big_rust.inputs[2].min_value = 0.0
    metall_big_rust.inputs[2].max_value = 2.0
    metall_big_rust.inputs[2].attribute_domain = 'POINT'
    
    #input Brightness
    metall_big_rust.inputs.new('NodeSocketFloat', "Brightness")
    metall_big_rust.inputs[3].default_value = 1.0
    metall_big_rust.inputs[3].min_value = 0.0
    metall_big_rust.inputs[3].max_value = 2.0
    metall_big_rust.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    metall_big_rust.inputs.new('NodeSocketFloatFactor', "Roughness")
    metall_big_rust.inputs[4].default_value = 0.5
    metall_big_rust.inputs[4].min_value = 0.0
    metall_big_rust.inputs[4].max_value = 1.0
    metall_big_rust.inputs[4].attribute_domain = 'POINT'
    
    #input Detail
    metall_big_rust.inputs.new('NodeSocketFloat', "Detail")
    metall_big_rust.inputs[5].default_value = 8.0
    metall_big_rust.inputs[5].min_value = 0.0
    metall_big_rust.inputs[5].max_value = 15.0
    metall_big_rust.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    metall_big_rust.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    metall_big_rust.inputs[6].default_value = 0.20000000298023224
    metall_big_rust.inputs[6].min_value = 0.0
    metall_big_rust.inputs[6].max_value = 1.0
    metall_big_rust.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    metall_big_rust.inputs.new('NodeSocketVector', "Normal")
    metall_big_rust.inputs[7].default_value = (0.0, 0.0, 0.0)
    metall_big_rust.inputs[7].min_value = -1.0
    metall_big_rust.inputs[7].max_value = 1.0
    metall_big_rust.inputs[7].attribute_domain = 'POINT'
    metall_big_rust.inputs[7].hide_value = True
    
    
    
    #node Noise Texture
    noise_texture = metall_big_rust.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 2.5
    #Roughness
    noise_texture.inputs[4].default_value = 0.7150003910064697
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    
    #Set locations
    principled_bsdf.location = (698.9857177734375, 240.0)
    colorramp.location = (221.9857177734375, 200.0)
    bump.location = (461.98565673828125, -240.0)
    colorramp_001.location = (141.9857177734375, -147.21865844726562)
    texture_coordinate_001.location = (-698.9857177734375, -24.296875)
    vector_math.location = (-358.9857177734375, 55.703125)
    group_output.location = (988.9857177734375, -0.0)
    invert.location = (-259.99993896484375, 199.99996948242188)
    math.location = (-20.0, 219.99996948242188)
    hue_saturation_value.location = (495.4627685546875, 229.9666748046875)
    colorramp_002.location = (370.0543212890625, -8.754852294921875)
    invert_001.location = (-376.8541259765625, -112.67324829101562)
    mix.location = (529.83935546875, 1.183807373046875)
    group_input.location = (-898.9857177734375, -0.0)
    noise_texture.location = (-80.5933837890625, -113.53817749023438)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    invert_001.width, invert_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize metall_big_rust links
    #principled_bsdf.BSDF -> group_output.BSDF
    metall_big_rust.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    metall_big_rust.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> hue_saturation_value.Color
    metall_big_rust.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #colorramp_001.Color -> bump.Height
    metall_big_rust.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    metall_big_rust.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> colorramp_001.Fac
    metall_big_rust.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #noise_texture.Fac -> colorramp_002.Fac
    metall_big_rust.links.new(noise_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix.A
    metall_big_rust.links.new(colorramp_002.outputs[0], mix.inputs[6])
    #texture_coordinate_001.Object -> vector_math.Vector
    metall_big_rust.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    metall_big_rust.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    metall_big_rust.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #group_input.Scale -> vector_math.Scale
    metall_big_rust.links.new(group_input.outputs[0], vector_math.inputs[3])
    #group_input.Color Hue -> invert.Fac
    metall_big_rust.links.new(group_input.outputs[1], invert.inputs[0])
    #invert.Color -> math.Value
    metall_big_rust.links.new(invert.outputs[0], math.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    metall_big_rust.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    metall_big_rust.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    metall_big_rust.links.new(group_input.outputs[3], hue_saturation_value.inputs[2])
    #mix.Result -> principled_bsdf.Roughness
    metall_big_rust.links.new(mix.outputs[2], principled_bsdf.inputs[9])
    #group_input.Roughness -> invert_001.Color
    metall_big_rust.links.new(group_input.outputs[4], invert_001.inputs[1])
    #invert_001.Color -> mix.Factor
    metall_big_rust.links.new(invert_001.outputs[0], mix.inputs[0])
    #group_input.Detail -> noise_texture.Detail
    metall_big_rust.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    metall_big_rust.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    metall_big_rust.links.new(group_input.outputs[7], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask
    metall_big_rust.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    metall_big_rust.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return metall_big_rust

metall_big_rust = metall_big_rust_node_group()

#initialize Metall Rust Big node group
def metall_rust_big_node_group():

    metall_rust_big = mat.node_tree
    #start with a clean node tree
    for node in metall_rust_big.nodes:
        metall_rust_big.nodes.remove(node)
    #initialize metall_rust_big nodes
    #node Material Output
    material_output = metall_rust_big.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Metall big Rust
    metall_big_rust_1 = metall_rust_big.nodes.new("ShaderNodeGroup")
    metall_big_rust_1.label = "Metall big Rust"
    metall_big_rust_1.name = "Metall big Rust"
    metall_big_rust_1.node_tree = metall_big_rust
    #Input_1
    metall_big_rust_1.inputs[0].default_value = 1.0
    #Input_2
    metall_big_rust_1.inputs[1].default_value = 0.0
    #Input_3
    metall_big_rust_1.inputs[2].default_value = 1.0
    #Input_4
    metall_big_rust_1.inputs[3].default_value = 1.0
    #Input_5
    metall_big_rust_1.inputs[4].default_value = 1.0
    #Input_6
    metall_big_rust_1.inputs[5].default_value = 9.0
    #Input_7
    metall_big_rust_1.inputs[6].default_value = 0.30000001192092896
    #Input_8
    metall_big_rust_1.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (689.96337890625, 60.080810546875)
    metall_big_rust_1.location = (448.85498046875, 60.080810546875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    metall_big_rust_1.width, metall_big_rust_1.height = 164.10955810546875, 100.0
    
    #initialize metall_rust_big links
    #metall_big_rust_1.BSDF -> material_output.Surface
    metall_rust_big.links.new(metall_big_rust_1.outputs[0], material_output.inputs[0])
    return metall_rust_big

metall_rust_big = metall_rust_big_node_group()

