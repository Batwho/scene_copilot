import bpy, mathutils

mat = bpy.data.materials.new(name = "Bricks")
mat.use_nodes = True
#initialize Bricks node group
def bricks_node_group():

    bricks = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Bricks")
    
    #initialize bricks nodes
    #node Mix.002
    mix_002 = bricks.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'ADD'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Bump.001
    bump_001 = bricks.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = True
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Mix.001
    mix_001 = bricks.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_001.inputs[7].default_value = (1.0, 0.6948475241661072, 0.5386866927146912, 1.0)
    
    #node Noise Texture.002
    noise_texture_002 = bricks.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #W
    noise_texture_002.inputs[1].default_value = 0.0
    #Scale
    noise_texture_002.inputs[2].default_value = 17.989999771118164
    #Detail
    noise_texture_002.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.7833333015441895
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node Texture Coordinate.001
    texture_coordinate_001 = bricks.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = bricks.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #bricks outputs
    #output BSDF
    bricks.outputs.new('NodeSocketShader', "BSDF")
    bricks.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    bricks.outputs.new('NodeSocketColor', "Albedo")
    bricks.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    bricks.outputs[1].attribute_domain = 'POINT'
    
    #output Mask 1
    bricks.outputs.new('NodeSocketColor', "Mask 1")
    bricks.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    bricks.outputs[2].attribute_domain = 'POINT'
    
    #output Mask 2
    bricks.outputs.new('NodeSocketColor', "Mask 2")
    bricks.outputs[3].default_value = (0.0, 0.0, 0.0, 1.0)
    bricks.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Vector Math.018
    vector_math_018 = bricks.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    #Vector_001
    vector_math_018.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math_018.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Principled BSDF
    principled_bsdf = bricks.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Noise Texture
    noise_texture = bricks.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 11.899999618530273
    #Detail
    noise_texture.inputs[3].default_value = 5.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix
    mix = bricks.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Noise Texture.001
    noise_texture_001 = bricks.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #W
    noise_texture_001.inputs[1].default_value = 0.0
    #Detail
    noise_texture_001.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.7833333015441895
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Reroute
    reroute = bricks.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node ColorRamp
    colorramp = bricks.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.4499998688697815
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.7590911388397217)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.10384935140609741, 0.10384935140609741, 0.10384935140609741, 1.0)

    
    #node Bump
    bump = bricks.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = bricks.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #bricks inputs
    #input Scale
    bricks.inputs.new('NodeSocketFloat', "Scale")
    bricks.inputs[0].default_value = 1.0
    bricks.inputs[0].min_value = -10000.0
    bricks.inputs[0].max_value = 10000.0
    bricks.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    bricks.inputs.new('NodeSocketColor', "Color1")
    bricks.inputs[1].default_value = (0.39135807752609253, 0.022317633032798767, 0.012369214557111263, 1.0)
    bricks.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    bricks.inputs.new('NodeSocketColor', "Color2")
    bricks.inputs[2].default_value = (0.07758204638957977, 0.004026635084301233, 0.002549803117290139, 1.0)
    bricks.inputs[2].attribute_domain = 'POINT'
    
    #input Mortar
    bricks.inputs.new('NodeSocketColor', "Mortar")
    bricks.inputs[3].default_value = (0.01779831014573574, 0.01779831014573574, 0.01779831014573574, 1.0)
    bricks.inputs[3].attribute_domain = 'POINT'
    
    #input Specular
    bricks.inputs.new('NodeSocketFloatFactor', "Specular")
    bricks.inputs[4].default_value = 0.10000000149011612
    bricks.inputs[4].min_value = 0.0
    bricks.inputs[4].max_value = 1.0
    bricks.inputs[4].attribute_domain = 'POINT'
    
    #input Roughness
    bricks.inputs.new('NodeSocketFloatFactor', "Roughness")
    bricks.inputs[5].default_value = 0.800000011920929
    bricks.inputs[5].min_value = 0.0
    bricks.inputs[5].max_value = 1.0
    bricks.inputs[5].attribute_domain = 'POINT'
    
    #input Mortar Size
    bricks.inputs.new('NodeSocketFloat', "Mortar Size")
    bricks.inputs[6].default_value = 0.019999999552965164
    bricks.inputs[6].min_value = 0.0
    bricks.inputs[6].max_value = 0.125
    bricks.inputs[6].attribute_domain = 'POINT'
    
    #input Mortar Smooth
    bricks.inputs.new('NodeSocketFloat', "Mortar Smooth")
    bricks.inputs[7].default_value = 0.38999998569488525
    bricks.inputs[7].min_value = 0.0
    bricks.inputs[7].max_value = 1.0
    bricks.inputs[7].attribute_domain = 'POINT'
    
    #input Brick Width
    bricks.inputs.new('NodeSocketFloat', "Brick Width")
    bricks.inputs[8].default_value = 0.5
    bricks.inputs[8].min_value = 0.009999999776482582
    bricks.inputs[8].max_value = 100.0
    bricks.inputs[8].attribute_domain = 'POINT'
    
    #input Row Height
    bricks.inputs.new('NodeSocketFloat', "Row Height")
    bricks.inputs[9].default_value = 0.25
    bricks.inputs[9].min_value = 0.009999999776482582
    bricks.inputs[9].max_value = 100.0
    bricks.inputs[9].attribute_domain = 'POINT'
    
    #input Noise Strength
    bricks.inputs.new('NodeSocketFloatFactor', "Noise Strength")
    bricks.inputs[10].default_value = 0.01041463389992714
    bricks.inputs[10].min_value = 0.0
    bricks.inputs[10].max_value = 1.0
    bricks.inputs[10].attribute_domain = 'POINT'
    
    #input Texture Noise Scale
    bricks.inputs.new('NodeSocketFloat', "Texture Noise Scale")
    bricks.inputs[11].default_value = 14.1899995803833
    bricks.inputs[11].min_value = -1000.0
    bricks.inputs[11].max_value = 1000.0
    bricks.inputs[11].attribute_domain = 'POINT'
    
    #input Dirt
    bricks.inputs.new('NodeSocketFloatFactor', "Dirt")
    bricks.inputs[12].default_value = 0.6083333492279053
    bricks.inputs[12].min_value = 0.0
    bricks.inputs[12].max_value = 1.0
    bricks.inputs[12].attribute_domain = 'POINT'
    
    #input Bump Strength
    bricks.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    bricks.inputs[13].default_value = 1.0
    bricks.inputs[13].min_value = 0.0
    bricks.inputs[13].max_value = 1.0
    bricks.inputs[13].attribute_domain = 'POINT'
    
    #input Noise Bump Strength
    bricks.inputs.new('NodeSocketFloatFactor', "Noise Bump Strength")
    bricks.inputs[14].default_value = 0.30000001192092896
    bricks.inputs[14].min_value = 0.0
    bricks.inputs[14].max_value = 1.0
    bricks.inputs[14].attribute_domain = 'POINT'
    
    #input Normal
    bricks.inputs.new('NodeSocketVector', "Normal")
    bricks.inputs[15].default_value = (0.0, 0.0, 0.0)
    bricks.inputs[15].min_value = -1.0
    bricks.inputs[15].max_value = 1.0
    bricks.inputs[15].attribute_domain = 'POINT'
    bricks.inputs[15].hide_value = True
    
    
    
    #node Mix.004
    mix_004 = bricks.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_004.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_004.inputs[2].default_value = 0.0
    #B_Float
    mix_004.inputs[3].default_value = 0.0
    #A_Vector
    mix_004.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_004.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.003
    mix_003 = bricks.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_003.inputs[2].default_value = 0.0
    #B_Float
    mix_003.inputs[3].default_value = 0.0
    #A_Vector
    mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Brick Texture
    brick_texture = bricks.nodes.new("ShaderNodeTexBrick")
    brick_texture.name = "Brick Texture"
    brick_texture.offset = 0.5
    brick_texture.offset_frequency = 2
    brick_texture.squash = 1.0
    brick_texture.squash_frequency = 2
    #Scale
    brick_texture.inputs[4].default_value = 10.0
    #Bias
    brick_texture.inputs[7].default_value = 0.0
    
    #node ColorRamp.001
    colorramp_001 = bricks.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.4181816577911377
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.6136367321014404)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    
    #Set locations
    mix_002.location = (-240.0, 240.00001525878906)
    bump_001.location = (260.0, -320.0)
    mix_001.location = (449.423095703125, 56.788116455078125)
    noise_texture_002.location = (520.0, 320.0)
    texture_coordinate_001.location = (-1279.999755859375, -159.99998474121094)
    group_output.location = (1570.0, -0.0)
    vector_math_018.location = (-939.999755859375, -79.99998474121094)
    principled_bsdf.location = (1280.0, 60.00001525878906)
    noise_texture.location = (-560.0, -239.99998474121094)
    mix.location = (-209.151123046875, 7.2649688720703125)
    noise_texture_001.location = (-60.0, 260.0)
    reroute.location = (-80.0, 299.9999694824219)
    colorramp.location = (180.00006103515625, 199.99996948242188)
    bump.location = (460.0, -199.99998474121094)
    group_input.location = (-1479.999755859375, -0.0)
    mix_004.location = (1060.0, 18.928268432617188)
    mix_003.location = (669.0, 17.106033325195312)
    brick_texture.location = (40.0, 20.000015258789062)
    colorramp_001.location = (740.0, 265.65521240234375)
    
    #Set dimensions
    mix_002.width, mix_002.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    brick_texture.width, brick_texture.height = 150.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    
    #initialize bricks links
    #principled_bsdf.BSDF -> group_output.BSDF
    bricks.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> brick_texture.Vector
    bricks.links.new(mix.outputs[2], brick_texture.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    bricks.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix_004.Result -> principled_bsdf.Base Color
    bricks.links.new(mix_004.outputs[2], principled_bsdf.inputs[0])
    #noise_texture.Color -> mix.B
    bricks.links.new(noise_texture.outputs[1], mix.inputs[7])
    #brick_texture.Color -> mix_001.A
    bricks.links.new(brick_texture.outputs[0], mix_001.inputs[6])
    #brick_texture.Color -> mix_002.B
    bricks.links.new(brick_texture.outputs[0], mix_002.inputs[7])
    #mix_002.Result -> noise_texture_001.Vector
    bricks.links.new(mix_002.outputs[2], noise_texture_001.inputs[0])
    #noise_texture_001.Fac -> colorramp.Fac
    bricks.links.new(noise_texture_001.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> mix_001.Factor
    bricks.links.new(colorramp.outputs[0], mix_001.inputs[0])
    #mix_001.Result -> mix_003.A
    bricks.links.new(mix_001.outputs[2], mix_003.inputs[6])
    #brick_texture.Color -> mix_003.B
    bricks.links.new(brick_texture.outputs[0], mix_003.inputs[7])
    #brick_texture.Fac -> mix_003.Factor
    bricks.links.new(brick_texture.outputs[1], mix_003.inputs[0])
    #brick_texture.Fac -> bump.Height
    bricks.links.new(brick_texture.outputs[1], bump.inputs[2])
    #bump_001.Normal -> bump.Normal
    bricks.links.new(bump_001.outputs[0], bump.inputs[3])
    #noise_texture_001.Fac -> bump_001.Height
    bricks.links.new(noise_texture_001.outputs[0], bump_001.inputs[2])
    #mix_003.Result -> mix_004.A
    bricks.links.new(mix_003.outputs[2], mix_004.inputs[6])
    #reroute.Output -> noise_texture_002.Vector
    bricks.links.new(reroute.outputs[0], noise_texture_002.inputs[0])
    #colorramp_001.Color -> mix_004.B
    bricks.links.new(colorramp_001.outputs[0], mix_004.inputs[7])
    #noise_texture_002.Fac -> colorramp_001.Fac
    bricks.links.new(noise_texture_002.outputs[0], colorramp_001.inputs[0])
    #texture_coordinate_001.UV -> vector_math_018.Vector
    bricks.links.new(texture_coordinate_001.outputs[2], vector_math_018.inputs[0])
    #vector_math_018.Vector -> mix.A
    bricks.links.new(vector_math_018.outputs[0], mix.inputs[6])
    #vector_math_018.Vector -> noise_texture.Vector
    bricks.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #vector_math_018.Vector -> mix_002.A
    bricks.links.new(vector_math_018.outputs[0], mix_002.inputs[6])
    #group_input.Scale -> vector_math_018.Scale
    bricks.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #group_input.Color1 -> brick_texture.Color1
    bricks.links.new(group_input.outputs[1], brick_texture.inputs[1])
    #group_input.Color2 -> brick_texture.Color2
    bricks.links.new(group_input.outputs[2], brick_texture.inputs[2])
    #group_input.Mortar -> brick_texture.Mortar
    bricks.links.new(group_input.outputs[3], brick_texture.inputs[3])
    #group_input.Mortar Size -> brick_texture.Mortar Size
    bricks.links.new(group_input.outputs[6], brick_texture.inputs[5])
    #group_input.Mortar Smooth -> brick_texture.Mortar Smooth
    bricks.links.new(group_input.outputs[7], brick_texture.inputs[6])
    #group_input.Specular -> principled_bsdf.Specular
    bricks.links.new(group_input.outputs[4], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    bricks.links.new(group_input.outputs[5], principled_bsdf.inputs[9])
    #group_input.Brick Width -> brick_texture.Brick Width
    bricks.links.new(group_input.outputs[8], brick_texture.inputs[8])
    #group_input.Row Height -> brick_texture.Row Height
    bricks.links.new(group_input.outputs[9], brick_texture.inputs[9])
    #group_input.Noise Strength -> mix.Factor
    bricks.links.new(group_input.outputs[10], mix.inputs[0])
    #group_input.Texture Noise Scale -> noise_texture_001.Scale
    bricks.links.new(group_input.outputs[11], noise_texture_001.inputs[2])
    #mix_002.Result -> reroute.Input
    bricks.links.new(mix_002.outputs[2], reroute.inputs[0])
    #group_input.Dirt -> mix_004.Factor
    bricks.links.new(group_input.outputs[12], mix_004.inputs[0])
    #group_input.Bump Strength -> bump.Strength
    bricks.links.new(group_input.outputs[13], bump.inputs[0])
    #group_input.Noise Bump Strength -> bump_001.Strength
    bricks.links.new(group_input.outputs[14], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    bricks.links.new(group_input.outputs[15], bump_001.inputs[3])
    #mix_004.Result -> group_output.Albedo
    bricks.links.new(mix_004.outputs[2], group_output.inputs[1])
    #brick_texture.Fac -> group_output.Mask 1
    bricks.links.new(brick_texture.outputs[1], group_output.inputs[2])
    #colorramp_001.Color -> group_output.Mask 2
    bricks.links.new(colorramp_001.outputs[0], group_output.inputs[3])
    return bricks

bricks = bricks_node_group()

#initialize Bricks node group
def bricks_1_node_group():

    bricks_1 = mat.node_tree
    #start with a clean node tree
    for node in bricks_1.nodes:
        bricks_1.nodes.remove(node)
    #initialize bricks_1 nodes
    #node Material Output
    material_output = bricks_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Bricks
    bricks_2 = bricks_1.nodes.new("ShaderNodeGroup")
    bricks_2.label = "Bricks"
    bricks_2.name = "Bricks"
    bricks_2.node_tree = bricks
    #Input_1
    bricks_2.inputs[0].default_value = 1.0
    #Input_2
    bricks_2.inputs[1].default_value = (0.39135807752609253, 0.022317633032798767, 0.012369214557111263, 1.0)
    #Input_3
    bricks_2.inputs[2].default_value = (0.07758204638957977, 0.004026635084301233, 0.002549803117290139, 1.0)
    #Input_4
    bricks_2.inputs[3].default_value = (0.01779831014573574, 0.01779831014573574, 0.01779831014573574, 1.0)
    #Input_7
    bricks_2.inputs[4].default_value = 0.10000000149011612
    #Input_8
    bricks_2.inputs[5].default_value = 0.800000011920929
    #Input_5
    bricks_2.inputs[6].default_value = 0.019999999552965164
    #Input_6
    bricks_2.inputs[7].default_value = 0.38999998569488525
    #Input_9
    bricks_2.inputs[8].default_value = 0.5
    #Input_10
    bricks_2.inputs[9].default_value = 0.25
    #Input_11
    bricks_2.inputs[10].default_value = 0.01041463389992714
    #Input_12
    bricks_2.inputs[11].default_value = 19.59000015258789
    #Input_13
    bricks_2.inputs[12].default_value = 0.6083333492279053
    #Input_14
    bricks_2.inputs[13].default_value = 1.0
    #Input_15
    bricks_2.inputs[14].default_value = 0.30000001192092896
    #Input_16
    bricks_2.inputs[15].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (650.4306640625, 155.118408203125)
    bricks_2.location = (377.0361328125, 155.11865234375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    bricks_2.width, bricks_2.height = 214.39453125, 100.0
    
    #initialize bricks_1 links
    #bricks_2.BSDF -> material_output.Surface
    bricks_1.links.new(bricks_2.outputs[0], material_output.inputs[0])
    return bricks_1

bricks_1 = bricks_1_node_group()

