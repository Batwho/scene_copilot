import bpy, mathutils

mat = bpy.data.materials.new(name = "White Fresnel")
mat.use_nodes = True
#initialize white_fresnel node group
def white_fresnel_node_group():

    white_fresnel = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "white_fresnel")
    
    #initialize white_fresnel nodes
    #node Group Output
    group_output = white_fresnel.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #white_fresnel outputs
    #output BSDF
    white_fresnel.outputs.new('NodeSocketShader', "BSDF")
    white_fresnel.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    white_fresnel.outputs.new('NodeSocketFloat', "Mask")
    white_fresnel.outputs[1].default_value = 0.0
    white_fresnel.outputs[1].min_value = -3.4028234663852886e+38
    white_fresnel.outputs[1].max_value = 3.4028234663852886e+38
    white_fresnel.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = white_fresnel.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.20000000298023224
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Layer Weight
    layer_weight = white_fresnel.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    
    #node Texture Coordinate
    texture_coordinate = white_fresnel.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = white_fresnel.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'LINEAR_LIGHT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = white_fresnel.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = white_fresnel.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #white_fresnel inputs
    #input Emission Color
    white_fresnel.inputs.new('NodeSocketColor', "Emission Color")
    white_fresnel.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    white_fresnel.inputs[0].attribute_domain = 'POINT'
    
    #input Emission Strength
    white_fresnel.inputs.new('NodeSocketFloat', "Emission Strength")
    white_fresnel.inputs[1].default_value = 4.0
    white_fresnel.inputs[1].min_value = 0.0
    white_fresnel.inputs[1].max_value = 1000000.0
    white_fresnel.inputs[1].attribute_domain = 'POINT'
    
    #input Base Color
    white_fresnel.inputs.new('NodeSocketColor', "Base Color")
    white_fresnel.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    white_fresnel.inputs[2].attribute_domain = 'POINT'
    
    #input Blend
    white_fresnel.inputs.new('NodeSocketFloat', "Blend")
    white_fresnel.inputs[3].default_value = 0.050000011920928955
    white_fresnel.inputs[3].min_value = 0.0
    white_fresnel.inputs[3].max_value = 1.0
    white_fresnel.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Amount
    white_fresnel.inputs.new('NodeSocketFloatFactor', "Noise Amount")
    white_fresnel.inputs[4].default_value = 0.0
    white_fresnel.inputs[4].min_value = 0.0
    white_fresnel.inputs[4].max_value = 1.0
    white_fresnel.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    white_fresnel.inputs.new('NodeSocketFloat', "Noise Scale")
    white_fresnel.inputs[5].default_value = 5.0
    white_fresnel.inputs[5].min_value = -1000.0
    white_fresnel.inputs[5].max_value = 1000.0
    white_fresnel.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Detail
    white_fresnel.inputs.new('NodeSocketFloat', "Noise Detail")
    white_fresnel.inputs[6].default_value = 2.0
    white_fresnel.inputs[6].min_value = 0.0
    white_fresnel.inputs[6].max_value = 15.0
    white_fresnel.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    white_fresnel.inputs.new('NodeSocketVector', "Normal")
    white_fresnel.inputs[7].default_value = (0.0, 0.0, 0.0)
    white_fresnel.inputs[7].min_value = -3.4028234663852886e+38
    white_fresnel.inputs[7].max_value = 3.4028234663852886e+38
    white_fresnel.inputs[7].attribute_domain = 'POINT'
    white_fresnel.inputs[7].hide_value = True
    
    
    
    
    #Set locations
    group_output.location = (500.00006103515625, -0.0)
    principled_bsdf.location = (210.00006103515625, 190.0)
    layer_weight.location = (-140.0, -140.0)
    texture_coordinate.location = (-620.0, -220.0)
    mix.location = (-326.79571533203125, -193.56521606445312)
    noise_texture.location = (-620.0001220703125, -462.7740173339844)
    group_input.location = (-820.0, -120.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    layer_weight.width, layer_weight.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize white_fresnel links
    #principled_bsdf.BSDF -> group_output.BSDF
    white_fresnel.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #layer_weight.Fresnel -> principled_bsdf.Alpha
    white_fresnel.links.new(layer_weight.outputs[0], principled_bsdf.inputs[21])
    #mix.Result -> layer_weight.Normal
    white_fresnel.links.new(mix.outputs[2], layer_weight.inputs[1])
    #texture_coordinate.Object -> mix.A
    white_fresnel.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Color -> mix.B
    white_fresnel.links.new(noise_texture.outputs[1], mix.inputs[7])
    #group_input.Base Color -> principled_bsdf.Base Color
    white_fresnel.links.new(group_input.outputs[2], principled_bsdf.inputs[0])
    #group_input.Blend -> layer_weight.Blend
    white_fresnel.links.new(group_input.outputs[3], layer_weight.inputs[0])
    #group_input.Emission Strength -> principled_bsdf.Emission Strength
    white_fresnel.links.new(group_input.outputs[1], principled_bsdf.inputs[20])
    #group_input.Noise Amount -> mix.Factor
    white_fresnel.links.new(group_input.outputs[4], mix.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    white_fresnel.links.new(group_input.outputs[5], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    white_fresnel.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Normal -> principled_bsdf.Normal
    white_fresnel.links.new(group_input.outputs[7], principled_bsdf.inputs[22])
    #group_input.Emission Color -> principled_bsdf.Emission
    white_fresnel.links.new(group_input.outputs[0], principled_bsdf.inputs[19])
    #layer_weight.Fresnel -> group_output.Mask
    white_fresnel.links.new(layer_weight.outputs[0], group_output.inputs[1])
    return white_fresnel

white_fresnel = white_fresnel_node_group()

#initialize White Fresnel node group
def white_fresnel_1_node_group():

    white_fresnel_1 = mat.node_tree
    #start with a clean node tree
    for node in white_fresnel_1.nodes:
        white_fresnel_1.nodes.remove(node)
    #initialize white_fresnel_1 nodes
    #node Material Output.001
    material_output_001 = white_fresnel_1.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = True
    material_output_001.target = 'ALL'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node white_fresnel
    white_fresnel_2 = white_fresnel_1.nodes.new("ShaderNodeGroup")
    white_fresnel_2.label = "white_fresnel"
    white_fresnel_2.name = "white_fresnel"
    white_fresnel_2.node_tree = white_fresnel
    #Input_1
    white_fresnel_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    white_fresnel_2.inputs[1].default_value = 4.0
    #Input_2
    white_fresnel_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_3
    white_fresnel_2.inputs[3].default_value = 0.050000011920928955
    #Input_5
    white_fresnel_2.inputs[4].default_value = 0.2550000250339508
    #Input_6
    white_fresnel_2.inputs[5].default_value = 5.0
    #Input_7
    white_fresnel_2.inputs[6].default_value = 2.0
    #Input_8
    white_fresnel_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output_001.location = (680.0, 100.0)
    white_fresnel_2.location = (380.000244140625, 100.0)
    
    #Set dimensions
    material_output_001.width, material_output_001.height = 140.0, 100.0
    white_fresnel_2.width, white_fresnel_2.height = 230.94464111328125, 100.0
    
    #initialize white_fresnel_1 links
    #white_fresnel_2.BSDF -> material_output_001.Surface
    white_fresnel_1.links.new(white_fresnel_2.outputs[0], material_output_001.inputs[0])
    return white_fresnel_1

white_fresnel_1 = white_fresnel_1_node_group()

