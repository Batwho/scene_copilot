import bpy, mathutils

mat = bpy.data.materials.new(name = "Minecraft Stone")
mat.use_nodes = True
#initialize Minecraft stone node group
def minecraft_stone_node_group():

    minecraft_stone = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Minecraft stone")
    
    #initialize minecraft_stone nodes
    #node Vector Math.004
    vector_math_004 = minecraft_stone.nodes.new("ShaderNodeVectorMath")
    vector_math_004.name = "Vector Math.004"
    vector_math_004.operation = 'MULTIPLY'
    #Vector_001
    vector_math_004.inputs[1].default_value = (0.23000001907348633, 0.8899999856948853, 1.0)
    
    #node ColorRamp
    colorramp = minecraft_stone.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.11818180978298187
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.014740373939275742, 0.014740373939275742, 0.014740373939275742, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.8090909123420715)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.09105468541383743, 0.09105468541383743, 0.09105468541383743, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.9090908765792847)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.16033534705638885, 0.16033534705638885, 0.16033534705638885, 1.0)

    
    #node Group Output
    group_output = minecraft_stone.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #minecraft_stone outputs
    #output BSDF
    minecraft_stone.outputs.new('NodeSocketShader', "BSDF")
    minecraft_stone.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    minecraft_stone.outputs.new('NodeSocketColor', "Albedo")
    minecraft_stone.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    minecraft_stone.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    minecraft_stone.outputs.new('NodeSocketFloat', "Mask")
    minecraft_stone.outputs[2].default_value = 0.0
    minecraft_stone.outputs[2].min_value = -3.4028234663852886e+38
    minecraft_stone.outputs[2].max_value = 3.4028234663852886e+38
    minecraft_stone.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    minecraft_stone.outputs.new('NodeSocketVector', "Normal")
    minecraft_stone.outputs[3].default_value = (0.0, 0.0, 0.0)
    minecraft_stone.outputs[3].min_value = -3.4028234663852886e+38
    minecraft_stone.outputs[3].max_value = 3.4028234663852886e+38
    minecraft_stone.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = minecraft_stone.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Vector Math.002
    vector_math_002 = minecraft_stone.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SNAP'
    
    #node Group Input
    group_input = minecraft_stone.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #minecraft_stone inputs
    #input Scale
    minecraft_stone.inputs.new('NodeSocketFloat', "Scale")
    minecraft_stone.inputs[0].default_value = 8.0
    minecraft_stone.inputs[0].min_value = -10000.0
    minecraft_stone.inputs[0].max_value = 10000.0
    minecraft_stone.inputs[0].attribute_domain = 'POINT'
    
    #input Color
    minecraft_stone.inputs.new('NodeSocketColor', "Color")
    minecraft_stone.inputs[1].default_value = (0.5, 0.5, 0.5, 1.0)
    minecraft_stone.inputs[1].attribute_domain = 'POINT'
    
    #input Specular
    minecraft_stone.inputs.new('NodeSocketFloatFactor', "Specular")
    minecraft_stone.inputs[2].default_value = 0.10000000149011612
    minecraft_stone.inputs[2].min_value = 0.0
    minecraft_stone.inputs[2].max_value = 1.0
    minecraft_stone.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    minecraft_stone.inputs.new('NodeSocketFloatFactor', "Roughness")
    minecraft_stone.inputs[3].default_value = 0.5
    minecraft_stone.inputs[3].min_value = 0.0
    minecraft_stone.inputs[3].max_value = 1.0
    minecraft_stone.inputs[3].attribute_domain = 'POINT'
    
    #input Pixel Amount
    minecraft_stone.inputs.new('NodeSocketFloat', "Pixel Amount")
    minecraft_stone.inputs[4].default_value = 8.389999389648438
    minecraft_stone.inputs[4].min_value = -1000.0
    minecraft_stone.inputs[4].max_value = 1000.0
    minecraft_stone.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    minecraft_stone.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    minecraft_stone.inputs[5].default_value = 0.5
    minecraft_stone.inputs[5].min_value = 0.0
    minecraft_stone.inputs[5].max_value = 1.0
    minecraft_stone.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    minecraft_stone.inputs.new('NodeSocketVector', "Normal")
    minecraft_stone.inputs[6].default_value = (0.0, 0.0, 0.0)
    minecraft_stone.inputs[6].min_value = -1.0
    minecraft_stone.inputs[6].max_value = 1.0
    minecraft_stone.inputs[6].attribute_domain = 'POINT'
    minecraft_stone.inputs[6].hide_value = True
    
    
    
    #node Mix
    mix = minecraft_stone.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'COLOR'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Voronoi Texture
    voronoi_texture = minecraft_stone.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 8.389999389648438
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Bump
    bump = minecraft_stone.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Texture Coordinate
    texture_coordinate = minecraft_stone.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Vector Math.003
    vector_math_003 = minecraft_stone.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'SCALE'
    
    #node Math
    math = minecraft_stone.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 8.0
    
    
    #Set locations
    vector_math_004.location = (-351.81353759765625, -24.7103271484375)
    colorramp.location = (349.02215576171875, 71.5694580078125)
    group_output.location = (1280.977783203125, -0.0)
    principled_bsdf.location = (990.9778442382812, 168.4305419921875)
    vector_math_002.location = (-570.9778442382812, -28.4305419921875)
    group_input.location = (-1190.977783203125, -0.0)
    mix.location = (714.846923828125, 155.373046875)
    voronoi_texture.location = (-90.9779052734375, 11.5694580078125)
    bump.location = (689.0221557617188, -168.4305419921875)
    texture_coordinate.location = (-1320.0, 40.0)
    vector_math_003.location = (-869.56982421875, 46.536319732666016)
    math.location = (-1006.2810668945312, -2.9217300415039062)
    
    #Set dimensions
    vector_math_004.width, vector_math_004.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    vector_math_003.width, vector_math_003.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    
    #initialize minecraft_stone links
    #principled_bsdf.BSDF -> group_output.BSDF
    minecraft_stone.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math_003.Vector -> vector_math_002.Vector
    minecraft_stone.links.new(vector_math_003.outputs[0], vector_math_002.inputs[0])
    #texture_coordinate.UV -> vector_math_003.Vector
    minecraft_stone.links.new(texture_coordinate.outputs[2], vector_math_003.inputs[0])
    #vector_math_002.Vector -> vector_math_004.Vector
    minecraft_stone.links.new(vector_math_002.outputs[0], vector_math_004.inputs[0])
    #vector_math_004.Vector -> voronoi_texture.Vector
    minecraft_stone.links.new(vector_math_004.outputs[0], voronoi_texture.inputs[0])
    #voronoi_texture.Distance -> colorramp.Fac
    minecraft_stone.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    minecraft_stone.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #voronoi_texture.Distance -> bump.Height
    minecraft_stone.links.new(voronoi_texture.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    minecraft_stone.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #math.Value -> vector_math_003.Scale
    minecraft_stone.links.new(math.outputs[0], vector_math_003.inputs[3])
    #colorramp.Color -> mix.A
    minecraft_stone.links.new(colorramp.outputs[0], mix.inputs[6])
    #group_input.Color -> mix.B
    minecraft_stone.links.new(group_input.outputs[1], mix.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    minecraft_stone.links.new(group_input.outputs[2], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    minecraft_stone.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Pixel Amount -> vector_math_002.Vector
    minecraft_stone.links.new(group_input.outputs[4], vector_math_002.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    minecraft_stone.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    minecraft_stone.links.new(group_input.outputs[6], bump.inputs[3])
    #mix.Result -> group_output.Albedo
    minecraft_stone.links.new(mix.outputs[2], group_output.inputs[1])
    #voronoi_texture.Distance -> group_output.Mask
    minecraft_stone.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #bump.Normal -> group_output.Normal
    minecraft_stone.links.new(bump.outputs[0], group_output.inputs[3])
    #group_input.Scale -> math.Value
    minecraft_stone.links.new(group_input.outputs[0], math.inputs[0])
    return minecraft_stone

minecraft_stone = minecraft_stone_node_group()

#initialize Minecraft Stone node group
def minecraft_stone_1_node_group():

    minecraft_stone_1 = mat.node_tree
    #start with a clean node tree
    for node in minecraft_stone_1.nodes:
        minecraft_stone_1.nodes.remove(node)
    #initialize minecraft_stone_1 nodes
    #node Material Output
    material_output = minecraft_stone_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Minecraft stone
    minecraft_stone_2 = minecraft_stone_1.nodes.new("ShaderNodeGroup")
    minecraft_stone_2.label = "Minecraft stone"
    minecraft_stone_2.name = "Minecraft stone"
    minecraft_stone_2.node_tree = minecraft_stone
    #Input_1
    minecraft_stone_2.inputs[0].default_value = 1.0
    #Input_2
    minecraft_stone_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_3
    minecraft_stone_2.inputs[2].default_value = 0.10000000149011612
    #Input_4
    minecraft_stone_2.inputs[3].default_value = 0.5
    #Input_5
    minecraft_stone_2.inputs[4].default_value = 0.125
    #Input_6
    minecraft_stone_2.inputs[5].default_value = 0.20000000298023224
    #Input_7
    minecraft_stone_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (699.0811767578125, 203.79995727539062)
    minecraft_stone_2.location = (433.8775634765625, 208.423828125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    minecraft_stone_2.width, minecraft_stone_2.height = 190.49267578125, 100.0
    
    #initialize minecraft_stone_1 links
    #minecraft_stone_2.BSDF -> material_output.Surface
    minecraft_stone_1.links.new(minecraft_stone_2.outputs[0], material_output.inputs[0])
    return minecraft_stone_1

minecraft_stone_1 = minecraft_stone_1_node_group()

