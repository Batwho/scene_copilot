import bpy, mathutils

mat = bpy.data.materials.new(name = "Birch")
mat.use_nodes = True
#initialize Birch node group
def birch_node_group():

    birch = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Birch")
    
    #initialize birch nodes
    #node ColorRamp.002
    colorramp_002 = birch.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.4179196357727051, 0.4179196357727051, 0.4179196357727051, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.45909079909324646)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_002_cre_2 = colorramp_002.color_ramp.elements.new(0.5000000596046448)
    colorramp_002_cre_2.alpha = 1.0
    colorramp_002_cre_2.color = (0.0, 0.0, 0.0, 1.0)

    
    #node ColorRamp
    colorramp = birch.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.6318185329437256)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.003
    colorramp_003 = birch.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.09090908616781235
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(1.0)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (0.18943311274051666, 0.18943311274051666, 0.18943311274051666, 1.0)

    
    #node Mapping
    mapping = birch.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    mapping.inputs[3].default_value = (1.0, 1.0, 4.300000190734863)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = birch.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = birch.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #birch outputs
    #output BSDF
    birch.outputs.new('NodeSocketShader', "BSDF")
    birch.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    birch.outputs.new('NodeSocketFloat', "Mask")
    birch.outputs[1].default_value = 0.0
    birch.outputs[1].min_value = -3.4028234663852886e+38
    birch.outputs[1].max_value = 3.4028234663852886e+38
    birch.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Vector Math
    vector_math = birch.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Mix
    mix = birch.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'BURN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Input
    group_input = birch.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #birch inputs
    #input Scale
    birch.inputs.new('NodeSocketFloat', "Scale")
    birch.inputs[0].default_value = 1.0
    birch.inputs[0].min_value = -10000.0
    birch.inputs[0].max_value = 10000.0
    birch.inputs[0].attribute_domain = 'POINT'
    
    #input Clamp
    birch.inputs.new('NodeSocketFloatFactor', "Clamp")
    birch.inputs[1].default_value = 0.8500000238418579
    birch.inputs[1].min_value = 0.0
    birch.inputs[1].max_value = 1.0
    birch.inputs[1].attribute_domain = 'POINT'
    
    #input Specular
    birch.inputs.new('NodeSocketFloatFactor', "Specular")
    birch.inputs[2].default_value = 0.054545462131500244
    birch.inputs[2].min_value = 0.0
    birch.inputs[2].max_value = 1.0
    birch.inputs[2].attribute_domain = 'POINT'
    
    #input Detail
    birch.inputs.new('NodeSocketFloat', "Detail")
    birch.inputs[3].default_value = 8.0
    birch.inputs[3].min_value = 0.0
    birch.inputs[3].max_value = 15.0
    birch.inputs[3].attribute_domain = 'POINT'
    
    #input Bump Strength
    birch.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    birch.inputs[4].default_value = 1.0
    birch.inputs[4].min_value = 0.0
    birch.inputs[4].max_value = 1.0
    birch.inputs[4].attribute_domain = 'POINT'
    
    #input Normal
    birch.inputs.new('NodeSocketVector', "Normal")
    birch.inputs[5].default_value = (0.0, 0.0, 0.0)
    birch.inputs[5].min_value = -1.0
    birch.inputs[5].max_value = 1.0
    birch.inputs[5].attribute_domain = 'POINT'
    birch.inputs[5].hide_value = True
    
    
    
    #node Principled BSDF
    principled_bsdf = birch.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Bump
    bump = birch.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Noise Texture
    noise_texture = birch.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 1.4600000381469727
    #Roughness
    noise_texture.inputs[4].default_value = 0.6916666626930237
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    
    #Set locations
    colorramp_002.location = (200.197021484375, -31.228179931640625)
    colorramp.location = (299.939697265625, 225.68887329101562)
    colorramp_003.location = (520.197021484375, 14.311126708984375)
    mapping.location = (-299.802978515625, 194.31112670898438)
    texture_coordinate_001.location = (-819.8029174804688, 94.31112670898438)
    group_output.location = (1109.802978515625, -0.0)
    vector_math.location = (-479.802978515625, 174.31109619140625)
    mix.location = (594.3821411132812, 262.20904541015625)
    group_input.location = (-1019.8029174804688, -0.0)
    principled_bsdf.location = (819.802978515625, 194.31112670898438)
    bump.location = (520.197021484375, -225.68887329101562)
    noise_texture.location = (-20.0604248046875, 194.3111572265625)
    
    #Set dimensions
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    mapping.width, mapping.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize birch links
    #principled_bsdf.BSDF -> group_output.BSDF
    birch.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    birch.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #mapping.Vector -> noise_texture.Vector
    birch.links.new(mapping.outputs[0], noise_texture.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    birch.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    birch.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp_002.Color -> bump.Height
    birch.links.new(colorramp_002.outputs[0], bump.inputs[2])
    #noise_texture.Fac -> colorramp_002.Fac
    birch.links.new(noise_texture.outputs[0], colorramp_002.inputs[0])
    #noise_texture.Fac -> colorramp_003.Fac
    birch.links.new(noise_texture.outputs[0], colorramp_003.inputs[0])
    #colorramp_003.Color -> principled_bsdf.Roughness
    birch.links.new(colorramp_003.outputs[0], principled_bsdf.inputs[9])
    #texture_coordinate_001.Object -> vector_math.Vector
    birch.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mapping.Vector
    birch.links.new(vector_math.outputs[0], mapping.inputs[0])
    #group_input.Scale -> vector_math.Scale
    birch.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> mix.A
    birch.links.new(colorramp.outputs[0], mix.inputs[6])
    #group_input.Clamp -> mix.Factor
    birch.links.new(group_input.outputs[1], mix.inputs[0])
    #group_input.Specular -> principled_bsdf.Specular
    birch.links.new(group_input.outputs[2], principled_bsdf.inputs[7])
    #group_input.Detail -> noise_texture.Detail
    birch.links.new(group_input.outputs[3], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    birch.links.new(group_input.outputs[4], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    birch.links.new(group_input.outputs[5], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask
    birch.links.new(noise_texture.outputs[0], group_output.inputs[1])
    return birch

birch = birch_node_group()

#initialize Birch node group
def birch_1_node_group():

    birch_1 = mat.node_tree
    #start with a clean node tree
    for node in birch_1.nodes:
        birch_1.nodes.remove(node)
    #initialize birch_1 nodes
    #node Material Output
    material_output = birch_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Birch
    birch_2 = birch_1.nodes.new("ShaderNodeGroup")
    birch_2.label = "Birch"
    birch_2.name = "Birch"
    birch_2.node_tree = birch
    #Input_1
    birch_2.inputs[0].default_value = 1.0
    #Input_2
    birch_2.inputs[1].default_value = 0.8051616549491882
    #Input_3
    birch_2.inputs[2].default_value = 0.10000000149011612
    #Input_4
    birch_2.inputs[3].default_value = 8.0
    #Input_5
    birch_2.inputs[4].default_value = 1.0
    #Input_6
    birch_2.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (669.71484375, 80.874267578125)
    birch_2.location = (422.72265625, 80.874267578125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    birch_2.width, birch_2.height = 175.38671875, 100.0
    
    #initialize birch_1 links
    #birch_2.BSDF -> material_output.Surface
    birch_1.links.new(birch_2.outputs[0], material_output.inputs[0])
    return birch_1

birch_1 = birch_1_node_group()

