import bpy, mathutils

mat = bpy.data.materials.new(name = "Tablecloth_red")
mat.use_nodes = True
#initialize Tablecloth_red node group
def tablecloth_red_node_group():

    tablecloth_red = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Tablecloth_red")
    
    #initialize tablecloth_red nodes
    #node Mix.004
    mix_004 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    
    #node Texture Coordinate.002
    texture_coordinate_002 = tablecloth_red.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_002.name = "Texture Coordinate.002"
    texture_coordinate_002.from_instancer = False
    
    #node Bump.001
    bump_001 = tablecloth_red.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Mix.005
    mix_005 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MULTIPLY'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_005.inputs[0].default_value = 1.0
    #B_Color
    mix_005.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    
    #node Wave Texture.001
    wave_texture_001 = tablecloth_red.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'Y'
    wave_texture_001.rings_direction = 'X'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Scale
    wave_texture_001.inputs[1].default_value = 200.0
    #Distortion
    wave_texture_001.inputs[2].default_value = 1.5
    #Detail
    wave_texture_001.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 1.6200000047683716
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture_001.inputs[6].default_value = 0.0
    
    #node Wave Texture
    wave_texture = tablecloth_red.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 200.0
    #Distortion
    wave_texture.inputs[2].default_value = 1.5
    #Detail
    wave_texture.inputs[3].default_value = 1.2000000476837158
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node ColorRamp.002
    colorramp_002 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.3954545855522156
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.6363639831542969)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.40454524755477905
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.7181820273399353)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Wave Texture.002
    wave_texture_002 = tablecloth_red.nodes.new("ShaderNodeTexWave")
    wave_texture_002.name = "Wave Texture.002"
    wave_texture_002.bands_direction = 'Y'
    wave_texture_002.rings_direction = 'X'
    wave_texture_002.wave_profile = 'SIN'
    wave_texture_002.wave_type = 'BANDS'
    #Scale
    wave_texture_002.inputs[1].default_value = 200.0
    #Distortion
    wave_texture_002.inputs[2].default_value = 1.5
    #Detail
    wave_texture_002.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_002.inputs[4].default_value = 1.6200000047683716
    #Detail Roughness
    wave_texture_002.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture_002.inputs[6].default_value = 0.0
    
    #node Reroute
    reroute = tablecloth_red.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Vector Math.002
    vector_math_002 = tablecloth_red.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SCALE'
    
    #node Vector Math.003
    vector_math_003 = tablecloth_red.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'SCALE'
    
    #node Noise Texture
    noise_texture = tablecloth_red.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node ColorRamp.005
    colorramp_005 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_005.name = "ColorRamp.005"
    colorramp_005.color_ramp.color_mode = 'RGB'
    colorramp_005.color_ramp.hue_interpolation = 'NEAR'
    colorramp_005.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_005.color_ramp.elements.remove(colorramp_005.color_ramp.elements[0])
    colorramp_005_cre_0 = colorramp_005.color_ramp.elements[0]
    colorramp_005_cre_0.position = 0.24090909957885742
    colorramp_005_cre_0.alpha = 1.0
    colorramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_005_cre_1 = colorramp_005.color_ramp.elements.new(0.6636365652084351)
    colorramp_005_cre_1.alpha = 1.0
    colorramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.006
    colorramp_006 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_006.name = "ColorRamp.006"
    colorramp_006.color_ramp.color_mode = 'RGB'
    colorramp_006.color_ramp.hue_interpolation = 'NEAR'
    colorramp_006.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_006.color_ramp.elements.remove(colorramp_006.color_ramp.elements[0])
    colorramp_006_cre_0 = colorramp_006.color_ramp.elements[0]
    colorramp_006_cre_0.position = 0.29545459151268005
    colorramp_006_cre_0.alpha = 1.0
    colorramp_006_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_006_cre_1 = colorramp_006.color_ramp.elements.new(0.6818183660507202)
    colorramp_006_cre_1.alpha = 1.0
    colorramp_006_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.007
    colorramp_007 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_007.name = "ColorRamp.007"
    colorramp_007.color_ramp.color_mode = 'RGB'
    colorramp_007.color_ramp.hue_interpolation = 'NEAR'
    colorramp_007.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_007.color_ramp.elements.remove(colorramp_007.color_ramp.elements[0])
    colorramp_007_cre_0 = colorramp_007.color_ramp.elements[0]
    colorramp_007_cre_0.position = 0.42272716760635376
    colorramp_007_cre_0.alpha = 1.0
    colorramp_007_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_007_cre_1 = colorramp_007.color_ramp.elements.new(1.0)
    colorramp_007_cre_1.alpha = 1.0
    colorramp_007_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Add Shader
    add_shader = tablecloth_red.nodes.new("ShaderNodeAddShader")
    add_shader.name = "Add Shader"
    
    #node Translucent BSDF
    translucent_bsdf = tablecloth_red.nodes.new("ShaderNodeBsdfTranslucent")
    translucent_bsdf.name = "Translucent BSDF"
    #Normal
    translucent_bsdf.inputs[1].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = tablecloth_red.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #tablecloth_red outputs
    #output Shader
    tablecloth_red.outputs.new('NodeSocketShader', "Shader")
    tablecloth_red.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    tablecloth_red.outputs.new('NodeSocketColor', "Albedo")
    tablecloth_red.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    tablecloth_red.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    tablecloth_red.outputs.new('NodeSocketColor', "Mask")
    tablecloth_red.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    tablecloth_red.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = tablecloth_red.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 1.5
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Mix Shader
    mix_shader = tablecloth_red.nodes.new("ShaderNodeMixShader")
    mix_shader.name = "Mix Shader"
    
    #node Noise Texture.002
    noise_texture_002 = tablecloth_red.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #Detail
    noise_texture_002.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node Math.002
    math_002 = tablecloth_red.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 8.0
    
    #node Math.003
    math_003 = tablecloth_red.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'MULTIPLY'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 8.9399995803833
    
    #node Wave Texture.003
    wave_texture_003 = tablecloth_red.nodes.new("ShaderNodeTexWave")
    wave_texture_003.name = "Wave Texture.003"
    wave_texture_003.bands_direction = 'X'
    wave_texture_003.rings_direction = 'X'
    wave_texture_003.wave_profile = 'SIN'
    wave_texture_003.wave_type = 'BANDS'
    #Scale
    wave_texture_003.inputs[1].default_value = 200.0
    #Distortion
    wave_texture_003.inputs[2].default_value = 1.5
    #Detail
    wave_texture_003.inputs[3].default_value = 1.2000000476837158
    #Detail Scale
    wave_texture_003.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture_003.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture_003.inputs[6].default_value = 0.0
    
    #node ColorRamp.003
    colorramp_003 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.3954545855522156
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.6363639831542969)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.004
    colorramp_004 = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.40454524755477905
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(0.7181820273399353)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Math
    math = tablecloth_red.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    
    #node Map Range
    map_range = tablecloth_red.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = 0.0
    #To Min
    map_range.inputs[3].default_value = 0.0
    #To Max
    map_range.inputs[4].default_value = 0.9100000262260437
    
    #node Invert
    invert = tablecloth_red.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Group Input
    group_input = tablecloth_red.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #tablecloth_red inputs
    #input Scale
    tablecloth_red.inputs.new('NodeSocketFloat', "Scale")
    tablecloth_red.inputs[0].default_value = 1.0
    tablecloth_red.inputs[0].min_value = -10000.0
    tablecloth_red.inputs[0].max_value = 10000.0
    tablecloth_red.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    tablecloth_red.inputs.new('NodeSocketColor', "Color1")
    tablecloth_red.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    tablecloth_red.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    tablecloth_red.inputs.new('NodeSocketColor', "Color2")
    tablecloth_red.inputs[2].default_value = (1.0, 0.07712893187999725, 0.05642371624708176, 1.0)
    tablecloth_red.inputs[2].attribute_domain = 'POINT'
    
    #input Color Blend
    tablecloth_red.inputs.new('NodeSocketFloat', "Color Blend")
    tablecloth_red.inputs[3].default_value = 0.9100000262260437
    tablecloth_red.inputs[3].min_value = -10000.0
    tablecloth_red.inputs[3].max_value = 10000.0
    tablecloth_red.inputs[3].attribute_domain = 'POINT'
    
    #input Pattern Darkening
    tablecloth_red.inputs.new('NodeSocketFloatFactor', "Pattern Darkening")
    tablecloth_red.inputs[4].default_value = 1.0
    tablecloth_red.inputs[4].min_value = 0.0
    tablecloth_red.inputs[4].max_value = 1.0
    tablecloth_red.inputs[4].attribute_domain = 'POINT'
    
    #input Specular
    tablecloth_red.inputs.new('NodeSocketFloatFactor', "Specular")
    tablecloth_red.inputs[5].default_value = 0.20000000298023224
    tablecloth_red.inputs[5].min_value = 0.0
    tablecloth_red.inputs[5].max_value = 1.0
    tablecloth_red.inputs[5].attribute_domain = 'POINT'
    
    #input Roughness
    tablecloth_red.inputs.new('NodeSocketFloatFactor', "Roughness")
    tablecloth_red.inputs[6].default_value = 1.0
    tablecloth_red.inputs[6].min_value = 0.0
    tablecloth_red.inputs[6].max_value = 1.0
    tablecloth_red.inputs[6].attribute_domain = 'POINT'
    
    #input Translucency
    tablecloth_red.inputs.new('NodeSocketFloatFactor', "Translucency")
    tablecloth_red.inputs[7].default_value = 0.800000011920929
    tablecloth_red.inputs[7].min_value = 0.0
    tablecloth_red.inputs[7].max_value = 1.0
    tablecloth_red.inputs[7].attribute_domain = 'POINT'
    
    #input Pattern Scale
    tablecloth_red.inputs.new('NodeSocketFloat', "Pattern Scale")
    tablecloth_red.inputs[8].default_value = 0.05000004172325134
    tablecloth_red.inputs[8].min_value = -10000.0
    tablecloth_red.inputs[8].max_value = 10000.0
    tablecloth_red.inputs[8].attribute_domain = 'POINT'
    
    #input Fabric Detail Darkening
    tablecloth_red.inputs.new('NodeSocketFloatFactor', "Fabric Detail Darkening")
    tablecloth_red.inputs[9].default_value = 1.0
    tablecloth_red.inputs[9].min_value = 0.0
    tablecloth_red.inputs[9].max_value = 1.0
    tablecloth_red.inputs[9].attribute_domain = 'POINT'
    
    #input Noise Scale
    tablecloth_red.inputs.new('NodeSocketFloat', "Noise Scale")
    tablecloth_red.inputs[10].default_value = 0.5
    tablecloth_red.inputs[10].min_value = -10000.0
    tablecloth_red.inputs[10].max_value = 10000.0
    tablecloth_red.inputs[10].attribute_domain = 'POINT'
    
    #input Bump Strength
    tablecloth_red.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    tablecloth_red.inputs[11].default_value = 0.20000000298023224
    tablecloth_red.inputs[11].min_value = 0.0
    tablecloth_red.inputs[11].max_value = 1.0
    tablecloth_red.inputs[11].attribute_domain = 'POINT'
    
    #input Normal
    tablecloth_red.inputs.new('NodeSocketVector', "Normal")
    tablecloth_red.inputs[12].default_value = (0.0, 0.0, 0.0)
    tablecloth_red.inputs[12].min_value = -1.0
    tablecloth_red.inputs[12].max_value = 1.0
    tablecloth_red.inputs[12].attribute_domain = 'POINT'
    tablecloth_red.inputs[12].hide_value = True
    
    
    
    #node Mix.008
    mix_008 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_008.name = "Mix.008"
    mix_008.blend_type = 'MULTIPLY'
    mix_008.clamp_factor = True
    mix_008.clamp_result = False
    mix_008.data_type = 'RGBA'
    mix_008.factor_mode = 'UNIFORM'
    
    #node Mix.007
    mix_007 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_007.name = "Mix.007"
    mix_007.blend_type = 'MULTIPLY'
    mix_007.clamp_factor = True
    mix_007.clamp_result = False
    mix_007.data_type = 'RGBA'
    mix_007.factor_mode = 'UNIFORM'
    
    #node Mix.006
    mix_006 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'MIX'
    mix_006.clamp_factor = True
    mix_006.clamp_result = False
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    
    #node Mix
    mix = tablecloth_red.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Mix.001
    mix_001 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'ADD'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    
    #node Math.001
    math_001 = tablecloth_red.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = True
    
    #node ColorRamp
    colorramp = tablecloth_red.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Mix.003
    mix_003 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MULTIPLY'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    
    #node Mix.002
    mix_002 = tablecloth_red.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    
    #node Reroute.001
    reroute_001 = tablecloth_red.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    
    #Set locations
    mix_004.location = (624.107421875, -432.18316650390625)
    texture_coordinate_002.location = (-2168.107421875, -205.03326416015625)
    bump_001.location = (1104.107421875, -612.1831665039062)
    mix_005.location = (844.107421875, -503.12713623046875)
    wave_texture_001.location = (-1235.892578125, -512.1831665039062)
    wave_texture.location = (-875.892578125, -172.18316650390625)
    colorramp_002.location = (-655.892578125, -172.18316650390625)
    colorramp_001.location = (-655.892578125, -412.18316650390625)
    wave_texture_002.location = (-1128.4658203125, 455.7947998046875)
    reroute.location = (-1379.892578125, -20.470184326171875)
    vector_math_002.location = (-1828.107421875, -125.03326416015625)
    vector_math_003.location = (-1607.892578125, 35.04119873046875)
    noise_texture.location = (-915.892578125, -692.1831665039062)
    colorramp_005.location = (-655.892578125, -652.1831665039062)
    colorramp_006.location = (-655.892578125, -872.1831665039062)
    colorramp_007.location = (75.66943359375, 277.85394287109375)
    add_shader.location = (1947.65380859375, -100.71197509765625)
    translucent_bsdf.location = (1704.107421875, 7.81683349609375)
    group_output.location = (2358.107421875, -0.0)
    principled_bsdf.location = (1598.24755859375, -112.18313598632812)
    mix_shader.location = (2168.107421875, -87.84075927734375)
    noise_texture_002.location = (-915.892578125, -912.1831665039062)
    math_002.location = (-1480.0, -740.0)
    math_003.location = (-1480.0, -920.0)
    wave_texture_003.location = (-983.200439453125, 776.4010009765625)
    colorramp_003.location = (-770.013427734375, 722.0723876953125)
    colorramp_004.location = (-829.28125, 489.5054931640625)
    math.location = (-236.11376953125, 660.4844970703125)
    map_range.location = (35.38720703125, 636.9315185546875)
    invert.location = (1302.957275390625, -133.275146484375)
    group_input.location = (-2368.107421875, -0.0)
    mix_008.location = (1358.6409912109375, 149.78778076171875)
    mix_007.location = (1180.0, 120.0)
    mix_006.location = (980.0, 120.0)
    mix.location = (404.107421875, -152.18313598632812)
    mix_001.location = (404.107421875, -332.1831359863281)
    math_001.location = (473.107421875, 462.7388916015625)
    colorramp.location = (693.234375, 403.514404296875)
    mix_003.location = (904.107421875, -112.18316650390625)
    mix_002.location = (1700.0, 200.0)
    reroute_001.location = (1580.0, 59.99993896484375)
    
    #Set dimensions
    mix_004.width, mix_004.height = 140.0, 100.0
    texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    wave_texture_002.width, wave_texture_002.height = 150.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    vector_math_003.width, vector_math_003.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    colorramp_005.width, colorramp_005.height = 240.0, 100.0
    colorramp_006.width, colorramp_006.height = 240.0, 100.0
    colorramp_007.width, colorramp_007.height = 240.0, 100.0
    add_shader.width, add_shader.height = 140.0, 100.0
    translucent_bsdf.width, translucent_bsdf.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_shader.width, mix_shader.height = 140.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    wave_texture_003.width, wave_texture_003.height = 150.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_008.width, mix_008.height = 140.0, 100.0
    mix_007.width, mix_007.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    
    #initialize tablecloth_red links
    #mix_shader.Shader -> group_output.Shader
    tablecloth_red.links.new(mix_shader.outputs[0], group_output.inputs[0])
    #wave_texture_001.Color -> colorramp_001.Fac
    tablecloth_red.links.new(wave_texture_001.outputs[0], colorramp_001.inputs[0])
    #wave_texture.Color -> colorramp_002.Fac
    tablecloth_red.links.new(wave_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix.A
    tablecloth_red.links.new(colorramp_002.outputs[0], mix.inputs[6])
    #colorramp_005.Color -> mix.B
    tablecloth_red.links.new(colorramp_005.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> colorramp_005.Fac
    tablecloth_red.links.new(noise_texture.outputs[0], colorramp_005.inputs[0])
    #colorramp_001.Color -> mix_001.A
    tablecloth_red.links.new(colorramp_001.outputs[0], mix_001.inputs[6])
    #colorramp_006.Color -> mix_001.B
    tablecloth_red.links.new(colorramp_006.outputs[0], mix_001.inputs[7])
    #noise_texture_002.Fac -> colorramp_006.Fac
    tablecloth_red.links.new(noise_texture_002.outputs[0], colorramp_006.inputs[0])
    #mix_005.Result -> bump_001.Height
    tablecloth_red.links.new(mix_005.outputs[2], bump_001.inputs[2])
    #mix.Result -> mix_004.A
    tablecloth_red.links.new(mix.outputs[2], mix_004.inputs[6])
    #mix_001.Result -> mix_004.B
    tablecloth_red.links.new(mix_001.outputs[2], mix_004.inputs[7])
    #bump_001.Normal -> principled_bsdf.Normal
    tablecloth_red.links.new(bump_001.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> mix_003.A
    tablecloth_red.links.new(mix.outputs[2], mix_003.inputs[6])
    #mix_001.Result -> mix_003.B
    tablecloth_red.links.new(mix_001.outputs[2], mix_003.inputs[7])
    #texture_coordinate_002.UV -> vector_math_002.Vector
    tablecloth_red.links.new(texture_coordinate_002.outputs[2], vector_math_002.inputs[0])
    #vector_math_002.Vector -> wave_texture.Vector
    tablecloth_red.links.new(vector_math_002.outputs[0], wave_texture.inputs[0])
    #vector_math_002.Vector -> wave_texture_001.Vector
    tablecloth_red.links.new(vector_math_002.outputs[0], wave_texture_001.inputs[0])
    #mix_004.Result -> mix_005.A
    tablecloth_red.links.new(mix_004.outputs[2], mix_005.inputs[6])
    #wave_texture_002.Color -> colorramp_004.Fac
    tablecloth_red.links.new(wave_texture_002.outputs[0], colorramp_004.inputs[0])
    #wave_texture_003.Color -> colorramp_003.Fac
    tablecloth_red.links.new(wave_texture_003.outputs[0], colorramp_003.inputs[0])
    #reroute.Output -> wave_texture_002.Vector
    tablecloth_red.links.new(reroute.outputs[0], wave_texture_002.inputs[0])
    #reroute.Output -> wave_texture_003.Vector
    tablecloth_red.links.new(reroute.outputs[0], wave_texture_003.inputs[0])
    #vector_math_003.Vector -> reroute.Input
    tablecloth_red.links.new(vector_math_003.outputs[0], reroute.inputs[0])
    #vector_math_002.Vector -> vector_math_003.Vector
    tablecloth_red.links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
    #colorramp_003.Color -> math.Value
    tablecloth_red.links.new(colorramp_003.outputs[0], math.inputs[0])
    #colorramp_004.Color -> math.Value
    tablecloth_red.links.new(colorramp_004.outputs[0], math.inputs[1])
    #math.Value -> map_range.Value
    tablecloth_red.links.new(math.outputs[0], map_range.inputs[0])
    #math_001.Value -> colorramp.Fac
    tablecloth_red.links.new(math_001.outputs[0], colorramp.inputs[0])
    #map_range.Result -> math_001.Value
    tablecloth_red.links.new(map_range.outputs[0], math_001.inputs[0])
    #colorramp_007.Color -> math_001.Value
    tablecloth_red.links.new(colorramp_007.outputs[0], math_001.inputs[1])
    #noise_texture_002.Fac -> colorramp_007.Fac
    tablecloth_red.links.new(noise_texture_002.outputs[0], colorramp_007.inputs[0])
    #principled_bsdf.BSDF -> add_shader.Shader
    tablecloth_red.links.new(principled_bsdf.outputs[0], add_shader.inputs[0])
    #translucent_bsdf.BSDF -> add_shader.Shader
    tablecloth_red.links.new(translucent_bsdf.outputs[0], add_shader.inputs[1])
    #add_shader.Shader -> mix_shader.Shader
    tablecloth_red.links.new(add_shader.outputs[0], mix_shader.inputs[1])
    #principled_bsdf.BSDF -> mix_shader.Shader
    tablecloth_red.links.new(principled_bsdf.outputs[0], mix_shader.inputs[2])
    #group_input.Scale -> vector_math_002.Scale
    tablecloth_red.links.new(group_input.outputs[0], vector_math_002.inputs[3])
    #colorramp.Color -> mix_006.Factor
    tablecloth_red.links.new(colorramp.outputs[0], mix_006.inputs[0])
    #mix_006.Result -> mix_007.A
    tablecloth_red.links.new(mix_006.outputs[2], mix_007.inputs[6])
    #mix_003.Result -> mix_007.B
    tablecloth_red.links.new(mix_003.outputs[2], mix_007.inputs[7])
    #reroute_001.Output -> principled_bsdf.Base Color
    tablecloth_red.links.new(reroute_001.outputs[0], principled_bsdf.inputs[0])
    #reroute_001.Output -> principled_bsdf.Subsurface Color
    tablecloth_red.links.new(reroute_001.outputs[0], principled_bsdf.inputs[3])
    #reroute_001.Output -> translucent_bsdf.Color
    tablecloth_red.links.new(reroute_001.outputs[0], translucent_bsdf.inputs[0])
    #group_input.Color1 -> mix_006.A
    tablecloth_red.links.new(group_input.outputs[1], mix_006.inputs[6])
    #group_input.Color2 -> mix_006.B
    tablecloth_red.links.new(group_input.outputs[2], mix_006.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    tablecloth_red.links.new(group_input.outputs[5], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    tablecloth_red.links.new(group_input.outputs[6], principled_bsdf.inputs[9])
    #invert.Color -> mix_shader.Fac
    tablecloth_red.links.new(invert.outputs[0], mix_shader.inputs[0])
    #group_input.Pattern Scale -> vector_math_003.Scale
    tablecloth_red.links.new(group_input.outputs[8], vector_math_003.inputs[3])
    #group_input.Color Blend -> map_range.From Max
    tablecloth_red.links.new(group_input.outputs[3], map_range.inputs[2])
    #vector_math_002.Vector -> noise_texture.Vector
    tablecloth_red.links.new(vector_math_002.outputs[0], noise_texture.inputs[0])
    #vector_math_002.Vector -> noise_texture_002.Vector
    tablecloth_red.links.new(vector_math_002.outputs[0], noise_texture_002.inputs[0])
    #group_input.Fabric Detail Darkening -> mix_007.Factor
    tablecloth_red.links.new(group_input.outputs[9], mix_007.inputs[0])
    #math_002.Value -> noise_texture.Scale
    tablecloth_red.links.new(math_002.outputs[0], noise_texture.inputs[2])
    #math_003.Value -> noise_texture_002.Scale
    tablecloth_red.links.new(math_003.outputs[0], noise_texture_002.inputs[2])
    #group_input.Noise Scale -> math_002.Value
    tablecloth_red.links.new(group_input.outputs[10], math_002.inputs[0])
    #group_input.Noise Scale -> math_003.Value
    tablecloth_red.links.new(group_input.outputs[10], math_003.inputs[0])
    #group_input.Translucency -> invert.Color
    tablecloth_red.links.new(group_input.outputs[7], invert.inputs[1])
    #mix_008.Result -> reroute_001.Input
    tablecloth_red.links.new(mix_008.outputs[2], reroute_001.inputs[0])
    #mix_007.Result -> mix_008.A
    tablecloth_red.links.new(mix_007.outputs[2], mix_008.inputs[6])
    #math_001.Value -> mix_008.B
    tablecloth_red.links.new(math_001.outputs[0], mix_008.inputs[7])
    #group_input.Pattern Darkening -> mix_008.Factor
    tablecloth_red.links.new(group_input.outputs[4], mix_008.inputs[0])
    #group_input.Bump Strength -> bump_001.Strength
    tablecloth_red.links.new(group_input.outputs[11], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    tablecloth_red.links.new(group_input.outputs[12], bump_001.inputs[3])
    #mix_002.Result -> group_output.Mask
    tablecloth_red.links.new(mix_002.outputs[2], group_output.inputs[2])
    #colorramp.Color -> mix_002.A
    tablecloth_red.links.new(colorramp.outputs[0], mix_002.inputs[6])
    #mix_003.Result -> mix_002.B
    tablecloth_red.links.new(mix_003.outputs[2], mix_002.inputs[7])
    #reroute_001.Output -> group_output.Albedo
    tablecloth_red.links.new(reroute_001.outputs[0], group_output.inputs[1])
    return tablecloth_red

tablecloth_red = tablecloth_red_node_group()

#initialize Tablecloth_red node group
def tablecloth_red_1_node_group():

    tablecloth_red_1 = mat.node_tree
    #start with a clean node tree
    for node in tablecloth_red_1.nodes:
        tablecloth_red_1.nodes.remove(node)
    #initialize tablecloth_red_1 nodes
    #node Material Output
    material_output = tablecloth_red_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Tablecloth_red
    tablecloth_red_2 = tablecloth_red_1.nodes.new("ShaderNodeGroup")
    tablecloth_red_2.label = "Tablecloth_red"
    tablecloth_red_2.name = "Tablecloth_red"
    tablecloth_red_2.node_tree = tablecloth_red
    #Input_1
    tablecloth_red_2.inputs[0].default_value = 1.0
    #Input_6
    tablecloth_red_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_7
    tablecloth_red_2.inputs[2].default_value = (1.0, 0.07712893187999725, 0.05642371624708176, 1.0)
    #Input_12
    tablecloth_red_2.inputs[3].default_value = 3.4200000762939453
    #Input_15
    tablecloth_red_2.inputs[4].default_value = 0.3333333432674408
    #Input_8
    tablecloth_red_2.inputs[5].default_value = 0.20000000298023224
    #Input_9
    tablecloth_red_2.inputs[6].default_value = 1.0
    #Input_10
    tablecloth_red_2.inputs[7].default_value = 0.30000001192092896
    #Input_11
    tablecloth_red_2.inputs[8].default_value = 0.05000004172325134
    #Input_13
    tablecloth_red_2.inputs[9].default_value = 1.0
    #Input_14
    tablecloth_red_2.inputs[10].default_value = 1.0
    #Input_16
    tablecloth_red_2.inputs[11].default_value = 0.20000000298023224
    #Input_17
    tablecloth_red_2.inputs[12].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (678.3232421875, 93.57080078125)
    tablecloth_red_2.location = (366.134765625, 87.61962890625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    tablecloth_red_2.width, tablecloth_red_2.height = 227.47314453125, 100.0
    
    #initialize tablecloth_red_1 links
    #tablecloth_red_2.Shader -> material_output.Surface
    tablecloth_red_1.links.new(tablecloth_red_2.outputs[0], material_output.inputs[0])
    return tablecloth_red_1

tablecloth_red_1 = tablecloth_red_1_node_group()

