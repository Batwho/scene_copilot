import bpy, mathutils

mat = bpy.data.materials.new(name = "Paper2")
mat.use_nodes = True
#initialize Paper2 node group
def paper2_node_group():

    paper2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Paper2")
    
    #initialize paper2 nodes
    #node Bump
    bump = paper2.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp.001
    colorramp_001 = paper2.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5136367082595825)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Principled BSDF
    principled_bsdf = paper2.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.10000000149011612
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.0
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = paper2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #paper2 outputs
    #output BSDF
    paper2.outputs.new('NodeSocketShader', "BSDF")
    paper2.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    paper2.outputs.new('NodeSocketColor', "Albedo")
    paper2.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    paper2.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    paper2.outputs.new('NodeSocketFloat', "Mask")
    paper2.outputs[2].default_value = 0.0
    paper2.outputs[2].min_value = -3.4028234663852886e+38
    paper2.outputs[2].max_value = 3.4028234663852886e+38
    paper2.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    paper2.outputs.new('NodeSocketVector', "Normal")
    paper2.outputs[3].default_value = (0.0, 0.0, 0.0)
    paper2.outputs[3].min_value = -3.4028234663852886e+38
    paper2.outputs[3].max_value = 3.4028234663852886e+38
    paper2.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node ColorRamp
    colorramp = paper2.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.34090930223464966
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.006407515611499548, 0.040202319622039795, 0.08724091947078705, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.8909085988998413)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.002
    mix_002 = paper2.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    
    #node Reroute
    reroute = paper2.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Texture Coordinate
    texture_coordinate = paper2.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Vector Math
    vector_math = paper2.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Mix
    mix = paper2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Voronoi Texture
    voronoi_texture = paper2.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Noise Texture.001
    noise_texture_001 = paper2.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 25.19999885559082
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.925000011920929
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = paper2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #paper2 inputs
    #input Color
    paper2.inputs.new('NodeSocketColor', "Color")
    paper2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    paper2.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    paper2.inputs.new('NodeSocketFloat', "Scale")
    paper2.inputs[1].default_value = 1.0
    paper2.inputs[1].min_value = -10000.0
    paper2.inputs[1].max_value = 10000.0
    paper2.inputs[1].attribute_domain = 'POINT'
    
    #input Circles Strength
    paper2.inputs.new('NodeSocketFloatFactor', "Circles Strength")
    paper2.inputs[2].default_value = 0.5916666984558105
    paper2.inputs[2].min_value = 0.0
    paper2.inputs[2].max_value = 1.0
    paper2.inputs[2].attribute_domain = 'POINT'
    
    #input Circles Scale
    paper2.inputs.new('NodeSocketFloat', "Circles Scale")
    paper2.inputs[3].default_value = 10.0
    paper2.inputs[3].min_value = -1000.0
    paper2.inputs[3].max_value = 1000.0
    paper2.inputs[3].attribute_domain = 'POINT'
    
    #input Detail
    paper2.inputs.new('NodeSocketFloat', "Detail")
    paper2.inputs[4].default_value = 9.09999942779541
    paper2.inputs[4].min_value = 0.0
    paper2.inputs[4].max_value = 15.0
    paper2.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    paper2.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    paper2.inputs[5].default_value = 0.2666666805744171
    paper2.inputs[5].min_value = 0.0
    paper2.inputs[5].max_value = 1.0
    paper2.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    paper2.inputs.new('NodeSocketVector', "Normal")
    paper2.inputs[6].default_value = (0.0, 0.0, 0.0)
    paper2.inputs[6].min_value = -1.0
    paper2.inputs[6].max_value = 1.0
    paper2.inputs[6].attribute_domain = 'POINT'
    paper2.inputs[6].hide_value = True
    
    
    
    #node Noise Texture
    noise_texture = paper2.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 5.0
    #Detail
    noise_texture.inputs[3].default_value = 11.100000381469727
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    
    #Set locations
    bump.location = (430.0, -202.96595764160156)
    colorramp_001.location = (-465.9263916015625, -203.04075622558594)
    principled_bsdf.location = (710.0, 97.03404235839844)
    group_output.location = (1000.0, -0.0)
    colorramp.location = (150.0, 137.03404235839844)
    mix_002.location = (450.0, 117.03404235839844)
    reroute.location = (-797.0963134765625, -106.59571838378906)
    texture_coordinate.location = (-1560.0, -40.0)
    vector_math.location = (-1071.6715087890625, 7.8085174560546875)
    mix.location = (-369.84130859375, 20.839614868164062)
    voronoi_texture.location = (-630.0, -182.9659423828125)
    noise_texture_001.location = (-710.0, 37.03404235839844)
    group_input.location = (-1520.0, 100.0)
    noise_texture.location = (-130.0, 17.034042358398438)
    
    #Set dimensions
    bump.width, bump.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize paper2 links
    #principled_bsdf.BSDF -> group_output.BSDF
    paper2.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> noise_texture.Vector
    paper2.links.new(mix.outputs[2], noise_texture.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    paper2.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #noise_texture_001.Color -> mix.A
    paper2.links.new(noise_texture_001.outputs[1], mix.inputs[6])
    #noise_texture.Fac -> bump.Height
    paper2.links.new(noise_texture.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    paper2.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp_001.Color -> mix.B
    paper2.links.new(colorramp_001.outputs[0], mix.inputs[7])
    #voronoi_texture.Distance -> colorramp_001.Fac
    paper2.links.new(voronoi_texture.outputs[0], colorramp_001.inputs[0])
    #colorramp.Color -> mix_002.B
    paper2.links.new(colorramp.outputs[0], mix_002.inputs[7])
    #mix_002.Result -> principled_bsdf.Base Color
    paper2.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #group_input.Color -> mix_002.A
    paper2.links.new(group_input.outputs[0], mix_002.inputs[6])
    #reroute.Output -> noise_texture_001.Vector
    paper2.links.new(reroute.outputs[0], noise_texture_001.inputs[0])
    #reroute.Output -> voronoi_texture.Vector
    paper2.links.new(reroute.outputs[0], voronoi_texture.inputs[0])
    #vector_math.Vector -> reroute.Input
    paper2.links.new(vector_math.outputs[0], reroute.inputs[0])
    #texture_coordinate.Generated -> vector_math.Vector
    paper2.links.new(texture_coordinate.outputs[0], vector_math.inputs[0])
    #group_input.Scale -> vector_math.Scale
    paper2.links.new(group_input.outputs[1], vector_math.inputs[3])
    #group_input.Circles Strength -> mix.Factor
    paper2.links.new(group_input.outputs[2], mix.inputs[0])
    #group_input.Circles Scale -> voronoi_texture.Scale
    paper2.links.new(group_input.outputs[3], voronoi_texture.inputs[2])
    #group_input.Detail -> noise_texture_001.Detail
    paper2.links.new(group_input.outputs[4], noise_texture_001.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    paper2.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    paper2.links.new(group_input.outputs[6], bump.inputs[3])
    #mix_002.Result -> group_output.Albedo
    paper2.links.new(mix_002.outputs[2], group_output.inputs[1])
    #noise_texture.Fac -> group_output.Mask
    paper2.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #bump.Normal -> group_output.Normal
    paper2.links.new(bump.outputs[0], group_output.inputs[3])
    return paper2

paper2 = paper2_node_group()

#initialize Paper2 node group
def paper2_1_node_group():

    paper2_1 = mat.node_tree
    #start with a clean node tree
    for node in paper2_1.nodes:
        paper2_1.nodes.remove(node)
    #initialize paper2_1 nodes
    #node Material Output
    material_output = paper2_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Paper2
    paper2_2 = paper2_1.nodes.new("ShaderNodeGroup")
    paper2_2.label = "Paper2"
    paper2_2.name = "Paper2"
    paper2_2.node_tree = paper2
    #Input_1
    paper2_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_2
    paper2_2.inputs[1].default_value = 1.0
    #Input_3
    paper2_2.inputs[2].default_value = 0.5916666984558105
    #Input_4
    paper2_2.inputs[3].default_value = 10.0
    #Input_5
    paper2_2.inputs[4].default_value = 9.09999942779541
    #Input_6
    paper2_2.inputs[5].default_value = 0.2666666805744171
    #Input_7
    paper2_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (600.5657348632812, 140.77334594726562)
    paper2_2.location = (366.354736328125, 143.73928833007812)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    paper2_2.width, paper2_2.height = 184.21099853515625, 100.0
    
    #initialize paper2_1 links
    #paper2_2.BSDF -> material_output.Surface
    paper2_1.links.new(paper2_2.outputs[0], material_output.inputs[0])
    return paper2_1

paper2_1 = paper2_1_node_group()

