import bpy, mathutils

mat = bpy.data.materials.new(name = "Glitch")
mat.use_nodes = True
#initialize Glitch node group
def glitch_node_group():

    glitch = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Glitch")
    
    #initialize glitch nodes
    #node Vector Math
    vector_math = glitch.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SNAP'
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math.inputs[3].default_value = 1.0
    
    #node White Noise Texture.001
    white_noise_texture_001 = glitch.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture_001.name = "White Noise Texture.001"
    white_noise_texture_001.noise_dimensions = '4D'
    #W
    white_noise_texture_001.inputs[1].default_value = 0.09999999403953552
    
    #node Hue Saturation Value
    hue_saturation_value = glitch.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Hue
    hue_saturation_value.inputs[0].default_value = 0.5
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Emission
    emission = glitch.nodes.new("ShaderNodeEmission")
    emission.name = "Emission"
    #Weight
    emission.inputs[2].default_value = 0.0
    
    #node Mix
    mix = glitch.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'BURN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Output
    group_output = glitch.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #glitch outputs
    #output Emission
    glitch.outputs.new('NodeSocketShader', "Emission")
    glitch.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Math
    math = glitch.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node White Noise Texture
    white_noise_texture = glitch.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture.name = "White Noise Texture"
    white_noise_texture.noise_dimensions = '4D'
    #W
    white_noise_texture.inputs[1].default_value = 0.0
    
    #node Texture Coordinate
    texture_coordinate = glitch.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node White Noise Texture.002
    white_noise_texture_002 = glitch.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture_002.name = "White Noise Texture.002"
    white_noise_texture_002.noise_dimensions = '3D'
    #W
    white_noise_texture_002.inputs[1].default_value = 0.0
    
    #node Mix.001
    mix_001 = glitch.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'LINEAR_LIGHT'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = glitch.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #glitch inputs
    #input Increments
    glitch.inputs.new('NodeSocketFloatFactor', "Increments")
    glitch.inputs[0].default_value = 0.0
    glitch.inputs[0].min_value = 0.0
    glitch.inputs[0].max_value = 1.0
    glitch.inputs[0].attribute_domain = 'POINT'
    
    #input Blur
    glitch.inputs.new('NodeSocketFloatFactor', "Blur")
    glitch.inputs[1].default_value = 0.021666716784238815
    glitch.inputs[1].min_value = 0.0
    glitch.inputs[1].max_value = 1.0
    glitch.inputs[1].attribute_domain = 'POINT'
    
    #input Brightnes
    glitch.inputs.new('NodeSocketFloat', "Brightnes")
    glitch.inputs[2].default_value = 5.0
    glitch.inputs[2].min_value = -10000.0
    glitch.inputs[2].max_value = 10000.0
    glitch.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    glitch.inputs.new('NodeSocketFloat', "Saturation")
    glitch.inputs[3].default_value = 2.0
    glitch.inputs[3].min_value = 0.0
    glitch.inputs[3].max_value = 2.0
    glitch.inputs[3].attribute_domain = 'POINT'
    
    #input Contrast Clamp
    glitch.inputs.new('NodeSocketFloatFactor', "Contrast Clamp")
    glitch.inputs[4].default_value = 0.0
    glitch.inputs[4].min_value = 0.0
    glitch.inputs[4].max_value = 1.0
    glitch.inputs[4].attribute_domain = 'POINT'
    
    
    
    
    #Set locations
    vector_math.location = (-152.28997802734375, 54.55842590332031)
    white_noise_texture_001.location = (40.0, -44.46685791015625)
    hue_saturation_value.location = (207.467041015625, 164.46685791015625)
    emission.location = (460.0, 115.53314208984375)
    mix.location = (220.0, -4.46685791015625)
    group_output.location = (650.0, -0.0)
    math.location = (386.19818115234375, 17.18255615234375)
    white_noise_texture.location = (40.0, 180.00003051757812)
    texture_coordinate.location = (-1000.0, 200.0)
    white_noise_texture_002.location = (-800.0, 40.0)
    mix_001.location = (-560.6107177734375, 183.56790161132812)
    group_input.location = (-1000.0, -60.0)
    
    #Set dimensions
    vector_math.width, vector_math.height = 140.0, 100.0
    white_noise_texture_001.width, white_noise_texture_001.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    emission.width, emission.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    white_noise_texture.width, white_noise_texture.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    white_noise_texture_002.width, white_noise_texture_002.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize glitch links
    #emission.Emission -> group_output.Emission
    glitch.links.new(emission.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> white_noise_texture.Vector
    glitch.links.new(vector_math.outputs[0], white_noise_texture.inputs[0])
    #mix_001.Result -> vector_math.Vector
    glitch.links.new(mix_001.outputs[2], vector_math.inputs[0])
    #hue_saturation_value.Color -> emission.Color
    glitch.links.new(hue_saturation_value.outputs[0], emission.inputs[0])
    #vector_math.Vector -> white_noise_texture_001.Vector
    glitch.links.new(vector_math.outputs[0], white_noise_texture_001.inputs[0])
    #math.Value -> emission.Strength
    glitch.links.new(math.outputs[0], emission.inputs[1])
    #white_noise_texture_001.Value -> mix.A
    glitch.links.new(white_noise_texture_001.outputs[0], mix.inputs[6])
    #white_noise_texture.Color -> hue_saturation_value.Color
    glitch.links.new(white_noise_texture.outputs[1], hue_saturation_value.inputs[4])
    #mix.Result -> math.Value
    glitch.links.new(mix.outputs[2], math.inputs[0])
    #group_input.Contrast Clamp -> mix.Factor
    glitch.links.new(group_input.outputs[4], mix.inputs[0])
    #group_input.Brightnes -> math.Value
    glitch.links.new(group_input.outputs[2], math.inputs[1])
    #group_input.Saturation -> hue_saturation_value.Saturation
    glitch.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #texture_coordinate.Object -> mix_001.A
    glitch.links.new(texture_coordinate.outputs[3], mix_001.inputs[6])
    #texture_coordinate.Object -> white_noise_texture_002.Vector
    glitch.links.new(texture_coordinate.outputs[3], white_noise_texture_002.inputs[0])
    #white_noise_texture_002.Color -> mix_001.B
    glitch.links.new(white_noise_texture_002.outputs[1], mix_001.inputs[7])
    #group_input.Blur -> mix_001.Factor
    glitch.links.new(group_input.outputs[1], mix_001.inputs[0])
    #group_input.Increments -> vector_math.Vector
    glitch.links.new(group_input.outputs[0], vector_math.inputs[1])
    return glitch

glitch = glitch_node_group()

#initialize Glitch node group
def glitch_1_node_group():

    glitch_1 = mat.node_tree
    #start with a clean node tree
    for node in glitch_1.nodes:
        glitch_1.nodes.remove(node)
    #initialize glitch_1 nodes
    #node Material Output
    material_output = glitch_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Glitch
    glitch_2 = glitch_1.nodes.new("ShaderNodeGroup")
    glitch_2.label = "Glitch"
    glitch_2.name = "Glitch"
    glitch_2.node_tree = glitch
    #Input_1
    glitch_2.inputs[0].default_value = 0.2834061086177826
    #Input_5
    glitch_2.inputs[1].default_value = 0.12337782233953476
    #Input_3
    glitch_2.inputs[2].default_value = 2.0
    #Input_4
    glitch_2.inputs[3].default_value = 5.0
    #Input_2
    glitch_2.inputs[4].default_value = 0.5877048373222351
    
    
    #Set locations
    material_output.location = (1020.0, 219.99998474121094)
    glitch_2.location = (700.0, 240.0)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    glitch_2.width, glitch_2.height = 203.79229736328125, 100.0
    
    #initialize glitch_1 links
    #glitch_2.Emission -> material_output.Volume
    glitch_1.links.new(glitch_2.outputs[0], material_output.inputs[1])
    return glitch_1

glitch_1 = glitch_1_node_group()

