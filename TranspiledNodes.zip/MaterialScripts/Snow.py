import bpy, mathutils

mat = bpy.data.materials.new(name = "Snow")
mat.use_nodes = True
#initialize Snow node group
def snow_node_group():

    snow = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Snow")
    
    #initialize snow nodes
    #node ColorRamp
    colorramp = snow.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.3960607945919037, 0.3960607945919037, 0.3960607945919037, 1.0)

    
    #node Principled BSDF
    principled_bsdf = snow.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = snow.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Bump.001
    bump_001 = snow.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Vector Math
    vector_math = snow.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = snow.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Invert
    invert = snow.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Mix
    mix = snow.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Input
    group_input = snow.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #snow inputs
    #input Base Color
    snow.inputs.new('NodeSocketColor', "Base Color")
    snow.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    snow.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    snow.inputs.new('NodeSocketFloat', "Scale")
    snow.inputs[1].default_value = 1.0
    snow.inputs[1].min_value = -10000.0
    snow.inputs[1].max_value = 10000.0
    snow.inputs[1].attribute_domain = 'POINT'
    
    #input Specular
    snow.inputs.new('NodeSocketFloatFactor', "Specular")
    snow.inputs[2].default_value = 0.5
    snow.inputs[2].min_value = 0.0
    snow.inputs[2].max_value = 1.0
    snow.inputs[2].attribute_domain = 'POINT'
    
    #input Subsurface
    snow.inputs.new('NodeSocketFloatFactor', "Subsurface")
    snow.inputs[3].default_value = 0.4227272570133209
    snow.inputs[3].min_value = 0.0
    snow.inputs[3].max_value = 1.0
    snow.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    snow.inputs.new('NodeSocketFloatFactor', "Roughness")
    snow.inputs[4].default_value = 0.5
    snow.inputs[4].min_value = 0.0
    snow.inputs[4].max_value = 1.0
    snow.inputs[4].attribute_domain = 'POINT'
    
    #input Detail
    snow.inputs.new('NodeSocketFloat', "Detail")
    snow.inputs[5].default_value = 2.0
    snow.inputs[5].min_value = 0.0
    snow.inputs[5].max_value = 15.0
    snow.inputs[5].attribute_domain = 'POINT'
    
    #input Hill Bump Strength
    snow.inputs.new('NodeSocketFloatFactor', "Hill Bump Strength")
    snow.inputs[6].default_value = 0.38333332538604736
    snow.inputs[6].min_value = 0.0
    snow.inputs[6].max_value = 1.0
    snow.inputs[6].attribute_domain = 'POINT'
    
    #input Crystall Bump Strength
    snow.inputs.new('NodeSocketFloatFactor', "Crystall Bump Strength")
    snow.inputs[7].default_value = 0.20000000298023224
    snow.inputs[7].min_value = 0.0
    snow.inputs[7].max_value = 1.0
    snow.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    snow.inputs.new('NodeSocketVector', "Normal")
    snow.inputs[8].default_value = (0.0, 0.0, 0.0)
    snow.inputs[8].min_value = -1.0
    snow.inputs[8].max_value = 1.0
    snow.inputs[8].attribute_domain = 'POINT'
    snow.inputs[8].hide_value = True
    
    
    
    #node RGB
    rgb = snow.nodes.new("ShaderNodeRGB")
    rgb.name = "RGB"
    
    rgb.outputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #node Voronoi Texture
    voronoi_texture = snow.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'SMOOTH_F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 200.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 0.21666666865348816
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Noise Texture
    noise_texture = snow.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 2.5
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Output
    group_output = snow.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #snow outputs
    #output BSDF
    snow.outputs.new('NodeSocketShader', "BSDF")
    snow.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    snow.outputs.new('NodeSocketColor', "Mask")
    snow.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    snow.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Mix.001
    mix_001 = snow.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.5
    
    #node ColorRamp.001
    colorramp_001 = snow.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    
    #Set locations
    colorramp.location = (223.03955078125, 131.69000244140625)
    principled_bsdf.location = (635.581787109375, 306.58160400390625)
    bump.location = (415.581787109375, -109.24847412109375)
    bump_001.location = (343.03955078125, -313.41839599609375)
    vector_math.location = (-295.5816650390625, 87.5892333984375)
    texture_coordinate_001.location = (-635.581787109375, 7.5892333984375)
    invert.location = (-259.54248046875, -78.59356689453125)
    mix.location = (480.0, 40.0)
    group_input.location = (-835.581787109375, -0.0)
    rgb.location = (283.0394592285156, 313.4184265136719)
    voronoi_texture.location = (3.039520263671875, 66.58160400390625)
    noise_texture.location = (163.03955078125, -113.41839599609375)
    group_output.location = (1240.0, 20.0)
    mix_001.location = (740.0, -360.0)
    colorramp_001.location = (536.253662109375, -515.9937744140625)
    
    #Set dimensions
    colorramp.width, colorramp.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    rgb.width, rgb.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    
    #initialize snow links
    #principled_bsdf.BSDF -> group_output.BSDF
    snow.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    snow.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    snow.links.new(noise_texture.outputs[0], bump.inputs[2])
    #rgb.Color -> principled_bsdf.Subsurface Radius
    snow.links.new(rgb.outputs[0], principled_bsdf.inputs[2])
    #voronoi_texture.Color -> colorramp.Fac
    snow.links.new(voronoi_texture.outputs[1], colorramp.inputs[0])
    #mix.Result -> principled_bsdf.Roughness
    snow.links.new(mix.outputs[2], principled_bsdf.inputs[9])
    #voronoi_texture.Color -> bump_001.Height
    snow.links.new(voronoi_texture.outputs[1], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    snow.links.new(bump_001.outputs[0], bump.inputs[3])
    #texture_coordinate_001.Object -> vector_math.Vector
    snow.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    snow.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    snow.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #group_input.Base Color -> principled_bsdf.Base Color
    snow.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Scale -> vector_math.Scale
    snow.links.new(group_input.outputs[1], vector_math.inputs[3])
    #group_input.Specular -> principled_bsdf.Specular
    snow.links.new(group_input.outputs[2], principled_bsdf.inputs[7])
    #group_input.Detail -> noise_texture.Detail
    snow.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #colorramp.Color -> mix.A
    snow.links.new(colorramp.outputs[0], mix.inputs[6])
    #invert.Color -> mix.Factor
    snow.links.new(invert.outputs[0], mix.inputs[0])
    #group_input.Roughness -> invert.Color
    snow.links.new(group_input.outputs[4], invert.inputs[1])
    #group_input.Hill Bump Strength -> bump.Strength
    snow.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Crystall Bump Strength -> bump_001.Strength
    snow.links.new(group_input.outputs[7], bump_001.inputs[0])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    snow.links.new(group_input.outputs[3], principled_bsdf.inputs[1])
    #group_input.Normal -> bump_001.Normal
    snow.links.new(group_input.outputs[8], bump_001.inputs[3])
    #group_input.Base Color -> principled_bsdf.Subsurface Color
    snow.links.new(group_input.outputs[0], principled_bsdf.inputs[3])
    #colorramp_001.Color -> mix_001.B
    snow.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #noise_texture.Fac -> mix_001.A
    snow.links.new(noise_texture.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> group_output.Mask
    snow.links.new(mix_001.outputs[2], group_output.inputs[1])
    #voronoi_texture.Color -> colorramp_001.Fac
    snow.links.new(voronoi_texture.outputs[1], colorramp_001.inputs[0])
    return snow

snow = snow_node_group()

#initialize Snow node group
def snow_1_node_group():

    snow_1 = mat.node_tree
    #start with a clean node tree
    for node in snow_1.nodes:
        snow_1.nodes.remove(node)
    #initialize snow_1 nodes
    #node Material Output
    material_output = snow_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Snow
    snow_2 = snow_1.nodes.new("ShaderNodeGroup")
    snow_2.label = "Snow"
    snow_2.name = "Snow"
    snow_2.use_custom_color = True
    snow_2.color = (0.4385440945625305, 0.4385440945625305, 0.4385440945625305)
    snow_2.node_tree = snow
    #Input_1
    snow_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_2
    snow_2.inputs[1].default_value = 1.0
    #Input_3
    snow_2.inputs[2].default_value = 0.5
    #Input_8
    snow_2.inputs[3].default_value = 0.4227272570133209
    #Input_5
    snow_2.inputs[4].default_value = 0.5
    #Input_4
    snow_2.inputs[5].default_value = 2.0
    #Input_6
    snow_2.inputs[6].default_value = 0.38333332538604736
    #Input_7
    snow_2.inputs[7].default_value = 0.20000000298023224
    #Input_9
    snow_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (582.9385375976562, 107.31582641601562)
    snow_2.location = (324.79205322265625, 107.31582641601562)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    snow_2.width, snow_2.height = 205.60446166992188, 100.0
    
    #initialize snow_1 links
    #snow_2.BSDF -> material_output.Surface
    snow_1.links.new(snow_2.outputs[0], material_output.inputs[0])
    return snow_1

snow_1 = snow_1_node_group()

