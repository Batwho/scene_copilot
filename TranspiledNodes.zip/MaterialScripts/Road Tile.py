import bpy, mathutils

mat = bpy.data.materials.new(name = "Road Tile")
mat.use_nodes = True
#initialize Road tile1 node group
def road_tile1_node_group():

    road_tile1 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Road tile1")
    
    #initialize road_tile1 nodes
    #node Bump.001
    bump_001 = road_tile1.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = True
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Bump
    bump = road_tile1.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp.001
    colorramp_001 = road_tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.33181828260421753
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.4954550266265869)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Reroute
    reroute = road_tile1.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Texture Coordinate.001
    texture_coordinate_001 = road_tile1.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Invert
    invert = road_tile1.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Mix
    mix = road_tile1.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Map Range
    map_range = road_tile1.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = -1.0
    #To Min
    map_range.inputs[3].default_value = 0.0
    #To Max
    map_range.inputs[4].default_value = 1.0
    
    #node Math.003
    math_003 = road_tile1.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'MULTIPLY'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 20.0
    
    #node Noise Texture
    noise_texture = road_tile1.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Roughness
    noise_texture.inputs[4].default_value = 0.8916666507720947
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = road_tile1.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #road_tile1 inputs
    #input Scale
    road_tile1.inputs.new('NodeSocketFloat', "Scale")
    road_tile1.inputs[0].default_value = 100.0
    road_tile1.inputs[0].min_value = -10000.0
    road_tile1.inputs[0].max_value = 10000.0
    road_tile1.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    road_tile1.inputs.new('NodeSocketColor', "Color1")
    road_tile1.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    road_tile1.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    road_tile1.inputs.new('NodeSocketColor', "Color2")
    road_tile1.inputs[2].default_value = (0.026195570826530457, 0.026195570826530457, 0.026195570826530457, 1.0)
    road_tile1.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    road_tile1.inputs.new('NodeSocketFloatFactor', "Specular")
    road_tile1.inputs[3].default_value = 0.10000000149011612
    road_tile1.inputs[3].min_value = 0.0
    road_tile1.inputs[3].max_value = 1.0
    road_tile1.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    road_tile1.inputs.new('NodeSocketFloatFactor', "Roughness")
    road_tile1.inputs[4].default_value = 0.800000011920929
    road_tile1.inputs[4].min_value = 0.0
    road_tile1.inputs[4].max_value = 1.0
    road_tile1.inputs[4].attribute_domain = 'POINT'
    
    #input Clamp
    road_tile1.inputs.new('NodeSocketFloatFactor', "Clamp")
    road_tile1.inputs[5].default_value = 0.9716654419898987
    road_tile1.inputs[5].min_value = 0.0
    road_tile1.inputs[5].max_value = 1.0
    road_tile1.inputs[5].attribute_domain = 'POINT'
    
    #input Tile Scale
    road_tile1.inputs.new('NodeSocketFloat', "Tile Scale")
    road_tile1.inputs[6].default_value = 1.0
    road_tile1.inputs[6].min_value = -10000.0
    road_tile1.inputs[6].max_value = 10000.0
    road_tile1.inputs[6].attribute_domain = 'POINT'
    
    #input Noise Scale
    road_tile1.inputs.new('NodeSocketFloat', "Noise Scale")
    road_tile1.inputs[7].default_value = 20.0
    road_tile1.inputs[7].min_value = -1000.0
    road_tile1.inputs[7].max_value = 1000.0
    road_tile1.inputs[7].attribute_domain = 'POINT'
    
    #input Noise Detail
    road_tile1.inputs.new('NodeSocketFloat', "Noise Detail")
    road_tile1.inputs[8].default_value = 10.0
    road_tile1.inputs[8].min_value = 0.0
    road_tile1.inputs[8].max_value = 15.0
    road_tile1.inputs[8].attribute_domain = 'POINT'
    
    #input Bump Strength
    road_tile1.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    road_tile1.inputs[9].default_value = 1.0
    road_tile1.inputs[9].min_value = 0.0
    road_tile1.inputs[9].max_value = 1.0
    road_tile1.inputs[9].attribute_domain = 'POINT'
    
    #input Noise Bump Strength
    road_tile1.inputs.new('NodeSocketFloatFactor', "Noise Bump Strength")
    road_tile1.inputs[10].default_value = 0.30000001192092896
    road_tile1.inputs[10].min_value = 0.0
    road_tile1.inputs[10].max_value = 1.0
    road_tile1.inputs[10].attribute_domain = 'POINT'
    
    #input Normal
    road_tile1.inputs.new('NodeSocketVector', "Normal")
    road_tile1.inputs[11].default_value = (0.0, 0.0, 0.0)
    road_tile1.inputs[11].min_value = -1.0
    road_tile1.inputs[11].max_value = 1.0
    road_tile1.inputs[11].attribute_domain = 'POINT'
    road_tile1.inputs[11].hide_value = True
    
    
    
    #node Separate XYZ
    separate_xyz = road_tile1.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"
    
    #node Math.001
    math_001 = road_tile1.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'SINE'
    math_001.use_clamp = False
    
    #node Vector Math
    vector_math = road_tile1.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Scale
    vector_math.inputs[3].default_value = 120.0
    
    #node Math
    math = road_tile1.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'SINE'
    math.use_clamp = False
    
    #node Group Output
    group_output = road_tile1.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #road_tile1 outputs
    #output BSDF
    road_tile1.outputs.new('NodeSocketShader', "BSDF")
    road_tile1.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    road_tile1.outputs.new('NodeSocketColor', "Albedo")
    road_tile1.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    road_tile1.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    road_tile1.outputs.new('NodeSocketColor', "Mask")
    road_tile1.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    road_tile1.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Math.004
    math_004 = road_tile1.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MULTIPLY'
    math_004.use_clamp = False
    #Value_001
    math_004.inputs[1].default_value = 100.0
    
    #node Math.002
    math_002 = road_tile1.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MAXIMUM'
    math_002.use_clamp = False
    
    #node Noise Texture.001
    noise_texture_001 = road_tile1.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.7583333253860474
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Principled BSDF
    principled_bsdf = road_tile1.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Vector Math.018
    vector_math_018 = road_tile1.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Mix.001
    mix_001 = road_tile1.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'BURN'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #B_Color
    mix_001.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node ColorRamp.002
    colorramp_002 = road_tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.4136362671852112
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.002
    mix_002 = road_tile1.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    
    #node Mix.003
    mix_003 = road_tile1.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Mix.004
    mix_004 = road_tile1.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'ADD'
    mix_004.clamp_factor = True
    mix_004.clamp_result = True
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    
    
    #Set locations
    bump_001.location = (806.0, -172.17138671875)
    bump.location = (1234.0, -41.464874267578125)
    colorramp_001.location = (526.0, 7.30670166015625)
    reroute.location = (-5.9658203125, -307.82861328125)
    texture_coordinate_001.location = (-1454.0, -12.17138671875)
    invert.location = (766.0, 307.82861328125)
    mix.location = (800.0, 179.99998474121094)
    map_range.location = (-54.0, 227.82861328125)
    math_003.location = (-140.0, -60.0)
    noise_texture.location = (306.0, -252.17138671875)
    group_input.location = (-1654.0, -0.0)
    separate_xyz.location = (-714.0, 107.82861328125)
    math_001.location = (-534.0, 27.82861328125)
    vector_math.location = (-934.0, 187.82861328125)
    math.location = (-494.0, 227.82861328125)
    group_output.location = (1979.9998779296875, 0.0)
    math_004.location = (-159.9998779296875, -329.36932373046875)
    math_002.location = (-274.0, 247.82861328125)
    noise_texture_001.location = (306.0, -12.171417236328125)
    principled_bsdf.location = (1679.9998779296875, 220.0)
    vector_math_018.location = (-1114.000244140625, 67.82862854003906)
    mix_001.location = (310.335693359375, 196.9219207763672)
    colorramp_002.location = (980.0, 239.99998474121094)
    mix_002.location = (1325.681640625, 294.8519287109375)
    mix_003.location = (1159.9998779296875, 459.9999694824219)
    mix_004.location = (1340.0, 560.0)
    
    #Set dimensions
    bump_001.width, bump_001.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    separate_xyz.width, separate_xyz.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    
    #initialize road_tile1 links
    #principled_bsdf.BSDF -> group_output.BSDF
    road_tile1.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> separate_xyz.Vector
    road_tile1.links.new(vector_math.outputs[0], separate_xyz.inputs[0])
    #separate_xyz.X -> math.Value
    road_tile1.links.new(separate_xyz.outputs[0], math.inputs[0])
    #separate_xyz.Y -> math_001.Value
    road_tile1.links.new(separate_xyz.outputs[1], math_001.inputs[0])
    #math.Value -> math_002.Value
    road_tile1.links.new(math.outputs[0], math_002.inputs[0])
    #math_001.Value -> math_002.Value
    road_tile1.links.new(math_001.outputs[0], math_002.inputs[1])
    #math_002.Value -> map_range.Value
    road_tile1.links.new(math_002.outputs[0], map_range.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    road_tile1.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> bump.Height
    road_tile1.links.new(mix.outputs[2], bump.inputs[2])
    #noise_texture.Fac -> bump_001.Height
    road_tile1.links.new(noise_texture.outputs[0], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    road_tile1.links.new(bump_001.outputs[0], bump.inputs[3])
    #reroute.Output -> noise_texture.Vector
    road_tile1.links.new(reroute.outputs[0], noise_texture.inputs[0])
    #colorramp_001.Color -> mix.B
    road_tile1.links.new(colorramp_001.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> colorramp_001.Fac
    road_tile1.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #mix_002.Result -> principled_bsdf.Base Color
    road_tile1.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #reroute.Output -> noise_texture_001.Vector
    road_tile1.links.new(reroute.outputs[0], noise_texture_001.inputs[0])
    #noise_texture_001.Fac -> colorramp_002.Fac
    road_tile1.links.new(noise_texture_001.outputs[0], colorramp_002.inputs[0])
    #texture_coordinate_001.UV -> vector_math_018.Vector
    road_tile1.links.new(texture_coordinate_001.outputs[2], vector_math_018.inputs[0])
    #vector_math_018.Vector -> vector_math.Vector
    road_tile1.links.new(vector_math_018.outputs[0], vector_math.inputs[0])
    #map_range.Result -> mix_001.A
    road_tile1.links.new(map_range.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> mix.A
    road_tile1.links.new(mix_001.outputs[2], mix.inputs[6])
    #mix_001.Result -> invert.Color
    road_tile1.links.new(mix_001.outputs[2], invert.inputs[1])
    #mix_003.Result -> mix_002.A
    road_tile1.links.new(mix_003.outputs[2], mix_002.inputs[6])
    #invert.Color -> mix_002.B
    road_tile1.links.new(invert.outputs[0], mix_002.inputs[7])
    #colorramp_002.Color -> mix_003.Factor
    road_tile1.links.new(colorramp_002.outputs[0], mix_003.inputs[0])
    #group_input.Clamp -> mix_001.Factor
    road_tile1.links.new(group_input.outputs[5], mix_001.inputs[0])
    #group_input.Color1 -> mix_003.A
    road_tile1.links.new(group_input.outputs[1], mix_003.inputs[6])
    #group_input.Color2 -> mix_003.B
    road_tile1.links.new(group_input.outputs[2], mix_003.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    road_tile1.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    road_tile1.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Tile Scale -> map_range.From Max
    road_tile1.links.new(group_input.outputs[6], map_range.inputs[2])
    #group_input.Scale -> vector_math_018.Scale
    road_tile1.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #math_004.Value -> noise_texture.Scale
    road_tile1.links.new(math_004.outputs[0], noise_texture.inputs[2])
    #math_003.Value -> noise_texture_001.Scale
    road_tile1.links.new(math_003.outputs[0], noise_texture_001.inputs[2])
    #group_input.Noise Scale -> math_003.Value
    road_tile1.links.new(group_input.outputs[7], math_003.inputs[0])
    #group_input.Noise Scale -> math_004.Value
    road_tile1.links.new(group_input.outputs[7], math_004.inputs[0])
    #group_input.Noise Detail -> noise_texture_001.Detail
    road_tile1.links.new(group_input.outputs[8], noise_texture_001.inputs[3])
    #group_input.Noise Detail -> noise_texture.Detail
    road_tile1.links.new(group_input.outputs[8], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    road_tile1.links.new(group_input.outputs[9], bump.inputs[0])
    #group_input.Noise Bump Strength -> bump_001.Strength
    road_tile1.links.new(group_input.outputs[10], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    road_tile1.links.new(group_input.outputs[11], bump_001.inputs[3])
    #vector_math_018.Vector -> reroute.Input
    road_tile1.links.new(vector_math_018.outputs[0], reroute.inputs[0])
    #mix_002.Result -> group_output.Albedo
    road_tile1.links.new(mix_002.outputs[2], group_output.inputs[1])
    #mix_001.Result -> mix_004.B
    road_tile1.links.new(mix_001.outputs[2], mix_004.inputs[7])
    #mix_004.Result -> group_output.Mask
    road_tile1.links.new(mix_004.outputs[2], group_output.inputs[2])
    #colorramp_002.Color -> mix_004.A
    road_tile1.links.new(colorramp_002.outputs[0], mix_004.inputs[6])
    return road_tile1

road_tile1 = road_tile1_node_group()

#initialize Road Tile node group
def road_tile_node_group():

    road_tile = mat.node_tree
    #start with a clean node tree
    for node in road_tile.nodes:
        road_tile.nodes.remove(node)
    #initialize road_tile nodes
    #node Material Output
    material_output = road_tile.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Road tile1
    road_tile1_1 = road_tile.nodes.new("ShaderNodeGroup")
    road_tile1_1.label = "Road tile1"
    road_tile1_1.name = "Road tile1"
    road_tile1_1.node_tree = road_tile1
    #Input_1
    road_tile1_1.inputs[0].default_value = 0.6499999761581421
    #Input_3
    road_tile1_1.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_4
    road_tile1_1.inputs[2].default_value = (0.026195570826530457, 0.026195570826530457, 0.026195570826530457, 1.0)
    #Input_5
    road_tile1_1.inputs[3].default_value = 0.10000000149011612
    #Input_6
    road_tile1_1.inputs[4].default_value = 0.800000011920929
    #Input_2
    road_tile1_1.inputs[5].default_value = 0.9740349054336548
    #Input_7
    road_tile1_1.inputs[6].default_value = 1.0
    #Input_8
    road_tile1_1.inputs[7].default_value = 1.0
    #Input_9
    road_tile1_1.inputs[8].default_value = 10.0
    #Input_10
    road_tile1_1.inputs[9].default_value = 1.0
    #Input_11
    road_tile1_1.inputs[10].default_value = 0.30000001192092896
    #Input_12
    road_tile1_1.inputs[11].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (671.22021484375, 155.118408203125)
    road_tile1_1.location = (372.91943359375, 155.118408203125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    road_tile1_1.width, road_tile1_1.height = 210.30078125, 100.0
    
    #initialize road_tile links
    #road_tile1_1.BSDF -> material_output.Surface
    road_tile.links.new(road_tile1_1.outputs[0], material_output.inputs[0])
    return road_tile

road_tile = road_tile_node_group()

