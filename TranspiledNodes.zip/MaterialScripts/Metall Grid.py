import bpy, mathutils

mat = bpy.data.materials.new(name = "Metall Grid")
mat.use_nodes = True
#initialize Metall_grid node group
def metall_grid_node_group():

    metall_grid = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Metall_grid")
    
    #initialize metall_grid nodes
    #node Math.001
    math_001 = metall_grid.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'GREATER_THAN'
    math_001.use_clamp = False
    
    #node Principled BSDF
    principled_bsdf = metall_grid.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = metall_grid.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Vector Math
    vector_math = metall_grid.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = metall_grid.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Wave Texture.001
    wave_texture_001 = metall_grid.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'Y'
    wave_texture_001.rings_direction = 'Y'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Scale
    wave_texture_001.inputs[1].default_value = 15.0
    #Detail
    wave_texture_001.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 2.0
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    
    #node RGB Curves
    rgb_curves = metall_grid.nodes.new("ShaderNodeRGBCurve")
    rgb_curves.name = "RGB Curves"
    #mapping settings
    rgb_curves.mapping.extend = 'EXTRAPOLATED'
    rgb_curves.mapping.tone = 'STANDARD'
    rgb_curves.mapping.black_level = (0.0, 0.0, 0.0)
    rgb_curves.mapping.white_level = (1.0, 1.0, 1.0)
    rgb_curves.mapping.clip_min_x = 0.0
    rgb_curves.mapping.clip_min_y = 0.0
    rgb_curves.mapping.clip_max_x = 1.0
    rgb_curves.mapping.clip_max_y = 1.0
    rgb_curves.mapping.use_clip = True
    #curve 0
    rgb_curves_curve_0 = rgb_curves.mapping.curves[0]
    rgb_curves_curve_0_point_0 = rgb_curves_curve_0.points[0]
    rgb_curves_curve_0_point_0.location = (0.0, 0.0)
    rgb_curves_curve_0_point_0.handle_type = 'AUTO'
    rgb_curves_curve_0_point_1 = rgb_curves_curve_0.points[1]
    rgb_curves_curve_0_point_1.location = (1.0, 1.0)
    rgb_curves_curve_0_point_1.handle_type = 'AUTO'
    #curve 1
    rgb_curves_curve_1 = rgb_curves.mapping.curves[1]
    rgb_curves_curve_1_point_0 = rgb_curves_curve_1.points[0]
    rgb_curves_curve_1_point_0.location = (0.0, 0.0)
    rgb_curves_curve_1_point_0.handle_type = 'AUTO'
    rgb_curves_curve_1_point_1 = rgb_curves_curve_1.points[1]
    rgb_curves_curve_1_point_1.location = (1.0, 1.0)
    rgb_curves_curve_1_point_1.handle_type = 'AUTO'
    #curve 2
    rgb_curves_curve_2 = rgb_curves.mapping.curves[2]
    rgb_curves_curve_2_point_0 = rgb_curves_curve_2.points[0]
    rgb_curves_curve_2_point_0.location = (0.0, 0.0)
    rgb_curves_curve_2_point_0.handle_type = 'AUTO'
    rgb_curves_curve_2_point_1 = rgb_curves_curve_2.points[1]
    rgb_curves_curve_2_point_1.location = (1.0, 1.0)
    rgb_curves_curve_2_point_1.handle_type = 'AUTO'
    #curve 3
    rgb_curves_curve_3 = rgb_curves.mapping.curves[3]
    rgb_curves_curve_3_point_0 = rgb_curves_curve_3.points[0]
    rgb_curves_curve_3_point_0.location = (0.0, 0.0)
    rgb_curves_curve_3_point_0.handle_type = 'AUTO'
    rgb_curves_curve_3_point_1 = rgb_curves_curve_3.points[1]
    rgb_curves_curve_3_point_1.location = (0.29090920090675354, 0.649999737739563)
    rgb_curves_curve_3_point_1.handle_type = 'AUTO'
    rgb_curves_curve_3_point_2 = rgb_curves_curve_3.points.new(1.0, 1.0)
    rgb_curves_curve_3_point_2.handle_type = 'AUTO'
    #update curve after changes
    rgb_curves.mapping.update()
    #Fac
    rgb_curves.inputs[0].default_value = 1.0
    
    #node Group Output
    group_output = metall_grid.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #metall_grid outputs
    #output BSDF
    metall_grid.outputs.new('NodeSocketShader', "BSDF")
    metall_grid.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    metall_grid.outputs.new('NodeSocketFloat', "Mask")
    metall_grid.outputs[1].default_value = 0.0
    metall_grid.outputs[1].min_value = -3.4028234663852886e+38
    metall_grid.outputs[1].max_value = 3.4028234663852886e+38
    metall_grid.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Wave Texture
    wave_texture = metall_grid.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 15.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 2.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    
    #node Group Input
    group_input = metall_grid.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #metall_grid inputs
    #input Scale
    metall_grid.inputs.new('NodeSocketFloat', "Scale")
    metall_grid.inputs[0].default_value = 1.0
    metall_grid.inputs[0].min_value = -10000.0
    metall_grid.inputs[0].max_value = 10000.0
    metall_grid.inputs[0].attribute_domain = 'POINT'
    
    #input Base Color
    metall_grid.inputs.new('NodeSocketColor', "Base Color")
    metall_grid.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    metall_grid.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    metall_grid.inputs.new('NodeSocketFloatFactor', "Roughness")
    metall_grid.inputs[2].default_value = 0.0
    metall_grid.inputs[2].min_value = 0.0
    metall_grid.inputs[2].max_value = 1.0
    metall_grid.inputs[2].attribute_domain = 'POINT'
    
    #input Distortion
    metall_grid.inputs.new('NodeSocketFloat', "Distortion")
    metall_grid.inputs[3].default_value = 0.0
    metall_grid.inputs[3].min_value = -1000.0
    metall_grid.inputs[3].max_value = 1000.0
    metall_grid.inputs[3].attribute_domain = 'POINT'
    
    #input Phase Offset X
    metall_grid.inputs.new('NodeSocketFloat', "Phase Offset X")
    metall_grid.inputs[4].default_value = 0.0
    metall_grid.inputs[4].min_value = -1000.0
    metall_grid.inputs[4].max_value = 1000.0
    metall_grid.inputs[4].attribute_domain = 'POINT'
    
    #input Phase Offset Y
    metall_grid.inputs.new('NodeSocketFloat', "Phase Offset Y")
    metall_grid.inputs[5].default_value = 0.0
    metall_grid.inputs[5].min_value = -1000.0
    metall_grid.inputs[5].max_value = 1000.0
    metall_grid.inputs[5].attribute_domain = 'POINT'
    
    #input Hole Scale
    metall_grid.inputs.new('NodeSocketFloat', "Hole Scale")
    metall_grid.inputs[6].default_value = 0.5099999904632568
    metall_grid.inputs[6].min_value = -10000.0
    metall_grid.inputs[6].max_value = 10000.0
    metall_grid.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    metall_grid.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    metall_grid.inputs[7].default_value = 0.2083333134651184
    metall_grid.inputs[7].min_value = 0.0
    metall_grid.inputs[7].max_value = 1.0
    metall_grid.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    metall_grid.inputs.new('NodeSocketVector', "Normal")
    metall_grid.inputs[8].default_value = (0.0, 0.0, 0.0)
    metall_grid.inputs[8].min_value = -1.0
    metall_grid.inputs[8].max_value = 1.0
    metall_grid.inputs[8].attribute_domain = 'POINT'
    metall_grid.inputs[8].hide_value = True
    
    
    
    #node Math
    math = metall_grid.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MAXIMUM'
    math.use_clamp = False
    
    
    #Set locations
    math_001.location = (352.3369140625, 206.65829467773438)
    principled_bsdf.location = (879.8775634765625, 241.81179809570312)
    bump.location = (611.412109375, -257.4797058105469)
    vector_math.location = (-528.587890625, 42.520294189453125)
    texture_coordinate_001.location = (-848.587890625, -17.479705810546875)
    wave_texture_001.location = (-248.587890625, -97.47964477539062)
    rgb_curves.location = (240.111328125, -71.4769287109375)
    group_output.location = (1169.8775634765625, -7.833953857421875)
    wave_texture.location = (-248.587890625, 202.52035522460938)
    group_input.location = (-1048.587890625, -7.833953857421875)
    math.location = (71.412109375, 202.52035522460938)
    
    #Set dimensions
    math_001.width, math_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    rgb_curves.width, rgb_curves.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    
    #initialize metall_grid links
    #principled_bsdf.BSDF -> group_output.BSDF
    metall_grid.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #wave_texture.Color -> math.Value
    metall_grid.links.new(wave_texture.outputs[0], math.inputs[0])
    #wave_texture_001.Color -> math.Value
    metall_grid.links.new(wave_texture_001.outputs[0], math.inputs[1])
    #math.Value -> math_001.Value
    metall_grid.links.new(math.outputs[0], math_001.inputs[0])
    #math_001.Value -> principled_bsdf.Alpha
    metall_grid.links.new(math_001.outputs[0], principled_bsdf.inputs[21])
    #bump.Normal -> principled_bsdf.Normal
    metall_grid.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #vector_math.Vector -> wave_texture.Vector
    metall_grid.links.new(vector_math.outputs[0], wave_texture.inputs[0])
    #vector_math.Vector -> wave_texture_001.Vector
    metall_grid.links.new(vector_math.outputs[0], wave_texture_001.inputs[0])
    #texture_coordinate_001.UV -> vector_math.Vector
    metall_grid.links.new(texture_coordinate_001.outputs[2], vector_math.inputs[0])
    #math.Value -> rgb_curves.Color
    metall_grid.links.new(math.outputs[0], rgb_curves.inputs[1])
    #rgb_curves.Color -> bump.Height
    metall_grid.links.new(rgb_curves.outputs[0], bump.inputs[2])
    #group_input.Scale -> vector_math.Scale
    metall_grid.links.new(group_input.outputs[0], vector_math.inputs[3])
    #group_input.Base Color -> principled_bsdf.Base Color
    metall_grid.links.new(group_input.outputs[1], principled_bsdf.inputs[0])
    #group_input.Distortion -> wave_texture.Distortion
    metall_grid.links.new(group_input.outputs[3], wave_texture.inputs[2])
    #group_input.Distortion -> wave_texture_001.Distortion
    metall_grid.links.new(group_input.outputs[3], wave_texture_001.inputs[2])
    #group_input.Phase Offset X -> wave_texture.Phase Offset
    metall_grid.links.new(group_input.outputs[4], wave_texture.inputs[6])
    #group_input.Phase Offset Y -> wave_texture_001.Phase Offset
    metall_grid.links.new(group_input.outputs[5], wave_texture_001.inputs[6])
    #group_input.Roughness -> principled_bsdf.Roughness
    metall_grid.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #group_input.Hole Scale -> math_001.Value
    metall_grid.links.new(group_input.outputs[6], math_001.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    metall_grid.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    metall_grid.links.new(group_input.outputs[8], bump.inputs[3])
    #math.Value -> group_output.Mask
    metall_grid.links.new(math.outputs[0], group_output.inputs[1])
    return metall_grid

metall_grid = metall_grid_node_group()

#initialize Metall Grid node group
def metall_grid_1_node_group():

    metall_grid_1 = mat.node_tree
    #start with a clean node tree
    for node in metall_grid_1.nodes:
        metall_grid_1.nodes.remove(node)
    #initialize metall_grid_1 nodes
    #node Material Output
    material_output = metall_grid_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Metall_grid
    metall_grid_2 = metall_grid_1.nodes.new("ShaderNodeGroup")
    metall_grid_2.label = "Metall_grid"
    metall_grid_2.name = "Metall_grid"
    metall_grid_2.node_tree = metall_grid
    #Input_1
    metall_grid_2.inputs[0].default_value = 1.0
    #Input_2
    metall_grid_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_6
    metall_grid_2.inputs[2].default_value = 0.0
    #Input_3
    metall_grid_2.inputs[3].default_value = 0.0
    #Input_4
    metall_grid_2.inputs[4].default_value = 0.0
    #Input_5
    metall_grid_2.inputs[5].default_value = 0.0
    #Input_7
    metall_grid_2.inputs[6].default_value = 0.5099999904632568
    #Input_8
    metall_grid_2.inputs[7].default_value = 0.20000000298023224
    #Input_9
    metall_grid_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (689.86083984375, 150.289794921875)
    metall_grid_2.location = (441.84423828125, 144.04833984375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    metall_grid_2.width, metall_grid_2.height = 171.0283203125, 100.0
    
    #initialize metall_grid_1 links
    #metall_grid_2.BSDF -> material_output.Surface
    metall_grid_1.links.new(metall_grid_2.outputs[0], material_output.inputs[0])
    return metall_grid_1

metall_grid_1 = metall_grid_1_node_group()

