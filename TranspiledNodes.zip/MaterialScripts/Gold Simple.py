import bpy, mathutils

mat = bpy.data.materials.new(name = "Gold Simple")
mat.use_nodes = True
#initialize Gold simple node group
def gold_simple_node_group():

    gold_simple = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Gold simple")
    
    #initialize gold_simple nodes
    #node Group Output
    group_output = gold_simple.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #gold_simple outputs
    #output BSDF
    gold_simple.outputs.new('NodeSocketShader', "BSDF")
    gold_simple.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Group Input
    group_input = gold_simple.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #gold_simple inputs
    #input Base Color
    gold_simple.inputs.new('NodeSocketColor', "Base Color")
    gold_simple.inputs[0].default_value = (1.0, 0.5040153861045837, 0.16143031418323517, 1.0)
    gold_simple.inputs[0].attribute_domain = 'POINT'
    
    #input Roughness
    gold_simple.inputs.new('NodeSocketFloatFactor', "Roughness")
    gold_simple.inputs[1].default_value = 0.15000000596046448
    gold_simple.inputs[1].min_value = 0.0
    gold_simple.inputs[1].max_value = 1.0
    gold_simple.inputs[1].attribute_domain = 'POINT'
    
    #input Anisotropic
    gold_simple.inputs.new('NodeSocketFloatFactor', "Anisotropic")
    gold_simple.inputs[2].default_value = 0.0
    gold_simple.inputs[2].min_value = 0.0
    gold_simple.inputs[2].max_value = 1.0
    gold_simple.inputs[2].attribute_domain = 'POINT'
    
    #input Normal
    gold_simple.inputs.new('NodeSocketVector', "Normal")
    gold_simple.inputs[3].default_value = (0.0, 0.0, 0.0)
    gold_simple.inputs[3].min_value = -3.4028234663852886e+38
    gold_simple.inputs[3].max_value = 3.4028234663852886e+38
    gold_simple.inputs[3].attribute_domain = 'POINT'
    gold_simple.inputs[3].hide_value = True
    
    
    
    #node Principled BSDF
    principled_bsdf = gold_simple.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    
    #Set locations
    group_output.location = (380.72991943359375, -0.0)
    group_input.location = (-290.72991943359375, -0.0)
    principled_bsdf.location = (90.72991943359375, 58.24493408203125)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    
    #initialize gold_simple links
    #principled_bsdf.BSDF -> group_output.BSDF
    gold_simple.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #group_input.Base Color -> principled_bsdf.Base Color
    gold_simple.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    gold_simple.links.new(group_input.outputs[1], principled_bsdf.inputs[9])
    #group_input.Anisotropic -> principled_bsdf.Anisotropic
    gold_simple.links.new(group_input.outputs[2], principled_bsdf.inputs[10])
    #group_input.Normal -> principled_bsdf.Normal
    gold_simple.links.new(group_input.outputs[3], principled_bsdf.inputs[22])
    return gold_simple

gold_simple = gold_simple_node_group()

#initialize Gold Simple node group
def gold_simple_1_node_group():

    gold_simple_1 = mat.node_tree
    #start with a clean node tree
    for node in gold_simple_1.nodes:
        gold_simple_1.nodes.remove(node)
    #initialize gold_simple_1 nodes
    #node Material Output
    material_output = gold_simple_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Gold simple
    gold_simple_2 = gold_simple_1.nodes.new("ShaderNodeGroup")
    gold_simple_2.label = "Gold simple"
    gold_simple_2.name = "Gold simple"
    gold_simple_2.node_tree = gold_simple
    #Input_1
    gold_simple_2.inputs[0].default_value = (1.0, 0.5040153861045837, 0.16143031418323517, 1.0)
    #Input_2
    gold_simple_2.inputs[1].default_value = 0.15000000596046448
    #Input_3
    gold_simple_2.inputs[2].default_value = 0.0
    #Input_4
    gold_simple_2.inputs[3].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (689.96337890625, 91.27099609375)
    gold_simple_2.location = (392.9638671875, 91.27099609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    gold_simple_2.width, gold_simple_2.height = 171.63775634765625, 100.0
    
    #initialize gold_simple_1 links
    #gold_simple_2.BSDF -> material_output.Surface
    gold_simple_1.links.new(gold_simple_2.outputs[0], material_output.inputs[0])
    return gold_simple_1

gold_simple_1 = gold_simple_1_node_group()

