import bpy, mathutils

mat = bpy.data.materials.new(name = "Bubble")
mat.use_nodes = True
#initialize Bubble node group
def bubble_node_group():

    bubble = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Bubble")
    
    #initialize bubble nodes
    #node Mix
    mix = bubble.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.6908330917358398
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate
    texture_coordinate = bubble.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Noise Texture
    noise_texture = bubble.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    noise_texture.inputs[1].default_value = 0.0949999988079071
    #Detail
    noise_texture.inputs[3].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Layer Weight
    layer_weight = bubble.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    #Blend
    layer_weight.inputs[0].default_value = 0.49000000953674316
    #Normal
    layer_weight.inputs[1].default_value = (0.0, 0.0, 0.0)
    
    #node Principled BSDF
    principled_bsdf = bubble.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Math
    math = bubble.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 3.4700000286102295
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Invert
    invert = bubble.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Input
    group_input = bubble.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #bubble inputs
    #input Color Hue
    bubble.inputs.new('NodeSocketFloatFactor', "Color Hue")
    bubble.inputs[0].default_value = 1.0
    bubble.inputs[0].min_value = 0.0
    bubble.inputs[0].max_value = 1.0
    bubble.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    bubble.inputs.new('NodeSocketFloat', "Scale")
    bubble.inputs[1].default_value = 0.5
    bubble.inputs[1].min_value = -10000.0
    bubble.inputs[1].max_value = 10000.0
    bubble.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    bubble.inputs.new('NodeSocketFloat', "Saturation")
    bubble.inputs[2].default_value = 1.2999999523162842
    bubble.inputs[2].min_value = 0.0
    bubble.inputs[2].max_value = 2.0
    bubble.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    bubble.inputs.new('NodeSocketFloatFactor', "Roughness")
    bubble.inputs[3].default_value = 0.0
    bubble.inputs[3].min_value = 0.0
    bubble.inputs[3].max_value = 1.0
    bubble.inputs[3].attribute_domain = 'POINT'
    
    #input IOR
    bubble.inputs.new('NodeSocketFloat', "IOR")
    bubble.inputs[4].default_value = 1.4500000476837158
    bubble.inputs[4].min_value = 0.0
    bubble.inputs[4].max_value = 1000.0
    bubble.inputs[4].attribute_domain = 'POINT'
    
    #input Normal
    bubble.inputs.new('NodeSocketVector', "Normal")
    bubble.inputs[5].default_value = (0.0, 0.0, 0.0)
    bubble.inputs[5].min_value = -1.0
    bubble.inputs[5].max_value = 1.0
    bubble.inputs[5].attribute_domain = 'POINT'
    bubble.inputs[5].hide_value = True
    
    
    
    #node Noise Texture.001
    noise_texture_001 = bubble.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #W
    noise_texture_001.inputs[1].default_value = 0.0
    #Detail
    noise_texture_001.inputs[3].default_value = 6.099999904632568
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.49166667461395264
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Group Output
    group_output = bubble.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #bubble outputs
    #output BSDF
    bubble.outputs.new('NodeSocketShader', "BSDF")
    bubble.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    bubble.outputs.new('NodeSocketColor', "Albedo")
    bubble.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    bubble.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    bubble.outputs.new('NodeSocketFloat', "Mask")
    bubble.outputs[2].default_value = 0.0
    bubble.outputs[2].min_value = -3.4028234663852886e+38
    bubble.outputs[2].max_value = 3.4028234663852886e+38
    bubble.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    bubble.outputs.new('NodeSocketVector', "Normal")
    bubble.outputs[3].default_value = (0.0, 0.0, 0.0)
    bubble.outputs[3].min_value = -3.4028234663852886e+38
    bubble.outputs[3].max_value = 3.4028234663852886e+38
    bubble.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Hue Saturation Value
    hue_saturation_value = bubble.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 2.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Mix.001
    mix_001 = bubble.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'COLOR'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Color
    mix_001.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Math.002
    math_002 = bubble.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.5
    #Value_002
    math_002.inputs[2].default_value = 0.5
    
    #node Bump
    bump = bubble.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Strength
    bump.inputs[0].default_value = 0.8387500047683716
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Math.001
    math_001 = bubble.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = 0.8100000023841858
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    
    #Set locations
    mix.location = (-314.9464111328125, -57.09358215332031)
    texture_coordinate.location = (-565.0535888671875, -170.0)
    noise_texture.location = (-85.0535888671875, -230.0)
    layer_weight.location = (-565.0535888671875, -49.99998474121094)
    principled_bsdf.location = (565.0535888671875, 250.0)
    math.location = (-305.0535888671875, 170.00003051757812)
    invert.location = (-199.99993896484375, 280.0)
    group_input.location = (-765.0535888671875, -0.0)
    noise_texture_001.location = (-94.9464111328125, -10.0)
    group_output.location = (855.0535888671875, -0.0)
    hue_saturation_value.location = (220.0, 140.00003051757812)
    mix_001.location = (380.0, 360.0000305175781)
    math_002.location = (40.0, 280.0)
    bump.location = (214.9464111328125, -130.14828491210938)
    math_001.location = (-305.0535888671875, -250.0)
    
    #Set dimensions
    mix.width, mix.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    layer_weight.width, layer_weight.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    
    #initialize bubble links
    #principled_bsdf.BSDF -> group_output.BSDF
    bubble.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    bubble.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    bubble.links.new(noise_texture.outputs[0], bump.inputs[2])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    bubble.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #noise_texture_001.Color -> hue_saturation_value.Color
    bubble.links.new(noise_texture_001.outputs[1], hue_saturation_value.inputs[4])
    #mix.Result -> noise_texture_001.Vector
    bubble.links.new(mix.outputs[2], noise_texture_001.inputs[0])
    #texture_coordinate.Object -> mix.B
    bubble.links.new(texture_coordinate.outputs[3], mix.inputs[7])
    #layer_weight.Fresnel -> mix.A
    bubble.links.new(layer_weight.outputs[0], mix.inputs[6])
    #math.Value -> noise_texture_001.Scale
    bubble.links.new(math.outputs[0], noise_texture_001.inputs[2])
    #math_001.Value -> noise_texture.Scale
    bubble.links.new(math_001.outputs[0], noise_texture.inputs[2])
    #group_input.Scale -> math.Value
    bubble.links.new(group_input.outputs[1], math.inputs[1])
    #group_input.Scale -> math_001.Value
    bubble.links.new(group_input.outputs[1], math_001.inputs[1])
    #group_input.Saturation -> hue_saturation_value.Saturation
    bubble.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    #group_input.Roughness -> principled_bsdf.Transmission Roughness
    bubble.links.new(group_input.outputs[3], principled_bsdf.inputs[18])
    #group_input.IOR -> principled_bsdf.IOR
    bubble.links.new(group_input.outputs[4], principled_bsdf.inputs[16])
    #group_input.Normal -> bump.Normal
    bubble.links.new(group_input.outputs[5], bump.inputs[3])
    #math_002.Value -> hue_saturation_value.Hue
    bubble.links.new(math_002.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Color Hue -> invert.Fac
    bubble.links.new(group_input.outputs[0], invert.inputs[0])
    #invert.Color -> math_002.Value
    bubble.links.new(invert.outputs[0], math_002.inputs[0])
    #noise_texture_001.Fac -> group_output.Mask
    bubble.links.new(noise_texture_001.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> mix_001.B
    bubble.links.new(hue_saturation_value.outputs[0], mix_001.inputs[7])
    #mix_001.Result -> group_output.Albedo
    bubble.links.new(mix_001.outputs[2], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    bubble.links.new(bump.outputs[0], group_output.inputs[3])
    return bubble

bubble = bubble_node_group()

#initialize Bubble node group
def bubble_1_node_group():

    bubble_1 = mat.node_tree
    #start with a clean node tree
    for node in bubble_1.nodes:
        bubble_1.nodes.remove(node)
    #initialize bubble_1 nodes
    #node Material Output
    material_output = bubble_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Bubble
    bubble_2 = bubble_1.nodes.new("ShaderNodeGroup")
    bubble_2.label = "Bubble"
    bubble_2.name = "Bubble"
    bubble_2.use_custom_color = True
    bubble_2.color = (0.07271838188171387, 0.17363101243972778, 0.2265842854976654)
    bubble_2.node_tree = bubble
    #Input_6
    bubble_2.inputs[0].default_value = 0.0
    #Input_1
    bubble_2.inputs[1].default_value = 0.5
    #Input_2
    bubble_2.inputs[2].default_value = 1.2999999523162842
    #Input_3
    bubble_2.inputs[3].default_value = 0.0
    #Input_4
    bubble_2.inputs[4].default_value = 1.4500000476837158
    #Input_5
    bubble_2.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (664.62548828125, 46.63232421875)
    bubble_2.location = (459.564453125, 44.364013671875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    bubble_2.width, bubble_2.height = 154.95361328125, 100.0
    
    #initialize bubble_1 links
    #bubble_2.BSDF -> material_output.Surface
    bubble_1.links.new(bubble_2.outputs[0], material_output.inputs[0])
    return bubble_1

bubble_1 = bubble_1_node_group()

