import bpy, mathutils

mat = bpy.data.materials.new(name = "Basic Fog Really Thick")
mat.use_nodes = True
#initialize Basic_Fog really thick node group
def basic_fog_really_thick_node_group():

    basic_fog_really_thick = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Basic_Fog really thick")
    
    #initialize basic_fog_really_thick nodes
    #node Group Output
    group_output = basic_fog_really_thick.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #basic_fog_really_thick outputs
    #output Volume
    basic_fog_really_thick.outputs.new('NodeSocketShader', "Volume")
    basic_fog_really_thick.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Principled Volume
    principled_volume = basic_fog_really_thick.nodes.new("ShaderNodeVolumePrincipled")
    principled_volume.name = "Principled Volume"
    #Color Attribute
    principled_volume.inputs[1].default_value = ""
    #Density Attribute
    principled_volume.inputs[3].default_value = "density"
    #Absorption Color
    principled_volume.inputs[5].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_volume.inputs[6].default_value = 0.0
    #Emission Color
    principled_volume.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    #Blackbody Intensity
    principled_volume.inputs[8].default_value = 0.0
    #Blackbody Tint
    principled_volume.inputs[9].default_value = (1.0, 1.0, 1.0, 1.0)
    #Temperature
    principled_volume.inputs[10].default_value = 1000.0
    #Temperature Attribute
    principled_volume.inputs[11].default_value = "temperature"
    #Weight
    principled_volume.inputs[12].default_value = 0.0
    
    #node Group Input
    group_input = basic_fog_really_thick.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #basic_fog_really_thick inputs
    #input Color
    basic_fog_really_thick.inputs.new('NodeSocketColor', "Color")
    basic_fog_really_thick.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    basic_fog_really_thick.inputs[0].attribute_domain = 'POINT'
    
    #input Density
    basic_fog_really_thick.inputs.new('NodeSocketFloat', "Density")
    basic_fog_really_thick.inputs[1].default_value = 0.10000000149011612
    basic_fog_really_thick.inputs[1].min_value = 0.0
    basic_fog_really_thick.inputs[1].max_value = 1000.0
    basic_fog_really_thick.inputs[1].attribute_domain = 'POINT'
    
    #input Anisotropy
    basic_fog_really_thick.inputs.new('NodeSocketFloatFactor', "Anisotropy")
    basic_fog_really_thick.inputs[2].default_value = 0.30000001192092896
    basic_fog_really_thick.inputs[2].min_value = -1.0
    basic_fog_really_thick.inputs[2].max_value = 1.0
    basic_fog_really_thick.inputs[2].attribute_domain = 'POINT'
    
    
    
    
    #Set locations
    group_output.location = (290.0, -0.0)
    principled_volume.location = (0.0, 0.0)
    group_input.location = (-200.0, -0.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    principled_volume.width, principled_volume.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize basic_fog_really_thick links
    #principled_volume.Volume -> group_output.Volume
    basic_fog_really_thick.links.new(principled_volume.outputs[0], group_output.inputs[0])
    #group_input.Color -> principled_volume.Color
    basic_fog_really_thick.links.new(group_input.outputs[0], principled_volume.inputs[0])
    #group_input.Density -> principled_volume.Density
    basic_fog_really_thick.links.new(group_input.outputs[1], principled_volume.inputs[2])
    #group_input.Anisotropy -> principled_volume.Anisotropy
    basic_fog_really_thick.links.new(group_input.outputs[2], principled_volume.inputs[4])
    return basic_fog_really_thick

basic_fog_really_thick = basic_fog_really_thick_node_group()

#initialize Basic Fog Really Thick node group
def basic_fog_really_thick_1_node_group():

    basic_fog_really_thick_1 = mat.node_tree
    #start with a clean node tree
    for node in basic_fog_really_thick_1.nodes:
        basic_fog_really_thick_1.nodes.remove(node)
    #initialize basic_fog_really_thick_1 nodes
    #node Material Output
    material_output = basic_fog_really_thick_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Basic_Fog really thick
    basic_fog_really_thick_2 = basic_fog_really_thick_1.nodes.new("ShaderNodeGroup")
    basic_fog_really_thick_2.label = "Basic_Fog really thick"
    basic_fog_really_thick_2.name = "Basic_Fog really thick"
    basic_fog_really_thick_2.node_tree = basic_fog_really_thick
    #Input_13
    basic_fog_really_thick_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_14
    basic_fog_really_thick_2.inputs[1].default_value = 0.10000000149011612
    #Input_15
    basic_fog_really_thick_2.inputs[2].default_value = 0.30000001192092896
    
    
    #Set locations
    material_output.location = (722.74951171875, 132.858154296875)
    basic_fog_really_thick_2.location = (395.64794921875, 132.858154296875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    basic_fog_really_thick_2.width, basic_fog_really_thick_2.height = 182.5107421875, 100.0
    
    #initialize basic_fog_really_thick_1 links
    #basic_fog_really_thick_2.Volume -> material_output.Volume
    basic_fog_really_thick_1.links.new(basic_fog_really_thick_2.outputs[0], material_output.inputs[1])
    return basic_fog_really_thick_1

basic_fog_really_thick_1 = basic_fog_really_thick_1_node_group()

