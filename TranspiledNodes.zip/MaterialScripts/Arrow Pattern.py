import bpy, mathutils

mat = bpy.data.materials.new(name = "Arrow Pattern")
mat.use_nodes = True
#initialize Arrow pattern node group
def arrow_pattern_node_group():

    arrow_pattern = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Arrow pattern")
    
    #initialize arrow_pattern nodes
    #node Vector Math
    vector_math = arrow_pattern.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate
    texture_coordinate = arrow_pattern.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node ColorRamp
    colorramp = arrow_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.37890923023223877
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.4227273464202881)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Wave Texture
    wave_texture = arrow_pattern.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'Y'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 6.2831854820251465
    #Distortion
    wave_texture.inputs[2].default_value = 0.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node ColorRamp.001
    colorramp_001 = arrow_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.15909096598625183
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.20909130573272705)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = arrow_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.4152728319168091
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.43636369705200195)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.003
    colorramp_003 = arrow_pattern.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.23636409640312195
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.34999996423721313)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Mix.002
    mix_002 = arrow_pattern.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'ADD'
    mix_002.clamp_factor = True
    mix_002.clamp_result = True
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix
    mix = arrow_pattern.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Wave Texture.001
    wave_texture_001 = arrow_pattern.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'X'
    wave_texture_001.rings_direction = 'X'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Scale
    wave_texture_001.inputs[1].default_value = 6.2831854820251465
    #Distortion
    wave_texture_001.inputs[2].default_value = 0.0
    #Detail
    wave_texture_001.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture_001.inputs[6].default_value = 0.0
    
    #node Voronoi Texture.001
    voronoi_texture_001 = arrow_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'MANHATTAN'
    voronoi_texture_001.feature = 'F1'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #W
    voronoi_texture_001.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture_001.inputs[2].default_value = 20.0
    #Smoothness
    voronoi_texture_001.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture_001.inputs[4].default_value = 0.699999988079071
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = arrow_pattern.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MANHATTAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture.inputs[2].default_value = 20.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.699999988079071
    #Randomness
    voronoi_texture.inputs[5].default_value = 0.0
    
    #node Mix.001
    mix_001 = arrow_pattern.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = arrow_pattern.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #arrow_pattern outputs
    #output BSDF
    arrow_pattern.outputs.new('NodeSocketShader', "BSDF")
    arrow_pattern.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = arrow_pattern.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Mix.003
    mix_003 = arrow_pattern.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_003.inputs[2].default_value = 0.0
    #B_Float
    mix_003.inputs[3].default_value = 0.0
    #A_Vector
    mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = arrow_pattern.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = arrow_pattern.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #arrow_pattern inputs
    #input Color1
    arrow_pattern.inputs.new('NodeSocketColor', "Color1")
    arrow_pattern.inputs[0].default_value = (1.0, 0.15037527680397034, 0.022407930344343185, 1.0)
    arrow_pattern.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    arrow_pattern.inputs.new('NodeSocketColor', "Color2")
    arrow_pattern.inputs[1].default_value = (0.08869040757417679, 0.08869040757417679, 0.08869040757417679, 1.0)
    arrow_pattern.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    arrow_pattern.inputs.new('NodeSocketFloat', "Scale")
    arrow_pattern.inputs[2].default_value = 1.0
    arrow_pattern.inputs[2].min_value = -10000.0
    arrow_pattern.inputs[2].max_value = 10000.0
    arrow_pattern.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    arrow_pattern.inputs.new('NodeSocketFloatFactor', "Roughness")
    arrow_pattern.inputs[3].default_value = 0.5
    arrow_pattern.inputs[3].min_value = 0.0
    arrow_pattern.inputs[3].max_value = 1.0
    arrow_pattern.inputs[3].attribute_domain = 'POINT'
    
    #input Bump Strength
    arrow_pattern.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    arrow_pattern.inputs[4].default_value = 1.0
    arrow_pattern.inputs[4].min_value = 0.0
    arrow_pattern.inputs[4].max_value = 1.0
    arrow_pattern.inputs[4].attribute_domain = 'POINT'
    
    #input Normal
    arrow_pattern.inputs.new('NodeSocketVector', "Normal")
    arrow_pattern.inputs[5].default_value = (0.0, 0.0, 0.0)
    arrow_pattern.inputs[5].min_value = -1.0
    arrow_pattern.inputs[5].max_value = 1.0
    arrow_pattern.inputs[5].attribute_domain = 'POINT'
    arrow_pattern.inputs[5].hide_value = True
    
    
    
    
    #Set locations
    vector_math.location = (-820.0, 113.46469116210938)
    texture_coordinate.location = (-1040.0, 133.46463012695312)
    colorramp.location = (-340.0, 193.46469116210938)
    wave_texture.location = (-540.0, 453.4646911621094)
    colorramp_001.location = (-300.00006103515625, 433.4646911621094)
    colorramp_002.location = (-339.9998779296875, -393.4646911621094)
    colorramp_003.location = (-299.9998779296875, -153.46469116210938)
    mix_002.location = (20.0001220703125, -373.4646911621094)
    mix.location = (20.0, 213.46469116210938)
    wave_texture_001.location = (-539.9998779296875, -133.46466064453125)
    voronoi_texture_001.location = (-539.9998779296875, -453.4646911621094)
    voronoi_texture.location = (-540.0, 133.46463012695312)
    mix_001.location = (248.254150390625, 131.842041015625)
    group_output.location = (1330.0, -0.0)
    principled_bsdf.location = (1040.0, 153.46469116210938)
    mix_003.location = (700.0, 113.46469116210938)
    bump.location = (860.0001220703125, -326.5353088378906)
    group_input.location = (-1240.0, -0.0)
    
    #Set dimensions
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize arrow_pattern links
    #principled_bsdf.BSDF -> group_output.BSDF
    arrow_pattern.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    arrow_pattern.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #texture_coordinate.UV -> vector_math.Vector
    arrow_pattern.links.new(texture_coordinate.outputs[2], vector_math.inputs[0])
    #voronoi_texture.Distance -> colorramp.Fac
    arrow_pattern.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> mix.A
    arrow_pattern.links.new(colorramp.outputs[0], mix.inputs[6])
    #vector_math.Vector -> wave_texture.Vector
    arrow_pattern.links.new(vector_math.outputs[0], wave_texture.inputs[0])
    #colorramp_001.Color -> mix.B
    arrow_pattern.links.new(colorramp_001.outputs[0], mix.inputs[7])
    #wave_texture.Color -> colorramp_001.Fac
    arrow_pattern.links.new(wave_texture.outputs[0], colorramp_001.inputs[0])
    #mix_001.Result -> bump.Height
    arrow_pattern.links.new(mix_001.outputs[2], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    arrow_pattern.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> mix_001.A
    arrow_pattern.links.new(mix.outputs[2], mix_001.inputs[6])
    #voronoi_texture_001.Distance -> colorramp_002.Fac
    arrow_pattern.links.new(voronoi_texture_001.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix_002.A
    arrow_pattern.links.new(colorramp_002.outputs[0], mix_002.inputs[6])
    #colorramp_003.Color -> mix_002.B
    arrow_pattern.links.new(colorramp_003.outputs[0], mix_002.inputs[7])
    #wave_texture_001.Color -> colorramp_003.Fac
    arrow_pattern.links.new(wave_texture_001.outputs[0], colorramp_003.inputs[0])
    #mix_002.Result -> mix_001.B
    arrow_pattern.links.new(mix_002.outputs[2], mix_001.inputs[7])
    #vector_math.Vector -> wave_texture_001.Vector
    arrow_pattern.links.new(vector_math.outputs[0], wave_texture_001.inputs[0])
    #vector_math.Vector -> voronoi_texture_001.Vector
    arrow_pattern.links.new(vector_math.outputs[0], voronoi_texture_001.inputs[0])
    #mix_001.Result -> mix_003.Factor
    arrow_pattern.links.new(mix_001.outputs[2], mix_003.inputs[0])
    #mix_003.Result -> principled_bsdf.Base Color
    arrow_pattern.links.new(mix_003.outputs[2], principled_bsdf.inputs[0])
    #group_input.Color1 -> mix_003.A
    arrow_pattern.links.new(group_input.outputs[0], mix_003.inputs[6])
    #group_input.Color2 -> mix_003.B
    arrow_pattern.links.new(group_input.outputs[1], mix_003.inputs[7])
    #group_input.Scale -> vector_math.Scale
    arrow_pattern.links.new(group_input.outputs[2], vector_math.inputs[3])
    #group_input.Roughness -> principled_bsdf.Roughness
    arrow_pattern.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    arrow_pattern.links.new(group_input.outputs[4], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    arrow_pattern.links.new(group_input.outputs[5], bump.inputs[3])
    return arrow_pattern

arrow_pattern = arrow_pattern_node_group()

#initialize Arrow Pattern node group
def arrow_pattern_1_node_group():

    arrow_pattern_1 = mat.node_tree
    #start with a clean node tree
    for node in arrow_pattern_1.nodes:
        arrow_pattern_1.nodes.remove(node)
    #initialize arrow_pattern_1 nodes
    #node Material Output
    material_output = arrow_pattern_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Arrow pattern
    arrow_pattern_2 = arrow_pattern_1.nodes.new("ShaderNodeGroup")
    arrow_pattern_2.label = "Arrow pattern"
    arrow_pattern_2.name = "Arrow pattern"
    arrow_pattern_2.node_tree = arrow_pattern
    #Input_1
    arrow_pattern_2.inputs[0].default_value = (1.0, 0.15037527680397034, 0.022407930344343185, 1.0)
    #Input_2
    arrow_pattern_2.inputs[1].default_value = (0.08868387341499329, 0.08868387341499329, 0.08868387341499329, 1.0)
    #Input_3
    arrow_pattern_2.inputs[2].default_value = 1.0
    #Input_4
    arrow_pattern_2.inputs[3].default_value = 0.5
    #Input_5
    arrow_pattern_2.inputs[4].default_value = 1.0
    #Input_6
    arrow_pattern_2.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (672.251953125, 101.66796875)
    arrow_pattern_2.location = (481.84344482421875, 100.0)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    arrow_pattern_2.width, arrow_pattern_2.height = 158.15655517578125, 100.0
    
    #initialize arrow_pattern_1 links
    #arrow_pattern_2.BSDF -> material_output.Surface
    arrow_pattern_1.links.new(arrow_pattern_2.outputs[0], material_output.inputs[0])
    return arrow_pattern_1

arrow_pattern_1 = arrow_pattern_1_node_group()

