import bpy, mathutils

mat = bpy.data.materials.new(name = "Tile1")
mat.use_nodes = True
#initialize Tile1 node group
def tile1_node_group():

    tile1 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Tile1")
    
    #initialize tile1 nodes
    #node ColorRamp.001
    colorramp_001 = tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.26363635063171387
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5000004172325134)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Noise Texture
    noise_texture = tile1.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.8916666507720947
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Reroute
    reroute = tile1.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Separate XYZ
    separate_xyz = tile1.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"
    
    #node Math
    math = tile1.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'SINE'
    math.use_clamp = False
    
    #node Math.001
    math_001 = tile1.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'SINE'
    math_001.use_clamp = False
    
    #node Vector Math
    vector_math = tile1.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Scale
    vector_math.inputs[3].default_value = 100.0
    
    #node Separate XYZ.001
    separate_xyz_001 = tile1.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz_001.name = "Separate XYZ.001"
    
    #node Math.003
    math_003 = tile1.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'SINE'
    math_003.use_clamp = False
    
    #node Math.004
    math_004 = tile1.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MAXIMUM'
    math_004.use_clamp = False
    
    #node Math.005
    math_005 = tile1.nodes.new("ShaderNodeMath")
    math_005.name = "Math.005"
    math_005.operation = 'SINE'
    math_005.use_clamp = False
    
    #node Vector Math.001
    vector_math_001 = tile1.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'SCALE'
    #Scale
    vector_math_001.inputs[3].default_value = 500.0
    
    #node ColorRamp.003
    colorramp_003 = tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.8863630890846252
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.9772727489471436)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Math.002
    math_002 = tile1.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MAXIMUM'
    math_002.use_clamp = False
    
    #node Mix.001
    mix_001 = tile1.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    
    #node Mix
    mix = tile1.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node ColorRamp.004
    colorramp_004 = tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.9318177103996277
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(1.0)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.005
    colorramp_005 = tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_005.name = "ColorRamp.005"
    colorramp_005.color_ramp.color_mode = 'RGB'
    colorramp_005.color_ramp.hue_interpolation = 'NEAR'
    colorramp_005.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_005.color_ramp.elements.remove(colorramp_005.color_ramp.elements[0])
    colorramp_005_cre_0 = colorramp_005.color_ramp.elements[0]
    colorramp_005_cre_0.position = 0.8181813955307007
    colorramp_005_cre_0.alpha = 1.0
    colorramp_005_cre_0.color = (0.20000000298023224, 0.20000000298023224, 0.20000000298023224, 1.0)

    colorramp_005_cre_1 = colorramp_005.color_ramp.elements.new(1.0)
    colorramp_005_cre_1.alpha = 1.0
    colorramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Math.006
    math_006 = tile1.nodes.new("ShaderNodeMath")
    math_006.name = "Math.006"
    math_006.operation = 'MAXIMUM'
    math_006.use_clamp = False
    
    #node ColorRamp
    colorramp = tile1.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.9636357426643372
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Principled BSDF
    principled_bsdf = tile1.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = tile1.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = tile1.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #tile1 outputs
    #output BSDF
    tile1.outputs.new('NodeSocketShader', "BSDF")
    tile1.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    tile1.outputs.new('NodeSocketColor', "Albedo")
    tile1.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    tile1.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    tile1.outputs.new('NodeSocketColor', "Mask")
    tile1.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    tile1.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Vector Math.018
    vector_math_018 = tile1.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Map Range
    map_range = tile1.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = -1.0
    #From Max
    map_range.inputs[2].default_value = 1.0
    #To Min
    map_range.inputs[3].default_value = 0.0
    
    #node Map Range.001
    map_range_001 = tile1.nodes.new("ShaderNodeMapRange")
    map_range_001.name = "Map Range.001"
    map_range_001.clamp = True
    map_range_001.data_type = 'FLOAT'
    map_range_001.interpolation_type = 'LINEAR'
    #From Min
    map_range_001.inputs[1].default_value = -1.0
    #From Max
    map_range_001.inputs[2].default_value = 1.0
    #To Min
    map_range_001.inputs[3].default_value = 0.0
    
    #node Group Input
    group_input = tile1.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #tile1 inputs
    #input Scale
    tile1.inputs.new('NodeSocketFloat', "Scale")
    tile1.inputs[0].default_value = 1.0
    tile1.inputs[0].min_value = -10000.0
    tile1.inputs[0].max_value = 10000.0
    tile1.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    tile1.inputs.new('NodeSocketColor', "Color1")
    tile1.inputs[1].default_value = (0.013754759915173054, 0.013754759915173054, 0.013754759915173054, 1.0)
    tile1.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    tile1.inputs.new('NodeSocketColor', "Color2")
    tile1.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    tile1.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    tile1.inputs.new('NodeSocketFloatFactor', "Specular")
    tile1.inputs[3].default_value = 0.10000000149011612
    tile1.inputs[3].min_value = 0.0
    tile1.inputs[3].max_value = 1.0
    tile1.inputs[3].attribute_domain = 'POINT'
    
    #input Big Stripe Thickness
    tile1.inputs.new('NodeSocketFloat', "Big Stripe Thickness")
    tile1.inputs[4].default_value = 1.0
    tile1.inputs[4].min_value = -10000.0
    tile1.inputs[4].max_value = 10000.0
    tile1.inputs[4].attribute_domain = 'POINT'
    
    #input Tiles Thickness
    tile1.inputs.new('NodeSocketFloat', "Tiles Thickness")
    tile1.inputs[5].default_value = 1.0
    tile1.inputs[5].min_value = -10000.0
    tile1.inputs[5].max_value = 10000.0
    tile1.inputs[5].attribute_domain = 'POINT'
    
    #input  Noise Scale
    tile1.inputs.new('NodeSocketFloat', " Noise Scale")
    tile1.inputs[6].default_value = 100.0
    tile1.inputs[6].min_value = -1000.0
    tile1.inputs[6].max_value = 1000.0
    tile1.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    tile1.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    tile1.inputs[7].default_value = 1.0
    tile1.inputs[7].min_value = 0.0
    tile1.inputs[7].max_value = 1.0
    tile1.inputs[7].attribute_domain = 'POINT'
    
    #input Noise Bump Strength
    tile1.inputs.new('NodeSocketFloatFactor', "Noise Bump Strength")
    tile1.inputs[8].default_value = 0.30000001192092896
    tile1.inputs[8].min_value = 0.0
    tile1.inputs[8].max_value = 1.0
    tile1.inputs[8].attribute_domain = 'POINT'
    
    #input Normal
    tile1.inputs.new('NodeSocketVector', "Normal")
    tile1.inputs[9].default_value = (0.0, 0.0, 0.0)
    tile1.inputs[9].min_value = -1.0
    tile1.inputs[9].max_value = 1.0
    tile1.inputs[9].attribute_domain = 'POINT'
    tile1.inputs[9].hide_value = True
    
    
    
    #node Bump
    bump = tile1.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Bump.001
    bump_001 = tile1.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = True
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Mix.002
    mix_002 = tile1.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node ColorRamp.002
    colorramp_002 = tile1.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.9636363983154297)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    
    #Set locations
    colorramp_001.location = (254.85888671875, -133.95510864257812)
    noise_texture.location = (34.85888671875, -393.4331970214844)
    reroute.location = (-277.10693359375, -449.0904235839844)
    separate_xyz.location = (-985.14111328125, -33.433197021484375)
    math.location = (-765.14111328125, 86.56680297851562)
    math_001.location = (-805.14111328125, -113.43319702148438)
    vector_math.location = (-1205.14111328125, 46.566802978515625)
    separate_xyz_001.location = (-945.1416015625, 309.09033203125)
    math_003.location = (-725.1416015625, 429.0904235839844)
    math_004.location = (-505.141357421875, 449.0904235839844)
    math_005.location = (-765.141357421875, 229.09033203125)
    vector_math_001.location = (-1165.1414794921875, 389.0903625488281)
    colorramp_003.location = (-105.14111328125, 386.5668029785156)
    math_002.location = (-545.14111328125, 106.56680297851562)
    mix_001.location = (314.85888671875, -376.5628662109375)
    mix.location = (924.49267578125, 36.71282958984375)
    colorramp_004.location = (574.85888671875, 86.5667724609375)
    colorramp_005.location = (1254.85888671875, 66.56680297851562)
    math_006.location = (384.595947265625, 448.5525207519531)
    colorramp.location = (-103.622314453125, 108.59585571289062)
    principled_bsdf.location = (1825.14111328125, 166.56680297851562)
    texture_coordinate_001.location = (-1825.14111328125, -113.4332275390625)
    group_output.location = (2115.14111328125, -0.0)
    vector_math_018.location = (-1485.14111328125, -33.433197021484375)
    map_range.location = (-325.14111328125, 86.56680297851562)
    map_range_001.location = (-285.141357421875, 429.0904235839844)
    group_input.location = (-2025.14111328125, -0.0)
    bump.location = (1503.14111328125, -182.7266845703125)
    bump_001.location = (534.85888671875, -313.4331970214844)
    mix_002.location = (1293.11279296875, 332.60107421875)
    colorramp_002.location = (765.695068359375, 329.5851745605469)
    
    #Set dimensions
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    separate_xyz.width, separate_xyz.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    vector_math_001.width, vector_math_001.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    colorramp_005.width, colorramp_005.height = 240.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    map_range_001.width, map_range_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    
    #initialize tile1 links
    #principled_bsdf.BSDF -> group_output.BSDF
    tile1.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #vector_math.Vector -> separate_xyz.Vector
    tile1.links.new(vector_math.outputs[0], separate_xyz.inputs[0])
    #separate_xyz.X -> math.Value
    tile1.links.new(separate_xyz.outputs[0], math.inputs[0])
    #separate_xyz.Y -> math_001.Value
    tile1.links.new(separate_xyz.outputs[1], math_001.inputs[0])
    #math.Value -> math_002.Value
    tile1.links.new(math.outputs[0], math_002.inputs[0])
    #math_001.Value -> math_002.Value
    tile1.links.new(math_001.outputs[0], math_002.inputs[1])
    #math_002.Value -> map_range.Value
    tile1.links.new(math_002.outputs[0], map_range.inputs[0])
    #map_range.Result -> colorramp.Fac
    tile1.links.new(map_range.outputs[0], colorramp.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    tile1.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> bump.Height
    tile1.links.new(mix.outputs[2], bump.inputs[2])
    #mix_001.Result -> bump_001.Height
    tile1.links.new(mix_001.outputs[2], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    tile1.links.new(bump_001.outputs[0], bump.inputs[3])
    #reroute.Output -> noise_texture.Vector
    tile1.links.new(reroute.outputs[0], noise_texture.inputs[0])
    #colorramp_001.Color -> mix.B
    tile1.links.new(colorramp_001.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> colorramp_001.Fac
    tile1.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #vector_math_001.Vector -> separate_xyz_001.Vector
    tile1.links.new(vector_math_001.outputs[0], separate_xyz_001.inputs[0])
    #separate_xyz_001.X -> math_003.Value
    tile1.links.new(separate_xyz_001.outputs[0], math_003.inputs[0])
    #separate_xyz_001.Y -> math_005.Value
    tile1.links.new(separate_xyz_001.outputs[1], math_005.inputs[0])
    #math_003.Value -> math_004.Value
    tile1.links.new(math_003.outputs[0], math_004.inputs[0])
    #math_005.Value -> math_004.Value
    tile1.links.new(math_005.outputs[0], math_004.inputs[1])
    #math_004.Value -> map_range_001.Value
    tile1.links.new(math_004.outputs[0], map_range_001.inputs[0])
    #map_range_001.Result -> colorramp_003.Fac
    tile1.links.new(map_range_001.outputs[0], colorramp_003.inputs[0])
    #colorramp_003.Color -> math_006.Value
    tile1.links.new(colorramp_003.outputs[0], math_006.inputs[0])
    #colorramp.Color -> math_006.Value
    tile1.links.new(colorramp.outputs[0], math_006.inputs[1])
    #colorramp_004.Color -> mix.A
    tile1.links.new(colorramp_004.outputs[0], mix.inputs[6])
    #mix_002.Result -> principled_bsdf.Base Color
    tile1.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #math_006.Value -> colorramp_002.Fac
    tile1.links.new(math_006.outputs[0], colorramp_002.inputs[0])
    #noise_texture.Fac -> mix_001.B
    tile1.links.new(noise_texture.outputs[0], mix_001.inputs[7])
    #math_006.Value -> colorramp_004.Fac
    tile1.links.new(math_006.outputs[0], colorramp_004.inputs[0])
    #colorramp_004.Color -> mix_001.A
    tile1.links.new(colorramp_004.outputs[0], mix_001.inputs[6])
    #math_006.Value -> colorramp_005.Fac
    tile1.links.new(math_006.outputs[0], colorramp_005.inputs[0])
    #colorramp_005.Color -> principled_bsdf.Roughness
    tile1.links.new(colorramp_005.outputs[0], principled_bsdf.inputs[9])
    #texture_coordinate_001.UV -> vector_math_018.Vector
    tile1.links.new(texture_coordinate_001.outputs[2], vector_math_018.inputs[0])
    #vector_math_018.Vector -> vector_math.Vector
    tile1.links.new(vector_math_018.outputs[0], vector_math.inputs[0])
    #vector_math_018.Vector -> reroute.Input
    tile1.links.new(vector_math_018.outputs[0], reroute.inputs[0])
    #vector_math_018.Vector -> vector_math_001.Vector
    tile1.links.new(vector_math_018.outputs[0], vector_math_001.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    tile1.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #colorramp_002.Color -> mix_002.Factor
    tile1.links.new(colorramp_002.outputs[0], mix_002.inputs[0])
    #group_input.Color1 -> mix_002.A
    tile1.links.new(group_input.outputs[1], mix_002.inputs[6])
    #group_input.Color2 -> mix_002.B
    tile1.links.new(group_input.outputs[2], mix_002.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    tile1.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Big Stripe Thickness -> map_range.To Max
    tile1.links.new(group_input.outputs[4], map_range.inputs[4])
    #group_input.Tiles Thickness -> map_range_001.To Max
    tile1.links.new(group_input.outputs[5], map_range_001.inputs[4])
    #group_input. Noise Scale -> noise_texture.Scale
    tile1.links.new(group_input.outputs[6], noise_texture.inputs[2])
    #group_input.Bump Strength -> bump.Strength
    tile1.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Noise Bump Strength -> bump_001.Strength
    tile1.links.new(group_input.outputs[8], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    tile1.links.new(group_input.outputs[9], bump_001.inputs[3])
    #mix_002.Result -> group_output.Albedo
    tile1.links.new(mix_002.outputs[2], group_output.inputs[1])
    #colorramp_002.Color -> group_output.Mask
    tile1.links.new(colorramp_002.outputs[0], group_output.inputs[2])
    return tile1

tile1 = tile1_node_group()

#initialize Tile1 node group
def tile1_1_node_group():

    tile1_1 = mat.node_tree
    #start with a clean node tree
    for node in tile1_1.nodes:
        tile1_1.nodes.remove(node)
    #initialize tile1_1 nodes
    #node Material Output
    material_output = tile1_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Tile1
    tile1_2 = tile1_1.nodes.new("ShaderNodeGroup")
    tile1_2.label = "Tile1"
    tile1_2.name = "Tile1"
    tile1_2.node_tree = tile1
    #Input_1
    tile1_2.inputs[0].default_value = 1.0
    #Input_2
    tile1_2.inputs[1].default_value = (0.013754759915173054, 0.013754759915173054, 0.013754759915173054, 1.0)
    #Input_3
    tile1_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    tile1_2.inputs[3].default_value = 0.10000000149011612
    #Input_5
    tile1_2.inputs[4].default_value = 1.0
    #Input_6
    tile1_2.inputs[5].default_value = 1.0
    #Input_7
    tile1_2.inputs[6].default_value = 100.0
    #Input_8
    tile1_2.inputs[7].default_value = 1.0
    #Input_9
    tile1_2.inputs[8].default_value = 0.30000001192092896
    #Input_10
    tile1_2.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (666.25830078125, 143.622314453125)
    tile1_2.location = (384.2392578125, 143.622314453125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    tile1_2.width, tile1_2.height = 211.736328125, 100.0
    
    #initialize tile1_1 links
    #tile1_2.BSDF -> material_output.Surface
    tile1_1.links.new(tile1_2.outputs[0], material_output.inputs[0])
    return tile1_1

tile1_1 = tile1_1_node_group()

