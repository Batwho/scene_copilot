import bpy, mathutils

mat = bpy.data.materials.new(name = "Green Fresnel Inverted")
mat.use_nodes = True
#initialize green_fresnel inverted node group
def green_fresnel_inverted_node_group():

    green_fresnel_inverted = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "green_fresnel inverted")
    
    #initialize green_fresnel_inverted nodes
    #node Layer Weight
    layer_weight = green_fresnel_inverted.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    
    #node ColorRamp
    colorramp = green_fresnel_inverted.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.39545440673828125)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Texture Coordinate
    texture_coordinate = green_fresnel_inverted.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = green_fresnel_inverted.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'LINEAR_LIGHT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = green_fresnel_inverted.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #green_fresnel_inverted outputs
    #output BSDF
    green_fresnel_inverted.outputs.new('NodeSocketShader', "BSDF")
    green_fresnel_inverted.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    green_fresnel_inverted.outputs.new('NodeSocketFloat', "Mask")
    green_fresnel_inverted.outputs[1].default_value = 0.0
    green_fresnel_inverted.outputs[1].min_value = -3.4028234663852886e+38
    green_fresnel_inverted.outputs[1].max_value = 3.4028234663852886e+38
    green_fresnel_inverted.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = green_fresnel_inverted.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.20000000298023224
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Noise Texture
    noise_texture = green_fresnel_inverted.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = green_fresnel_inverted.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #green_fresnel_inverted inputs
    #input Emission
    green_fresnel_inverted.inputs.new('NodeSocketColor', "Emission")
    green_fresnel_inverted.inputs[0].default_value = (1.0, 0.44432228803634644, 0.0, 1.0)
    green_fresnel_inverted.inputs[0].attribute_domain = 'POINT'
    
    #input Emission Strength
    green_fresnel_inverted.inputs.new('NodeSocketFloat', "Emission Strength")
    green_fresnel_inverted.inputs[1].default_value = 4.0
    green_fresnel_inverted.inputs[1].min_value = 0.0
    green_fresnel_inverted.inputs[1].max_value = 1000000.0
    green_fresnel_inverted.inputs[1].attribute_domain = 'POINT'
    
    #input Base Color
    green_fresnel_inverted.inputs.new('NodeSocketColor', "Base Color")
    green_fresnel_inverted.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    green_fresnel_inverted.inputs[2].attribute_domain = 'POINT'
    
    #input Blend
    green_fresnel_inverted.inputs.new('NodeSocketFloat', "Blend")
    green_fresnel_inverted.inputs[3].default_value = 0.7200000286102295
    green_fresnel_inverted.inputs[3].min_value = 0.0
    green_fresnel_inverted.inputs[3].max_value = 1.0
    green_fresnel_inverted.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Strenth
    green_fresnel_inverted.inputs.new('NodeSocketFloatFactor', "Noise Strenth")
    green_fresnel_inverted.inputs[4].default_value = 0.25
    green_fresnel_inverted.inputs[4].min_value = 0.0
    green_fresnel_inverted.inputs[4].max_value = 1.0
    green_fresnel_inverted.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    green_fresnel_inverted.inputs.new('NodeSocketFloat', "Noise Scale")
    green_fresnel_inverted.inputs[5].default_value = 5.0
    green_fresnel_inverted.inputs[5].min_value = -1000.0
    green_fresnel_inverted.inputs[5].max_value = 1000.0
    green_fresnel_inverted.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Detail
    green_fresnel_inverted.inputs.new('NodeSocketFloat', "Noise Detail")
    green_fresnel_inverted.inputs[6].default_value = 2.0
    green_fresnel_inverted.inputs[6].min_value = 0.0
    green_fresnel_inverted.inputs[6].max_value = 15.0
    green_fresnel_inverted.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    green_fresnel_inverted.inputs.new('NodeSocketVector', "Normal")
    green_fresnel_inverted.inputs[7].default_value = (0.0, 0.0, 0.0)
    green_fresnel_inverted.inputs[7].min_value = -3.4028234663852886e+38
    green_fresnel_inverted.inputs[7].max_value = 3.4028234663852886e+38
    green_fresnel_inverted.inputs[7].attribute_domain = 'POINT'
    green_fresnel_inverted.inputs[7].hide_value = True
    
    
    
    
    #Set locations
    layer_weight.location = (-130.00006103515625, -80.0)
    colorramp.location = (309.99993896484375, -60.0)
    texture_coordinate.location = (-710.0000610351562, -40.0)
    mix.location = (-374.28753662109375, -69.726318359375)
    group_output.location = (1000.0000610351562, -0.0)
    principled_bsdf.location = (710.0000610351562, 280.0)
    noise_texture.location = (-570.0000610351562, -280.0)
    group_input.location = (-910.0000610351562, -0.0)
    
    #Set dimensions
    layer_weight.width, layer_weight.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize green_fresnel_inverted links
    #principled_bsdf.BSDF -> group_output.BSDF
    green_fresnel_inverted.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #layer_weight.Facing -> colorramp.Fac
    green_fresnel_inverted.links.new(layer_weight.outputs[1], colorramp.inputs[0])
    #colorramp.Color -> principled_bsdf.Alpha
    green_fresnel_inverted.links.new(colorramp.outputs[0], principled_bsdf.inputs[21])
    #mix.Result -> layer_weight.Normal
    green_fresnel_inverted.links.new(mix.outputs[2], layer_weight.inputs[1])
    #texture_coordinate.Object -> mix.A
    green_fresnel_inverted.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Color -> mix.B
    green_fresnel_inverted.links.new(noise_texture.outputs[1], mix.inputs[7])
    #group_input.Emission -> principled_bsdf.Emission
    green_fresnel_inverted.links.new(group_input.outputs[0], principled_bsdf.inputs[19])
    #group_input.Emission Strength -> principled_bsdf.Emission Strength
    green_fresnel_inverted.links.new(group_input.outputs[1], principled_bsdf.inputs[20])
    #group_input.Base Color -> principled_bsdf.Base Color
    green_fresnel_inverted.links.new(group_input.outputs[2], principled_bsdf.inputs[0])
    #group_input.Blend -> layer_weight.Blend
    green_fresnel_inverted.links.new(group_input.outputs[3], layer_weight.inputs[0])
    #group_input.Noise Strenth -> mix.Factor
    green_fresnel_inverted.links.new(group_input.outputs[4], mix.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    green_fresnel_inverted.links.new(group_input.outputs[5], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    green_fresnel_inverted.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Normal -> principled_bsdf.Normal
    green_fresnel_inverted.links.new(group_input.outputs[7], principled_bsdf.inputs[22])
    #layer_weight.Facing -> group_output.Mask
    green_fresnel_inverted.links.new(layer_weight.outputs[1], group_output.inputs[1])
    return green_fresnel_inverted

green_fresnel_inverted = green_fresnel_inverted_node_group()

#initialize Green Fresnel Inverted node group
def green_fresnel_inverted_1_node_group():

    green_fresnel_inverted_1 = mat.node_tree
    #start with a clean node tree
    for node in green_fresnel_inverted_1.nodes:
        green_fresnel_inverted_1.nodes.remove(node)
    #initialize green_fresnel_inverted_1 nodes
    #node Material Output.001
    material_output_001 = green_fresnel_inverted_1.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = True
    material_output_001.target = 'ALL'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output_001.inputs[3].default_value = 0.0
    
    #node green_fresnel inverted
    green_fresnel_inverted_2 = green_fresnel_inverted_1.nodes.new("ShaderNodeGroup")
    green_fresnel_inverted_2.label = "green_fresnel inverted"
    green_fresnel_inverted_2.name = "green_fresnel inverted"
    green_fresnel_inverted_2.node_tree = green_fresnel_inverted
    #Input_1
    green_fresnel_inverted_2.inputs[0].default_value = (0.04026598483324051, 1.0, 0.0, 1.0)
    #Input_2
    green_fresnel_inverted_2.inputs[1].default_value = 4.0
    #Input_3
    green_fresnel_inverted_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    green_fresnel_inverted_2.inputs[3].default_value = 0.7200000286102295
    #Input_5
    green_fresnel_inverted_2.inputs[4].default_value = 0.25
    #Input_6
    green_fresnel_inverted_2.inputs[5].default_value = 5.0
    #Input_7
    green_fresnel_inverted_2.inputs[6].default_value = 2.0
    #Input_8
    green_fresnel_inverted_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output_001.location = (723.39697265625, 100.7794189453125)
    green_fresnel_inverted_2.location = (423.39697265625, 100.7794189453125)
    
    #Set dimensions
    material_output_001.width, material_output_001.height = 140.0, 100.0
    green_fresnel_inverted_2.width, green_fresnel_inverted_2.height = 219.48193359375, 100.0
    
    #initialize green_fresnel_inverted_1 links
    #green_fresnel_inverted_2.BSDF -> material_output_001.Surface
    green_fresnel_inverted_1.links.new(green_fresnel_inverted_2.outputs[0], material_output_001.inputs[0])
    return green_fresnel_inverted_1

green_fresnel_inverted_1 = green_fresnel_inverted_1_node_group()

