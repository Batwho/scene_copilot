import bpy, mathutils

mat = bpy.data.materials.new(name = "Volume Stars")
mat.use_nodes = True
#initialize Volume Stars node group
def volume_stars_node_group():

    volume_stars = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Volume Stars")
    
    #initialize volume_stars nodes
    #node Texture Coordinate.001
    texture_coordinate_001 = volume_stars.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math
    vector_math = volume_stars.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Invert
    invert = volume_stars.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Invert.001
    invert_001 = volume_stars.nodes.new("ShaderNodeInvert")
    invert_001.name = "Invert.001"
    #Color
    invert_001.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.001
    mix_001 = volume_stars.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'DODGE'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #B_Color
    mix_001.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp
    colorramp = volume_stars.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.154545396566391)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.6272726655006409)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Math.002
    math_002 = volume_stars.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 100.0
    
    #node Math.003
    math_003 = volume_stars.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'ADD'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 1.0
    
    #node Voronoi Texture
    voronoi_texture = volume_stars.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 10.0
    
    #node Group Output
    group_output = volume_stars.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #volume_stars outputs
    #output Emission
    volume_stars.outputs.new('NodeSocketShader', "Emission")
    volume_stars.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    volume_stars.outputs.new('NodeSocketColor', "Albedo")
    volume_stars.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    volume_stars.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    volume_stars.outputs.new('NodeSocketFloat', "Mask")
    volume_stars.outputs[2].default_value = 0.0
    volume_stars.outputs[2].min_value = -3.4028234663852886e+38
    volume_stars.outputs[2].max_value = 3.4028234663852886e+38
    volume_stars.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Emission
    emission = volume_stars.nodes.new("ShaderNodeEmission")
    emission.name = "Emission"
    
    #node Mix
    mix = volume_stars.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'COLOR'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Math
    math = volume_stars.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    
    #node Group Input
    group_input = volume_stars.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #volume_stars inputs
    #input Scale
    volume_stars.inputs.new('NodeSocketFloat', "Scale")
    volume_stars.inputs[0].default_value = 1.0
    volume_stars.inputs[0].min_value = -10000.0
    volume_stars.inputs[0].max_value = 10000.0
    volume_stars.inputs[0].attribute_domain = 'POINT'
    
    #input Random Color Strength
    volume_stars.inputs.new('NodeSocketFloatFactor', "Random Color Strength")
    volume_stars.inputs[1].default_value = 0.5
    volume_stars.inputs[1].min_value = 0.0
    volume_stars.inputs[1].max_value = 1.0
    volume_stars.inputs[1].attribute_domain = 'POINT'
    
    #input Single Color Strength
    volume_stars.inputs.new('NodeSocketFloatFactor', "Single Color Strength")
    volume_stars.inputs[2].default_value = 0.0
    volume_stars.inputs[2].min_value = 0.0
    volume_stars.inputs[2].max_value = 1.0
    volume_stars.inputs[2].attribute_domain = 'POINT'
    
    #input Single Color
    volume_stars.inputs.new('NodeSocketColor', "Single Color")
    volume_stars.inputs[3].default_value = (0.5, 0.5, 0.5, 1.0)
    volume_stars.inputs[3].attribute_domain = 'POINT'
    
    #input Size Stars
    volume_stars.inputs.new('NodeSocketFloatFactor', "Size Stars")
    volume_stars.inputs[4].default_value = 1.0
    volume_stars.inputs[4].min_value = 0.0
    volume_stars.inputs[4].max_value = 1.0
    volume_stars.inputs[4].attribute_domain = 'POINT'
    
    #input Star Shape
    volume_stars.inputs.new('NodeSocketFloat', "Star Shape")
    volume_stars.inputs[5].default_value = 0.5699999928474426
    volume_stars.inputs[5].min_value = 0.0
    volume_stars.inputs[5].max_value = 32.0
    volume_stars.inputs[5].attribute_domain = 'POINT'
    
    #input Brightness
    volume_stars.inputs.new('NodeSocketFloat', "Brightness")
    volume_stars.inputs[6].default_value = 50.0
    volume_stars.inputs[6].min_value = -10000.0
    volume_stars.inputs[6].max_value = 10000.0
    volume_stars.inputs[6].attribute_domain = 'POINT'
    
    #input Random Location
    volume_stars.inputs.new('NodeSocketFloatFactor', "Random Location")
    volume_stars.inputs[7].default_value = 1.0
    volume_stars.inputs[7].min_value = 0.0
    volume_stars.inputs[7].max_value = 1.0
    volume_stars.inputs[7].attribute_domain = 'POINT'
    
    
    
    #node Math.001
    math_001 = volume_stars.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    
    #node Mix.002
    mix_002 = volume_stars.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'COLOR'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    
    #Set locations
    texture_coordinate_001.location = (-820.0, -139.99996948242188)
    vector_math.location = (-480.00006103515625, -60.0)
    invert.location = (120.0, 140.0)
    invert_001.location = (-500.0, 180.0)
    mix_001.location = (-80.0, 180.0)
    colorramp.location = (251.06280517578125, 299.1976318359375)
    math_002.location = (551.9566650390625, 292.1114501953125)
    math_003.location = (708.2100830078125, 243.01766967773438)
    voronoi_texture.location = (-280.0, -20.0)
    group_output.location = (1220.0, 0.0)
    emission.location = (980.0000610351562, 40.0)
    mix.location = (260.0001220703125, 60.0)
    math.location = (597.5220947265625, 18.6710205078125)
    group_input.location = (-1020.0, 40.0)
    math_001.location = (762.0283203125, 7.613861083984375)
    mix_002.location = (420.0, 40.0)
    
    #Set dimensions
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    invert_001.width, invert_001.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    emission.width, emission.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    
    #initialize volume_stars links
    #mix_002.Result -> math.Value
    volume_stars.links.new(mix_002.outputs[2], math.inputs[0])
    #invert.Color -> mix.A
    volume_stars.links.new(invert.outputs[0], mix.inputs[6])
    #voronoi_texture.Color -> mix.B
    volume_stars.links.new(voronoi_texture.outputs[1], mix.inputs[7])
    #texture_coordinate_001.Object -> vector_math.Vector
    volume_stars.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    volume_stars.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    volume_stars.links.new(group_input.outputs[0], vector_math.inputs[3])
    #voronoi_texture.Distance -> mix_001.A
    volume_stars.links.new(voronoi_texture.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> invert.Color
    volume_stars.links.new(mix_001.outputs[2], invert.inputs[1])
    #invert_001.Color -> mix_001.Factor
    volume_stars.links.new(invert_001.outputs[0], mix_001.inputs[0])
    #group_input.Size Stars -> invert_001.Fac
    volume_stars.links.new(group_input.outputs[4], invert_001.inputs[0])
    #mix.Result -> mix_002.A
    volume_stars.links.new(mix.outputs[2], mix_002.inputs[6])
    #group_input.Single Color -> mix_002.B
    volume_stars.links.new(group_input.outputs[3], mix_002.inputs[7])
    #math.Value -> math_001.Value
    volume_stars.links.new(math.outputs[0], math_001.inputs[0])
    #mix_001.Result -> colorramp.Fac
    volume_stars.links.new(mix_001.outputs[2], colorramp.inputs[0])
    #math_003.Value -> math_001.Value
    volume_stars.links.new(math_003.outputs[0], math_001.inputs[1])
    #colorramp.Color -> math_002.Value
    volume_stars.links.new(colorramp.outputs[0], math_002.inputs[0])
    #math_002.Value -> math_003.Value
    volume_stars.links.new(math_002.outputs[0], math_003.inputs[0])
    #group_input.Star Shape -> voronoi_texture.Exponent
    volume_stars.links.new(group_input.outputs[5], voronoi_texture.inputs[4])
    #group_input.Random Location -> voronoi_texture.Randomness
    volume_stars.links.new(group_input.outputs[7], voronoi_texture.inputs[5])
    #math_001.Value -> emission.Strength
    volume_stars.links.new(math_001.outputs[0], emission.inputs[1])
    #emission.Emission -> group_output.Emission
    volume_stars.links.new(emission.outputs[0], group_output.inputs[0])
    #mix_002.Result -> emission.Color
    volume_stars.links.new(mix_002.outputs[2], emission.inputs[0])
    #group_input.Random Color Strength -> mix.Factor
    volume_stars.links.new(group_input.outputs[1], mix.inputs[0])
    #group_input.Single Color Strength -> mix_002.Factor
    volume_stars.links.new(group_input.outputs[2], mix_002.inputs[0])
    #group_input.Brightness -> math.Value
    volume_stars.links.new(group_input.outputs[6], math.inputs[1])
    #math_001.Value -> group_output.Mask
    volume_stars.links.new(math_001.outputs[0], group_output.inputs[2])
    #mix_002.Result -> group_output.Albedo
    volume_stars.links.new(mix_002.outputs[2], group_output.inputs[1])
    return volume_stars

volume_stars = volume_stars_node_group()

#initialize Volume Stars node group
def volume_stars_1_node_group():

    volume_stars_1 = mat.node_tree
    #start with a clean node tree
    for node in volume_stars_1.nodes:
        volume_stars_1.nodes.remove(node)
    #initialize volume_stars_1 nodes
    #node Material Output
    material_output = volume_stars_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Volume Stars
    volume_stars_2 = volume_stars_1.nodes.new("ShaderNodeGroup")
    volume_stars_2.label = "Volume Stars"
    volume_stars_2.name = "Volume Stars"
    volume_stars_2.node_tree = volume_stars
    #Input_1
    volume_stars_2.inputs[0].default_value = 0.30000001192092896
    #Input_9
    volume_stars_2.inputs[1].default_value = 0.5
    #Input_10
    volume_stars_2.inputs[2].default_value = 0.0
    #Input_3
    volume_stars_2.inputs[3].default_value = (0.03426942229270935, 0.5596672296524048, 1.0, 1.0)
    #Input_2
    volume_stars_2.inputs[4].default_value = 0.3267350494861603
    #Input_6
    volume_stars_2.inputs[5].default_value = 0.4599999785423279
    #Input_11
    volume_stars_2.inputs[6].default_value = 50.0
    #Input_7
    volume_stars_2.inputs[7].default_value = 1.0
    
    
    #Set locations
    material_output.location = (670.84326171875, 80.874267578125)
    volume_stars_2.location = (383.74169921875, 80.874267578125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    volume_stars_2.width, volume_stars_2.height = 216.261962890625, 100.0
    
    #initialize volume_stars_1 links
    #volume_stars_2.Emission -> material_output.Volume
    volume_stars_1.links.new(volume_stars_2.outputs[0], material_output.inputs[1])
    return volume_stars_1

volume_stars_1 = volume_stars_1_node_group()

