import bpy, mathutils

mat = bpy.data.materials.new(name = "Crystall Colorfull")
mat.use_nodes = True
#initialize Crystall Colorfull node group
def crystall_colorfull_node_group():

    crystall_colorfull = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Crystall Colorfull")
    
    #initialize crystall_colorfull nodes
    #node Layer Weight
    layer_weight = crystall_colorfull.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    
    #node Texture Coordinate
    texture_coordinate = crystall_colorfull.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = crystall_colorfull.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'SUBTRACT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.001
    colorramp_001 = crystall_colorfull.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 0.00431778421625495, 0.6670443415641785, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5000004768371582)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.4880087375640869, 1.0, 1.0)

    
    #node Principled BSDF
    principled_bsdf = crystall_colorfull.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Math
    math = crystall_colorfull.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 8.0
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Group Output
    group_output = crystall_colorfull.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #crystall_colorfull outputs
    #output BSDF
    crystall_colorfull.outputs.new('NodeSocketShader', "BSDF")
    crystall_colorfull.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    crystall_colorfull.outputs.new('NodeSocketColor', "Albedo")
    crystall_colorfull.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    crystall_colorfull.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    crystall_colorfull.outputs.new('NodeSocketFloat', "Mask")
    crystall_colorfull.outputs[2].default_value = 0.0
    crystall_colorfull.outputs[2].min_value = -3.4028234663852886e+38
    crystall_colorfull.outputs[2].max_value = 3.4028234663852886e+38
    crystall_colorfull.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    crystall_colorfull.outputs.new('NodeSocketVector', "Normal")
    crystall_colorfull.outputs[3].default_value = (0.0, 0.0, 0.0)
    crystall_colorfull.outputs[3].min_value = -3.4028234663852886e+38
    crystall_colorfull.outputs[3].max_value = 3.4028234663852886e+38
    crystall_colorfull.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Voronoi Texture
    voronoi_texture = crystall_colorfull.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.2600000202655792
    
    #node Bump
    bump = crystall_colorfull.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Hue Saturation Value
    hue_saturation_value = crystall_colorfull.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Group Input
    group_input = crystall_colorfull.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #crystall_colorfull inputs
    #input Scale
    crystall_colorfull.inputs.new('NodeSocketFloat', "Scale")
    crystall_colorfull.inputs[0].default_value = 0.5
    crystall_colorfull.inputs[0].min_value = -10000.0
    crystall_colorfull.inputs[0].max_value = 10000.0
    crystall_colorfull.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    crystall_colorfull.inputs.new('NodeSocketFloat', "Color Hue")
    crystall_colorfull.inputs[1].default_value = 0.5
    crystall_colorfull.inputs[1].min_value = 0.0
    crystall_colorfull.inputs[1].max_value = 1.0
    crystall_colorfull.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    crystall_colorfull.inputs.new('NodeSocketFloat', "Saturation")
    crystall_colorfull.inputs[2].default_value = 1.0
    crystall_colorfull.inputs[2].min_value = 0.0
    crystall_colorfull.inputs[2].max_value = 2.0
    crystall_colorfull.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    crystall_colorfull.inputs.new('NodeSocketFloatFactor', "Roughness")
    crystall_colorfull.inputs[3].default_value = 0.0
    crystall_colorfull.inputs[3].min_value = 0.0
    crystall_colorfull.inputs[3].max_value = 1.0
    crystall_colorfull.inputs[3].attribute_domain = 'POINT'
    
    #input Randomness
    crystall_colorfull.inputs.new('NodeSocketFloatFactor', "Randomness")
    crystall_colorfull.inputs[4].default_value = 1.0
    crystall_colorfull.inputs[4].min_value = 0.0
    crystall_colorfull.inputs[4].max_value = 1.0
    crystall_colorfull.inputs[4].attribute_domain = 'POINT'
    
    #input Color Mix
    crystall_colorfull.inputs.new('NodeSocketFloat', "Color Mix")
    crystall_colorfull.inputs[5].default_value = 0.5
    crystall_colorfull.inputs[5].min_value = 0.0
    crystall_colorfull.inputs[5].max_value = 1.0
    crystall_colorfull.inputs[5].attribute_domain = 'POINT'
    
    #input IOR
    crystall_colorfull.inputs.new('NodeSocketFloat', "IOR")
    crystall_colorfull.inputs[6].default_value = 1.4500000476837158
    crystall_colorfull.inputs[6].min_value = 0.0
    crystall_colorfull.inputs[6].max_value = 1000.0
    crystall_colorfull.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    crystall_colorfull.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    crystall_colorfull.inputs[7].default_value = 0.13375015556812286
    crystall_colorfull.inputs[7].min_value = 0.0
    crystall_colorfull.inputs[7].max_value = 1.0
    crystall_colorfull.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    crystall_colorfull.inputs.new('NodeSocketVector', "Normal")
    crystall_colorfull.inputs[8].default_value = (0.0, 0.0, 0.0)
    crystall_colorfull.inputs[8].min_value = -1.0
    crystall_colorfull.inputs[8].max_value = 1.0
    crystall_colorfull.inputs[8].attribute_domain = 'POINT'
    crystall_colorfull.inputs[8].hide_value = True
    
    
    
    
    #Set locations
    layer_weight.location = (-70.5775146484375, 97.1160888671875)
    texture_coordinate.location = (-730.2044677734375, 54.711822509765625)
    mix.location = (-280.7586669921875, 94.71182250976562)
    colorramp_001.location = (149.7955322265625, 200.22988891601562)
    principled_bsdf.location = (730.2044067382812, 34.711822509765625)
    math.location = (-730.2044677734375, -205.28817749023438)
    group_output.location = (1020.2044067382812, -0.0)
    voronoi_texture.location = (-550.2044677734375, -85.28817749023438)
    bump.location = (423.44281005859375, -147.31475830078125)
    hue_saturation_value.location = (500.20440673828125, 205.28817749023438)
    group_input.location = (-930.2044677734375, -0.0)
    
    #Set dimensions
    layer_weight.width, layer_weight.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize crystall_colorfull links
    #principled_bsdf.BSDF -> group_output.BSDF
    crystall_colorfull.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    crystall_colorfull.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Distance -> bump.Height
    crystall_colorfull.links.new(voronoi_texture.outputs[0], bump.inputs[2])
    #mix.Result -> layer_weight.Normal
    crystall_colorfull.links.new(mix.outputs[2], layer_weight.inputs[1])
    #texture_coordinate.Object -> mix.A
    crystall_colorfull.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #voronoi_texture.Distance -> mix.B
    crystall_colorfull.links.new(voronoi_texture.outputs[0], mix.inputs[7])
    #layer_weight.Facing -> colorramp_001.Fac
    crystall_colorfull.links.new(layer_weight.outputs[1], colorramp_001.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    crystall_colorfull.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #math.Value -> voronoi_texture.Scale
    crystall_colorfull.links.new(math.outputs[0], voronoi_texture.inputs[2])
    #colorramp_001.Color -> hue_saturation_value.Color
    crystall_colorfull.links.new(colorramp_001.outputs[0], hue_saturation_value.inputs[4])
    #group_input.Scale -> math.Value
    crystall_colorfull.links.new(group_input.outputs[0], math.inputs[1])
    #group_input.Color Mix -> layer_weight.Blend
    crystall_colorfull.links.new(group_input.outputs[5], layer_weight.inputs[0])
    #group_input.Color Hue -> hue_saturation_value.Hue
    crystall_colorfull.links.new(group_input.outputs[1], hue_saturation_value.inputs[0])
    #group_input.Bump Strength -> bump.Strength
    crystall_colorfull.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Roughness -> principled_bsdf.Transmission Roughness
    crystall_colorfull.links.new(group_input.outputs[3], principled_bsdf.inputs[18])
    #group_input.IOR -> principled_bsdf.IOR
    crystall_colorfull.links.new(group_input.outputs[6], principled_bsdf.inputs[16])
    #group_input.Normal -> bump.Normal
    crystall_colorfull.links.new(group_input.outputs[8], bump.inputs[3])
    #group_input.Randomness -> voronoi_texture.Randomness
    crystall_colorfull.links.new(group_input.outputs[4], voronoi_texture.inputs[5])
    #voronoi_texture.Distance -> group_output.Mask
    crystall_colorfull.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    crystall_colorfull.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    crystall_colorfull.links.new(bump.outputs[0], group_output.inputs[3])
    #group_input.Saturation -> hue_saturation_value.Saturation
    crystall_colorfull.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    return crystall_colorfull

crystall_colorfull = crystall_colorfull_node_group()

#initialize Crystall Colorfull node group
def crystall_colorfull_1_node_group():

    crystall_colorfull_1 = mat.node_tree
    #start with a clean node tree
    for node in crystall_colorfull_1.nodes:
        crystall_colorfull_1.nodes.remove(node)
    #initialize crystall_colorfull_1 nodes
    #node Material Output
    material_output = crystall_colorfull_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Crystall Colorfull
    crystall_colorfull_2 = crystall_colorfull_1.nodes.new("ShaderNodeGroup")
    crystall_colorfull_2.label = "Crystall Colorfull"
    crystall_colorfull_2.name = "Crystall Colorfull"
    crystall_colorfull_2.use_custom_color = True
    crystall_colorfull_2.color = (0.05267355591058731, 0.16529950499534607, 0.24619480967521667)
    crystall_colorfull_2.node_tree = crystall_colorfull
    #Input_1
    crystall_colorfull_2.inputs[0].default_value = 0.5
    #Input_3
    crystall_colorfull_2.inputs[1].default_value = 0.5
    #Input_12
    crystall_colorfull_2.inputs[2].default_value = 1.0
    #Input_5
    crystall_colorfull_2.inputs[3].default_value = 0.0
    #Input_8
    crystall_colorfull_2.inputs[4].default_value = 1.0
    #Input_2
    crystall_colorfull_2.inputs[5].default_value = 0.5
    #Input_6
    crystall_colorfull_2.inputs[6].default_value = 1.4500000476837158
    #Input_4
    crystall_colorfull_2.inputs[7].default_value = 0.20000000298023224
    #Input_7
    crystall_colorfull_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (673.2578125, 49.68408203125)
    crystall_colorfull_2.location = (422.1943359375, 49.68408203125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    crystall_colorfull_2.width, crystall_colorfull_2.height = 170.654541015625, 100.0
    
    #initialize crystall_colorfull_1 links
    #crystall_colorfull_2.BSDF -> material_output.Surface
    crystall_colorfull_1.links.new(crystall_colorfull_2.outputs[0], material_output.inputs[0])
    return crystall_colorfull_1

crystall_colorfull_1 = crystall_colorfull_1_node_group()

