import bpy, mathutils

mat = bpy.data.materials.new(name = "Stone Bright")
mat.use_nodes = True
#initialize Stone bright node group
def stone_bright_node_group():

    stone_bright = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Stone bright")
    
    #initialize stone_bright nodes
    #node Principled BSDF
    principled_bsdf = stone_bright.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = stone_bright.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #stone_bright outputs
    #output BSDF
    stone_bright.outputs.new('NodeSocketShader', "BSDF")
    stone_bright.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    stone_bright.outputs.new('NodeSocketColor', "Albedo")
    stone_bright.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    stone_bright.outputs[1].attribute_domain = 'POINT'
    
    #output Mask 
    stone_bright.outputs.new('NodeSocketFloat', "Mask ")
    stone_bright.outputs[2].default_value = 0.0
    stone_bright.outputs[2].min_value = -3.4028234663852886e+38
    stone_bright.outputs[2].max_value = 3.4028234663852886e+38
    stone_bright.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Vector Math
    vector_math = stone_bright.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = stone_bright.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node ColorRamp
    colorramp = stone_bright.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.304545521736145
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.058587487787008286, 0.058587487787008286, 0.058587487787008286, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = stone_bright.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = stone_bright.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #stone_bright inputs
    #input Scale
    stone_bright.inputs.new('NodeSocketFloat', "Scale")
    stone_bright.inputs[0].default_value = 1.0
    stone_bright.inputs[0].min_value = -10000.0
    stone_bright.inputs[0].max_value = 10000.0
    stone_bright.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    stone_bright.inputs.new('NodeSocketColor', "Color1")
    stone_bright.inputs[1].default_value = (0.058587487787008286, 0.058587487787008286, 0.058587487787008286, 1.0)
    stone_bright.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    stone_bright.inputs.new('NodeSocketColor', "Color2")
    stone_bright.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    stone_bright.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    stone_bright.inputs.new('NodeSocketFloatFactor', "Specular")
    stone_bright.inputs[3].default_value = 0.5
    stone_bright.inputs[3].min_value = 0.0
    stone_bright.inputs[3].max_value = 1.0
    stone_bright.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    stone_bright.inputs.new('NodeSocketFloatFactor', "Roughness")
    stone_bright.inputs[4].default_value = 0.5
    stone_bright.inputs[4].min_value = 0.0
    stone_bright.inputs[4].max_value = 1.0
    stone_bright.inputs[4].attribute_domain = 'POINT'
    
    #input Detail
    stone_bright.inputs.new('NodeSocketFloat', "Detail")
    stone_bright.inputs[5].default_value = 10.0
    stone_bright.inputs[5].min_value = 0.0
    stone_bright.inputs[5].max_value = 15.0
    stone_bright.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    stone_bright.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    stone_bright.inputs[6].default_value = 0.10000000149011612
    stone_bright.inputs[6].min_value = 0.0
    stone_bright.inputs[6].max_value = 1.0
    stone_bright.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    stone_bright.inputs.new('NodeSocketVector', "Normal")
    stone_bright.inputs[7].default_value = (0.0, 0.0, 0.0)
    stone_bright.inputs[7].min_value = -1.0
    stone_bright.inputs[7].max_value = 1.0
    stone_bright.inputs[7].attribute_domain = 'POINT'
    stone_bright.inputs[7].hide_value = True
    
    
    
    #node Noise Texture
    noise_texture = stone_bright.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 3.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.7166666984558105
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix
    mix = stone_bright.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    
    #Set locations
    principled_bsdf.location = (662.5631713867188, 230.0)
    group_output.location = (952.5631713867188, -0.0)
    vector_math.location = (-453.9227294921875, 107.998291015625)
    texture_coordinate_001.location = (-793.9227294921875, 27.99835205078125)
    colorramp.location = (50.01446533203125, 187.00894165039062)
    bump.location = (299.20654296875, -238.35272216796875)
    group_input.location = (-993.9227294921875, -8.35272216796875)
    noise_texture.location = (-100.7933349609375, 121.64727783203125)
    mix.location = (468.869140625, 188.76119995117188)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    
    #initialize stone_bright links
    #principled_bsdf.BSDF -> group_output.BSDF
    stone_bright.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    stone_bright.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    stone_bright.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #noise_texture.Fac -> bump.Height
    stone_bright.links.new(noise_texture.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    stone_bright.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #texture_coordinate_001.Object -> vector_math.Vector
    stone_bright.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    stone_bright.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    stone_bright.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> mix.Factor
    stone_bright.links.new(colorramp.outputs[0], mix.inputs[0])
    #group_input.Color1 -> mix.A
    stone_bright.links.new(group_input.outputs[1], mix.inputs[6])
    #group_input.Color2 -> mix.B
    stone_bright.links.new(group_input.outputs[2], mix.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    stone_bright.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    stone_bright.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Detail -> noise_texture.Detail
    stone_bright.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    stone_bright.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    stone_bright.links.new(group_input.outputs[7], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask 
    stone_bright.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    stone_bright.links.new(mix.outputs[2], group_output.inputs[1])
    return stone_bright

stone_bright = stone_bright_node_group()

#initialize Stone Bright node group
def stone_bright_1_node_group():

    stone_bright_1 = mat.node_tree
    #start with a clean node tree
    for node in stone_bright_1.nodes:
        stone_bright_1.nodes.remove(node)
    #initialize stone_bright_1 nodes
    #node Material Output
    material_output = stone_bright_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Stone bright
    stone_bright_2 = stone_bright_1.nodes.new("ShaderNodeGroup")
    stone_bright_2.label = "Stone bright"
    stone_bright_2.name = "Stone bright"
    stone_bright_2.node_tree = stone_bright
    #Input_1
    stone_bright_2.inputs[0].default_value = 1.0
    #Input_2
    stone_bright_2.inputs[1].default_value = (0.058587487787008286, 0.058587487787008286, 0.058587487787008286, 1.0)
    #Input_3
    stone_bright_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    stone_bright_2.inputs[3].default_value = 0.5
    #Input_5
    stone_bright_2.inputs[4].default_value = 0.5
    #Input_6
    stone_bright_2.inputs[5].default_value = 10.0
    #Input_7
    stone_bright_2.inputs[6].default_value = 0.10000000149011612
    #Input_8
    stone_bright_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (649.623046875, 81.66796875)
    stone_bright_2.location = (406.775390625, 81.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    stone_bright_2.width, stone_bright_2.height = 180.85037231445312, 100.0
    
    #initialize stone_bright_1 links
    #stone_bright_2.BSDF -> material_output.Surface
    stone_bright_1.links.new(stone_bright_2.outputs[0], material_output.inputs[0])
    return stone_bright_1

stone_bright_1 = stone_bright_1_node_group()

