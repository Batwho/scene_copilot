import bpy, mathutils

mat = bpy.data.materials.new(name = "Soft Blur")
mat.use_nodes = True
#initialize Soft Blur node group
def soft_blur_node_group():

    soft_blur = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Soft Blur")
    
    #initialize soft_blur nodes
    #node Mix.001
    mix_001 = soft_blur.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'BURN'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.9999899864196777
    #B_Color
    mix_001.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.002
    mix_002 = soft_blur.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'DODGE'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #B_Color
    mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix
    mix = soft_blur.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'LINEAR_LIGHT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Texture Coordinate
    texture_coordinate = soft_blur.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node White Noise Texture
    white_noise_texture = soft_blur.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture.name = "White Noise Texture"
    white_noise_texture.noise_dimensions = '3D'
    
    #node ColorRamp.001
    colorramp_001 = soft_blur.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.003
    mix_003 = soft_blur.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = soft_blur.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    
    #node Math.001
    math_001 = soft_blur.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    
    #node Emission
    emission = soft_blur.nodes.new("ShaderNodeEmission")
    emission.name = "Emission"
    
    #node Group Output
    group_output = soft_blur.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #soft_blur outputs
    #output Emission
    soft_blur.outputs.new('NodeSocketShader', "Emission")
    soft_blur.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Math
    math = soft_blur.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    
    #node Group Input
    group_input = soft_blur.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #soft_blur inputs
    #input Color1
    soft_blur.inputs.new('NodeSocketColor', "Color1")
    soft_blur.inputs[0].default_value = (0.017467118799686432, 0.54216068983078, 1.0, 1.0)
    soft_blur.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    soft_blur.inputs.new('NodeSocketColor', "Color2")
    soft_blur.inputs[1].default_value = (1.0, 0.34806567430496216, 0.9816965460777283, 1.0)
    soft_blur.inputs[1].attribute_domain = 'POINT'
    
    #input Brightnes
    soft_blur.inputs.new('NodeSocketFloat', "Brightnes")
    soft_blur.inputs[2].default_value = 3.0
    soft_blur.inputs[2].min_value = -10000.0
    soft_blur.inputs[2].max_value = 10000.0
    soft_blur.inputs[2].attribute_domain = 'POINT'
    
    #input Blur
    soft_blur.inputs.new('NodeSocketFloatFactor', "Blur")
    soft_blur.inputs[3].default_value = 0.05374997481703758
    soft_blur.inputs[3].min_value = 0.0
    soft_blur.inputs[3].max_value = 1.0
    soft_blur.inputs[3].attribute_domain = 'POINT'
    
    #input Clamp
    soft_blur.inputs.new('NodeSocketFloatFactor', "Clamp")
    soft_blur.inputs[4].default_value = 0.3499999940395355
    soft_blur.inputs[4].min_value = 0.0
    soft_blur.inputs[4].max_value = 1.0
    soft_blur.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    soft_blur.inputs.new('NodeSocketFloat', "Noise Scale")
    soft_blur.inputs[5].default_value = 2.0
    soft_blur.inputs[5].min_value = -1000.0
    soft_blur.inputs[5].max_value = 1000.0
    soft_blur.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Detail
    soft_blur.inputs.new('NodeSocketFloat', "Noise Detail")
    soft_blur.inputs[6].default_value = 0.0
    soft_blur.inputs[6].min_value = 0.0
    soft_blur.inputs[6].max_value = 15.0
    soft_blur.inputs[6].attribute_domain = 'POINT'
    
    #input Noise Distortion
    soft_blur.inputs.new('NodeSocketFloat', "Noise Distortion")
    soft_blur.inputs[7].default_value = 0.5
    soft_blur.inputs[7].min_value = -1000.0
    soft_blur.inputs[7].max_value = 1000.0
    soft_blur.inputs[7].attribute_domain = 'POINT'
    
    #input Space Adition
    soft_blur.inputs.new('NodeSocketFloat', "Space Adition")
    soft_blur.inputs[8].default_value = 0.0
    soft_blur.inputs[8].min_value = -10000.0
    soft_blur.inputs[8].max_value = 10000.0
    soft_blur.inputs[8].attribute_domain = 'POINT'
    
    
    
    
    #Set locations
    mix_001.location = (400.0, -50.0)
    mix_002.location = (225.35546875, -77.6156005859375)
    mix.location = (-220.0, 70.00001525878906)
    texture_coordinate.location = (-580.0, -70.00001525878906)
    white_noise_texture.location = (-400.0, -170.00001525878906)
    colorramp_001.location = (120.0, 170.00001525878906)
    mix_003.location = (400.0, 150.00001525878906)
    noise_texture.location = (-60.0, -49.99998474121094)
    math_001.location = (559.6729736328125, -39.219970703125)
    emission.location = (980.0, -40.0)
    group_output.location = (1180.0, -20.0)
    math.location = (800.0, -100.0)
    group_input.location = (-780.0, -0.0)
    
    #Set dimensions
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    white_noise_texture.width, white_noise_texture.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    emission.width, emission.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize soft_blur links
    #emission.Emission -> group_output.Emission
    soft_blur.links.new(emission.outputs[0], group_output.inputs[0])
    #texture_coordinate.Object -> white_noise_texture.Vector
    soft_blur.links.new(texture_coordinate.outputs[3], white_noise_texture.inputs[0])
    #texture_coordinate.Object -> mix.A
    soft_blur.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #mix.Result -> noise_texture.Vector
    soft_blur.links.new(mix.outputs[2], noise_texture.inputs[0])
    #white_noise_texture.Color -> mix.B
    soft_blur.links.new(white_noise_texture.outputs[1], mix.inputs[7])
    #math.Value -> emission.Strength
    soft_blur.links.new(math.outputs[0], emission.inputs[1])
    #noise_texture.Fac -> colorramp_001.Fac
    soft_blur.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #mix_002.Result -> mix_001.A
    soft_blur.links.new(mix_002.outputs[2], mix_001.inputs[6])
    #noise_texture.Color -> mix_002.A
    soft_blur.links.new(noise_texture.outputs[1], mix_002.inputs[6])
    #colorramp_001.Color -> mix_003.Factor
    soft_blur.links.new(colorramp_001.outputs[0], mix_003.inputs[0])
    #mix_003.Result -> emission.Color
    soft_blur.links.new(mix_003.outputs[2], emission.inputs[0])
    #group_input.Blur -> mix.Factor
    soft_blur.links.new(group_input.outputs[3], mix.inputs[0])
    #group_input.Clamp -> mix_002.Factor
    soft_blur.links.new(group_input.outputs[4], mix_002.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    soft_blur.links.new(group_input.outputs[5], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    soft_blur.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Color1 -> mix_003.A
    soft_blur.links.new(group_input.outputs[0], mix_003.inputs[6])
    #group_input.Color2 -> mix_003.B
    soft_blur.links.new(group_input.outputs[1], mix_003.inputs[7])
    #math_001.Value -> math.Value
    soft_blur.links.new(math_001.outputs[0], math.inputs[0])
    #group_input.Noise Distortion -> noise_texture.Distortion
    soft_blur.links.new(group_input.outputs[7], noise_texture.inputs[5])
    #group_input.Space Adition -> math.Value
    soft_blur.links.new(group_input.outputs[8], math.inputs[1])
    #mix_001.Result -> math_001.Value
    soft_blur.links.new(mix_001.outputs[2], math_001.inputs[0])
    #group_input.Brightnes -> math_001.Value
    soft_blur.links.new(group_input.outputs[2], math_001.inputs[1])
    return soft_blur

soft_blur = soft_blur_node_group()

#initialize Soft Blur node group
def soft_blur_1_node_group():

    soft_blur_1 = mat.node_tree
    #start with a clean node tree
    for node in soft_blur_1.nodes:
        soft_blur_1.nodes.remove(node)
    #initialize soft_blur_1 nodes
    #node Material Output
    material_output = soft_blur_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Soft Blur
    soft_blur_2 = soft_blur_1.nodes.new("ShaderNodeGroup")
    soft_blur_2.label = "Soft Blur"
    soft_blur_2.name = "Soft Blur"
    soft_blur_2.node_tree = soft_blur
    #Input_5
    soft_blur_2.inputs[0].default_value = (0.017467118799686432, 0.54216068983078, 1.0, 1.0)
    #Input_6
    soft_blur_2.inputs[1].default_value = (1.0, 0.34806567430496216, 0.9816965460777283, 1.0)
    #Input_9
    soft_blur_2.inputs[2].default_value = 3.0
    #Input_1
    soft_blur_2.inputs[3].default_value = 0.11857125163078308
    #Input_2
    soft_blur_2.inputs[4].default_value = 0.3499999940395355
    #Input_3
    soft_blur_2.inputs[5].default_value = 2.0
    #Input_4
    soft_blur_2.inputs[6].default_value = 0.0
    #Input_7
    soft_blur_2.inputs[7].default_value = 0.5
    #Input_8
    soft_blur_2.inputs[8].default_value = 0.10000000149011612
    
    
    #Set locations
    material_output.location = (1020.0, 219.99998474121094)
    soft_blur_2.location = (300.1400146484375, 251.7601776123047)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    soft_blur_2.width, soft_blur_2.height = 195.7383270263672, 100.0
    
    #initialize soft_blur_1 links
    #soft_blur_2.Emission -> material_output.Volume
    soft_blur_1.links.new(soft_blur_2.outputs[0], material_output.inputs[1])
    return soft_blur_1

soft_blur_1 = soft_blur_1_node_group()

