import bpy, mathutils

mat = bpy.data.materials.new(name = "Oil")
mat.use_nodes = True
#initialize Oil node group
def oil_node_group():

    oil = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Oil")
    
    #initialize oil nodes
    #node Layer Weight
    layer_weight = oil.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    
    #node ColorRamp
    colorramp = oil.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.013636363670229912
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.0340910367667675)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.7597348690032959, 0.0, 1.0, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.04318179562687874)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.0, 0.6768743395805359, 1.0, 1.0)

    colorramp_cre_3 = colorramp.color_ramp.elements.new(0.06363637745380402)
    colorramp_cre_3.alpha = 1.0
    colorramp_cre_3.color = (0.0012612567516043782, 1.0, 0.0, 1.0)

    colorramp_cre_4 = colorramp.color_ramp.elements.new(0.09545480459928513)
    colorramp_cre_4.alpha = 1.0
    colorramp_cre_4.color = (1.0, 0.6912853717803955, 0.0, 1.0)

    colorramp_cre_5 = colorramp.color_ramp.elements.new(0.2863643169403076)
    colorramp_cre_5.alpha = 1.0
    colorramp_cre_5.color = (1.0, 0.0, 0.0031131708528846502, 1.0)

    
    #node Mix
    mix = oil.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.4691665768623352
    
    #node Texture Coordinate
    texture_coordinate = oil.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Noise Texture
    noise_texture = oil.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture.inputs[5].default_value = 2.859999895095825
    
    #node Add Shader
    add_shader = oil.nodes.new("ShaderNodeAddShader")
    add_shader.name = "Add Shader"
    
    #node Principled BSDF
    principled_bsdf = oil.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Base Color
    principled_bsdf.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.0363636314868927
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5727272629737854
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.10000000149011612
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Hue Saturation Value
    hue_saturation_value = oil.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Glossy BSDF
    glossy_bsdf = oil.nodes.new("ShaderNodeBsdfGlossy")
    glossy_bsdf.name = "Glossy BSDF"
    glossy_bsdf.distribution = 'GGX'
    #Roughness
    glossy_bsdf.inputs[1].default_value = 0.0
    
    #node Mix Shader
    mix_shader = oil.nodes.new("ShaderNodeMixShader")
    mix_shader.name = "Mix Shader"
    
    #node Mix Shader.001
    mix_shader_001 = oil.nodes.new("ShaderNodeMixShader")
    mix_shader_001.name = "Mix Shader.001"
    #Fac
    mix_shader_001.inputs[0].default_value = 0.5750000476837158
    
    #node Refraction BSDF
    refraction_bsdf = oil.nodes.new("ShaderNodeBsdfRefraction")
    refraction_bsdf.name = "Refraction BSDF"
    refraction_bsdf.distribution = 'BECKMANN'
    #Roughness
    refraction_bsdf.inputs[1].default_value = 0.0
    #IOR
    refraction_bsdf.inputs[2].default_value = 1.4500000476837158
    
    #node Math
    math = oil.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 2.799999952316284
    
    #node Group Output
    group_output = oil.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #oil outputs
    #output Shader
    oil.outputs.new('NodeSocketShader', "Shader")
    oil.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    oil.outputs.new('NodeSocketColor', "Albedo")
    oil.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    oil.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    oil.outputs.new('NodeSocketFloat', "Mask")
    oil.outputs[2].default_value = 0.0
    oil.outputs[2].min_value = -3.4028234663852886e+38
    oil.outputs[2].max_value = 3.4028234663852886e+38
    oil.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    oil.outputs.new('NodeSocketVector', "Normal")
    oil.outputs[3].default_value = (0.0, 0.0, 0.0)
    oil.outputs[3].min_value = -3.4028234663852886e+38
    oil.outputs[3].max_value = 3.4028234663852886e+38
    oil.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Bump
    bump = oil.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = oil.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #oil inputs
    #input Scale
    oil.inputs.new('NodeSocketFloat', "Scale")
    oil.inputs[0].default_value = 0.5
    oil.inputs[0].min_value = -10000.0
    oil.inputs[0].max_value = 10000.0
    oil.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    oil.inputs.new('NodeSocketFloat', "Color Hue")
    oil.inputs[1].default_value = 0.5
    oil.inputs[1].min_value = 0.0
    oil.inputs[1].max_value = 1.0
    oil.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    oil.inputs.new('NodeSocketFloat', "Saturation")
    oil.inputs[2].default_value = 0.6999999284744263
    oil.inputs[2].min_value = 0.0
    oil.inputs[2].max_value = 2.0
    oil.inputs[2].attribute_domain = 'POINT'
    
    #input Brightnes
    oil.inputs.new('NodeSocketFloat', "Brightnes")
    oil.inputs[3].default_value = 0.8999999761581421
    oil.inputs[3].min_value = 0.0
    oil.inputs[3].max_value = 2.0
    oil.inputs[3].attribute_domain = 'POINT'
    
    #input Detail
    oil.inputs.new('NodeSocketFloat', "Detail")
    oil.inputs[4].default_value = 3.0399999618530273
    oil.inputs[4].min_value = 0.0
    oil.inputs[4].max_value = 15.0
    oil.inputs[4].attribute_domain = 'POINT'
    
    #input Effect Fresnel
    oil.inputs.new('NodeSocketFloat', "Effect Fresnel")
    oil.inputs[5].default_value = 0.10000000149011612
    oil.inputs[5].min_value = 0.0
    oil.inputs[5].max_value = 1.0
    oil.inputs[5].attribute_domain = 'POINT'
    
    #input Effect Mix
    oil.inputs.new('NodeSocketFloatFactor', "Effect Mix")
    oil.inputs[6].default_value = 0.925000011920929
    oil.inputs[6].min_value = 0.0
    oil.inputs[6].max_value = 1.0
    oil.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    oil.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    oil.inputs[7].default_value = 0.14166666567325592
    oil.inputs[7].min_value = 0.0
    oil.inputs[7].max_value = 1.0
    oil.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    oil.inputs.new('NodeSocketVector', "Normal")
    oil.inputs[8].default_value = (0.0, 0.0, 0.0)
    oil.inputs[8].min_value = -1.0
    oil.inputs[8].max_value = 1.0
    oil.inputs[8].attribute_domain = 'POINT'
    oil.inputs[8].hide_value = True
    
    
    
    
    #Set locations
    layer_weight.location = (-585.0, 147.61398315429688)
    colorramp.location = (-165.0, 147.61398315429688)
    mix.location = (-785.0, 107.61398315429688)
    texture_coordinate.location = (-1165.0, 187.61398315429688)
    noise_texture.location = (-1005.0, -92.38601684570312)
    add_shader.location = (1065.0, 19.366973876953125)
    principled_bsdf.location = (215.0, -112.38601684570312)
    hue_saturation_value.location = (155.0, 202.85818481445312)
    glossy_bsdf.location = (615.0, 207.61398315429688)
    mix_shader.location = (1285.0, 22.421783447265625)
    mix_shader_001.location = (845.0, 120.292724609375)
    refraction_bsdf.location = (375.0, 167.61398315429688)
    math.location = (-1285.0, -112.38601684570312)
    group_output.location = (1475.0, -0.0)
    bump.location = (-63.41168212890625, -207.6139678955078)
    group_input.location = (-1485.0, -0.0)
    
    #Set dimensions
    layer_weight.width, layer_weight.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    add_shader.width, add_shader.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    glossy_bsdf.width, glossy_bsdf.height = 150.0, 100.0
    mix_shader.width, mix_shader.height = 140.0, 100.0
    mix_shader_001.width, mix_shader_001.height = 140.0, 100.0
    refraction_bsdf.width, refraction_bsdf.height = 150.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize oil links
    #mix_shader.Shader -> group_output.Shader
    oil.links.new(mix_shader.outputs[0], group_output.inputs[0])
    #noise_texture.Fac -> bump.Height
    oil.links.new(noise_texture.outputs[0], bump.inputs[2])
    #layer_weight.Fresnel -> colorramp.Fac
    oil.links.new(layer_weight.outputs[0], colorramp.inputs[0])
    #mix.Result -> layer_weight.Normal
    oil.links.new(mix.outputs[2], layer_weight.inputs[1])
    #texture_coordinate.Object -> mix.A
    oil.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Fac -> mix.B
    oil.links.new(noise_texture.outputs[0], mix.inputs[7])
    #add_shader.Shader -> mix_shader.Shader
    oil.links.new(add_shader.outputs[0], mix_shader.inputs[1])
    #principled_bsdf.BSDF -> add_shader.Shader
    oil.links.new(principled_bsdf.outputs[0], add_shader.inputs[1])
    #bump.Normal -> principled_bsdf.Normal
    oil.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp.Color -> hue_saturation_value.Color
    oil.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #principled_bsdf.BSDF -> mix_shader.Shader
    oil.links.new(principled_bsdf.outputs[0], mix_shader.inputs[2])
    #bump.Normal -> refraction_bsdf.Normal
    oil.links.new(bump.outputs[0], refraction_bsdf.inputs[3])
    #hue_saturation_value.Color -> refraction_bsdf.Color
    oil.links.new(hue_saturation_value.outputs[0], refraction_bsdf.inputs[0])
    #bump.Normal -> glossy_bsdf.Normal
    oil.links.new(bump.outputs[0], glossy_bsdf.inputs[2])
    #hue_saturation_value.Color -> glossy_bsdf.Color
    oil.links.new(hue_saturation_value.outputs[0], glossy_bsdf.inputs[0])
    #mix_shader_001.Shader -> add_shader.Shader
    oil.links.new(mix_shader_001.outputs[0], add_shader.inputs[0])
    #glossy_bsdf.BSDF -> mix_shader_001.Shader
    oil.links.new(glossy_bsdf.outputs[0], mix_shader_001.inputs[1])
    #refraction_bsdf.BSDF -> mix_shader_001.Shader
    oil.links.new(refraction_bsdf.outputs[0], mix_shader_001.inputs[2])
    #math.Value -> noise_texture.Scale
    oil.links.new(math.outputs[0], noise_texture.inputs[2])
    #group_input.Scale -> math.Value
    oil.links.new(group_input.outputs[0], math.inputs[1])
    #group_input.Color Hue -> hue_saturation_value.Hue
    oil.links.new(group_input.outputs[1], hue_saturation_value.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    oil.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    #group_input.Brightnes -> hue_saturation_value.Value
    oil.links.new(group_input.outputs[3], hue_saturation_value.inputs[2])
    #group_input.Bump Strength -> bump.Strength
    oil.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Effect Mix -> mix_shader.Fac
    oil.links.new(group_input.outputs[6], mix_shader.inputs[0])
    #group_input.Detail -> noise_texture.Detail
    oil.links.new(group_input.outputs[4], noise_texture.inputs[3])
    #group_input.Normal -> bump.Normal
    oil.links.new(group_input.outputs[8], bump.inputs[3])
    #layer_weight.Fresnel -> group_output.Mask
    oil.links.new(layer_weight.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    oil.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    oil.links.new(bump.outputs[0], group_output.inputs[3])
    #group_input.Effect Fresnel -> layer_weight.Blend
    oil.links.new(group_input.outputs[5], layer_weight.inputs[0])
    return oil

oil = oil_node_group()

#initialize Oil node group
def oil_1_node_group():

    oil_1 = mat.node_tree
    #start with a clean node tree
    for node in oil_1.nodes:
        oil_1.nodes.remove(node)
    #initialize oil_1 nodes
    #node Material Output
    material_output = oil_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Oil
    oil_2 = oil_1.nodes.new("ShaderNodeGroup")
    oil_2.label = "Oil"
    oil_2.name = "Oil"
    oil_2.use_custom_color = True
    oil_2.color = (0.04776229336857796, 0.13321316242218018, 0.16264207661151886)
    oil_2.node_tree = oil
    #Input_1
    oil_2.inputs[0].default_value = 0.5
    #Input_2
    oil_2.inputs[1].default_value = 0.5
    #Input_3
    oil_2.inputs[2].default_value = 0.699999988079071
    #Input_4
    oil_2.inputs[3].default_value = 0.8999999761581421
    #Input_7
    oil_2.inputs[4].default_value = 3.0
    #Input_12
    oil_2.inputs[5].default_value = 0.10000000149011612
    #Input_6
    oil_2.inputs[6].default_value = 0.925000011920929
    #Input_5
    oil_2.inputs[7].default_value = 0.1666666716337204
    #Input_8
    oil_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (676.0947265625, 44.433349609375)
    oil_2.location = (427.4375915527344, 44.433349609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    oil_2.width, oil_2.height = 178.65780639648438, 100.0
    
    #initialize oil_1 links
    #oil_2.Shader -> material_output.Surface
    oil_1.links.new(oil_2.outputs[0], material_output.inputs[0])
    return oil_1

oil_1 = oil_1_node_group()

