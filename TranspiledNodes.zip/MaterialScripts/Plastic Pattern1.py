import bpy, mathutils

mat = bpy.data.materials.new(name = "Plastic Pattern1")
mat.use_nodes = True
#initialize Plastic_Pattern1 node group
def plastic_pattern1_node_group():

    plastic_pattern1 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Plastic_Pattern1")
    
    #initialize plastic_pattern1 nodes
    #node Texture Coordinate
    texture_coordinate = plastic_pattern1.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = plastic_pattern1.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = plastic_pattern1.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.6166666746139526
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node ColorRamp
    colorramp = plastic_pattern1.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.25
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.6581215858459473, 1.0, 0.09767217934131622, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.2818182706832886)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.04715077579021454, 0.08519774675369263, 0.022172948345541954, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = plastic_pattern1.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.25
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.2818182706832886)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Mix.001
    mix_001 = plastic_pattern1.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Voronoi Texture
    voronoi_texture = plastic_pattern1.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Math.001
    math_001 = plastic_pattern1.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = 14.5
    
    #node Math
    math = plastic_pattern1.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 5.0
    
    #node Principled BSDF
    principled_bsdf = plastic_pattern1.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = plastic_pattern1.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #plastic_pattern1 outputs
    #output BSDF
    plastic_pattern1.outputs.new('NodeSocketShader', "BSDF")
    plastic_pattern1.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    plastic_pattern1.outputs.new('NodeSocketColor', "Albedo")
    plastic_pattern1.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    plastic_pattern1.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    plastic_pattern1.outputs.new('NodeSocketFloat', "Mask")
    plastic_pattern1.outputs[2].default_value = 0.0
    plastic_pattern1.outputs[2].min_value = -3.4028234663852886e+38
    plastic_pattern1.outputs[2].max_value = 3.4028234663852886e+38
    plastic_pattern1.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Invert
    invert = plastic_pattern1.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.002
    math_002 = plastic_pattern1.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.5
    
    #node Group Input
    group_input = plastic_pattern1.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #plastic_pattern1 inputs
    #input Scale
    plastic_pattern1.inputs.new('NodeSocketFloat', "Scale")
    plastic_pattern1.inputs[0].default_value = 0.5
    plastic_pattern1.inputs[0].min_value = -10000.0
    plastic_pattern1.inputs[0].max_value = 10000.0
    plastic_pattern1.inputs[0].attribute_domain = 'POINT'
    
    #input Roughness
    plastic_pattern1.inputs.new('NodeSocketFloatFactor', "Roughness")
    plastic_pattern1.inputs[1].default_value = 0.6000000238418579
    plastic_pattern1.inputs[1].min_value = 0.0
    plastic_pattern1.inputs[1].max_value = 1.0
    plastic_pattern1.inputs[1].attribute_domain = 'POINT'
    
    #input Color hue
    plastic_pattern1.inputs.new('NodeSocketFloatFactor', "Color hue")
    plastic_pattern1.inputs[2].default_value = 1.0
    plastic_pattern1.inputs[2].min_value = 0.0
    plastic_pattern1.inputs[2].max_value = 1.0
    plastic_pattern1.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    plastic_pattern1.inputs.new('NodeSocketFloat', "Saturation")
    plastic_pattern1.inputs[3].default_value = 1.0
    plastic_pattern1.inputs[3].min_value = 0.0
    plastic_pattern1.inputs[3].max_value = 2.0
    plastic_pattern1.inputs[3].attribute_domain = 'POINT'
    
    #input Brightness
    plastic_pattern1.inputs.new('NodeSocketFloat', "Brightness")
    plastic_pattern1.inputs[4].default_value = 1.0
    plastic_pattern1.inputs[4].min_value = 0.0
    plastic_pattern1.inputs[4].max_value = 2.0
    plastic_pattern1.inputs[4].attribute_domain = 'POINT'
    
    #input Mix Effect
    plastic_pattern1.inputs.new('NodeSocketFloatFactor', "Mix Effect")
    plastic_pattern1.inputs[5].default_value = 0.18416671454906464
    plastic_pattern1.inputs[5].min_value = 0.0
    plastic_pattern1.inputs[5].max_value = 1.0
    plastic_pattern1.inputs[5].attribute_domain = 'POINT'
    
    #input Dark Mask
    plastic_pattern1.inputs.new('NodeSocketFloatFactor', "Dark Mask")
    plastic_pattern1.inputs[6].default_value = 0.25
    plastic_pattern1.inputs[6].min_value = 0.0
    plastic_pattern1.inputs[6].max_value = 1.0
    plastic_pattern1.inputs[6].attribute_domain = 'POINT'
    
    #input Detail
    plastic_pattern1.inputs.new('NodeSocketFloat', "Detail")
    plastic_pattern1.inputs[7].default_value = 5.0
    plastic_pattern1.inputs[7].min_value = 0.0
    plastic_pattern1.inputs[7].max_value = 15.0
    plastic_pattern1.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    plastic_pattern1.inputs.new('NodeSocketVector', "Normal")
    plastic_pattern1.inputs[8].default_value = (0.0, 0.0, 0.0)
    plastic_pattern1.inputs[8].min_value = -3.4028234663852886e+38
    plastic_pattern1.inputs[8].max_value = 3.4028234663852886e+38
    plastic_pattern1.inputs[8].attribute_domain = 'POINT'
    plastic_pattern1.inputs[8].hide_value = True
    
    
    
    #node Hue Saturation Value
    hue_saturation_value = plastic_pattern1.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    
    #Set locations
    texture_coordinate.location = (-369.77117919921875, 77.43994140625)
    mix.location = (-149.77117919921875, 19.78253173828125)
    noise_texture.location = (-369.77117919921875, -177.43988037109375)
    colorramp.location = (290.22894287109375, 111.4698486328125)
    colorramp_001.location = (290.22894287109375, -101.68743896484375)
    mix_001.location = (610.2288208007812, 137.47576904296875)
    voronoi_texture.location = (70.22882080078125, 57.44000244140625)
    math_001.location = (-729.7710571289062, 177.43988037109375)
    math.location = (-829.7710571289062, -2.56005859375)
    principled_bsdf.location = (1059.77099609375, 137.43988037109375)
    group_output.location = (1349.77099609375, -0.0)
    invert.location = (60.0, 260.0000305175781)
    math_002.location = (385.2874755859375, 291.1802062988281)
    group_input.location = (-1029.77099609375, -0.0)
    hue_saturation_value.location = (830.0, 146.29425048828125)
    
    #Set dimensions
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    
    #initialize plastic_pattern1 links
    #principled_bsdf.BSDF -> group_output.BSDF
    plastic_pattern1.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    plastic_pattern1.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #mix.Result -> voronoi_texture.Vector
    plastic_pattern1.links.new(mix.outputs[2], voronoi_texture.inputs[0])
    #texture_coordinate.Object -> mix.A
    plastic_pattern1.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Color -> mix.B
    plastic_pattern1.links.new(noise_texture.outputs[1], mix.inputs[7])
    #voronoi_texture.Distance -> colorramp.Fac
    plastic_pattern1.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #voronoi_texture.Color -> colorramp_001.Fac
    plastic_pattern1.links.new(voronoi_texture.outputs[1], colorramp_001.inputs[0])
    #colorramp.Color -> mix_001.A
    plastic_pattern1.links.new(colorramp.outputs[0], mix_001.inputs[6])
    #colorramp_001.Color -> mix_001.B
    plastic_pattern1.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #math_001.Value -> voronoi_texture.Scale
    plastic_pattern1.links.new(math_001.outputs[0], voronoi_texture.inputs[2])
    #math.Value -> noise_texture.Scale
    plastic_pattern1.links.new(math.outputs[0], noise_texture.inputs[2])
    #mix_001.Result -> hue_saturation_value.Color
    plastic_pattern1.links.new(mix_001.outputs[2], hue_saturation_value.inputs[4])
    #group_input.Color hue -> invert.Fac
    plastic_pattern1.links.new(group_input.outputs[2], invert.inputs[0])
    #math_002.Value -> hue_saturation_value.Hue
    plastic_pattern1.links.new(math_002.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math_002.Value
    plastic_pattern1.links.new(invert.outputs[0], math_002.inputs[0])
    #group_input.Scale -> math_001.Value
    plastic_pattern1.links.new(group_input.outputs[0], math_001.inputs[1])
    #group_input.Scale -> math.Value
    plastic_pattern1.links.new(group_input.outputs[0], math.inputs[1])
    #group_input.Mix Effect -> mix.Factor
    plastic_pattern1.links.new(group_input.outputs[5], mix.inputs[0])
    #group_input.Detail -> noise_texture.Detail
    plastic_pattern1.links.new(group_input.outputs[7], noise_texture.inputs[3])
    #group_input.Saturation -> hue_saturation_value.Saturation
    plastic_pattern1.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Roughness -> principled_bsdf.Roughness
    plastic_pattern1.links.new(group_input.outputs[1], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    plastic_pattern1.links.new(group_input.outputs[8], principled_bsdf.inputs[22])
    #group_input.Dark Mask -> mix_001.Factor
    plastic_pattern1.links.new(group_input.outputs[6], mix_001.inputs[0])
    #group_input.Brightness -> hue_saturation_value.Value
    plastic_pattern1.links.new(group_input.outputs[4], hue_saturation_value.inputs[2])
    #voronoi_texture.Distance -> group_output.Mask
    plastic_pattern1.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    plastic_pattern1.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return plastic_pattern1

plastic_pattern1 = plastic_pattern1_node_group()

#initialize Plastic Pattern1 node group
def plastic_pattern1_1_node_group():

    plastic_pattern1_1 = mat.node_tree
    #start with a clean node tree
    for node in plastic_pattern1_1.nodes:
        plastic_pattern1_1.nodes.remove(node)
    #initialize plastic_pattern1_1 nodes
    #node Material Output
    material_output = plastic_pattern1_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Plastic_Pattern1
    plastic_pattern1_2 = plastic_pattern1_1.nodes.new("ShaderNodeGroup")
    plastic_pattern1_2.label = "Plastic_Pattern1"
    plastic_pattern1_2.name = "Plastic_Pattern1"
    plastic_pattern1_2.use_custom_color = True
    plastic_pattern1_2.color = (0.08714018017053604, 0.08714018017053604, 0.08714018017053604)
    plastic_pattern1_2.node_tree = plastic_pattern1
    #Input_2
    plastic_pattern1_2.inputs[0].default_value = 1.0
    #Input_6
    plastic_pattern1_2.inputs[1].default_value = 0.6000000238418579
    #Input_1
    plastic_pattern1_2.inputs[2].default_value = 0.0
    #Input_5
    plastic_pattern1_2.inputs[3].default_value = 1.0
    #Input_9
    plastic_pattern1_2.inputs[4].default_value = 1.0
    #Input_3
    plastic_pattern1_2.inputs[5].default_value = 0.16260164976119995
    #Input_8
    plastic_pattern1_2.inputs[6].default_value = 0.25
    #Input_4
    plastic_pattern1_2.inputs[7].default_value = 5.0
    #Input_7
    plastic_pattern1_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (676.82080078125, 83.641845703125)
    plastic_pattern1_2.location = (437.27880859375, 73.331787109375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    plastic_pattern1_2.width, plastic_pattern1_2.height = 143.233642578125, 100.0
    
    #initialize plastic_pattern1_1 links
    #plastic_pattern1_2.BSDF -> material_output.Surface
    plastic_pattern1_1.links.new(plastic_pattern1_2.outputs[0], material_output.inputs[0])
    return plastic_pattern1_1

plastic_pattern1_1 = plastic_pattern1_1_node_group()

