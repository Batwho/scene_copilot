import bpy, mathutils

mat = bpy.data.materials.new(name = "Wood Brown")
mat.use_nodes = True
#initialize wood brown node group
def wood_brown_node_group():

    wood_brown = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "wood brown")
    
    #initialize wood_brown nodes
    #node ColorRamp.001
    colorramp_001 = wood_brown.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5863639116287231)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.003
    colorramp_003 = wood_brown.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.0
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.7818183898925781)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump.001
    bump_001 = wood_brown.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Mix.003
    mix_003 = wood_brown.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 0.38291677832603455
    
    #node Mix.001
    mix_001 = wood_brown.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.09499995410442352
    
    #node Mapping
    mapping = wood_brown.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, -0.05999999865889549, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.5229006409645081, -1.2147490978240967, 1.8737854957580566)
    #Scale
    mapping.inputs[3].default_value = (21.23999786376953, 0.4399995803833008, 0.07000011205673218)
    
    #node Principled BSDF
    principled_bsdf = wood_brown.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.05000000074505806
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate.002
    texture_coordinate_002 = wood_brown.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_002.name = "Texture Coordinate.002"
    texture_coordinate_002.from_instancer = False
    
    #node Group Output
    group_output = wood_brown.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #wood_brown outputs
    #output BSDF
    wood_brown.outputs.new('NodeSocketShader', "BSDF")
    wood_brown.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    wood_brown.outputs.new('NodeSocketColor', "Mask")
    wood_brown.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    wood_brown.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Vector Math
    vector_math = wood_brown.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Wave Texture
    wave_texture = wood_brown.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Distortion
    wave_texture.inputs[2].default_value = 11.90999984741211
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 0.5099999904632568
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = wood_brown.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'SMOOTH_F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Smoothness
    voronoi_texture.inputs[3].default_value = 0.3333333432674408
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Bump
    bump = wood_brown.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Noise Texture
    noise_texture = wood_brown.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.6033335328102112
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Voronoi Texture.001
    voronoi_texture_001 = wood_brown.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'EUCLIDEAN'
    voronoi_texture_001.feature = 'F2'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 1.0
    
    #node Reroute
    reroute = wood_brown.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Mix.006
    mix_006 = wood_brown.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'DODGE'
    mix_006.clamp_factor = True
    mix_006.clamp_result = False
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    #B_Color
    mix_006.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix
    mix = wood_brown.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Group Input
    group_input = wood_brown.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #wood_brown inputs
    #input Scale
    wood_brown.inputs.new('NodeSocketFloat', "Scale")
    wood_brown.inputs[0].default_value = 1.0
    wood_brown.inputs[0].min_value = -10000.0
    wood_brown.inputs[0].max_value = 10000.0
    wood_brown.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    wood_brown.inputs.new('NodeSocketColor', "Color1")
    wood_brown.inputs[1].default_value = (0.15241800248622894, 0.05328400060534477, 0.022985000163316727, 1.0)
    wood_brown.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    wood_brown.inputs.new('NodeSocketColor', "Color2")
    wood_brown.inputs[2].default_value = (0.006211999803781509, 0.0028719999827444553, 0.002005999907851219, 1.0)
    wood_brown.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    wood_brown.inputs.new('NodeSocketFloatFactor', "Roughness")
    wood_brown.inputs[3].default_value = 0.5
    wood_brown.inputs[3].min_value = 0.0
    wood_brown.inputs[3].max_value = 1.0
    wood_brown.inputs[3].attribute_domain = 'POINT'
    
    #input Scratches Mix
    wood_brown.inputs.new('NodeSocketFloatFactor', "Scratches Mix")
    wood_brown.inputs[4].default_value = 1.0
    wood_brown.inputs[4].min_value = 0.0
    wood_brown.inputs[4].max_value = 1.0
    wood_brown.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    wood_brown.inputs.new('NodeSocketFloat', "Noise Scale")
    wood_brown.inputs[5].default_value = 1.9500000476837158
    wood_brown.inputs[5].min_value = -1000.0
    wood_brown.inputs[5].max_value = 1000.0
    wood_brown.inputs[5].attribute_domain = 'POINT'
    
    #input Bands Amount
    wood_brown.inputs.new('NodeSocketFloat', "Bands Amount")
    wood_brown.inputs[6].default_value = 6.900000095367432
    wood_brown.inputs[6].min_value = -1000.0
    wood_brown.inputs[6].max_value = 1000.0
    wood_brown.inputs[6].attribute_domain = 'POINT'
    
    #input Branchhole Amount
    wood_brown.inputs.new('NodeSocketFloat', "Branchhole Amount")
    wood_brown.inputs[7].default_value = 1.5
    wood_brown.inputs[7].min_value = -1000.0
    wood_brown.inputs[7].max_value = 1000.0
    wood_brown.inputs[7].attribute_domain = 'POINT'
    
    #input Influence Branchholes
    wood_brown.inputs.new('NodeSocketFloatFactor', "Influence Branchholes")
    wood_brown.inputs[8].default_value = 0.7225000858306885
    wood_brown.inputs[8].min_value = 0.0
    wood_brown.inputs[8].max_value = 1.0
    wood_brown.inputs[8].attribute_domain = 'POINT'
    
    #input Scratches Mask
    wood_brown.inputs.new('NodeSocketFloatFactor', "Scratches Mask")
    wood_brown.inputs[9].default_value = 0.47583335638046265
    wood_brown.inputs[9].min_value = 0.0
    wood_brown.inputs[9].max_value = 1.0
    wood_brown.inputs[9].attribute_domain = 'POINT'
    
    #input Scratches Amount
    wood_brown.inputs.new('NodeSocketFloat', "Scratches Amount")
    wood_brown.inputs[10].default_value = 5.0
    wood_brown.inputs[10].min_value = -1000.0
    wood_brown.inputs[10].max_value = 1000.0
    wood_brown.inputs[10].attribute_domain = 'POINT'
    
    #input Bump Strength
    wood_brown.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    wood_brown.inputs[11].default_value = 0.5
    wood_brown.inputs[11].min_value = 0.0
    wood_brown.inputs[11].max_value = 1.0
    wood_brown.inputs[11].attribute_domain = 'POINT'
    
    #input Scratches Bump Strength
    wood_brown.inputs.new('NodeSocketFloatFactor', "Scratches Bump Strength")
    wood_brown.inputs[12].default_value = 0.20000000298023224
    wood_brown.inputs[12].min_value = 0.0
    wood_brown.inputs[12].max_value = 1.0
    wood_brown.inputs[12].attribute_domain = 'POINT'
    
    #input Normal
    wood_brown.inputs.new('NodeSocketVector', "Normal")
    wood_brown.inputs[13].default_value = (0.0, 0.0, 0.0)
    wood_brown.inputs[13].min_value = -1.0
    wood_brown.inputs[13].max_value = 1.0
    wood_brown.inputs[13].attribute_domain = 'POINT'
    wood_brown.inputs[13].hide_value = True
    
    
    
    #node Mix.004
    mix_004 = wood_brown.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MIX'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    
    #node ColorRamp.002
    colorramp_002 = wood_brown.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.002
    mix_002 = wood_brown.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    
    #Set locations
    colorramp_001.location = (-489.103515625, 188.10780334472656)
    colorramp_003.location = (515.2288818359375, -198.98379516601562)
    bump_001.location = (1015.2288818359375, -350.0)
    mix_003.location = (15.2288818359375, -228.34024047851562)
    mix_001.location = (65.2288818359375, 215.72154235839844)
    mapping.location = (-304.7711181640625, -256.5)
    principled_bsdf.location = (1354.7711181640625, 350.0)
    texture_coordinate_002.location = (-1354.7711181640625, 130.0)
    group_output.location = (1644.7711181640625, -0.0)
    vector_math.location = (-1014.7711181640625, 210.0)
    wave_texture.location = (285.2288818359375, 190.0)
    voronoi_texture.location = (-694.7711181640625, 110.0)
    bump.location = (1085.2288818359375, -170.00001525878906)
    noise_texture.location = (-154.7711181640625, 50.0)
    voronoi_texture_001.location = (0.0, -480.0)
    reroute.location = (490.6951904296875, -537.039794921875)
    mix_006.location = (280.0000305175781, -500.0)
    mix.location = (-154.7711181640625, 236.53573608398438)
    group_input.location = (-1554.7711181640625, -0.0)
    mix_004.location = (1064.639404296875, 233.05975341796875)
    colorramp_002.location = (760.0, 200.00001525878906)
    mix_002.location = (580.0, 200.00001525878906)
    
    #Set dimensions
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mapping.width, mapping.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    
    #initialize wood_brown links
    #principled_bsdf.BSDF -> group_output.BSDF
    wood_brown.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix_001.Result -> wave_texture.Vector
    wood_brown.links.new(mix_001.outputs[2], wave_texture.inputs[0])
    #colorramp_001.Color -> mix.A
    wood_brown.links.new(colorramp_001.outputs[0], mix.inputs[6])
    #voronoi_texture.Distance -> colorramp_001.Fac
    wood_brown.links.new(voronoi_texture.outputs[0], colorramp_001.inputs[0])
    #mix_002.Result -> colorramp_002.Fac
    wood_brown.links.new(mix_002.outputs[2], colorramp_002.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    wood_brown.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp_003.Color -> bump.Height
    wood_brown.links.new(colorramp_003.outputs[0], bump.inputs[2])
    #wave_texture.Fac -> colorramp_003.Fac
    wood_brown.links.new(wave_texture.outputs[1], colorramp_003.inputs[0])
    #mix.Result -> mix_001.A
    wood_brown.links.new(mix.outputs[2], mix_001.inputs[6])
    #noise_texture.Fac -> mix_001.B
    wood_brown.links.new(noise_texture.outputs[0], mix_001.inputs[7])
    #mix_003.Result -> voronoi_texture_001.Vector
    wood_brown.links.new(mix_003.outputs[2], voronoi_texture_001.inputs[0])
    #reroute.Output -> bump_001.Height
    wood_brown.links.new(reroute.outputs[0], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    wood_brown.links.new(bump_001.outputs[0], bump.inputs[3])
    #wave_texture.Fac -> mix_002.A
    wood_brown.links.new(wave_texture.outputs[1], mix_002.inputs[6])
    #reroute.Output -> mix_002.B
    wood_brown.links.new(reroute.outputs[0], mix_002.inputs[7])
    #mapping.Vector -> mix_003.A
    wood_brown.links.new(mapping.outputs[0], mix_003.inputs[6])
    #noise_texture.Fac -> mix_003.B
    wood_brown.links.new(noise_texture.outputs[0], mix_003.inputs[7])
    #texture_coordinate_002.Object -> vector_math.Vector
    wood_brown.links.new(texture_coordinate_002.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mix.B
    wood_brown.links.new(vector_math.outputs[0], mix.inputs[7])
    #vector_math.Vector -> voronoi_texture.Vector
    wood_brown.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #vector_math.Vector -> mapping.Vector
    wood_brown.links.new(vector_math.outputs[0], mapping.inputs[0])
    #group_input.Scale -> vector_math.Scale
    wood_brown.links.new(group_input.outputs[0], vector_math.inputs[3])
    #mix_004.Result -> principled_bsdf.Base Color
    wood_brown.links.new(mix_004.outputs[2], principled_bsdf.inputs[0])
    #colorramp_002.Color -> mix_004.Factor
    wood_brown.links.new(colorramp_002.outputs[0], mix_004.inputs[0])
    #group_input.Color1 -> mix_004.A
    wood_brown.links.new(group_input.outputs[1], mix_004.inputs[6])
    #group_input.Color2 -> mix_004.B
    wood_brown.links.new(group_input.outputs[2], mix_004.inputs[7])
    #group_input.Scratches Mix -> mix_002.Factor
    wood_brown.links.new(group_input.outputs[4], mix_002.inputs[0])
    #group_input.Bands Amount -> wave_texture.Scale
    wood_brown.links.new(group_input.outputs[6], wave_texture.inputs[1])
    #group_input.Branchhole Amount -> voronoi_texture.Scale
    wood_brown.links.new(group_input.outputs[7], voronoi_texture.inputs[2])
    #group_input.Scratches Amount -> voronoi_texture_001.Scale
    wood_brown.links.new(group_input.outputs[10], voronoi_texture_001.inputs[2])
    #group_input.Bump Strength -> bump.Strength
    wood_brown.links.new(group_input.outputs[11], bump.inputs[0])
    #group_input.Scratches Bump Strength -> bump_001.Strength
    wood_brown.links.new(group_input.outputs[12], bump_001.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    wood_brown.links.new(group_input.outputs[5], noise_texture.inputs[2])
    #group_input.Roughness -> principled_bsdf.Roughness
    wood_brown.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Normal -> bump_001.Normal
    wood_brown.links.new(group_input.outputs[13], bump_001.inputs[3])
    #voronoi_texture_001.Distance -> mix_006.A
    wood_brown.links.new(voronoi_texture_001.outputs[0], mix_006.inputs[6])
    #mix_006.Result -> reroute.Input
    wood_brown.links.new(mix_006.outputs[2], reroute.inputs[0])
    #group_input.Scratches Mask -> mix_006.Factor
    wood_brown.links.new(group_input.outputs[9], mix_006.inputs[0])
    #group_input.Influence Branchholes -> mix.Factor
    wood_brown.links.new(group_input.outputs[8], mix.inputs[0])
    #mix_002.Result -> group_output.Mask
    wood_brown.links.new(mix_002.outputs[2], group_output.inputs[1])
    return wood_brown

wood_brown = wood_brown_node_group()

#initialize Wood Brown node group
def wood_brown_1_node_group():

    wood_brown_1 = mat.node_tree
    #start with a clean node tree
    for node in wood_brown_1.nodes:
        wood_brown_1.nodes.remove(node)
    #initialize wood_brown_1 nodes
    #node Material Output
    material_output = wood_brown_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node wood brown
    wood_brown_2 = wood_brown_1.nodes.new("ShaderNodeGroup")
    wood_brown_2.label = "wood brown"
    wood_brown_2.name = "wood brown"
    wood_brown_2.node_tree = wood_brown
    #Input_1
    wood_brown_2.inputs[0].default_value = 1.0
    #Input_2
    wood_brown_2.inputs[1].default_value = (0.15241800248622894, 0.05328400060534477, 0.022985000163316727, 1.0)
    #Input_3
    wood_brown_2.inputs[2].default_value = (0.006211999803781509, 0.0028719999827444553, 0.002005999907851219, 1.0)
    #Input_11
    wood_brown_2.inputs[3].default_value = 0.6000000238418579
    #Input_4
    wood_brown_2.inputs[4].default_value = 1.0
    #Input_10
    wood_brown_2.inputs[5].default_value = 1.9500000476837158
    #Input_5
    wood_brown_2.inputs[6].default_value = 6.900000095367432
    #Input_6
    wood_brown_2.inputs[7].default_value = 1.5
    #Input_14
    wood_brown_2.inputs[8].default_value = 0.7225000858306885
    #Input_13
    wood_brown_2.inputs[9].default_value = 0.47583335638046265
    #Input_7
    wood_brown_2.inputs[10].default_value = 5.0
    #Input_8
    wood_brown_2.inputs[11].default_value = 0.5
    #Input_9
    wood_brown_2.inputs[12].default_value = 0.20000000298023224
    #Input_12
    wood_brown_2.inputs[13].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (659.125, 80.874267578125)
    wood_brown_2.location = (352.77880859375, 80.87451171875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    wood_brown_2.width, wood_brown_2.height = 246.8038330078125, 100.0
    
    #initialize wood_brown_1 links
    #wood_brown_2.BSDF -> material_output.Surface
    wood_brown_1.links.new(wood_brown_2.outputs[0], material_output.inputs[0])
    return wood_brown_1

wood_brown_1 = wood_brown_1_node_group()

