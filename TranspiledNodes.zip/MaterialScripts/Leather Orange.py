import bpy, mathutils

mat = bpy.data.materials.new(name = "Leather Orange")
mat.use_nodes = True
#initialize Leather_orange node group
def leather_orange_node_group():

    leather_orange = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Leather_orange")
    
    #initialize leather_orange nodes
    #node Mix
    mix = leather_orange.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.10000000149011612
    
    #node Mix.002
    mix_002 = leather_orange.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.30000001192092896
    
    #node Bump.001
    bump_001 = leather_orange.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Bump
    bump = leather_orange.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Noise Texture.001
    noise_texture_001 = leather_orange.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 2.0
    #Detail
    noise_texture_001.inputs[3].default_value = 2.080000162124634
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.38458251953125
    #Distortion
    noise_texture_001.inputs[5].default_value = 2.999999761581421
    
    #node Principled BSDF
    principled_bsdf = leather_orange.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 1.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp
    colorramp = leather_orange.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 0.2824811637401581, 0.04521981626749039, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.11363702267408371)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 0.21614404022693634, 0.027088060975074768, 1.0)

    
    #node Vector Math.002
    vector_math_002 = leather_orange.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SCALE'
    
    #node Texture Coordinate.002
    texture_coordinate_002 = leather_orange.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_002.name = "Texture Coordinate.002"
    texture_coordinate_002.from_instancer = False
    
    #node Group Output
    group_output = leather_orange.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #leather_orange outputs
    #output BSDF
    leather_orange.outputs.new('NodeSocketShader', "BSDF")
    leather_orange.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    leather_orange.outputs.new('NodeSocketColor', "Albedo")
    leather_orange.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    leather_orange.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    leather_orange.outputs.new('NodeSocketColor', "Mask")
    leather_orange.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    leather_orange.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Noise Texture
    noise_texture = leather_orange.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 7.0
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5916666388511658
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Hue Saturation Value
    hue_saturation_value = leather_orange.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = leather_orange.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = leather_orange.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Voronoi Texture.001
    voronoi_texture_001 = leather_orange.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'EUCLIDEAN'
    voronoi_texture_001.feature = 'F1'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture_001.inputs[2].default_value = 300.0
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 1.0
    
    #node Math.001
    math_001 = leather_orange.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    
    #node Group Input
    group_input = leather_orange.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #leather_orange inputs
    #input Color Hue
    leather_orange.inputs.new('NodeSocketFloatFactor', "Color Hue")
    leather_orange.inputs[0].default_value = 1.0
    leather_orange.inputs[0].min_value = 0.0
    leather_orange.inputs[0].max_value = 1.0
    leather_orange.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    leather_orange.inputs.new('NodeSocketFloat', "Scale")
    leather_orange.inputs[1].default_value = 1.0
    leather_orange.inputs[1].min_value = -10000.0
    leather_orange.inputs[1].max_value = 10000.0
    leather_orange.inputs[1].attribute_domain = 'POINT'
    
    #input Specular
    leather_orange.inputs.new('NodeSocketFloatFactor', "Specular")
    leather_orange.inputs[2].default_value = 0.5
    leather_orange.inputs[2].min_value = 0.0
    leather_orange.inputs[2].max_value = 1.0
    leather_orange.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    leather_orange.inputs.new('NodeSocketFloatFactor', "Roughness")
    leather_orange.inputs[3].default_value = 0.5
    leather_orange.inputs[3].min_value = 0.0
    leather_orange.inputs[3].max_value = 1.0
    leather_orange.inputs[3].attribute_domain = 'POINT'
    
    #input Saturation
    leather_orange.inputs.new('NodeSocketFloat', "Saturation")
    leather_orange.inputs[4].default_value = 1.0
    leather_orange.inputs[4].min_value = 0.0
    leather_orange.inputs[4].max_value = 2.0
    leather_orange.inputs[4].attribute_domain = 'POINT'
    
    #input Brightness
    leather_orange.inputs.new('NodeSocketFloat', "Brightness")
    leather_orange.inputs[5].default_value = 1.0
    leather_orange.inputs[5].min_value = 0.0
    leather_orange.inputs[5].max_value = 2.0
    leather_orange.inputs[5].attribute_domain = 'POINT'
    
    #input Randomness
    leather_orange.inputs.new('NodeSocketFloatFactor', "Randomness")
    leather_orange.inputs[6].default_value = 1.0
    leather_orange.inputs[6].min_value = 0.0
    leather_orange.inputs[6].max_value = 1.0
    leather_orange.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    leather_orange.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    leather_orange.inputs[7].default_value = 1.0
    leather_orange.inputs[7].min_value = 0.0
    leather_orange.inputs[7].max_value = 1.0
    leather_orange.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    leather_orange.inputs.new('NodeSocketVector', "Normal")
    leather_orange.inputs[8].default_value = (0.0, 0.0, 0.0)
    leather_orange.inputs[8].min_value = -1.0
    leather_orange.inputs[8].max_value = 1.0
    leather_orange.inputs[8].attribute_domain = 'POINT'
    leather_orange.inputs[8].hide_value = True
    
    
    
    #node Mix.001
    mix_001 = leather_orange.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.699999988079071
    
    #node Voronoi Texture
    voronoi_texture = leather_orange.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 67.0
    
    #node ColorRamp.001
    colorramp_001 = leather_orange.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.19090908765792847
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.6454548835754395)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    
    #Set locations
    mix.location = (-273.8466796875, 189.99998474121094)
    mix_002.location = (-385.86669921875, -47.527252197265625)
    bump_001.location = (706.1533203125, -229.99998474121094)
    bump.location = (1014.13330078125, -110.00001525878906)
    noise_texture_001.location = (-633.8466796875, -250.00001525878906)
    principled_bsdf.location = (1253.84619140625, 250.00001525878906)
    colorramp.location = (426.1533203125, 230.00001525878906)
    vector_math_002.location = (-913.8466796875, 149.99998474121094)
    texture_coordinate_002.location = (-1253.8466796875, 69.99998474121094)
    group_output.location = (1543.84619140625, -0.0)
    noise_texture.location = (-633.8466796875, -30.000015258789062)
    hue_saturation_value.location = (815.95068359375, 279.8857421875)
    invert.location = (-300.0, 323.3990478515625)
    math.location = (142.4940185546875, 390.75653076171875)
    voronoi_texture_001.location = (-165.86669921875, 9.999984741210938)
    math_001.location = (279.9999694824219, -200.0)
    group_input.location = (-1453.8466796875, -0.0)
    mix_001.location = (628.4406127929688, 465.9349670410156)
    voronoi_texture.location = (146.1533203125, 230.00001525878906)
    colorramp_001.location = (54.1533203125, 39.1956787109375)
    
    #Set dimensions
    mix.width, mix.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    
    #initialize leather_orange links
    #principled_bsdf.BSDF -> group_output.BSDF
    leather_orange.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    leather_orange.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    leather_orange.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Distance -> colorramp.Fac
    leather_orange.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> bump.Height
    leather_orange.links.new(colorramp.outputs[0], bump.inputs[2])
    #mix.Result -> voronoi_texture.Vector
    leather_orange.links.new(mix.outputs[2], voronoi_texture.inputs[0])
    #noise_texture.Color -> mix.B
    leather_orange.links.new(noise_texture.outputs[1], mix.inputs[7])
    #mix_002.Result -> voronoi_texture_001.Vector
    leather_orange.links.new(mix_002.outputs[2], voronoi_texture_001.inputs[0])
    #voronoi_texture_001.Distance -> colorramp_001.Fac
    leather_orange.links.new(voronoi_texture_001.outputs[0], colorramp_001.inputs[0])
    #bump_001.Normal -> bump.Normal
    leather_orange.links.new(bump_001.outputs[0], bump.inputs[3])
    #colorramp_001.Color -> bump_001.Height
    leather_orange.links.new(colorramp_001.outputs[0], bump_001.inputs[2])
    #noise_texture_001.Color -> mix_002.B
    leather_orange.links.new(noise_texture_001.outputs[1], mix_002.inputs[7])
    #texture_coordinate_002.Object -> vector_math_002.Vector
    leather_orange.links.new(texture_coordinate_002.outputs[3], vector_math_002.inputs[0])
    #vector_math_002.Vector -> mix.A
    leather_orange.links.new(vector_math_002.outputs[0], mix.inputs[6])
    #vector_math_002.Vector -> mix_002.A
    leather_orange.links.new(vector_math_002.outputs[0], mix_002.inputs[6])
    #vector_math_002.Vector -> noise_texture.Vector
    leather_orange.links.new(vector_math_002.outputs[0], noise_texture.inputs[0])
    #vector_math_002.Vector -> noise_texture_001.Vector
    leather_orange.links.new(vector_math_002.outputs[0], noise_texture_001.inputs[0])
    #group_input.Scale -> vector_math_002.Scale
    leather_orange.links.new(group_input.outputs[1], vector_math_002.inputs[3])
    #colorramp.Color -> hue_saturation_value.Color
    leather_orange.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #group_input.Color Hue -> invert.Fac
    leather_orange.links.new(group_input.outputs[0], invert.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    leather_orange.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math.Value
    leather_orange.links.new(invert.outputs[0], math.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    leather_orange.links.new(group_input.outputs[4], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    leather_orange.links.new(group_input.outputs[5], hue_saturation_value.inputs[2])
    #group_input.Specular -> principled_bsdf.Specular
    leather_orange.links.new(group_input.outputs[2], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    leather_orange.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Randomness -> voronoi_texture.Randomness
    leather_orange.links.new(group_input.outputs[6], voronoi_texture.inputs[5])
    #math_001.Value -> bump_001.Strength
    leather_orange.links.new(math_001.outputs[0], bump_001.inputs[0])
    #group_input.Bump Strength -> bump.Strength
    leather_orange.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Bump Strength -> math_001.Value
    leather_orange.links.new(group_input.outputs[7], math_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    leather_orange.links.new(group_input.outputs[8], bump_001.inputs[3])
    #voronoi_texture.Distance -> mix_001.A
    leather_orange.links.new(voronoi_texture.outputs[0], mix_001.inputs[6])
    #colorramp_001.Color -> mix_001.B
    leather_orange.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #mix_001.Result -> group_output.Mask
    leather_orange.links.new(mix_001.outputs[2], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    leather_orange.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return leather_orange

leather_orange = leather_orange_node_group()

#initialize Leather Orange node group
def leather_orange_1_node_group():

    leather_orange_1 = mat.node_tree
    #start with a clean node tree
    for node in leather_orange_1.nodes:
        leather_orange_1.nodes.remove(node)
    #initialize leather_orange_1 nodes
    #node Material Output
    material_output = leather_orange_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Leather_orange
    leather_orange_2 = leather_orange_1.nodes.new("ShaderNodeGroup")
    leather_orange_2.label = "Leather_orange"
    leather_orange_2.name = "Leather_orange"
    leather_orange_2.node_tree = leather_orange
    #Input_2
    leather_orange_2.inputs[0].default_value = 0.0
    #Input_1
    leather_orange_2.inputs[1].default_value = 1.0
    #Input_5
    leather_orange_2.inputs[2].default_value = 0.5
    #Input_6
    leather_orange_2.inputs[3].default_value = 0.5
    #Input_3
    leather_orange_2.inputs[4].default_value = 1.0
    #Input_4
    leather_orange_2.inputs[5].default_value = 1.0
    #Input_7
    leather_orange_2.inputs[6].default_value = 0.36477985978126526
    #Input_8
    leather_orange_2.inputs[7].default_value = 0.20000000298023224
    #Input_9
    leather_orange_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (669.46533203125, 141.66796875)
    leather_orange_2.location = (421.98583984375, 141.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    leather_orange_2.width, leather_orange_2.height = 179.4990234375, 100.0
    
    #initialize leather_orange_1 links
    #leather_orange_2.BSDF -> material_output.Surface
    leather_orange_1.links.new(leather_orange_2.outputs[0], material_output.inputs[0])
    return leather_orange_1

leather_orange_1 = leather_orange_1_node_group()

