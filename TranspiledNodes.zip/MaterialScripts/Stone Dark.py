import bpy, mathutils

mat = bpy.data.materials.new(name = "Stone Dark")
mat.use_nodes = True
#initialize Stone dark node group
def stone_dark_node_group():

    stone_dark = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Stone dark")
    
    #initialize stone_dark nodes
    #node ColorRamp
    colorramp = stone_dark.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.3681817948818207
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = stone_dark.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.34545451402664185
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Vector Math
    vector_math = stone_dark.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = stone_dark.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = stone_dark.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #stone_dark outputs
    #output BSDF
    stone_dark.outputs.new('NodeSocketShader', "BSDF")
    stone_dark.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    stone_dark.outputs.new('NodeSocketColor', "Albedo")
    stone_dark.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    stone_dark.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    stone_dark.outputs.new('NodeSocketFloat', "Mask")
    stone_dark.outputs[2].default_value = 0.0
    stone_dark.outputs[2].min_value = -3.4028234663852886e+38
    stone_dark.outputs[2].max_value = 3.4028234663852886e+38
    stone_dark.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Mix
    mix = stone_dark.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Principled BSDF
    principled_bsdf = stone_dark.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = stone_dark.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #stone_dark inputs
    #input Scale
    stone_dark.inputs.new('NodeSocketFloat', "Scale")
    stone_dark.inputs[0].default_value = 1.0
    stone_dark.inputs[0].min_value = -10000.0
    stone_dark.inputs[0].max_value = 10000.0
    stone_dark.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    stone_dark.inputs.new('NodeSocketColor', "Color1")
    stone_dark.inputs[1].default_value = (0.007649629842489958, 0.007649629842489958, 0.007649629842489958, 1.0)
    stone_dark.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    stone_dark.inputs.new('NodeSocketColor', "Color2")
    stone_dark.inputs[2].default_value = (0.14379411935806274, 0.14379411935806274, 0.14379411935806274, 1.0)
    stone_dark.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    stone_dark.inputs.new('NodeSocketFloatFactor', "Specular")
    stone_dark.inputs[3].default_value = 0.5
    stone_dark.inputs[3].min_value = 0.0
    stone_dark.inputs[3].max_value = 1.0
    stone_dark.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    stone_dark.inputs.new('NodeSocketFloatFactor', "Roughness")
    stone_dark.inputs[4].default_value = 0.5
    stone_dark.inputs[4].min_value = 0.0
    stone_dark.inputs[4].max_value = 1.0
    stone_dark.inputs[4].attribute_domain = 'POINT'
    
    #input Detail
    stone_dark.inputs.new('NodeSocketFloat', "Detail")
    stone_dark.inputs[5].default_value = 10.0
    stone_dark.inputs[5].min_value = 0.0
    stone_dark.inputs[5].max_value = 15.0
    stone_dark.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    stone_dark.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    stone_dark.inputs[6].default_value = 0.10000000149011612
    stone_dark.inputs[6].min_value = 0.0
    stone_dark.inputs[6].max_value = 1.0
    stone_dark.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    stone_dark.inputs.new('NodeSocketVector', "Normal")
    stone_dark.inputs[7].default_value = (0.0, 0.0, 0.0)
    stone_dark.inputs[7].min_value = -1.0
    stone_dark.inputs[7].max_value = 1.0
    stone_dark.inputs[7].attribute_domain = 'POINT'
    stone_dark.inputs[7].hide_value = True
    
    
    
    #node Bump
    bump = stone_dark.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Noise Texture
    noise_texture = stone_dark.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 3.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.7166666984558105
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    
    #Set locations
    colorramp.location = (255.09857177734375, 170.2967529296875)
    colorramp_001.location = (182.71014404296875, -83.81204223632812)
    vector_math.location = (-394.70709228515625, 89.99996948242188)
    texture_coordinate_001.location = (-734.7070922851562, 10.0)
    group_output.location = (1024.70703125, -0.0)
    mix.location = (547.0113525390625, 186.28140258789062)
    principled_bsdf.location = (734.7070922851562, 230.0)
    group_input.location = (-934.7070922851562, -0.0)
    bump.location = (502.7100830078125, -230.0)
    noise_texture.location = (-56.8983154296875, 130.0)
    
    #Set dimensions
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize stone_dark links
    #principled_bsdf.BSDF -> group_output.BSDF
    stone_dark.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    stone_dark.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    stone_dark.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #colorramp_001.Color -> bump.Height
    stone_dark.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    stone_dark.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> colorramp_001.Fac
    stone_dark.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #texture_coordinate_001.Object -> vector_math.Vector
    stone_dark.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    stone_dark.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    stone_dark.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> mix.Factor
    stone_dark.links.new(colorramp.outputs[0], mix.inputs[0])
    #group_input.Color1 -> mix.A
    stone_dark.links.new(group_input.outputs[1], mix.inputs[6])
    #group_input.Color2 -> mix.B
    stone_dark.links.new(group_input.outputs[2], mix.inputs[7])
    #group_input.Specular -> principled_bsdf.Specular
    stone_dark.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    stone_dark.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Detail -> noise_texture.Detail
    stone_dark.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    stone_dark.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    stone_dark.links.new(group_input.outputs[7], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask
    stone_dark.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    stone_dark.links.new(mix.outputs[2], group_output.inputs[1])
    return stone_dark

stone_dark = stone_dark_node_group()

#initialize Stone Dark node group
def stone_dark_1_node_group():

    stone_dark_1 = mat.node_tree
    #start with a clean node tree
    for node in stone_dark_1.nodes:
        stone_dark_1.nodes.remove(node)
    #initialize stone_dark_1 nodes
    #node Material Output
    material_output = stone_dark_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Stone dark
    stone_dark_2 = stone_dark_1.nodes.new("ShaderNodeGroup")
    stone_dark_2.label = "Stone dark"
    stone_dark_2.name = "Stone dark"
    stone_dark_2.node_tree = stone_dark
    #Input_1
    stone_dark_2.inputs[0].default_value = 1.0
    #Input_2
    stone_dark_2.inputs[1].default_value = (0.007649629842489958, 0.007649629842489958, 0.007649629842489958, 1.0)
    #Input_3
    stone_dark_2.inputs[2].default_value = (0.14379411935806274, 0.14379411935806274, 0.14379411935806274, 1.0)
    #Input_4
    stone_dark_2.inputs[3].default_value = 0.5
    #Input_5
    stone_dark_2.inputs[4].default_value = 0.5
    #Input_6
    stone_dark_2.inputs[5].default_value = 10.0
    #Input_7
    stone_dark_2.inputs[6].default_value = 0.10000000149011612
    #Input_8
    stone_dark_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (695.037109375, 81.66796875)
    stone_dark_2.location = (447.439453125, 81.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    stone_dark_2.width, stone_dark_2.height = 185.99209594726562, 100.0
    
    #initialize stone_dark_1 links
    #stone_dark_2.BSDF -> material_output.Surface
    stone_dark_1.links.new(stone_dark_2.outputs[0], material_output.inputs[0])
    return stone_dark_1

stone_dark_1 = stone_dark_1_node_group()

