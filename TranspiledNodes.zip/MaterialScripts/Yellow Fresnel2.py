import bpy, mathutils

mat = bpy.data.materials.new(name = "Yellow Fresnel2")
mat.use_nodes = True
#initialize yellow_fresnel 2 node group
def yellow_fresnel_2_node_group():

    yellow_fresnel_2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "yellow_fresnel 2")
    
    #initialize yellow_fresnel_2 nodes
    #node Group Output
    group_output = yellow_fresnel_2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #yellow_fresnel_2 outputs
    #output BSDF
    yellow_fresnel_2.outputs.new('NodeSocketShader', "BSDF")
    yellow_fresnel_2.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    yellow_fresnel_2.outputs.new('NodeSocketFloat', "Mask")
    yellow_fresnel_2.outputs[1].default_value = 0.0
    yellow_fresnel_2.outputs[1].min_value = -3.4028234663852886e+38
    yellow_fresnel_2.outputs[1].max_value = 3.4028234663852886e+38
    yellow_fresnel_2.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = yellow_fresnel_2.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.20000000298023224
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate
    texture_coordinate = yellow_fresnel_2.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = yellow_fresnel_2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'LINEAR_LIGHT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = yellow_fresnel_2.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = yellow_fresnel_2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #yellow_fresnel_2 inputs
    #input Emission Color
    yellow_fresnel_2.inputs.new('NodeSocketColor', "Emission Color")
    yellow_fresnel_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    yellow_fresnel_2.inputs[0].attribute_domain = 'POINT'
    
    #input Emission Strength
    yellow_fresnel_2.inputs.new('NodeSocketFloat', "Emission Strength")
    yellow_fresnel_2.inputs[1].default_value = 4.0
    yellow_fresnel_2.inputs[1].min_value = 0.0
    yellow_fresnel_2.inputs[1].max_value = 1000000.0
    yellow_fresnel_2.inputs[1].attribute_domain = 'POINT'
    
    #input Base Color
    yellow_fresnel_2.inputs.new('NodeSocketColor', "Base Color")
    yellow_fresnel_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    yellow_fresnel_2.inputs[2].attribute_domain = 'POINT'
    
    #input Blend
    yellow_fresnel_2.inputs.new('NodeSocketFloat', "Blend")
    yellow_fresnel_2.inputs[3].default_value = 0.050000011920928955
    yellow_fresnel_2.inputs[3].min_value = 0.0
    yellow_fresnel_2.inputs[3].max_value = 1.0
    yellow_fresnel_2.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Amount
    yellow_fresnel_2.inputs.new('NodeSocketFloatFactor', "Noise Amount")
    yellow_fresnel_2.inputs[4].default_value = 0.0
    yellow_fresnel_2.inputs[4].min_value = 0.0
    yellow_fresnel_2.inputs[4].max_value = 1.0
    yellow_fresnel_2.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Scale
    yellow_fresnel_2.inputs.new('NodeSocketFloat', "Noise Scale")
    yellow_fresnel_2.inputs[5].default_value = 5.0
    yellow_fresnel_2.inputs[5].min_value = -1000.0
    yellow_fresnel_2.inputs[5].max_value = 1000.0
    yellow_fresnel_2.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Detail
    yellow_fresnel_2.inputs.new('NodeSocketFloat', "Noise Detail")
    yellow_fresnel_2.inputs[6].default_value = 2.0
    yellow_fresnel_2.inputs[6].min_value = 0.0
    yellow_fresnel_2.inputs[6].max_value = 15.0
    yellow_fresnel_2.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    yellow_fresnel_2.inputs.new('NodeSocketVector', "Normal")
    yellow_fresnel_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    yellow_fresnel_2.inputs[7].min_value = -3.4028234663852886e+38
    yellow_fresnel_2.inputs[7].max_value = 3.4028234663852886e+38
    yellow_fresnel_2.inputs[7].attribute_domain = 'POINT'
    yellow_fresnel_2.inputs[7].hide_value = True
    
    
    
    #node Layer Weight
    layer_weight = yellow_fresnel_2.nodes.new("ShaderNodeLayerWeight")
    layer_weight.name = "Layer Weight"
    
    
    #Set locations
    group_output.location = (500.00006103515625, -0.0)
    principled_bsdf.location = (210.00006103515625, 190.0)
    texture_coordinate.location = (-620.0, -220.0)
    mix.location = (-326.79571533203125, -193.56521606445312)
    noise_texture.location = (-620.0001220703125, -462.7740173339844)
    group_input.location = (-820.0, -120.0)
    layer_weight.location = (-140.0, -140.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    layer_weight.width, layer_weight.height = 140.0, 100.0
    
    #initialize yellow_fresnel_2 links
    #principled_bsdf.BSDF -> group_output.BSDF
    yellow_fresnel_2.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> layer_weight.Normal
    yellow_fresnel_2.links.new(mix.outputs[2], layer_weight.inputs[1])
    #texture_coordinate.Object -> mix.A
    yellow_fresnel_2.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture.Color -> mix.B
    yellow_fresnel_2.links.new(noise_texture.outputs[1], mix.inputs[7])
    #group_input.Base Color -> principled_bsdf.Base Color
    yellow_fresnel_2.links.new(group_input.outputs[2], principled_bsdf.inputs[0])
    #group_input.Blend -> layer_weight.Blend
    yellow_fresnel_2.links.new(group_input.outputs[3], layer_weight.inputs[0])
    #group_input.Emission Strength -> principled_bsdf.Emission Strength
    yellow_fresnel_2.links.new(group_input.outputs[1], principled_bsdf.inputs[20])
    #group_input.Noise Amount -> mix.Factor
    yellow_fresnel_2.links.new(group_input.outputs[4], mix.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    yellow_fresnel_2.links.new(group_input.outputs[5], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    yellow_fresnel_2.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Normal -> principled_bsdf.Normal
    yellow_fresnel_2.links.new(group_input.outputs[7], principled_bsdf.inputs[22])
    #group_input.Emission Color -> principled_bsdf.Emission
    yellow_fresnel_2.links.new(group_input.outputs[0], principled_bsdf.inputs[19])
    #layer_weight.Facing -> principled_bsdf.Alpha
    yellow_fresnel_2.links.new(layer_weight.outputs[1], principled_bsdf.inputs[21])
    #layer_weight.Facing -> group_output.Mask
    yellow_fresnel_2.links.new(layer_weight.outputs[1], group_output.inputs[1])
    return yellow_fresnel_2

yellow_fresnel_2 = yellow_fresnel_2_node_group()

#initialize Yellow Fresnel2 node group
def yellow_fresnel2_node_group():

    yellow_fresnel2 = mat.node_tree
    #start with a clean node tree
    for node in yellow_fresnel2.nodes:
        yellow_fresnel2.nodes.remove(node)
    #initialize yellow_fresnel2 nodes
    #node Material Output.001
    material_output_001 = yellow_fresnel2.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = True
    material_output_001.target = 'ALL'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node yellow_fresnel 2
    yellow_fresnel_2_1 = yellow_fresnel2.nodes.new("ShaderNodeGroup")
    yellow_fresnel_2_1.label = "yellow_fresnel 2"
    yellow_fresnel_2_1.name = "yellow_fresnel 2"
    yellow_fresnel_2_1.node_tree = yellow_fresnel_2
    #Input_1
    yellow_fresnel_2_1.inputs[0].default_value = (1.0, 0.4452008903026581, 0.0, 1.0)
    #Input_4
    yellow_fresnel_2_1.inputs[1].default_value = 4.0
    #Input_2
    yellow_fresnel_2_1.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_3
    yellow_fresnel_2_1.inputs[3].default_value = 0.03999999910593033
    #Input_5
    yellow_fresnel_2_1.inputs[4].default_value = 0.2550000250339508
    #Input_6
    yellow_fresnel_2_1.inputs[5].default_value = 5.0
    #Input_7
    yellow_fresnel_2_1.inputs[6].default_value = 2.0
    #Input_8
    yellow_fresnel_2_1.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output_001.location = (680.0, 100.0)
    yellow_fresnel_2_1.location = (380.000244140625, 100.0)
    
    #Set dimensions
    material_output_001.width, material_output_001.height = 140.0, 100.0
    yellow_fresnel_2_1.width, yellow_fresnel_2_1.height = 230.94464111328125, 100.0
    
    #initialize yellow_fresnel2 links
    #yellow_fresnel_2_1.BSDF -> material_output_001.Surface
    yellow_fresnel2.links.new(yellow_fresnel_2_1.outputs[0], material_output_001.inputs[0])
    return yellow_fresnel2

yellow_fresnel2 = yellow_fresnel2_node_group()

