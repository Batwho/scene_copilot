import bpy, mathutils

mat = bpy.data.materials.new(name = "Water Big")
mat.use_nodes = True
#initialize Water big node group
def water_big_node_group():

    water_big = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Water big")
    
    #initialize water_big nodes
    #node Principled BSDF
    principled_bsdf = water_big.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = water_big.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #water_big outputs
    #output BSDF
    water_big.outputs.new('NodeSocketShader', "BSDF")
    water_big.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    water_big.outputs.new('NodeSocketFloat', "Mask")
    water_big.outputs[1].default_value = 0.0
    water_big.outputs[1].min_value = -3.4028234663852886e+38
    water_big.outputs[1].max_value = 3.4028234663852886e+38
    water_big.outputs[1].attribute_domain = 'POINT'
    
    #output Normal
    water_big.outputs.new('NodeSocketVector', "Normal")
    water_big.outputs[2].default_value = (0.0, 0.0, 0.0)
    water_big.outputs[2].min_value = -3.4028234663852886e+38
    water_big.outputs[2].max_value = 3.4028234663852886e+38
    water_big.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Noise Texture
    noise_texture = water_big.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.5666666626930237
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Math
    math = water_big.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 21.0
    
    #node Group Input
    group_input = water_big.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #water_big inputs
    #input Color
    water_big.inputs.new('NodeSocketColor', "Color")
    water_big.inputs[0].default_value = (0.5593096017837524, 0.8119493722915649, 1.0, 1.0)
    water_big.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    water_big.inputs.new('NodeSocketFloat', "Scale")
    water_big.inputs[1].default_value = 0.5
    water_big.inputs[1].min_value = -10000.0
    water_big.inputs[1].max_value = 10000.0
    water_big.inputs[1].attribute_domain = 'POINT'
    
    #input Detail
    water_big.inputs.new('NodeSocketFloat', "Detail")
    water_big.inputs[2].default_value = 2.0
    water_big.inputs[2].min_value = 0.0
    water_big.inputs[2].max_value = 15.0
    water_big.inputs[2].attribute_domain = 'POINT'
    
    #input Inner Roughness
    water_big.inputs.new('NodeSocketFloatFactor', "Inner Roughness")
    water_big.inputs[3].default_value = 0.0
    water_big.inputs[3].min_value = 0.0
    water_big.inputs[3].max_value = 1.0
    water_big.inputs[3].attribute_domain = 'POINT'
    
    #input Outer Roughness
    water_big.inputs.new('NodeSocketFloatFactor', "Outer Roughness")
    water_big.inputs[4].default_value = 0.0
    water_big.inputs[4].min_value = 0.0
    water_big.inputs[4].max_value = 1.0
    water_big.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    water_big.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    water_big.inputs[5].default_value = 0.20000000298023224
    water_big.inputs[5].min_value = 0.0
    water_big.inputs[5].max_value = 1.0
    water_big.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    water_big.inputs.new('NodeSocketVector', "Normal")
    water_big.inputs[6].default_value = (0.0, 0.0, 0.0)
    water_big.inputs[6].min_value = -1.0
    water_big.inputs[6].max_value = 1.0
    water_big.inputs[6].attribute_domain = 'POINT'
    water_big.inputs[6].hide_value = True
    
    
    
    #node Bump
    bump = water_big.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    principled_bsdf.location = (560.0, 210.0)
    group_output.location = (850.0, -0.0)
    noise_texture.location = (0.0, -210.0)
    math.location = (-420.0, -29.999969482421875)
    group_input.location = (-600.0, -40.0)
    bump.location = (340.0, -209.75051879882812)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize water_big links
    #principled_bsdf.BSDF -> group_output.BSDF
    water_big.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    water_big.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    water_big.links.new(noise_texture.outputs[0], bump.inputs[2])
    #math.Value -> noise_texture.Scale
    water_big.links.new(math.outputs[0], noise_texture.inputs[2])
    #group_input.Scale -> math.Value
    water_big.links.new(group_input.outputs[1], math.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    water_big.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Inner Roughness -> principled_bsdf.Transmission Roughness
    water_big.links.new(group_input.outputs[3], principled_bsdf.inputs[18])
    #group_input.Outer Roughness -> principled_bsdf.Roughness
    water_big.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Color -> principled_bsdf.Base Color
    water_big.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Detail -> noise_texture.Detail
    water_big.links.new(group_input.outputs[2], noise_texture.inputs[3])
    #group_input.Normal -> bump.Normal
    water_big.links.new(group_input.outputs[6], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask
    water_big.links.new(noise_texture.outputs[0], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    water_big.links.new(bump.outputs[0], group_output.inputs[2])
    return water_big

water_big = water_big_node_group()

#initialize Water Big node group
def water_big_1_node_group():

    water_big_1 = mat.node_tree
    #start with a clean node tree
    for node in water_big_1.nodes:
        water_big_1.nodes.remove(node)
    #initialize water_big_1 nodes
    #node Material Output
    material_output = water_big_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Water big
    water_big_2 = water_big_1.nodes.new("ShaderNodeGroup")
    water_big_2.label = "Water big"
    water_big_2.name = "Water big"
    water_big_2.use_custom_color = True
    water_big_2.color = (0.08500330150127411, 0.20698420703411102, 0.24619480967521667)
    water_big_2.node_tree = water_big
    #Input_6
    water_big_2.inputs[0].default_value = (0.5593096017837524, 0.8119493722915649, 1.0, 1.0)
    #Input_1
    water_big_2.inputs[1].default_value = 1.0
    #Input_7
    water_big_2.inputs[2].default_value = 3.0
    #Input_4
    water_big_2.inputs[3].default_value = 0.0
    #Input_5
    water_big_2.inputs[4].default_value = 0.0
    #Input_3
    water_big_2.inputs[5].default_value = 0.20000000298023224
    #Input_8
    water_big_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (697.05078125, 44.433349609375)
    water_big_2.location = (438.5859375, 44.433349609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    water_big_2.width, water_big_2.height = 178.46453857421875, 100.0
    
    #initialize water_big_1 links
    #water_big_2.BSDF -> material_output.Surface
    water_big_1.links.new(water_big_2.outputs[0], material_output.inputs[0])
    return water_big_1

water_big_1 = water_big_1_node_group()

