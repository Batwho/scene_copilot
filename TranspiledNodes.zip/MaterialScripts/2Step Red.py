import bpy, mathutils

mat = bpy.data.materials.new(name = "2Step Red")
mat.use_nodes = True
#initialize 2step_red node group
def _2step_red_node_group():

    _2step_red = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "2step_red")
    
    #initialize _2step_red nodes
    #node Principled BSDF
    principled_bsdf = _2step_red.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Shader to RGB
    shader_to_rgb = _2step_red.nodes.new("ShaderNodeShaderToRGB")
    shader_to_rgb.name = "Shader to RGB"
    
    #node Group Output
    group_output = _2step_red.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #_2step_red outputs
    #output Color
    _2step_red.outputs.new('NodeSocketColor', "Color")
    _2step_red.outputs[0].default_value = (0.0, 0.0, 0.0, 0.0)
    _2step_red.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Mix
    mix = _2step_red.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.001
    mix_001 = _2step_red.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'COLOR'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node 2step_white
    _2step_white = _2step_red.nodes.new("ShaderNodeValToRGB")
    _2step_white.label = "2step_white"
    _2step_white.name = "2step_white"
    _2step_white.color_ramp.color_mode = 'RGB'
    _2step_white.color_ramp.hue_interpolation = 'NEAR'
    _2step_white.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    _2step_white.color_ramp.elements.remove(_2step_white.color_ramp.elements[0])
    _2step_white_cre_0 = _2step_white.color_ramp.elements[0]
    _2step_white_cre_0.position = 0.0
    _2step_white_cre_0.alpha = 1.0
    _2step_white_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    _2step_white_cre_1 = _2step_white.color_ramp.elements.new(0.004545455798506737)
    _2step_white_cre_1.alpha = 1.0
    _2step_white_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    _2step_white_cre_2 = _2step_white.color_ramp.elements.new(0.6318185329437256)
    _2step_white_cre_2.alpha = 1.0
    _2step_white_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    #Fac
    _2step_white.inputs[0].default_value = 0.5
    
    #node 2step_white.001
    _2step_white_001 = _2step_red.nodes.new("ShaderNodeValToRGB")
    _2step_white_001.label = "2step_white"
    _2step_white_001.name = "2step_white.001"
    _2step_white_001.color_ramp.color_mode = 'RGB'
    _2step_white_001.color_ramp.hue_interpolation = 'NEAR'
    _2step_white_001.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    _2step_white_001.color_ramp.elements.remove(_2step_white_001.color_ramp.elements[0])
    _2step_white_001_cre_0 = _2step_white_001.color_ramp.elements[0]
    _2step_white_001_cre_0.position = 0.0
    _2step_white_001_cre_0.alpha = 1.0
    _2step_white_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    _2step_white_001_cre_1 = _2step_white_001.color_ramp.elements.new(0.004545455798506737)
    _2step_white_001_cre_1.alpha = 1.0
    _2step_white_001_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    _2step_white_001_cre_2 = _2step_white_001.color_ramp.elements.new(0.6318185329437256)
    _2step_white_001_cre_2.alpha = 1.0
    _2step_white_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    #Fac
    _2step_white_001.inputs[0].default_value = 0.5
    
    #node ColorRamp
    colorramp = _2step_red.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.004545455798506737)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.6318185329437256)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node 2step_white.002
    _2step_white_002 = _2step_red.nodes.new("ShaderNodeValToRGB")
    _2step_white_002.label = "2step_white"
    _2step_white_002.name = "2step_white.002"
    _2step_white_002.color_ramp.color_mode = 'RGB'
    _2step_white_002.color_ramp.hue_interpolation = 'NEAR'
    _2step_white_002.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    _2step_white_002.color_ramp.elements.remove(_2step_white_002.color_ramp.elements[0])
    _2step_white_002_cre_0 = _2step_white_002.color_ramp.elements[0]
    _2step_white_002_cre_0.position = 0.0
    _2step_white_002_cre_0.alpha = 1.0
    _2step_white_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    _2step_white_002_cre_1 = _2step_white_002.color_ramp.elements.new(0.004545455798506737)
    _2step_white_002_cre_1.alpha = 1.0
    _2step_white_002_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    _2step_white_002_cre_2 = _2step_white_002.color_ramp.elements.new(0.6318185329437256)
    _2step_white_002_cre_2.alpha = 1.0
    _2step_white_002_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    #Fac
    _2step_white_002.inputs[0].default_value = 0.5
    
    #node Group Input
    group_input = _2step_red.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #_2step_red inputs
    #input Color
    _2step_red.inputs.new('NodeSocketColor', "Color")
    _2step_red.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    _2step_red.inputs[0].attribute_domain = 'POINT'
    
    #input Saturation
    _2step_red.inputs.new('NodeSocketFloatFactor', "Saturation")
    _2step_red.inputs[1].default_value = 1.0
    _2step_red.inputs[1].min_value = 0.0
    _2step_red.inputs[1].max_value = 1.0
    _2step_red.inputs[1].attribute_domain = 'POINT'
    
    #input Darkening
    _2step_red.inputs.new('NodeSocketFloatFactor', "Darkening")
    _2step_red.inputs[2].default_value = 1.0
    _2step_red.inputs[2].min_value = 0.0
    _2step_red.inputs[2].max_value = 1.0
    _2step_red.inputs[2].attribute_domain = 'POINT'
    
    #input Light Threshold
    _2step_red.inputs.new('NodeSocketFloat', "Light Threshold")
    _2step_red.inputs[3].default_value = 1.0
    _2step_red.inputs[3].min_value = 0.0
    _2step_red.inputs[3].max_value = 1000.0
    _2step_red.inputs[3].attribute_domain = 'POINT'
    
    #input Normal
    _2step_red.inputs.new('NodeSocketVector', "Normal")
    _2step_red.inputs[4].default_value = (0.0, 0.0, 0.0)
    _2step_red.inputs[4].min_value = -3.4028234663852886e+38
    _2step_red.inputs[4].max_value = 3.4028234663852886e+38
    _2step_red.inputs[4].attribute_domain = 'POINT'
    _2step_red.inputs[4].hide_value = True
    
    
    
    
    #Set locations
    principled_bsdf.location = (-535.0, -33.58367919921875)
    shader_to_rgb.location = (-225.0, -18.372955322265625)
    group_output.location = (725.0, -0.0)
    mix.location = (535.0, 33.583648681640625)
    mix_001.location = (322.0633544921875, -90.370361328125)
    _2step_white.location = (3270.0, 385.7627258300781)
    _2step_white_001.location = (3270.0, 385.7627258300781)
    colorramp.location = (-40.0, -80.0)
    _2step_white_002.location = (3270.0, 385.7626953125)
    group_input.location = (-980.0, 0.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    _2step_white.width, _2step_white.height = 240.0, 100.0
    _2step_white_001.width, _2step_white_001.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    _2step_white_002.width, _2step_white_002.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize _2step_red links
    #mix.Result -> group_output.Color
    _2step_red.links.new(mix.outputs[2], group_output.inputs[0])
    #principled_bsdf.BSDF -> shader_to_rgb.Shader
    _2step_red.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
    #shader_to_rgb.Color -> colorramp.Fac
    _2step_red.links.new(shader_to_rgb.outputs[0], colorramp.inputs[0])
    #mix_001.Result -> mix.A
    _2step_red.links.new(mix_001.outputs[2], mix.inputs[6])
    #group_input.Darkening -> mix.Factor
    _2step_red.links.new(group_input.outputs[2], mix.inputs[0])
    #colorramp.Color -> mix_001.A
    _2step_red.links.new(colorramp.outputs[0], mix_001.inputs[6])
    #group_input.Color -> mix_001.B
    _2step_red.links.new(group_input.outputs[0], mix_001.inputs[7])
    #group_input.Saturation -> mix_001.Factor
    _2step_red.links.new(group_input.outputs[1], mix_001.inputs[0])
    #group_input.Light Threshold -> principled_bsdf.Base Color
    _2step_red.links.new(group_input.outputs[3], principled_bsdf.inputs[0])
    #group_input.Normal -> principled_bsdf.Normal
    _2step_red.links.new(group_input.outputs[4], principled_bsdf.inputs[22])
    #group_input.Light Threshold -> principled_bsdf.Specular
    _2step_red.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    return _2step_red

_2step_red = _2step_red_node_group()

#initialize 2Step Red node group
def _2step_red_1_node_group():

    _2step_red_1 = mat.node_tree
    #start with a clean node tree
    for node in _2step_red_1.nodes:
        _2step_red_1.nodes.remove(node)
    #initialize _2step_red_1 nodes
    #node Material Output
    material_output = _2step_red_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node 2step_red
    _2step_red_2 = _2step_red_1.nodes.new("ShaderNodeGroup")
    _2step_red_2.label = "2step_red"
    _2step_red_2.name = "2step_red"
    _2step_red_2.node_tree = _2step_red
    #Input_2
    _2step_red_2.inputs[0].default_value = (1.0, 0.12763148546218872, 0.08328443020582199, 1.0)
    #Input_3
    _2step_red_2.inputs[1].default_value = 1.0
    #Input_1
    _2step_red_2.inputs[2].default_value = 0.0
    #Input_4
    _2step_red_2.inputs[3].default_value = 1.0
    #Input_5
    _2step_red_2.inputs[4].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (662.0546875, 91.27099609375)
    _2step_red_2.location = (412.4765625, 91.27099609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    _2step_red_2.width, _2step_red_2.height = 181.463134765625, 100.0
    
    #initialize _2step_red_1 links
    #_2step_red_2.Color -> material_output.Surface
    _2step_red_1.links.new(_2step_red_2.outputs[0], material_output.inputs[0])
    return _2step_red_1

_2step_red_1 = _2step_red_1_node_group()

