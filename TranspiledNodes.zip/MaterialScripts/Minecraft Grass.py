import bpy, mathutils

mat = bpy.data.materials.new(name = "Minecraft Grass")
mat.use_nodes = True
#initialize Minecraft grass node group
def minecraft_grass_node_group():

    minecraft_grass = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Minecraft grass")
    
    #initialize minecraft_grass nodes
    #node Mapping
    mapping = minecraft_grass.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 1.5707963705062866, 0.0)
    #Scale
    mapping.inputs[3].default_value = (1.0, 1.0, 1.0)
    
    #node Gradient Texture
    gradient_texture = minecraft_grass.nodes.new("ShaderNodeTexGradient")
    gradient_texture.name = "Gradient Texture"
    gradient_texture.gradient_type = 'LINEAR'
    
    #node Texture Coordinate
    texture_coordinate = minecraft_grass.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Principled BSDF
    principled_bsdf = minecraft_grass.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Vector Math.003
    vector_math_003 = minecraft_grass.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'SCALE'
    
    #node ColorRamp
    colorramp = minecraft_grass.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.15454541146755219
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.02175462618470192, 0.16406069695949554, 0.008013102225959301, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.18735867738723755, 0.44580891728401184, 0.033361975103616714, 1.0)

    
    #node Vector Math.002
    vector_math_002 = minecraft_grass.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SNAP'
    #Vector_001
    vector_math_002.inputs[1].default_value = (0.10000000149011612, 0.10000000149011612, 0.10000000149011612)
    
    #node Noise Texture.001
    noise_texture_001 = minecraft_grass.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 2.270000457763672
    #Detail
    noise_texture_001.inputs[3].default_value = 0.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.0
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node ColorRamp.003
    colorramp_003 = minecraft_grass.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.586363673210144
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(1.0)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (0.469220370054245, 0.469220370054245, 0.469220370054245, 1.0)

    
    #node Mix Shader
    mix_shader = minecraft_grass.nodes.new("ShaderNodeMixShader")
    mix_shader.name = "Mix Shader"
    
    #node Group Output
    group_output = minecraft_grass.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #minecraft_grass outputs
    #output Shader
    minecraft_grass.outputs.new('NodeSocketShader', "Shader")
    minecraft_grass.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    minecraft_grass.outputs.new('NodeSocketColor', "Albedo")
    minecraft_grass.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    minecraft_grass.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    minecraft_grass.outputs.new('NodeSocketFloat', "Mask")
    minecraft_grass.outputs[2].default_value = 0.0
    minecraft_grass.outputs[2].min_value = -3.4028234663852886e+38
    minecraft_grass.outputs[2].max_value = 3.4028234663852886e+38
    minecraft_grass.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    minecraft_grass.outputs.new('NodeSocketVector', "Normal")
    minecraft_grass.outputs[3].default_value = (0.0, 0.0, 0.0)
    minecraft_grass.outputs[3].min_value = 0.0
    minecraft_grass.outputs[3].max_value = 0.0
    minecraft_grass.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node ColorRamp.002
    colorramp_002 = minecraft_grass.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (0.5516237020492554, 0.5516237020492554, 0.5516237020492554, 1.0)

    
    #node Noise Texture
    noise_texture = minecraft_grass.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 2.4000003337860107
    #Detail
    noise_texture.inputs[3].default_value = 0.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.0
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Hue Saturation Value
    hue_saturation_value = minecraft_grass.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node ColorRamp.001
    colorramp_001 = minecraft_grass.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.040678709745407104, 0.026127921417355537, 0.01455450989305973, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.25217872858047485, 0.11257505416870117, 0.053297221660614014, 1.0)

    
    #node Mix.001
    mix_001 = minecraft_grass.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Math.002
    math_002 = minecraft_grass.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.5
    
    #node Invert.001
    invert_001 = minecraft_grass.nodes.new("ShaderNodeInvert")
    invert_001.name = "Invert.001"
    #Color
    invert_001.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Hue Saturation Value.001
    hue_saturation_value_001 = minecraft_grass.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value_001.name = "Hue Saturation Value.001"
    #Saturation
    hue_saturation_value_001.inputs[1].default_value = 1.0
    #Value
    hue_saturation_value_001.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value_001.inputs[3].default_value = 1.0
    
    #node Math.003
    math_003 = minecraft_grass.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'ADD'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 0.5
    
    #node Math.001
    math_001 = minecraft_grass.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'GREATER_THAN'
    math_001.use_clamp = False
    
    #node Mix
    mix = minecraft_grass.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'BURN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Invert
    invert = minecraft_grass.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Invert.002
    invert_002 = minecraft_grass.nodes.new("ShaderNodeInvert")
    invert_002.name = "Invert.002"
    #Color
    invert_002.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Input
    group_input = minecraft_grass.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #minecraft_grass inputs
    #input Scale
    minecraft_grass.inputs.new('NodeSocketFloat', "Scale")
    minecraft_grass.inputs[0].default_value = 1.0
    minecraft_grass.inputs[0].min_value = -10000.0
    minecraft_grass.inputs[0].max_value = 10000.0
    minecraft_grass.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue Grass
    minecraft_grass.inputs.new('NodeSocketFloatFactor', "Color Hue Grass")
    minecraft_grass.inputs[1].default_value = 1.0
    minecraft_grass.inputs[1].min_value = 0.0
    minecraft_grass.inputs[1].max_value = 1.0
    minecraft_grass.inputs[1].attribute_domain = 'POINT'
    
    #input Color Hue Dirt
    minecraft_grass.inputs.new('NodeSocketFloatFactor', "Color Hue Dirt")
    minecraft_grass.inputs[2].default_value = 1.0
    minecraft_grass.inputs[2].min_value = 0.0
    minecraft_grass.inputs[2].max_value = 1.0
    minecraft_grass.inputs[2].attribute_domain = 'POINT'
    
    #input Gras Saturation
    minecraft_grass.inputs.new('NodeSocketFloatFactor', "Gras Saturation")
    minecraft_grass.inputs[3].default_value = 1.0
    minecraft_grass.inputs[3].min_value = 0.0
    minecraft_grass.inputs[3].max_value = 1.0
    minecraft_grass.inputs[3].attribute_domain = 'POINT'
    
    #input Specular
    minecraft_grass.inputs.new('NodeSocketFloatFactor', "Specular")
    minecraft_grass.inputs[4].default_value = 0.20000000298023224
    minecraft_grass.inputs[4].min_value = 0.0
    minecraft_grass.inputs[4].max_value = 1.0
    minecraft_grass.inputs[4].attribute_domain = 'POINT'
    
    #input Stone Mask
    minecraft_grass.inputs.new('NodeSocketFloat', "Stone Mask")
    minecraft_grass.inputs[5].default_value = 0.7099999785423279
    minecraft_grass.inputs[5].min_value = -10000.0
    minecraft_grass.inputs[5].max_value = 10000.0
    minecraft_grass.inputs[5].attribute_domain = 'POINT'
    
    #input Gras/Sirt Mask Noise
    minecraft_grass.inputs.new('NodeSocketFloatFactor', "Gras/Sirt Mask Noise")
    minecraft_grass.inputs[6].default_value = 0.8416666984558105
    minecraft_grass.inputs[6].min_value = 0.0
    minecraft_grass.inputs[6].max_value = 1.0
    minecraft_grass.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    minecraft_grass.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    minecraft_grass.inputs[7].default_value = 0.20000000298023224
    minecraft_grass.inputs[7].min_value = 0.0
    minecraft_grass.inputs[7].max_value = 1.0
    minecraft_grass.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    minecraft_grass.inputs.new('NodeSocketVector', "Normal")
    minecraft_grass.inputs[8].default_value = (0.0, 0.0, 0.0)
    minecraft_grass.inputs[8].min_value = -1.0
    minecraft_grass.inputs[8].max_value = 1.0
    minecraft_grass.inputs[8].attribute_domain = 'POINT'
    minecraft_grass.inputs[8].hide_value = True
    
    
    
    #node Principled BSDF.001
    principled_bsdf_001 = minecraft_grass.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf_001.name = "Principled BSDF.001"
    principled_bsdf_001.distribution = 'GGX'
    principled_bsdf_001.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf_001.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf_001.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf_001.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf_001.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf_001.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf_001.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf_001.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf_001.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf_001.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf_001.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf_001.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf_001.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf_001.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf_001.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf_001.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf_001.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf_001.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf_001.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf_001.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf_001.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf_001.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Reroute
    reroute = minecraft_grass.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Math
    math = minecraft_grass.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'GREATER_THAN'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.0
    
    #node Mix.002
    mix_002 = minecraft_grass.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node White Noise Texture
    white_noise_texture = minecraft_grass.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture.name = "White Noise Texture"
    white_noise_texture.noise_dimensions = '3D'
    
    #node Bump
    bump = minecraft_grass.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    mapping.location = (-766.6976318359375, 422.10589599609375)
    gradient_texture.location = (-546.697265625, 270.5093994140625)
    texture_coordinate.location = (-1186.697265625, 90.50942993164062)
    principled_bsdf.location = (393.302734375, -87.954833984375)
    vector_math_003.location = (-1006.697265625, 70.50942993164062)
    colorramp.location = (53.302734375, -69.4906005859375)
    vector_math_002.location = (-766.6972045898438, 30.509429931640625)
    noise_texture_001.location = (-566.697265625, -109.4906005859375)
    colorramp_003.location = (-326.697265625, -209.4906005859375)
    mix_shader.location = (1186.697265625, 10.509429931640625)
    group_output.location = (1376.697265625, -0.0)
    colorramp_002.location = (80.0, -500.0)
    noise_texture.location = (193.3031005859375, 529.4906005859375)
    hue_saturation_value.location = (300.0, 80.0)
    colorramp_001.location = (-620.0, -580.0)
    mix_001.location = (-80.0, -600.0)
    math_002.location = (-333.88397216796875, 422.28076171875)
    invert_001.location = (-1120.0, -360.0)
    hue_saturation_value_001.location = (-313.03070068359375, -637.8861083984375)
    math_003.location = (-900.0, -320.0)
    math_001.location = (-333.697265625, -375.71697998046875)
    mix.location = (-97.881103515625, 293.1536865234375)
    invert.location = (-540.0, 380.0)
    invert_002.location = (-1020.0, 280.0)
    group_input.location = (-1386.697265625, -0.0)
    principled_bsdf_001.location = (760.0, -240.0)
    reroute.location = (681.8241577148438, -363.1779479980469)
    math.location = (214.154541015625, 283.96246337890625)
    mix_002.location = (960.0, 200.0)
    white_noise_texture.location = (-246.697265625, 70.5093994140625)
    bump.location = (73.302734375, -309.4906005859375)
    
    #Set dimensions
    mapping.width, mapping.height = 140.0, 100.0
    gradient_texture.width, gradient_texture.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    vector_math_003.width, vector_math_003.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    mix_shader.width, mix_shader.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    invert_001.width, invert_001.height = 140.0, 100.0
    hue_saturation_value_001.width, hue_saturation_value_001.height = 150.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    invert_002.width, invert_002.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf_001.width, principled_bsdf_001.height = 240.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    math.width, math.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    white_noise_texture.width, white_noise_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize minecraft_grass links
    #mix_shader.Shader -> group_output.Shader
    minecraft_grass.links.new(mix_shader.outputs[0], group_output.inputs[0])
    #vector_math_002.Vector -> white_noise_texture.Vector
    minecraft_grass.links.new(vector_math_002.outputs[0], white_noise_texture.inputs[0])
    #vector_math_003.Vector -> vector_math_002.Vector
    minecraft_grass.links.new(vector_math_003.outputs[0], vector_math_002.inputs[0])
    #mapping.Vector -> gradient_texture.Vector
    minecraft_grass.links.new(mapping.outputs[0], gradient_texture.inputs[0])
    #gradient_texture.Color -> mix.A
    minecraft_grass.links.new(gradient_texture.outputs[0], mix.inputs[6])
    #noise_texture.Fac -> mix.B
    minecraft_grass.links.new(noise_texture.outputs[0], mix.inputs[7])
    #vector_math_002.Vector -> mapping.Vector
    minecraft_grass.links.new(vector_math_002.outputs[0], mapping.inputs[0])
    #mix.Result -> math.Value
    minecraft_grass.links.new(mix.outputs[2], math.inputs[0])
    #principled_bsdf.BSDF -> mix_shader.Shader
    minecraft_grass.links.new(principled_bsdf.outputs[0], mix_shader.inputs[2])
    #math.Value -> mix_shader.Fac
    minecraft_grass.links.new(math.outputs[0], mix_shader.inputs[0])
    #white_noise_texture.Value -> colorramp.Fac
    minecraft_grass.links.new(white_noise_texture.outputs[0], colorramp.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    minecraft_grass.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #vector_math_002.Vector -> noise_texture.Vector
    minecraft_grass.links.new(vector_math_002.outputs[0], noise_texture.inputs[0])
    #texture_coordinate.Object -> vector_math_003.Vector
    minecraft_grass.links.new(texture_coordinate.outputs[3], vector_math_003.inputs[0])
    #white_noise_texture.Color -> bump.Height
    minecraft_grass.links.new(white_noise_texture.outputs[1], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    minecraft_grass.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #principled_bsdf_001.BSDF -> mix_shader.Shader
    minecraft_grass.links.new(principled_bsdf_001.outputs[0], mix_shader.inputs[1])
    #white_noise_texture.Value -> colorramp_001.Fac
    minecraft_grass.links.new(white_noise_texture.outputs[0], colorramp_001.inputs[0])
    #reroute.Output -> principled_bsdf_001.Base Color
    minecraft_grass.links.new(reroute.outputs[0], principled_bsdf_001.inputs[0])
    #bump.Normal -> principled_bsdf_001.Normal
    minecraft_grass.links.new(bump.outputs[0], principled_bsdf_001.inputs[22])
    #white_noise_texture.Value -> colorramp_002.Fac
    minecraft_grass.links.new(white_noise_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> principled_bsdf_001.Roughness
    minecraft_grass.links.new(colorramp_002.outputs[0], principled_bsdf_001.inputs[9])
    #colorramp_002.Color -> principled_bsdf.Roughness
    minecraft_grass.links.new(colorramp_002.outputs[0], principled_bsdf.inputs[9])
    #vector_math_002.Vector -> noise_texture_001.Vector
    minecraft_grass.links.new(vector_math_002.outputs[0], noise_texture_001.inputs[0])
    #colorramp_003.Color -> mix_001.B
    minecraft_grass.links.new(colorramp_003.outputs[0], mix_001.inputs[7])
    #math_001.Value -> mix_001.Factor
    minecraft_grass.links.new(math_001.outputs[0], mix_001.inputs[0])
    #noise_texture_001.Fac -> math_001.Value
    minecraft_grass.links.new(noise_texture_001.outputs[0], math_001.inputs[0])
    #noise_texture_001.Fac -> colorramp_003.Fac
    minecraft_grass.links.new(noise_texture_001.outputs[0], colorramp_003.inputs[0])
    #group_input.Scale -> vector_math_003.Scale
    minecraft_grass.links.new(group_input.outputs[0], vector_math_003.inputs[3])
    #colorramp.Color -> hue_saturation_value.Color
    minecraft_grass.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #group_input.Color Hue Grass -> invert.Fac
    minecraft_grass.links.new(group_input.outputs[1], invert.inputs[0])
    #math_002.Value -> hue_saturation_value.Hue
    minecraft_grass.links.new(math_002.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math_002.Value
    minecraft_grass.links.new(invert.outputs[0], math_002.inputs[0])
    #hue_saturation_value_001.Color -> mix_001.A
    minecraft_grass.links.new(hue_saturation_value_001.outputs[0], mix_001.inputs[6])
    #colorramp_001.Color -> hue_saturation_value_001.Color
    minecraft_grass.links.new(colorramp_001.outputs[0], hue_saturation_value_001.inputs[4])
    #invert_001.Color -> math_003.Value
    minecraft_grass.links.new(invert_001.outputs[0], math_003.inputs[0])
    #group_input.Color Hue Dirt -> invert_001.Fac
    minecraft_grass.links.new(group_input.outputs[2], invert_001.inputs[0])
    #math_003.Value -> hue_saturation_value_001.Hue
    minecraft_grass.links.new(math_003.outputs[0], hue_saturation_value_001.inputs[0])
    #group_input.Stone Mask -> math_001.Value
    minecraft_grass.links.new(group_input.outputs[5], math_001.inputs[1])
    #group_input.Gras/Sirt Mask Noise -> mix.Factor
    minecraft_grass.links.new(group_input.outputs[6], mix.inputs[0])
    #invert_002.Color -> hue_saturation_value.Saturation
    minecraft_grass.links.new(invert_002.outputs[0], hue_saturation_value.inputs[1])
    #group_input.Gras Saturation -> invert_002.Fac
    minecraft_grass.links.new(group_input.outputs[3], invert_002.inputs[0])
    #group_input.Specular -> principled_bsdf.Specular
    minecraft_grass.links.new(group_input.outputs[4], principled_bsdf.inputs[7])
    #group_input.Specular -> principled_bsdf_001.Specular
    minecraft_grass.links.new(group_input.outputs[4], principled_bsdf_001.inputs[7])
    #group_input.Bump Strength -> bump.Strength
    minecraft_grass.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    minecraft_grass.links.new(group_input.outputs[8], bump.inputs[3])
    #mix_001.Result -> reroute.Input
    minecraft_grass.links.new(mix_001.outputs[2], reroute.inputs[0])
    #reroute.Output -> mix_002.A
    minecraft_grass.links.new(reroute.outputs[0], mix_002.inputs[6])
    #math.Value -> mix_002.Factor
    minecraft_grass.links.new(math.outputs[0], mix_002.inputs[0])
    #hue_saturation_value.Color -> mix_002.B
    minecraft_grass.links.new(hue_saturation_value.outputs[0], mix_002.inputs[7])
    #mix_002.Result -> group_output.Albedo
    minecraft_grass.links.new(mix_002.outputs[2], group_output.inputs[1])
    #white_noise_texture.Value -> group_output.Mask
    minecraft_grass.links.new(white_noise_texture.outputs[0], group_output.inputs[2])
    #bump.Normal -> group_output.Normal
    minecraft_grass.links.new(bump.outputs[0], group_output.inputs[3])
    return minecraft_grass

minecraft_grass = minecraft_grass_node_group()

#initialize Minecraft Grass node group
def minecraft_grass_1_node_group():

    minecraft_grass_1 = mat.node_tree
    #start with a clean node tree
    for node in minecraft_grass_1.nodes:
        minecraft_grass_1.nodes.remove(node)
    #initialize minecraft_grass_1 nodes
    #node Material Output
    material_output = minecraft_grass_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Minecraft grass
    minecraft_grass_2 = minecraft_grass_1.nodes.new("ShaderNodeGroup")
    minecraft_grass_2.label = "Minecraft grass"
    minecraft_grass_2.name = "Minecraft grass"
    minecraft_grass_2.node_tree = minecraft_grass
    #Input_1
    minecraft_grass_2.inputs[0].default_value = 1.0
    #Input_3
    minecraft_grass_2.inputs[1].default_value = 1.0
    #Input_4
    minecraft_grass_2.inputs[2].default_value = 1.0
    #Input_7
    minecraft_grass_2.inputs[3].default_value = 1.0
    #Input_8
    minecraft_grass_2.inputs[4].default_value = 0.20000000298023224
    #Input_5
    minecraft_grass_2.inputs[5].default_value = 0.7099999785423279
    #Input_6
    minecraft_grass_2.inputs[6].default_value = 0.8416666984558105
    #Input_9
    minecraft_grass_2.inputs[7].default_value = 0.20000000298023224
    #Input_10
    minecraft_grass_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (747.2008056640625, 95.37793731689453)
    minecraft_grass_2.location = (437.9549255371094, 120.0018081665039)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    minecraft_grass_2.width, minecraft_grass_2.height = 214.534912109375, 100.0
    
    #initialize minecraft_grass_1 links
    #minecraft_grass_2.Shader -> material_output.Surface
    minecraft_grass_1.links.new(minecraft_grass_2.outputs[0], material_output.inputs[0])
    return minecraft_grass_1

minecraft_grass_1 = minecraft_grass_1_node_group()

