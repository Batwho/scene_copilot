import bpy, mathutils

mat = bpy.data.materials.new(name = "Gold Textured")
mat.use_nodes = True
#initialize Gold_little_imperf. node group
def gold_little_imperf__node_group():

    gold_little_imperf_ = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Gold_little_imperf.")
    
    #initialize gold_little_imperf_ nodes
    #node Group Output
    group_output = gold_little_imperf_.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #gold_little_imperf_ outputs
    #output BSDF
    gold_little_imperf_.outputs.new('NodeSocketShader', "BSDF")
    gold_little_imperf_.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    gold_little_imperf_.outputs.new('NodeSocketFloat', "Mask")
    gold_little_imperf_.outputs[1].default_value = 0.0
    gold_little_imperf_.outputs[1].min_value = -3.4028234663852886e+38
    gold_little_imperf_.outputs[1].max_value = 3.4028234663852886e+38
    gold_little_imperf_.outputs[1].attribute_domain = 'POINT'
    
    
    
    #node Texture Coordinate.001
    texture_coordinate_001 = gold_little_imperf_.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node ColorRamp
    colorramp = gold_little_imperf_.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.32272735238075256
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.010435192845761776, 0.010435192845761776, 0.010435192845761776, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.8318183422088623)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.5349621176719666, 0.5349621176719666, 0.5349621176719666, 1.0)

    
    #node Vector Math
    vector_math = gold_little_imperf_.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Math
    math = gold_little_imperf_.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = True
    #Value_002
    math.inputs[2].default_value = -0.4899999499320984
    
    #node Noise Texture
    noise_texture = gold_little_imperf_.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 5.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    
    #node Group Input
    group_input = gold_little_imperf_.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #gold_little_imperf_ inputs
    #input Scale
    gold_little_imperf_.inputs.new('NodeSocketFloat', "Scale")
    gold_little_imperf_.inputs[0].default_value = 1.0
    gold_little_imperf_.inputs[0].min_value = -10000.0
    gold_little_imperf_.inputs[0].max_value = 10000.0
    gold_little_imperf_.inputs[0].attribute_domain = 'POINT'
    
    #input Base Color
    gold_little_imperf_.inputs.new('NodeSocketColor', "Base Color")
    gold_little_imperf_.inputs[1].default_value = (1.0, 0.5040153861045837, 0.16143031418323517, 1.0)
    gold_little_imperf_.inputs[1].attribute_domain = 'POINT'
    
    #input Anisotropic
    gold_little_imperf_.inputs.new('NodeSocketFloatFactor', "Anisotropic")
    gold_little_imperf_.inputs[2].default_value = 0.0
    gold_little_imperf_.inputs[2].min_value = 0.0
    gold_little_imperf_.inputs[2].max_value = 1.0
    gold_little_imperf_.inputs[2].attribute_domain = 'POINT'
    
    #input Mix Roughness
    gold_little_imperf_.inputs.new('NodeSocketFloat', "Mix Roughness")
    gold_little_imperf_.inputs[3].default_value = -0.28999996185302734
    gold_little_imperf_.inputs[3].min_value = -10000.0
    gold_little_imperf_.inputs[3].max_value = 10000.0
    gold_little_imperf_.inputs[3].attribute_domain = 'POINT'
    
    #input Detail
    gold_little_imperf_.inputs.new('NodeSocketFloat', "Detail")
    gold_little_imperf_.inputs[4].default_value = 8.0
    gold_little_imperf_.inputs[4].min_value = 0.0
    gold_little_imperf_.inputs[4].max_value = 15.0
    gold_little_imperf_.inputs[4].attribute_domain = 'POINT'
    
    #input Distortion
    gold_little_imperf_.inputs.new('NodeSocketFloat', "Distortion")
    gold_little_imperf_.inputs[5].default_value = 0.0
    gold_little_imperf_.inputs[5].min_value = -1000.0
    gold_little_imperf_.inputs[5].max_value = 1000.0
    gold_little_imperf_.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    gold_little_imperf_.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    gold_little_imperf_.inputs[6].default_value = 0.009999999776482582
    gold_little_imperf_.inputs[6].min_value = 0.0
    gold_little_imperf_.inputs[6].max_value = 1.0
    gold_little_imperf_.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    gold_little_imperf_.inputs.new('NodeSocketVector', "Normal")
    gold_little_imperf_.inputs[7].default_value = (0.0, 0.0, 0.0)
    gold_little_imperf_.inputs[7].min_value = -1.0
    gold_little_imperf_.inputs[7].max_value = 1.0
    gold_little_imperf_.inputs[7].attribute_domain = 'POINT'
    gold_little_imperf_.inputs[7].hide_value = True
    
    
    
    #node Principled BSDF
    principled_bsdf = gold_little_imperf_.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Bump
    bump = gold_little_imperf_.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    group_output.location = (828.5, -0.0)
    texture_coordinate_001.location = (-720.0, -20.0)
    colorramp.location = (40.0, 40.0)
    vector_math.location = (-380.0, 60.00006103515625)
    math.location = (300.01629638671875, 99.09481811523438)
    noise_texture.location = (-180.0, 0.0)
    group_input.location = (-920.0, 0.0)
    principled_bsdf.location = (538.5, 260.0)
    bump.location = (120.0, -259.9999694824219)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize gold_little_imperf_ links
    #principled_bsdf.BSDF -> group_output.BSDF
    gold_little_imperf_.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #math.Value -> principled_bsdf.Roughness
    gold_little_imperf_.links.new(math.outputs[0], principled_bsdf.inputs[9])
    #noise_texture.Fac -> colorramp.Fac
    gold_little_imperf_.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    gold_little_imperf_.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    gold_little_imperf_.links.new(noise_texture.outputs[0], bump.inputs[2])
    #texture_coordinate_001.Object -> vector_math.Vector
    gold_little_imperf_.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    gold_little_imperf_.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    gold_little_imperf_.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> math.Value
    gold_little_imperf_.links.new(colorramp.outputs[0], math.inputs[0])
    #group_input.Mix Roughness -> math.Value
    gold_little_imperf_.links.new(group_input.outputs[3], math.inputs[1])
    #group_input.Detail -> noise_texture.Detail
    gold_little_imperf_.links.new(group_input.outputs[4], noise_texture.inputs[3])
    #group_input.Distortion -> noise_texture.Distortion
    gold_little_imperf_.links.new(group_input.outputs[5], noise_texture.inputs[5])
    #group_input.Base Color -> principled_bsdf.Base Color
    gold_little_imperf_.links.new(group_input.outputs[1], principled_bsdf.inputs[0])
    #group_input.Anisotropic -> principled_bsdf.Anisotropic
    gold_little_imperf_.links.new(group_input.outputs[2], principled_bsdf.inputs[10])
    #group_input.Bump Strength -> bump.Strength
    gold_little_imperf_.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    gold_little_imperf_.links.new(group_input.outputs[7], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask
    gold_little_imperf_.links.new(noise_texture.outputs[0], group_output.inputs[1])
    return gold_little_imperf_

gold_little_imperf_ = gold_little_imperf__node_group()

#initialize Gold Textured node group
def gold_textured_node_group():

    gold_textured = mat.node_tree
    #start with a clean node tree
    for node in gold_textured.nodes:
        gold_textured.nodes.remove(node)
    #initialize gold_textured nodes
    #node Material Output
    material_output = gold_textured.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Gold_little_imperf.
    gold_little_imperf__1 = gold_textured.nodes.new("ShaderNodeGroup")
    gold_little_imperf__1.label = "Gold_little_imperf."
    gold_little_imperf__1.name = "Gold_little_imperf."
    gold_little_imperf__1.node_tree = gold_little_imperf_
    #Input_1
    gold_little_imperf__1.inputs[0].default_value = 1.0
    #Input_5
    gold_little_imperf__1.inputs[1].default_value = (1.0, 0.5040153861045837, 0.16143031418323517, 1.0)
    #Input_6
    gold_little_imperf__1.inputs[2].default_value = 0.0
    #Input_2
    gold_little_imperf__1.inputs[3].default_value = 0.0
    #Input_3
    gold_little_imperf__1.inputs[4].default_value = 8.0
    #Input_4
    gold_little_imperf__1.inputs[5].default_value = 0.0
    #Input_7
    gold_little_imperf__1.inputs[6].default_value = 0.009999999776482582
    #Input_8
    gold_little_imperf__1.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (669.20068359375, 132.858154296875)
    gold_little_imperf__1.location = (396.65234375, 132.858154296875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    gold_little_imperf__1.width, gold_little_imperf__1.height = 195.54910278320312, 100.0
    
    #initialize gold_textured links
    #gold_little_imperf__1.BSDF -> material_output.Surface
    gold_textured.links.new(gold_little_imperf__1.outputs[0], material_output.inputs[0])
    return gold_textured

gold_textured = gold_textured_node_group()

