import bpy, mathutils

mat = bpy.data.materials.new(name = "Ceramic Pattern4 Birds Smal")
mat.use_nodes = True
#initialize Ceramic Pattern4 birds_smal node group
def ceramic_pattern4_birds_smal_node_group():

    ceramic_pattern4_birds_smal = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Ceramic Pattern4 birds_smal")
    
    #initialize ceramic_pattern4_birds_smal nodes
    #node Texture Coordinate
    texture_coordinate = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mapping
    mapping = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    mapping.inputs[3].default_value = (1.0, 1.0, 1.0)
    
    #node Voronoi Texture
    voronoi_texture = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'F2'
    voronoi_texture.voronoi_dimensions = '3D'
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node ColorRamp
    colorramp = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.4090907573699951
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5545452237129211)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(0.6272727847099304)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_3 = colorramp_001.color_ramp.elements.new(0.7772724628448486)
    colorramp_001_cre_3.alpha = 1.0
    colorramp_001_cre_3.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Math.014
    math_014 = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeMath")
    math_014.name = "Math.014"
    math_014.operation = 'MULTIPLY'
    math_014.use_clamp = False
    #Value
    math_014.inputs[0].default_value = 3.6700000762939453
    #Value_002
    math_014.inputs[2].default_value = 0.5
    
    #node Group Output
    group_output = ceramic_pattern4_birds_smal.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #ceramic_pattern4_birds_smal outputs
    #output BSDF
    ceramic_pattern4_birds_smal.outputs.new('NodeSocketShader', "BSDF")
    ceramic_pattern4_birds_smal.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    ceramic_pattern4_birds_smal.outputs.new('NodeSocketColor', "Albedo")
    ceramic_pattern4_birds_smal.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    ceramic_pattern4_birds_smal.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    ceramic_pattern4_birds_smal.outputs.new('NodeSocketFloat', "Mask")
    ceramic_pattern4_birds_smal.outputs[2].default_value = 0.0
    ceramic_pattern4_birds_smal.outputs[2].min_value = -3.4028234663852886e+38
    ceramic_pattern4_birds_smal.outputs[2].max_value = 3.4028234663852886e+38
    ceramic_pattern4_birds_smal.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Bump
    bump = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Math.015
    math_015 = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeMath")
    math_015.name = "Math.015"
    math_015.operation = 'MULTIPLY'
    math_015.use_clamp = False
    #Value
    math_015.inputs[0].default_value = 0.1899999976158142
    #Value_002
    math_015.inputs[2].default_value = 0.5
    
    #node Math.016
    math_016 = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeMath")
    math_016.name = "Math.016"
    math_016.operation = 'MULTIPLY'
    math_016.use_clamp = False
    #Value_002
    math_016.inputs[2].default_value = 0.5
    
    #node Math.017
    math_017 = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeMath")
    math_017.name = "Math.017"
    math_017.operation = 'MULTIPLY'
    math_017.use_clamp = False
    #Value_001
    math_017.inputs[1].default_value = 0.10000000149011612
    #Value_002
    math_017.inputs[2].default_value = 0.5
    
    #node Group Input
    group_input = ceramic_pattern4_birds_smal.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #ceramic_pattern4_birds_smal inputs
    #input Color1
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketColor', "Color1")
    ceramic_pattern4_birds_smal.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    ceramic_pattern4_birds_smal.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketColor', "Color2")
    ceramic_pattern4_birds_smal.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    ceramic_pattern4_birds_smal.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketFloat', "Scale")
    ceramic_pattern4_birds_smal.inputs[2].default_value = 0.5
    ceramic_pattern4_birds_smal.inputs[2].min_value = -10000.0
    ceramic_pattern4_birds_smal.inputs[2].max_value = 10000.0
    ceramic_pattern4_birds_smal.inputs[2].attribute_domain = 'POINT'
    
    #input Ring Amount
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketFloat', "Ring Amount")
    ceramic_pattern4_birds_smal.inputs[3].default_value = 0.5
    ceramic_pattern4_birds_smal.inputs[3].min_value = -10000.0
    ceramic_pattern4_birds_smal.inputs[3].max_value = 10000.0
    ceramic_pattern4_birds_smal.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketFloatFactor', "Roughness")
    ceramic_pattern4_birds_smal.inputs[4].default_value = 0.0
    ceramic_pattern4_birds_smal.inputs[4].min_value = 0.0
    ceramic_pattern4_birds_smal.inputs[4].max_value = 1.0
    ceramic_pattern4_birds_smal.inputs[4].attribute_domain = 'POINT'
    
    #input Effect1
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketFloat', "Effect1")
    ceramic_pattern4_birds_smal.inputs[5].default_value = 0.1899999976158142
    ceramic_pattern4_birds_smal.inputs[5].min_value = -10000.0
    ceramic_pattern4_birds_smal.inputs[5].max_value = 10000.0
    ceramic_pattern4_birds_smal.inputs[5].attribute_domain = 'POINT'
    
    #input Randomness
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketFloatFactor', "Randomness")
    ceramic_pattern4_birds_smal.inputs[6].default_value = 0.0
    ceramic_pattern4_birds_smal.inputs[6].min_value = 0.0
    ceramic_pattern4_birds_smal.inputs[6].max_value = 1.0
    ceramic_pattern4_birds_smal.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    ceramic_pattern4_birds_smal.inputs[7].default_value = 1.0
    ceramic_pattern4_birds_smal.inputs[7].min_value = 0.0
    ceramic_pattern4_birds_smal.inputs[7].max_value = 1.0
    ceramic_pattern4_birds_smal.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    ceramic_pattern4_birds_smal.inputs.new('NodeSocketVector', "Normal")
    ceramic_pattern4_birds_smal.inputs[8].default_value = (0.0, 0.0, 0.0)
    ceramic_pattern4_birds_smal.inputs[8].min_value = -1.0
    ceramic_pattern4_birds_smal.inputs[8].max_value = 1.0
    ceramic_pattern4_birds_smal.inputs[8].attribute_domain = 'POINT'
    ceramic_pattern4_birds_smal.inputs[8].hide_value = True
    
    
    
    #node Wave Texture
    wave_texture = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Distortion
    wave_texture.inputs[2].default_value = 0.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Mix
    mix = ceramic_pattern4_birds_smal.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    texture_coordinate.location = (-476.7711181640625, 111.5)
    mapping.location = (-266.7711181640625, 128.5)
    voronoi_texture.location = (23.2288818359375, 110.0)
    principled_bsdf.location = (1009.7711181640625, 190.0)
    colorramp.location = (423.2288818359375, 109.99996948242188)
    colorramp_001.location = (423.2288818359375, -110.0)
    math_014.location = (-716.7711791992188, 50.0)
    group_output.location = (1299.7711181640625, -0.0)
    bump.location = (783.2289428710938, -230.0)
    math_015.location = (-696.7711181640625, 230.0)
    math_016.location = (-503.14666748046875, 280.4642333984375)
    math_017.location = (-673.1323852539062, -147.28070068359375)
    group_input.location = (-1209.7711181640625, -0.0)
    wave_texture.location = (203.22882080078125, 110.0)
    mix.location = (763.3370361328125, 152.96575927734375)
    
    #Set dimensions
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mapping.width, mapping.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    math_014.width, math_014.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    math_015.width, math_015.height = 140.0, 100.0
    math_016.width, math_016.height = 140.0, 100.0
    math_017.width, math_017.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    
    #initialize ceramic_pattern4_birds_smal links
    #principled_bsdf.BSDF -> group_output.BSDF
    ceramic_pattern4_birds_smal.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mapping.Vector -> voronoi_texture.Vector
    ceramic_pattern4_birds_smal.links.new(mapping.outputs[0], voronoi_texture.inputs[0])
    #texture_coordinate.Object -> mapping.Vector
    ceramic_pattern4_birds_smal.links.new(texture_coordinate.outputs[3], mapping.inputs[0])
    #voronoi_texture.Distance -> wave_texture.Vector
    ceramic_pattern4_birds_smal.links.new(voronoi_texture.outputs[0], wave_texture.inputs[0])
    #wave_texture.Color -> colorramp.Fac
    ceramic_pattern4_birds_smal.links.new(wave_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    ceramic_pattern4_birds_smal.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #colorramp_001.Color -> bump.Height
    ceramic_pattern4_birds_smal.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #wave_texture.Color -> colorramp_001.Fac
    ceramic_pattern4_birds_smal.links.new(wave_texture.outputs[0], colorramp_001.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    ceramic_pattern4_birds_smal.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #math_016.Value -> wave_texture.Scale
    ceramic_pattern4_birds_smal.links.new(math_016.outputs[0], wave_texture.inputs[1])
    #math_014.Value -> voronoi_texture.Scale
    ceramic_pattern4_birds_smal.links.new(math_014.outputs[0], voronoi_texture.inputs[2])
    #group_input.Scale -> math_015.Value
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[2], math_015.inputs[1])
    #group_input.Scale -> math_014.Value
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[2], math_014.inputs[1])
    #colorramp.Color -> mix.Factor
    ceramic_pattern4_birds_smal.links.new(colorramp.outputs[0], mix.inputs[0])
    #group_input.Color1 -> mix.A
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[0], mix.inputs[6])
    #group_input.Color2 -> mix.B
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[1], mix.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #math_015.Value -> math_016.Value
    ceramic_pattern4_birds_smal.links.new(math_015.outputs[0], math_016.inputs[0])
    #group_input.Ring Amount -> math_016.Value
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[3], math_016.inputs[1])
    #group_input.Effect1 -> math_017.Value
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[5], math_017.inputs[0])
    #math_017.Value -> voronoi_texture.Exponent
    ceramic_pattern4_birds_smal.links.new(math_017.outputs[0], voronoi_texture.inputs[4])
    #group_input.Randomness -> voronoi_texture.Randomness
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[6], voronoi_texture.inputs[5])
    #group_input.Bump Strength -> bump.Strength
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    ceramic_pattern4_birds_smal.links.new(group_input.outputs[8], bump.inputs[3])
    #wave_texture.Fac -> group_output.Mask
    ceramic_pattern4_birds_smal.links.new(wave_texture.outputs[1], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    ceramic_pattern4_birds_smal.links.new(mix.outputs[2], group_output.inputs[1])
    return ceramic_pattern4_birds_smal

ceramic_pattern4_birds_smal = ceramic_pattern4_birds_smal_node_group()

#initialize Ceramic Pattern4 Birds Smal node group
def ceramic_pattern4_birds_smal_1_node_group():

    ceramic_pattern4_birds_smal_1 = mat.node_tree
    #start with a clean node tree
    for node in ceramic_pattern4_birds_smal_1.nodes:
        ceramic_pattern4_birds_smal_1.nodes.remove(node)
    #initialize ceramic_pattern4_birds_smal_1 nodes
    #node Material Output
    material_output = ceramic_pattern4_birds_smal_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Ceramic Pattern4 birds_smal
    ceramic_pattern4_birds_smal_2 = ceramic_pattern4_birds_smal_1.nodes.new("ShaderNodeGroup")
    ceramic_pattern4_birds_smal_2.label = "Ceramic Pattern4 birds_smal"
    ceramic_pattern4_birds_smal_2.name = "Ceramic Pattern4 birds_smal"
    ceramic_pattern4_birds_smal_2.node_tree = ceramic_pattern4_birds_smal
    #Input_2
    ceramic_pattern4_birds_smal_2.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_3
    ceramic_pattern4_birds_smal_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_1
    ceramic_pattern4_birds_smal_2.inputs[2].default_value = 1.0
    #Input_5
    ceramic_pattern4_birds_smal_2.inputs[3].default_value = 1.0
    #Input_4
    ceramic_pattern4_birds_smal_2.inputs[4].default_value = 0.0
    #Input_6
    ceramic_pattern4_birds_smal_2.inputs[5].default_value = 5.0
    #Input_7
    ceramic_pattern4_birds_smal_2.inputs[6].default_value = 0.0
    #Input_8
    ceramic_pattern4_birds_smal_2.inputs[7].default_value = 0.6000000238418579
    #Input_9
    ceramic_pattern4_birds_smal_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (650.787109375, 60.080810546875)
    ceramic_pattern4_birds_smal_2.location = (414.2451171875, 60.080810546875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    ceramic_pattern4_birds_smal_2.width, ceramic_pattern4_birds_smal_2.height = 167.559814453125, 100.0
    
    #initialize ceramic_pattern4_birds_smal_1 links
    #ceramic_pattern4_birds_smal_2.BSDF -> material_output.Surface
    ceramic_pattern4_birds_smal_1.links.new(ceramic_pattern4_birds_smal_2.outputs[0], material_output.inputs[0])
    return ceramic_pattern4_birds_smal_1

ceramic_pattern4_birds_smal_1 = ceramic_pattern4_birds_smal_1_node_group()

