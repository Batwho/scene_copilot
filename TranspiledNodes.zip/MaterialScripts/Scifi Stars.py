import bpy, mathutils

mat = bpy.data.materials.new(name = "Scifi Stars")
mat.use_nodes = True
#initialize Scifi stars node group
def scifi_stars_node_group():

    scifi_stars = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Scifi stars")
    
    #initialize scifi_stars nodes
    #node ColorRamp.003
    colorramp_003 = scifi_stars.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.0
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.7363638281822205)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump.001
    bump_001 = scifi_stars.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = True
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Bump
    bump = scifi_stars.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp
    colorramp = scifi_stars.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.18636451661586761)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Vector Math.018
    vector_math_018 = scifi_stars.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = scifi_stars.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Mix.002
    mix_002 = scifi_stars.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'DODGE'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #B_Color
    mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Voronoi Texture
    voronoi_texture = scifi_stars.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'SMOOTH_F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 5.0
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Noise Texture
    noise_texture = scifi_stars.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 3.0
    #Detail
    noise_texture.inputs[3].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix
    mix = scifi_stars.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Mix.001
    mix_001 = scifi_stars.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Reroute
    reroute = scifi_stars.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Reroute.001
    reroute_001 = scifi_stars.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Mix.003
    mix_003 = scifi_stars.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'COLOR'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    #A_Color
    mix_003.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.004
    mix_004 = scifi_stars.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'COLOR'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    #A_Color
    mix_004.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node ColorRamp.001
    colorramp_001 = scifi_stars.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.005
    mix_005 = scifi_stars.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MIX'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    
    #node Mix.006
    mix_006 = scifi_stars.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'COLOR'
    mix_006.clamp_factor = True
    mix_006.clamp_result = False
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    
    #node Principled BSDF
    principled_bsdf = scifi_stars.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Reroute.002
    reroute_002 = scifi_stars.nodes.new("NodeReroute")
    reroute_002.name = "Reroute.002"
    #node Math
    math = scifi_stars.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 50.0
    
    #node Group Output
    group_output = scifi_stars.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #scifi_stars outputs
    #output BSDF
    scifi_stars.outputs.new('NodeSocketShader', "BSDF")
    scifi_stars.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    scifi_stars.outputs.new('NodeSocketColor', "Albedo")
    scifi_stars.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    scifi_stars.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    scifi_stars.outputs.new('NodeSocketColor', "Mask")
    scifi_stars.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    scifi_stars.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Group Input
    group_input = scifi_stars.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #scifi_stars inputs
    #input Scale
    scifi_stars.inputs.new('NodeSocketFloat', "Scale")
    scifi_stars.inputs[0].default_value = 1.0
    scifi_stars.inputs[0].min_value = -10000.0
    scifi_stars.inputs[0].max_value = 10000.0
    scifi_stars.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    scifi_stars.inputs.new('NodeSocketColor', "Color1")
    scifi_stars.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    scifi_stars.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    scifi_stars.inputs.new('NodeSocketColor', "Color2")
    scifi_stars.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    scifi_stars.inputs[2].attribute_domain = 'POINT'
    
    #input Emission Color
    scifi_stars.inputs.new('NodeSocketColor', "Emission Color")
    scifi_stars.inputs[3].default_value = (0.32327327132225037, 0.7885132431983948, 1.0, 1.0)
    scifi_stars.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    scifi_stars.inputs.new('NodeSocketFloatFactor', "Roughness")
    scifi_stars.inputs[4].default_value = 0.0
    scifi_stars.inputs[4].min_value = 0.0
    scifi_stars.inputs[4].max_value = 1.0
    scifi_stars.inputs[4].attribute_domain = 'POINT'
    
    #input Dot Clamp
    scifi_stars.inputs.new('NodeSocketFloatFactor', "Dot Clamp")
    scifi_stars.inputs[5].default_value = 0.7166666984558105
    scifi_stars.inputs[5].min_value = 0.0
    scifi_stars.inputs[5].max_value = 1.0
    scifi_stars.inputs[5].attribute_domain = 'POINT'
    
    #input Smoothness
    scifi_stars.inputs.new('NodeSocketFloatFactor', "Smoothness")
    scifi_stars.inputs[6].default_value = 0.01666666753590107
    scifi_stars.inputs[6].min_value = 0.0
    scifi_stars.inputs[6].max_value = 1.0
    scifi_stars.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    scifi_stars.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    scifi_stars.inputs[7].default_value = 1.0
    scifi_stars.inputs[7].min_value = 0.0
    scifi_stars.inputs[7].max_value = 1.0
    scifi_stars.inputs[7].attribute_domain = 'POINT'
    
    #input Dot Bump Strength
    scifi_stars.inputs.new('NodeSocketFloatFactor', "Dot Bump Strength")
    scifi_stars.inputs[8].default_value = 0.10000000149011612
    scifi_stars.inputs[8].min_value = 0.0
    scifi_stars.inputs[8].max_value = 1.0
    scifi_stars.inputs[8].attribute_domain = 'POINT'
    
    #input Normal
    scifi_stars.inputs.new('NodeSocketVector', "Normal")
    scifi_stars.inputs[9].default_value = (0.0, 0.0, 0.0)
    scifi_stars.inputs[9].min_value = -1.0
    scifi_stars.inputs[9].max_value = 1.0
    scifi_stars.inputs[9].attribute_domain = 'POINT'
    scifi_stars.inputs[9].hide_value = True
    
    
    
    
    #Set locations
    colorramp_003.location = (-73.99993896484375, 294.14288330078125)
    bump_001.location = (486.00006103515625, -320.0)
    bump.location = (686.0000610351562, -180.0)
    colorramp.location = (466.00006103515625, 40.0)
    vector_math_018.location = (-613.9999389648438, 160.0)
    texture_coordinate_001.location = (-953.9999389648438, 80.0)
    mix_002.location = (201.360595703125, -247.26278686523438)
    voronoi_texture.location = (-293.99993896484375, 0.0)
    noise_texture.location = (-293.99993896484375, 246.5409698486328)
    mix.location = (220.0, 0.0)
    mix_001.location = (684.6866455078125, 253.95346069335938)
    reroute.location = (563.9482421875, 117.41703796386719)
    reroute_001.location = (591.989501953125, 96.015380859375)
    mix_003.location = (700.0, 660.0)
    mix_004.location = (700.0, 460.0)
    colorramp_001.location = (226.00006103515625, 239.99996948242188)
    mix_005.location = (920.1817626953125, 599.2977905273438)
    mix_006.location = (1089.394287109375, 563.897705078125)
    principled_bsdf.location = (953.9999389648438, 320.0)
    reroute_002.location = (607.0643920898438, -205.31192016601562)
    math.location = (734.0000610351562, 32.025390625)
    group_output.location = (1360.0, 60.0)
    group_input.location = (-1154.0, -0.0)
    
    #Set dimensions
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    reroute_002.width, reroute_002.height = 16.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize scifi_stars links
    #principled_bsdf.BSDF -> group_output.BSDF
    scifi_stars.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    scifi_stars.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Color -> bump.Height
    scifi_stars.links.new(voronoi_texture.outputs[1], bump.inputs[2])
    #math.Value -> principled_bsdf.Emission Strength
    scifi_stars.links.new(math.outputs[0], principled_bsdf.inputs[20])
    #mix.Result -> colorramp.Fac
    scifi_stars.links.new(mix.outputs[2], colorramp.inputs[0])
    #colorramp.Color -> math.Value
    scifi_stars.links.new(colorramp.outputs[0], math.inputs[0])
    #voronoi_texture.Color -> colorramp_001.Fac
    scifi_stars.links.new(voronoi_texture.outputs[1], colorramp_001.inputs[0])
    #mix_001.Result -> principled_bsdf.Base Color
    scifi_stars.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #bump_001.Normal -> bump.Normal
    scifi_stars.links.new(bump_001.outputs[0], bump.inputs[3])
    #mix_002.Result -> bump_001.Height
    scifi_stars.links.new(mix_002.outputs[2], bump_001.inputs[2])
    #voronoi_texture.Distance -> mix.B
    scifi_stars.links.new(voronoi_texture.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> colorramp_003.Fac
    scifi_stars.links.new(noise_texture.outputs[0], colorramp_003.inputs[0])
    #colorramp_003.Color -> mix.A
    scifi_stars.links.new(colorramp_003.outputs[0], mix.inputs[6])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    scifi_stars.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    scifi_stars.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #vector_math_018.Vector -> voronoi_texture.Vector
    scifi_stars.links.new(vector_math_018.outputs[0], voronoi_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    scifi_stars.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #colorramp_001.Color -> mix_001.Factor
    scifi_stars.links.new(colorramp_001.outputs[0], mix_001.inputs[0])
    #reroute.Output -> mix_001.A
    scifi_stars.links.new(reroute.outputs[0], mix_001.inputs[6])
    #reroute_001.Output -> mix_001.B
    scifi_stars.links.new(reroute_001.outputs[0], mix_001.inputs[7])
    #voronoi_texture.Distance -> mix_002.A
    scifi_stars.links.new(voronoi_texture.outputs[0], mix_002.inputs[6])
    #group_input.Dot Clamp -> mix_002.Factor
    scifi_stars.links.new(group_input.outputs[5], mix_002.inputs[0])
    #group_input.Smoothness -> voronoi_texture.Smoothness
    scifi_stars.links.new(group_input.outputs[6], voronoi_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    scifi_stars.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Dot Bump Strength -> bump_001.Strength
    scifi_stars.links.new(group_input.outputs[8], bump_001.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    scifi_stars.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Normal -> bump_001.Normal
    scifi_stars.links.new(group_input.outputs[9], bump_001.inputs[3])
    #mix.Result -> group_output.Mask
    scifi_stars.links.new(mix.outputs[2], group_output.inputs[2])
    #group_input.Color1 -> reroute.Input
    scifi_stars.links.new(group_input.outputs[1], reroute.inputs[0])
    #group_input.Color2 -> reroute_001.Input
    scifi_stars.links.new(group_input.outputs[2], reroute_001.inputs[0])
    #mix_006.Result -> group_output.Albedo
    scifi_stars.links.new(mix_006.outputs[2], group_output.inputs[1])
    #reroute.Output -> mix_003.B
    scifi_stars.links.new(reroute.outputs[0], mix_003.inputs[7])
    #reroute_001.Output -> mix_004.B
    scifi_stars.links.new(reroute_001.outputs[0], mix_004.inputs[7])
    #mix_003.Result -> mix_005.A
    scifi_stars.links.new(mix_003.outputs[2], mix_005.inputs[6])
    #mix_004.Result -> mix_005.B
    scifi_stars.links.new(mix_004.outputs[2], mix_005.inputs[7])
    #colorramp_001.Color -> mix_005.Factor
    scifi_stars.links.new(colorramp_001.outputs[0], mix_005.inputs[0])
    #mix_005.Result -> mix_006.A
    scifi_stars.links.new(mix_005.outputs[2], mix_006.inputs[6])
    #reroute_002.Output -> principled_bsdf.Emission
    scifi_stars.links.new(reroute_002.outputs[0], principled_bsdf.inputs[19])
    #group_input.Emission Color -> reroute_002.Input
    scifi_stars.links.new(group_input.outputs[3], reroute_002.inputs[0])
    #reroute_002.Output -> mix_006.B
    scifi_stars.links.new(reroute_002.outputs[0], mix_006.inputs[7])
    #math.Value -> mix_006.Factor
    scifi_stars.links.new(math.outputs[0], mix_006.inputs[0])
    return scifi_stars

scifi_stars = scifi_stars_node_group()

#initialize Scifi Stars node group
def scifi_stars_1_node_group():

    scifi_stars_1 = mat.node_tree
    #start with a clean node tree
    for node in scifi_stars_1.nodes:
        scifi_stars_1.nodes.remove(node)
    #initialize scifi_stars_1 nodes
    #node Material Output
    material_output = scifi_stars_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Scifi stars
    scifi_stars_2 = scifi_stars_1.nodes.new("ShaderNodeGroup")
    scifi_stars_2.label = "Scifi stars"
    scifi_stars_2.name = "Scifi stars"
    scifi_stars_2.node_tree = scifi_stars
    #Input_1
    scifi_stars_2.inputs[0].default_value = 1.0
    #Input_2
    scifi_stars_2.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_3
    scifi_stars_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_18
    scifi_stars_2.inputs[3].default_value = (0.32327327132225037, 0.7885132431983948, 1.0, 1.0)
    #Input_9
    scifi_stars_2.inputs[4].default_value = 0.0
    #Input_5
    scifi_stars_2.inputs[5].default_value = 0.7166666984558105
    #Input_6
    scifi_stars_2.inputs[6].default_value = 0.010831705294549465
    #Input_7
    scifi_stars_2.inputs[7].default_value = 1.0
    #Input_8
    scifi_stars_2.inputs[8].default_value = 0.10000000149011612
    #Input_10
    scifi_stars_2.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (668.03759765625, 112.064697265625)
    scifi_stars_2.location = (400.396484375, 112.064697265625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    scifi_stars_2.width, scifi_stars_2.height = 192.298095703125, 100.0
    
    #initialize scifi_stars_1 links
    #scifi_stars_2.BSDF -> material_output.Surface
    scifi_stars_1.links.new(scifi_stars_2.outputs[0], material_output.inputs[0])
    return scifi_stars_1

scifi_stars_1 = scifi_stars_1_node_group()

