import bpy, mathutils

mat = bpy.data.materials.new(name = "2Step Purple Texture2")
mat.use_nodes = True
#initialize 2step_purple_texture2 node group
def _2step_purple_texture2_node_group():

    _2step_purple_texture2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "2step_purple_texture2")
    
    #initialize _2step_purple_texture2 nodes
    #node ColorRamp
    colorramp = _2step_purple_texture2.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.004545455798506737)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.6318185329437256)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.002
    mix_002 = _2step_purple_texture2.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'BURN'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node ColorRamp.001
    colorramp_001 = _2step_purple_texture2.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.2090909481048584
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.001
    mix_001 = _2step_purple_texture2.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'DODGE'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Shader to RGB
    shader_to_rgb = _2step_purple_texture2.nodes.new("ShaderNodeShaderToRGB")
    shader_to_rgb.name = "Shader to RGB"
    
    #node Group Output
    group_output = _2step_purple_texture2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #_2step_purple_texture2 outputs
    #output Color
    _2step_purple_texture2.outputs.new('NodeSocketColor', "Color")
    _2step_purple_texture2.outputs[0].default_value = (0.0, 0.0, 0.0, 0.0)
    _2step_purple_texture2.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Mix
    mix = _2step_purple_texture2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.003
    mix_003 = _2step_purple_texture2.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'COLOR'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    
    #node Noise Texture
    noise_texture = _2step_purple_texture2.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = _2step_purple_texture2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #_2step_purple_texture2 inputs
    #input Color
    _2step_purple_texture2.inputs.new('NodeSocketColor', "Color")
    _2step_purple_texture2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    _2step_purple_texture2.inputs[0].attribute_domain = 'POINT'
    
    #input Saturation
    _2step_purple_texture2.inputs.new('NodeSocketFloatFactor', "Saturation")
    _2step_purple_texture2.inputs[1].default_value = 1.0
    _2step_purple_texture2.inputs[1].min_value = 0.0
    _2step_purple_texture2.inputs[1].max_value = 1.0
    _2step_purple_texture2.inputs[1].attribute_domain = 'POINT'
    
    #input Darkening
    _2step_purple_texture2.inputs.new('NodeSocketFloatFactor', "Darkening")
    _2step_purple_texture2.inputs[2].default_value = 1.0
    _2step_purple_texture2.inputs[2].min_value = 0.0
    _2step_purple_texture2.inputs[2].max_value = 1.0
    _2step_purple_texture2.inputs[2].attribute_domain = 'POINT'
    
    #input Light Threshold
    _2step_purple_texture2.inputs.new('NodeSocketFloat', "Light Threshold")
    _2step_purple_texture2.inputs[3].default_value = 1.0
    _2step_purple_texture2.inputs[3].min_value = 0.0
    _2step_purple_texture2.inputs[3].max_value = 1000.0
    _2step_purple_texture2.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Scale
    _2step_purple_texture2.inputs.new('NodeSocketFloat', "Noise Scale")
    _2step_purple_texture2.inputs[4].default_value = 44.099998474121094
    _2step_purple_texture2.inputs[4].min_value = -1000.0
    _2step_purple_texture2.inputs[4].max_value = 1000.0
    _2step_purple_texture2.inputs[4].attribute_domain = 'POINT'
    
    #input Noise Detail
    _2step_purple_texture2.inputs.new('NodeSocketFloat', "Noise Detail")
    _2step_purple_texture2.inputs[5].default_value = 8.729999542236328
    _2step_purple_texture2.inputs[5].min_value = 0.0
    _2step_purple_texture2.inputs[5].max_value = 15.0
    _2step_purple_texture2.inputs[5].attribute_domain = 'POINT'
    
    #input Noise Dodge
    _2step_purple_texture2.inputs.new('NodeSocketFloatFactor', "Noise Dodge")
    _2step_purple_texture2.inputs[6].default_value = 1.0
    _2step_purple_texture2.inputs[6].min_value = 0.0
    _2step_purple_texture2.inputs[6].max_value = 1.0
    _2step_purple_texture2.inputs[6].attribute_domain = 'POINT'
    
    #input Noise Burn
    _2step_purple_texture2.inputs.new('NodeSocketFloatFactor', "Noise Burn")
    _2step_purple_texture2.inputs[7].default_value = 0.10000000149011612
    _2step_purple_texture2.inputs[7].min_value = 0.0
    _2step_purple_texture2.inputs[7].max_value = 1.0
    _2step_purple_texture2.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    _2step_purple_texture2.inputs.new('NodeSocketVector', "Normal")
    _2step_purple_texture2.inputs[8].default_value = (0.0, 0.0, 0.0)
    _2step_purple_texture2.inputs[8].min_value = -3.4028234663852886e+38
    _2step_purple_texture2.inputs[8].max_value = 3.4028234663852886e+38
    _2step_purple_texture2.inputs[8].attribute_domain = 'POINT'
    _2step_purple_texture2.inputs[8].hide_value = True
    
    
    
    #node Principled BSDF
    principled_bsdf = _2step_purple_texture2.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    colorramp.location = (470.0, 158.82850646972656)
    mix_002.location = (280.86767578125, 3.0998992919921875)
    colorramp_001.location = (-258.7119140625, -153.83277893066406)
    mix_001.location = (61.005126953125, 24.618270874023438)
    shader_to_rgb.location = (-480.0, 108.27650451660156)
    group_output.location = (1180.0, 0.0)
    mix.location = (980.0000610351562, 159.99996948242188)
    mix_003.location = (782.675537109375, 177.54827880859375)
    noise_texture.location = (-478.7119140625, -160.2331085205078)
    group_input.location = (-1400.0, 180.0)
    principled_bsdf.location = (-790.0, 93.0657958984375)
    
    #Set dimensions
    colorramp.width, colorramp.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    
    #initialize _2step_purple_texture2 links
    #mix.Result -> group_output.Color
    _2step_purple_texture2.links.new(mix.outputs[2], group_output.inputs[0])
    #principled_bsdf.BSDF -> shader_to_rgb.Shader
    _2step_purple_texture2.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
    #mix_003.Result -> mix.A
    _2step_purple_texture2.links.new(mix_003.outputs[2], mix.inputs[6])
    #colorramp_001.Color -> mix_001.B
    _2step_purple_texture2.links.new(colorramp_001.outputs[0], mix_001.inputs[7])
    #noise_texture.Fac -> colorramp_001.Fac
    _2step_purple_texture2.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #mix_001.Result -> mix_002.A
    _2step_purple_texture2.links.new(mix_001.outputs[2], mix_002.inputs[6])
    #colorramp_001.Color -> mix_002.B
    _2step_purple_texture2.links.new(colorramp_001.outputs[0], mix_002.inputs[7])
    #shader_to_rgb.Color -> mix_001.A
    _2step_purple_texture2.links.new(shader_to_rgb.outputs[0], mix_001.inputs[6])
    #mix_002.Result -> colorramp.Fac
    _2step_purple_texture2.links.new(mix_002.outputs[2], colorramp.inputs[0])
    #colorramp.Color -> mix_003.A
    _2step_purple_texture2.links.new(colorramp.outputs[0], mix_003.inputs[6])
    #group_input.Color -> mix_003.B
    _2step_purple_texture2.links.new(group_input.outputs[0], mix_003.inputs[7])
    #group_input.Saturation -> mix_003.Factor
    _2step_purple_texture2.links.new(group_input.outputs[1], mix_003.inputs[0])
    #group_input.Darkening -> mix.Factor
    _2step_purple_texture2.links.new(group_input.outputs[2], mix.inputs[0])
    #group_input.Light Threshold -> principled_bsdf.Base Color
    _2step_purple_texture2.links.new(group_input.outputs[3], principled_bsdf.inputs[0])
    #group_input.Noise Scale -> noise_texture.Scale
    _2step_purple_texture2.links.new(group_input.outputs[4], noise_texture.inputs[2])
    #group_input.Noise Detail -> noise_texture.Detail
    _2step_purple_texture2.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #group_input.Noise Dodge -> mix_001.Factor
    _2step_purple_texture2.links.new(group_input.outputs[6], mix_001.inputs[0])
    #group_input.Noise Burn -> mix_002.Factor
    _2step_purple_texture2.links.new(group_input.outputs[7], mix_002.inputs[0])
    #group_input.Normal -> principled_bsdf.Normal
    _2step_purple_texture2.links.new(group_input.outputs[8], principled_bsdf.inputs[22])
    #group_input.Light Threshold -> principled_bsdf.Specular
    _2step_purple_texture2.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    return _2step_purple_texture2

_2step_purple_texture2 = _2step_purple_texture2_node_group()

#initialize 2Step Purple Texture2 node group
def _2step_purple_texture2_1_node_group():

    _2step_purple_texture2_1 = mat.node_tree
    #start with a clean node tree
    for node in _2step_purple_texture2_1.nodes:
        _2step_purple_texture2_1.nodes.remove(node)
    #initialize _2step_purple_texture2_1 nodes
    #node Material Output
    material_output = _2step_purple_texture2_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node 2step_purple_texture2
    _2step_purple_texture2_2 = _2step_purple_texture2_1.nodes.new("ShaderNodeGroup")
    _2step_purple_texture2_2.label = "2step_purple_texture2"
    _2step_purple_texture2_2.name = "2step_purple_texture2"
    _2step_purple_texture2_2.node_tree = _2step_purple_texture2
    #Input_1
    _2step_purple_texture2_2.inputs[0].default_value = (0.5428619384765625, 0.14698980748653412, 1.0, 1.0)
    #Input_2
    _2step_purple_texture2_2.inputs[1].default_value = 1.0
    #Input_3
    _2step_purple_texture2_2.inputs[2].default_value = 0.0
    #Input_4
    _2step_purple_texture2_2.inputs[3].default_value = 1.0
    #Input_5
    _2step_purple_texture2_2.inputs[4].default_value = 44.099998474121094
    #Input_6
    _2step_purple_texture2_2.inputs[5].default_value = 8.729999542236328
    #Input_7
    _2step_purple_texture2_2.inputs[6].default_value = 1.0
    #Input_8
    _2step_purple_texture2_2.inputs[7].default_value = 0.10000000149011612
    #Input_9
    _2step_purple_texture2_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (680.0, 60.0)
    _2step_purple_texture2_2.location = (391.771484375, 66.88818359375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    _2step_purple_texture2_2.width, _2step_purple_texture2_2.height = 198.30810546875, 100.0
    
    #initialize _2step_purple_texture2_1 links
    #_2step_purple_texture2_2.Color -> material_output.Surface
    _2step_purple_texture2_1.links.new(_2step_purple_texture2_2.outputs[0], material_output.inputs[0])
    return _2step_purple_texture2_1

_2step_purple_texture2_1 = _2step_purple_texture2_1_node_group()

