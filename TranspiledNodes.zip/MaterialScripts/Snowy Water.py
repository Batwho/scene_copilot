import bpy, mathutils

mat = bpy.data.materials.new(name = "Snowy Water")
mat.use_nodes = True
#initialize Snowy Water node group
def snowy_water_node_group():

    snowy_water = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Snowy Water")
    
    #initialize snowy_water nodes
    #node ColorRamp.003
    colorramp_003 = snowy_water.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.39545443654060364
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.6912487745285034, 0.9542499780654907, 1.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.5500002503395081)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp
    colorramp = snowy_water.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.4818180799484253
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.6363638639450073)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = snowy_water.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.4272727966308594
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5363641977310181)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = snowy_water.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.45454537868499756
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.7272729873657227)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Noise Texture
    noise_texture = snowy_water.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Roughness
    noise_texture.inputs[4].default_value = 0.7333333492279053
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix
    mix = snowy_water.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.10000000149011612
    
    #node Noise Texture.001
    noise_texture_001 = snowy_water.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Vector
    noise_texture_001.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Detail
    noise_texture_001.inputs[3].default_value = 2.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.5
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Math
    math = snowy_water.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 4.0
    
    #node Texture Coordinate
    texture_coordinate = snowy_water.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Invert
    invert = snowy_water.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.002
    math_002 = snowy_water.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.5
    
    #node Math.001
    math_001 = snowy_water.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = 2.0
    
    #node Group Output
    group_output = snowy_water.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #snowy_water outputs
    #output Shader
    snowy_water.outputs.new('NodeSocketShader', "Shader")
    snowy_water.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    snowy_water.outputs.new('NodeSocketColor', "Albedo")
    snowy_water.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    snowy_water.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    snowy_water.outputs.new('NodeSocketFloat', "Mask")
    snowy_water.outputs[2].default_value = 0.0
    snowy_water.outputs[2].min_value = -3.4028234663852886e+38
    snowy_water.outputs[2].max_value = 3.4028234663852886e+38
    snowy_water.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    snowy_water.outputs.new('NodeSocketVector', "Normal")
    snowy_water.outputs[3].default_value = (0.0, 0.0, 0.0)
    snowy_water.outputs[3].min_value = -3.4028234663852886e+38
    snowy_water.outputs[3].max_value = 3.4028234663852886e+38
    snowy_water.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Hue Saturation Value
    hue_saturation_value = snowy_water.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = snowy_water.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = snowy_water.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = snowy_water.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #snowy_water inputs
    #input Color Hue
    snowy_water.inputs.new('NodeSocketFloatFactor', "Color Hue")
    snowy_water.inputs[0].default_value = 1.0
    snowy_water.inputs[0].min_value = 0.0
    snowy_water.inputs[0].max_value = 1.0
    snowy_water.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    snowy_water.inputs.new('NodeSocketFloat', "Scale")
    snowy_water.inputs[1].default_value = 0.5
    snowy_water.inputs[1].min_value = -10000.0
    snowy_water.inputs[1].max_value = 10000.0
    snowy_water.inputs[1].attribute_domain = 'POINT'
    
    #input Detail
    snowy_water.inputs.new('NodeSocketFloat', "Detail")
    snowy_water.inputs[2].default_value = 2.0
    snowy_water.inputs[2].min_value = 0.0
    snowy_water.inputs[2].max_value = 15.0
    snowy_water.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    snowy_water.inputs.new('NodeSocketFloat', "Saturation")
    snowy_water.inputs[3].default_value = 1.0
    snowy_water.inputs[3].min_value = 0.0
    snowy_water.inputs[3].max_value = 2.0
    snowy_water.inputs[3].attribute_domain = 'POINT'
    
    #input Brightness
    snowy_water.inputs.new('NodeSocketFloat', "Brightness")
    snowy_water.inputs[4].default_value = 1.0
    snowy_water.inputs[4].min_value = 0.0
    snowy_water.inputs[4].max_value = 2.0
    snowy_water.inputs[4].attribute_domain = 'POINT'
    
    #input Roughness
    snowy_water.inputs.new('NodeSocketFloatFactor', "Roughness")
    snowy_water.inputs[5].default_value = 0.0
    snowy_water.inputs[5].min_value = 0.0
    snowy_water.inputs[5].max_value = 1.0
    snowy_water.inputs[5].attribute_domain = 'POINT'
    
    #input IOR
    snowy_water.inputs.new('NodeSocketFloat', "IOR")
    snowy_water.inputs[6].default_value = 1.4500000476837158
    snowy_water.inputs[6].min_value = 0.0
    snowy_water.inputs[6].max_value = 1000.0
    snowy_water.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    snowy_water.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    snowy_water.inputs[7].default_value = 0.30000001192092896
    snowy_water.inputs[7].min_value = 0.0
    snowy_water.inputs[7].max_value = 1.0
    snowy_water.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    snowy_water.inputs.new('NodeSocketVector', "Normal")
    snowy_water.inputs[8].default_value = (0.0, 0.0, 0.0)
    snowy_water.inputs[8].min_value = -1.0
    snowy_water.inputs[8].max_value = 1.0
    snowy_water.inputs[8].attribute_domain = 'POINT'
    snowy_water.inputs[8].hide_value = True
    
    
    
    
    #Set locations
    colorramp_003.location = (779.8984375, 341.161376953125)
    colorramp.location = (459.8984375, 172.8917236328125)
    colorramp_001.location = (459.8984375, -67.1082763671875)
    colorramp_002.location = (559.8984375, -249.36480712890625)
    noise_texture.location = (-0.1015625, 12.89166259765625)
    mix.location = (-240.1015625, -7.1082763671875)
    noise_texture_001.location = (-520.1015014648438, -247.1082763671875)
    math.location = (-957.1015014648438, -7.1082763671875)
    texture_coordinate.location = (-660.0, 0.0)
    invert.location = (-480.0, 260.0000305175781)
    math_002.location = (-44.658935546875, 314.1139221191406)
    math_001.location = (-957.1015014648438, -167.1082763671875)
    group_output.location = (1619.8984375, 45.89825439453125)
    hue_saturation_value.location = (1100.0, 312.38409423828125)
    principled_bsdf.location = (1329.8984375, 192.89178466796875)
    bump.location = (879.8984375, -207.1082763671875)
    group_input.location = (-1157.1015625, 45.89825439453125)
    
    #Set dimensions
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize snowy_water links
    #principled_bsdf.BSDF -> group_output.Shader
    snowy_water.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    snowy_water.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    snowy_water.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> colorramp_001.Fac
    snowy_water.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #colorramp_001.Color -> principled_bsdf.Transmission
    snowy_water.links.new(colorramp_001.outputs[0], principled_bsdf.inputs[17])
    #colorramp.Color -> principled_bsdf.Roughness
    snowy_water.links.new(colorramp.outputs[0], principled_bsdf.inputs[9])
    #colorramp_002.Color -> bump.Height
    snowy_water.links.new(colorramp_002.outputs[0], bump.inputs[2])
    #noise_texture.Fac -> colorramp_002.Fac
    snowy_water.links.new(noise_texture.outputs[0], colorramp_002.inputs[0])
    #noise_texture.Fac -> colorramp_003.Fac
    snowy_water.links.new(noise_texture.outputs[0], colorramp_003.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    snowy_water.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #mix.Result -> noise_texture.Vector
    snowy_water.links.new(mix.outputs[2], noise_texture.inputs[0])
    #texture_coordinate.Object -> mix.A
    snowy_water.links.new(texture_coordinate.outputs[3], mix.inputs[6])
    #noise_texture_001.Color -> mix.B
    snowy_water.links.new(noise_texture_001.outputs[1], mix.inputs[7])
    #math.Value -> noise_texture.Scale
    snowy_water.links.new(math.outputs[0], noise_texture.inputs[2])
    #math_001.Value -> noise_texture_001.Scale
    snowy_water.links.new(math_001.outputs[0], noise_texture_001.inputs[2])
    #group_input.Scale -> math.Value
    snowy_water.links.new(group_input.outputs[1], math.inputs[1])
    #group_input.Scale -> math_001.Value
    snowy_water.links.new(group_input.outputs[1], math_001.inputs[1])
    #colorramp_003.Color -> hue_saturation_value.Color
    snowy_water.links.new(colorramp_003.outputs[0], hue_saturation_value.inputs[4])
    #group_input.Color Hue -> invert.Fac
    snowy_water.links.new(group_input.outputs[0], invert.inputs[0])
    #math_002.Value -> hue_saturation_value.Hue
    snowy_water.links.new(math_002.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math_002.Value
    snowy_water.links.new(invert.outputs[0], math_002.inputs[0])
    #group_input.Brightness -> hue_saturation_value.Value
    snowy_water.links.new(group_input.outputs[4], hue_saturation_value.inputs[2])
    #group_input.Saturation -> hue_saturation_value.Saturation
    snowy_water.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Roughness -> principled_bsdf.Transmission Roughness
    snowy_water.links.new(group_input.outputs[5], principled_bsdf.inputs[18])
    #group_input.Detail -> noise_texture.Detail
    snowy_water.links.new(group_input.outputs[2], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    snowy_water.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    snowy_water.links.new(group_input.outputs[8], bump.inputs[3])
    #group_input.IOR -> principled_bsdf.IOR
    snowy_water.links.new(group_input.outputs[6], principled_bsdf.inputs[16])
    #noise_texture.Fac -> group_output.Mask
    snowy_water.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    snowy_water.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    snowy_water.links.new(bump.outputs[0], group_output.inputs[3])
    return snowy_water

snowy_water = snowy_water_node_group()

#initialize Snowy Water node group
def snowy_water_1_node_group():

    snowy_water_1 = mat.node_tree
    #start with a clean node tree
    for node in snowy_water_1.nodes:
        snowy_water_1.nodes.remove(node)
    #initialize snowy_water_1 nodes
    #node Material Output
    material_output = snowy_water_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Snowy Water
    snowy_water_2 = snowy_water_1.nodes.new("ShaderNodeGroup")
    snowy_water_2.label = "Snowy Water"
    snowy_water_2.name = "Snowy Water"
    snowy_water_2.use_custom_color = True
    snowy_water_2.color = (0.05368918925523758, 0.11709138005971909, 0.1473141759634018)
    snowy_water_2.node_tree = snowy_water
    #Input_2
    snowy_water_2.inputs[0].default_value = 0.0
    #Input_1
    snowy_water_2.inputs[1].default_value = 1.0
    #Input_9
    snowy_water_2.inputs[2].default_value = 8.0
    #Input_4
    snowy_water_2.inputs[3].default_value = 1.0
    #Input_3
    snowy_water_2.inputs[4].default_value = 1.0
    #Input_7
    snowy_water_2.inputs[5].default_value = 0.0
    #Input_12
    snowy_water_2.inputs[6].default_value = 1.3300000429153442
    #Input_10
    snowy_water_2.inputs[7].default_value = 0.15000000596046448
    #Input_11
    snowy_water_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (670.56884765625, 39.12353515625)
    snowy_water_2.location = (387.89404296875, 39.12353515625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    snowy_water_2.width, snowy_water_2.height = 166.6754150390625, 100.0
    
    #initialize snowy_water_1 links
    #snowy_water_2.Shader -> material_output.Surface
    snowy_water_1.links.new(snowy_water_2.outputs[0], material_output.inputs[0])
    return snowy_water_1

snowy_water_1 = snowy_water_1_node_group()

