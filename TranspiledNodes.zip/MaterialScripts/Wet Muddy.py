import bpy, mathutils

mat = bpy.data.materials.new(name = "Wet Muddy")
mat.use_nodes = True
#initialize wet_muddy node group
def wet_muddy_node_group():

    wet_muddy = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "wet_muddy")
    
    #initialize wet_muddy nodes
    #node Bump
    bump = wet_muddy.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp.003
    colorramp_003 = wet_muddy.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.44090890884399414
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.6909093856811523)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.004
    colorramp_004 = wet_muddy.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.3318181037902832
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(0.5227277278900146)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Vector Math.018
    vector_math_018 = wet_muddy.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node ColorRamp.002
    colorramp_002 = wet_muddy.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.44090890884399414
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.5000004768371582)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = wet_muddy.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #A_Color
    mix.inputs[6].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Principled BSDF
    principled_bsdf = wet_muddy.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = wet_muddy.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #wet_muddy outputs
    #output BSDF
    wet_muddy.outputs.new('NodeSocketShader', "BSDF")
    wet_muddy.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    wet_muddy.outputs.new('NodeSocketColor', "Albedo")
    wet_muddy.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    wet_muddy.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    wet_muddy.outputs.new('NodeSocketColor', "Mask")
    wet_muddy.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    wet_muddy.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node ColorRamp
    colorramp = wet_muddy.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.4454544186592102
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.005568232852965593, 0.003973093815147877, 0.0031143338419497013, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.04302739351987839, 0.02301127463579178, 0.014748882502317429, 1.0)

    
    #node Hue Saturation Value
    hue_saturation_value = wet_muddy.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = wet_muddy.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Math
    math = wet_muddy.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Noise Texture
    noise_texture = wet_muddy.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 2.5
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix.002
    mix_002 = wet_muddy.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'DODGE'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #B_Color
    mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = wet_muddy.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Math.001
    math_001 = wet_muddy.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    
    #node Math.002
    math_002 = wet_muddy.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.7300000190734863
    
    #node Group Input
    group_input = wet_muddy.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #wet_muddy inputs
    #input Scale
    wet_muddy.inputs.new('NodeSocketFloat', "Scale")
    wet_muddy.inputs[0].default_value = 1.0
    wet_muddy.inputs[0].min_value = -10000.0
    wet_muddy.inputs[0].max_value = 10000.0
    wet_muddy.inputs[0].attribute_domain = 'POINT'
    
    #input Land Addition
    wet_muddy.inputs.new('NodeSocketFloatFactor', "Land Addition")
    wet_muddy.inputs[1].default_value = 1.0
    wet_muddy.inputs[1].min_value = 0.0
    wet_muddy.inputs[1].max_value = 1.0
    wet_muddy.inputs[1].attribute_domain = 'POINT'
    
    #input Land Subtraction
    wet_muddy.inputs.new('NodeSocketFloatFactor', "Land Subtraction")
    wet_muddy.inputs[2].default_value = 0.0
    wet_muddy.inputs[2].min_value = 0.0
    wet_muddy.inputs[2].max_value = 1.0
    wet_muddy.inputs[2].attribute_domain = 'POINT'
    
    #input Color Hue
    wet_muddy.inputs.new('NodeSocketFloatFactor', "Color Hue")
    wet_muddy.inputs[3].default_value = 1.0
    wet_muddy.inputs[3].min_value = 0.0
    wet_muddy.inputs[3].max_value = 1.0
    wet_muddy.inputs[3].attribute_domain = 'POINT'
    
    #input Saturation
    wet_muddy.inputs.new('NodeSocketFloat', "Saturation")
    wet_muddy.inputs[4].default_value = 1.0
    wet_muddy.inputs[4].min_value = 0.0
    wet_muddy.inputs[4].max_value = 2.0
    wet_muddy.inputs[4].attribute_domain = 'POINT'
    
    #input Brightness
    wet_muddy.inputs.new('NodeSocketFloat', "Brightness")
    wet_muddy.inputs[5].default_value = 1.0
    wet_muddy.inputs[5].min_value = 0.0
    wet_muddy.inputs[5].max_value = 2.0
    wet_muddy.inputs[5].attribute_domain = 'POINT'
    
    #input Detail
    wet_muddy.inputs.new('NodeSocketFloat', "Detail")
    wet_muddy.inputs[6].default_value = 10.0
    wet_muddy.inputs[6].min_value = 0.0
    wet_muddy.inputs[6].max_value = 15.0
    wet_muddy.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    wet_muddy.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    wet_muddy.inputs[7].default_value = 0.30000001192092896
    wet_muddy.inputs[7].min_value = 0.0
    wet_muddy.inputs[7].max_value = 1.0
    wet_muddy.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    wet_muddy.inputs.new('NodeSocketVector', "Normal")
    wet_muddy.inputs[8].default_value = (0.0, 0.0, 0.0)
    wet_muddy.inputs[8].min_value = -1.0
    wet_muddy.inputs[8].max_value = 1.0
    wet_muddy.inputs[8].attribute_domain = 'POINT'
    wet_muddy.inputs[8].hide_value = True
    
    
    
    #node Mix.001
    mix_001 = wet_muddy.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'BURN'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #B_Color
    mix_001.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    
    #Set locations
    bump.location = (570.2288818359375, -182.865478515625)
    colorramp_003.location = (190.2288818359375, -362.865478515625)
    colorramp_004.location = (210.2288818359375, 77.13449096679688)
    vector_math_018.location = (-509.7711181640625, 37.134521484375)
    colorramp_002.location = (196.6029052734375, -150.08961486816406)
    mix.location = (490.2288818359375, 362.865478515625)
    principled_bsdf.location = (849.7711181640625, 297.134521484375)
    group_output.location = (1139.7711181640625, -0.0)
    colorramp.location = (-60.0, 320.0)
    hue_saturation_value.location = (260.0000305175781, 320.0)
    invert.location = (-500.0, 280.0)
    math.location = (-265.28851318359375, 347.679443359375)
    noise_texture.location = (-320.0, 0.0)
    mix_002.location = (-160.0, 20.0)
    texture_coordinate_001.location = (-849.7711181640625, -42.865478515625)
    math_001.location = (-860.0, -460.0)
    math_002.location = (-860.0, -320.0)
    group_input.location = (-1080.0, -6.103515625e-05)
    mix_001.location = (-0.62432861328125, 88.26449584960938)
    
    #Set dimensions
    bump.width, bump.height = 140.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    
    #initialize wet_muddy links
    #principled_bsdf.BSDF -> group_output.BSDF
    wet_muddy.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    wet_muddy.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #colorramp_002.Color -> principled_bsdf.Roughness
    wet_muddy.links.new(colorramp_002.outputs[0], principled_bsdf.inputs[9])
    #bump.Normal -> principled_bsdf.Normal
    wet_muddy.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp_003.Color -> bump.Height
    wet_muddy.links.new(colorramp_003.outputs[0], bump.inputs[2])
    #noise_texture.Fac -> mix_002.A
    wet_muddy.links.new(noise_texture.outputs[0], mix_002.inputs[6])
    #colorramp_004.Color -> mix.Factor
    wet_muddy.links.new(colorramp_004.outputs[0], mix.inputs[0])
    #colorramp.Color -> hue_saturation_value.Color
    wet_muddy.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    wet_muddy.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    wet_muddy.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    wet_muddy.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #hue_saturation_value.Color -> mix.B
    wet_muddy.links.new(hue_saturation_value.outputs[0], mix.inputs[7])
    #group_input.Color Hue -> invert.Fac
    wet_muddy.links.new(group_input.outputs[3], invert.inputs[0])
    #invert.Color -> math.Value
    wet_muddy.links.new(invert.outputs[0], math.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    wet_muddy.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    wet_muddy.links.new(group_input.outputs[4], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    wet_muddy.links.new(group_input.outputs[5], hue_saturation_value.inputs[2])
    #group_input.Detail -> noise_texture.Detail
    wet_muddy.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    wet_muddy.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    wet_muddy.links.new(group_input.outputs[8], bump.inputs[3])
    #mix_001.Result -> colorramp_004.Fac
    wet_muddy.links.new(mix_001.outputs[2], colorramp_004.inputs[0])
    #mix_001.Result -> colorramp.Fac
    wet_muddy.links.new(mix_001.outputs[2], colorramp.inputs[0])
    #mix_001.Result -> colorramp_002.Fac
    wet_muddy.links.new(mix_001.outputs[2], colorramp_002.inputs[0])
    #mix_001.Result -> colorramp_003.Fac
    wet_muddy.links.new(mix_001.outputs[2], colorramp_003.inputs[0])
    #mix_002.Result -> mix_001.A
    wet_muddy.links.new(mix_002.outputs[2], mix_001.inputs[6])
    #group_input.Land Addition -> math_002.Value
    wet_muddy.links.new(group_input.outputs[1], math_002.inputs[0])
    #group_input.Land Subtraction -> math_001.Value
    wet_muddy.links.new(group_input.outputs[2], math_001.inputs[0])
    #math_001.Value -> mix_001.Factor
    wet_muddy.links.new(math_001.outputs[0], mix_001.inputs[0])
    #math_002.Value -> mix_002.Factor
    wet_muddy.links.new(math_002.outputs[0], mix_002.inputs[0])
    #mix_001.Result -> group_output.Mask
    wet_muddy.links.new(mix_001.outputs[2], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    wet_muddy.links.new(mix.outputs[2], group_output.inputs[1])
    return wet_muddy

wet_muddy = wet_muddy_node_group()

#initialize Wet Muddy node group
def wet_muddy_1_node_group():

    wet_muddy_1 = mat.node_tree
    #start with a clean node tree
    for node in wet_muddy_1.nodes:
        wet_muddy_1.nodes.remove(node)
    #initialize wet_muddy_1 nodes
    #node Material Output
    material_output = wet_muddy_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node wet_muddy
    wet_muddy_2 = wet_muddy_1.nodes.new("ShaderNodeGroup")
    wet_muddy_2.label = "wet_muddy"
    wet_muddy_2.name = "wet_muddy"
    wet_muddy_2.node_tree = wet_muddy
    #Input_1
    wet_muddy_2.inputs[0].default_value = 1.0
    #Input_15
    wet_muddy_2.inputs[1].default_value = 0.0
    #Input_16
    wet_muddy_2.inputs[2].default_value = 0.0
    #Input_9
    wet_muddy_2.inputs[3].default_value = 0.0
    #Input_10
    wet_muddy_2.inputs[4].default_value = 1.0
    #Input_11
    wet_muddy_2.inputs[5].default_value = 1.0
    #Input_12
    wet_muddy_2.inputs[6].default_value = 15.0
    #Input_13
    wet_muddy_2.inputs[7].default_value = 0.30000001192092896
    #Input_14
    wet_muddy_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (672.97314453125, 91.27099609375)
    wet_muddy_2.location = (413.431640625, 91.27099609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    wet_muddy_2.width, wet_muddy_2.height = 166.67333984375, 100.0
    
    #initialize wet_muddy_1 links
    #wet_muddy_2.BSDF -> material_output.Surface
    wet_muddy_1.links.new(wet_muddy_2.outputs[0], material_output.inputs[0])
    return wet_muddy_1

wet_muddy_1 = wet_muddy_1_node_group()

