import bpy, mathutils

mat = bpy.data.materials.new(name = "Basic Shiny")
mat.use_nodes = True
#initialize Basic_shiny node group
def basic_shiny_node_group():

    basic_shiny = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Basic_shiny")
    
    #initialize basic_shiny nodes
    #node Principled BSDF
    principled_bsdf = basic_shiny.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.23181818425655365
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Shader to RGB
    shader_to_rgb = basic_shiny.nodes.new("ShaderNodeShaderToRGB")
    shader_to_rgb.name = "Shader to RGB"
    
    #node ColorRamp
    colorramp = basic_shiny.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.13181816041469574)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.034212928265333176, 0.034212928265333176, 0.034212928265333176, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.4318182170391083)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Group Output
    group_output = basic_shiny.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #basic_shiny outputs
    #output Color
    basic_shiny.outputs.new('NodeSocketColor', "Color")
    basic_shiny.outputs[0].default_value = (0.0, 0.0, 0.0, 0.0)
    basic_shiny.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Mix.001
    mix_001 = basic_shiny.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #B_Color
    mix_001.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix
    mix = basic_shiny.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'COLOR'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Group Input
    group_input = basic_shiny.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #basic_shiny inputs
    #input Color
    basic_shiny.inputs.new('NodeSocketColor', "Color")
    basic_shiny.inputs[0].default_value = (0.5, 0.5, 0.5, 1.0)
    basic_shiny.inputs[0].attribute_domain = 'POINT'
    
    #input Saturation
    basic_shiny.inputs.new('NodeSocketFloatFactor', "Saturation")
    basic_shiny.inputs[1].default_value = 0.5
    basic_shiny.inputs[1].min_value = 0.0
    basic_shiny.inputs[1].max_value = 1.0
    basic_shiny.inputs[1].attribute_domain = 'POINT'
    
    #input Darkening
    basic_shiny.inputs.new('NodeSocketFloatFactor', "Darkening")
    basic_shiny.inputs[2].default_value = 0.5
    basic_shiny.inputs[2].min_value = 0.0
    basic_shiny.inputs[2].max_value = 1.0
    basic_shiny.inputs[2].attribute_domain = 'POINT'
    
    #input Light Threshold
    basic_shiny.inputs.new('NodeSocketFloat', "Light Threshold")
    basic_shiny.inputs[3].default_value = 1.0
    basic_shiny.inputs[3].min_value = 0.0
    basic_shiny.inputs[3].max_value = 1000.0
    basic_shiny.inputs[3].attribute_domain = 'POINT'
    
    #input Normal
    basic_shiny.inputs.new('NodeSocketVector', "Normal")
    basic_shiny.inputs[4].default_value = (0.0, 0.0, 0.0)
    basic_shiny.inputs[4].min_value = -3.4028234663852886e+38
    basic_shiny.inputs[4].max_value = 3.4028234663852886e+38
    basic_shiny.inputs[4].attribute_domain = 'POINT'
    basic_shiny.inputs[4].hide_value = True
    
    
    
    
    #Set locations
    principled_bsdf.location = (-626.411376953125, -43.300872802734375)
    shader_to_rgb.location = (-306.411376953125, -23.300872802734375)
    colorramp.location = (7.7451171875, 37.055267333984375)
    group_output.location = (816.411376953125, -0.0)
    mix_001.location = (626.411376953125, 43.30084228515625)
    mix.location = (403.0986328125, 34.2515869140625)
    group_input.location = (-1200.0, -40.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize basic_shiny links
    #mix_001.Result -> group_output.Color
    basic_shiny.links.new(mix_001.outputs[2], group_output.inputs[0])
    #principled_bsdf.BSDF -> shader_to_rgb.Shader
    basic_shiny.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
    #shader_to_rgb.Color -> colorramp.Fac
    basic_shiny.links.new(shader_to_rgb.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> mix.A
    basic_shiny.links.new(colorramp.outputs[0], mix.inputs[6])
    #mix.Result -> mix_001.A
    basic_shiny.links.new(mix.outputs[2], mix_001.inputs[6])
    #group_input.Color -> mix.B
    basic_shiny.links.new(group_input.outputs[0], mix.inputs[7])
    #group_input.Saturation -> mix.Factor
    basic_shiny.links.new(group_input.outputs[1], mix.inputs[0])
    #group_input.Darkening -> mix_001.Factor
    basic_shiny.links.new(group_input.outputs[2], mix_001.inputs[0])
    #group_input.Light Threshold -> principled_bsdf.Base Color
    basic_shiny.links.new(group_input.outputs[3], principled_bsdf.inputs[0])
    #group_input.Light Threshold -> principled_bsdf.Specular
    basic_shiny.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Normal -> principled_bsdf.Normal
    basic_shiny.links.new(group_input.outputs[4], principled_bsdf.inputs[22])
    return basic_shiny

basic_shiny = basic_shiny_node_group()

#initialize Basic Shiny node group
def basic_shiny_1_node_group():

    basic_shiny_1 = mat.node_tree
    #start with a clean node tree
    for node in basic_shiny_1.nodes:
        basic_shiny_1.nodes.remove(node)
    #initialize basic_shiny_1 nodes
    #node Material Output
    material_output = basic_shiny_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Basic_shiny
    basic_shiny_2 = basic_shiny_1.nodes.new("ShaderNodeGroup")
    basic_shiny_2.label = "Basic_shiny"
    basic_shiny_2.name = "Basic_shiny"
    basic_shiny_2.node_tree = basic_shiny
    #Input_1
    basic_shiny_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_2
    basic_shiny_2.inputs[1].default_value = 0.5
    #Input_3
    basic_shiny_2.inputs[2].default_value = 0.5
    #Input_4
    basic_shiny_2.inputs[3].default_value = 1.0
    #Input_5
    basic_shiny_2.inputs[4].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (677.2411499023438, 107.06201171875)
    basic_shiny_2.location = (417.8398742675781, 107.06201171875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    basic_shiny_2.width, basic_shiny_2.height = 179.40127563476562, 100.0
    
    #initialize basic_shiny_1 links
    #basic_shiny_2.Color -> material_output.Surface
    basic_shiny_1.links.new(basic_shiny_2.outputs[0], material_output.inputs[0])
    return basic_shiny_1

basic_shiny_1 = basic_shiny_1_node_group()

