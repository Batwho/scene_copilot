import bpy, mathutils

mat = bpy.data.materials.new(name = "Water Smal")
mat.use_nodes = True
#initialize Water smal node group
def water_smal_node_group():

    water_smal = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Water smal")
    
    #initialize water_smal nodes
    #node Group Output
    group_output = water_smal.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #water_smal outputs
    #output BSDF
    water_smal.outputs.new('NodeSocketShader', "BSDF")
    water_smal.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    water_smal.outputs.new('NodeSocketFloat', "Mask")
    water_smal.outputs[1].default_value = 0.0
    water_smal.outputs[1].min_value = -3.4028234663852886e+38
    water_smal.outputs[1].max_value = 3.4028234663852886e+38
    water_smal.outputs[1].attribute_domain = 'POINT'
    
    #output Normal
    water_smal.outputs.new('NodeSocketVector', "Normal")
    water_smal.outputs[2].default_value = (0.0, 0.0, 0.0)
    water_smal.outputs[2].min_value = -3.4028234663852886e+38
    water_smal.outputs[2].max_value = 3.4028234663852886e+38
    water_smal.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = water_smal.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Math
    math = water_smal.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 3.9000000953674316
    
    #node Group Input
    group_input = water_smal.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #water_smal inputs
    #input Color
    water_smal.inputs.new('NodeSocketColor', "Color")
    water_smal.inputs[0].default_value = (0.5593096017837524, 0.8119493722915649, 1.0, 1.0)
    water_smal.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    water_smal.inputs.new('NodeSocketFloat', "Scale")
    water_smal.inputs[1].default_value = 0.5
    water_smal.inputs[1].min_value = -10000.0
    water_smal.inputs[1].max_value = 10000.0
    water_smal.inputs[1].attribute_domain = 'POINT'
    
    #input Detail
    water_smal.inputs.new('NodeSocketFloat', "Detail")
    water_smal.inputs[2].default_value = 2.0
    water_smal.inputs[2].min_value = 0.0
    water_smal.inputs[2].max_value = 15.0
    water_smal.inputs[2].attribute_domain = 'POINT'
    
    #input Outer Roughness
    water_smal.inputs.new('NodeSocketFloatFactor', "Outer Roughness")
    water_smal.inputs[3].default_value = 0.0
    water_smal.inputs[3].min_value = 0.0
    water_smal.inputs[3].max_value = 1.0
    water_smal.inputs[3].attribute_domain = 'POINT'
    
    #input Inner Roughness
    water_smal.inputs.new('NodeSocketFloatFactor', "Inner Roughness")
    water_smal.inputs[4].default_value = 0.0
    water_smal.inputs[4].min_value = 0.0
    water_smal.inputs[4].max_value = 1.0
    water_smal.inputs[4].attribute_domain = 'POINT'
    
    #input IOR
    water_smal.inputs.new('NodeSocketFloat', "IOR")
    water_smal.inputs[5].default_value = 1.4500000476837158
    water_smal.inputs[5].min_value = 0.0
    water_smal.inputs[5].max_value = 1000.0
    water_smal.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    water_smal.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    water_smal.inputs[6].default_value = 0.20000000298023224
    water_smal.inputs[6].min_value = 0.0
    water_smal.inputs[6].max_value = 1.0
    water_smal.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    water_smal.inputs.new('NodeSocketVector', "Normal")
    water_smal.inputs[7].default_value = (0.0, 0.0, 0.0)
    water_smal.inputs[7].min_value = -1.0
    water_smal.inputs[7].max_value = 1.0
    water_smal.inputs[7].attribute_domain = 'POINT'
    water_smal.inputs[7].hide_value = True
    
    
    
    #node Noise Texture
    noise_texture = water_smal.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Vector
    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Roughness
    noise_texture.inputs[4].default_value = 0.5666666626930237
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Bump
    bump = water_smal.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    group_output.location = (830.0, -0.0)
    principled_bsdf.location = (540.0, 210.0)
    math.location = (-380.0, -110.0)
    group_input.location = (-580.0, -0.0)
    noise_texture.location = (-20.0, -210.0)
    bump.location = (320.0, -209.75051879882812)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize water_smal links
    #principled_bsdf.BSDF -> group_output.BSDF
    water_smal.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    water_smal.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    water_smal.links.new(noise_texture.outputs[0], bump.inputs[2])
    #math.Value -> noise_texture.Scale
    water_smal.links.new(math.outputs[0], noise_texture.inputs[2])
    #group_input.Color -> principled_bsdf.Base Color
    water_smal.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Scale -> math.Value
    water_smal.links.new(group_input.outputs[1], math.inputs[1])
    #group_input.Outer Roughness -> principled_bsdf.Roughness
    water_smal.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Inner Roughness -> principled_bsdf.Transmission Roughness
    water_smal.links.new(group_input.outputs[4], principled_bsdf.inputs[18])
    #group_input.IOR -> principled_bsdf.IOR
    water_smal.links.new(group_input.outputs[5], principled_bsdf.inputs[16])
    #group_input.Bump Strength -> bump.Strength
    water_smal.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Detail -> noise_texture.Detail
    water_smal.links.new(group_input.outputs[2], noise_texture.inputs[3])
    #group_input.Normal -> bump.Normal
    water_smal.links.new(group_input.outputs[7], bump.inputs[3])
    #noise_texture.Fac -> group_output.Mask
    water_smal.links.new(noise_texture.outputs[0], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    water_smal.links.new(bump.outputs[0], group_output.inputs[2])
    return water_smal

water_smal = water_smal_node_group()

#initialize Water Smal node group
def water_smal_1_node_group():

    water_smal_1 = mat.node_tree
    #start with a clean node tree
    for node in water_smal_1.nodes:
        water_smal_1.nodes.remove(node)
    #initialize water_smal_1 nodes
    #node Material Output
    material_output = water_smal_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Water smal
    water_smal_2 = water_smal_1.nodes.new("ShaderNodeGroup")
    water_smal_2.label = "Water smal"
    water_smal_2.name = "Water smal"
    water_smal_2.use_custom_color = True
    water_smal_2.color = (0.08006712049245834, 0.18339265882968903, 0.23955239355564117)
    water_smal_2.node_tree = water_smal
    #Input_1
    water_smal_2.inputs[0].default_value = (0.5593096017837524, 0.8119493722915649, 1.0, 1.0)
    #Input_2
    water_smal_2.inputs[1].default_value = 1.0
    #Input_7
    water_smal_2.inputs[2].default_value = 2.0
    #Input_3
    water_smal_2.inputs[3].default_value = 0.0
    #Input_4
    water_smal_2.inputs[4].default_value = 0.0
    #Input_5
    water_smal_2.inputs[5].default_value = 1.4500000476837158
    #Input_6
    water_smal_2.inputs[6].default_value = 0.20000000298023224
    #Input_9
    water_smal_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (719.90185546875, 43.86474609375)
    water_smal_2.location = (439.90234375, 43.86474609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    water_smal_2.width, water_smal_2.height = 181.49697875976562, 100.0
    
    #initialize water_smal_1 links
    #water_smal_2.BSDF -> material_output.Surface
    water_smal_1.links.new(water_smal_2.outputs[0], material_output.inputs[0])
    return water_smal_1

water_smal_1 = water_smal_1_node_group()

