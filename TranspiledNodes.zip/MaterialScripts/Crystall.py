import bpy, mathutils

mat = bpy.data.materials.new(name = "Crystall")
mat.use_nodes = True
#initialize Crystall node group
def crystall_node_group():

    crystall = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Crystall")
    
    #initialize crystall nodes
    #node Principled BSDF
    principled_bsdf = crystall.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = crystall.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.2600000202655792
    
    #node Math
    math = crystall.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 8.0
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Group Output
    group_output = crystall.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #crystall outputs
    #output BSDF
    crystall.outputs.new('NodeSocketShader', "BSDF")
    crystall.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    crystall.outputs.new('NodeSocketColor', "Albedo")
    crystall.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    crystall.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    crystall.outputs.new('NodeSocketFloat', "Mask")
    crystall.outputs[2].default_value = 0.0
    crystall.outputs[2].min_value = -3.4028234663852886e+38
    crystall.outputs[2].max_value = 3.4028234663852886e+38
    crystall.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    crystall.outputs.new('NodeSocketVector', "Normal")
    crystall.outputs[3].default_value = (0.0, 0.0, 0.0)
    crystall.outputs[3].min_value = -3.4028234663852886e+38
    crystall.outputs[3].max_value = 3.4028234663852886e+38
    crystall.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Invert
    invert = crystall.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Invert.001
    invert_001 = crystall.nodes.new("ShaderNodeInvert")
    invert_001.name = "Invert.001"
    #Fac
    invert_001.inputs[0].default_value = 1.0
    
    #node Group Input
    group_input = crystall.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #crystall inputs
    #input Color1
    crystall.inputs.new('NodeSocketColor', "Color1")
    crystall.inputs[0].default_value = (0.5, 0.5, 0.5, 1.0)
    crystall.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    crystall.inputs.new('NodeSocketColor', "Color2")
    crystall.inputs[1].default_value = (0.5, 0.5, 0.5, 1.0)
    crystall.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    crystall.inputs.new('NodeSocketFloat', "Scale")
    crystall.inputs[2].default_value = 0.5
    crystall.inputs[2].min_value = -10000.0
    crystall.inputs[2].max_value = 10000.0
    crystall.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    crystall.inputs.new('NodeSocketFloatFactor', "Roughness")
    crystall.inputs[3].default_value = 0.0
    crystall.inputs[3].min_value = 0.0
    crystall.inputs[3].max_value = 1.0
    crystall.inputs[3].attribute_domain = 'POINT'
    
    #input Randomness
    crystall.inputs.new('NodeSocketFloatFactor', "Randomness")
    crystall.inputs[4].default_value = 1.0
    crystall.inputs[4].min_value = 0.0
    crystall.inputs[4].max_value = 1.0
    crystall.inputs[4].attribute_domain = 'POINT'
    
    #input IOR
    crystall.inputs.new('NodeSocketFloat', "IOR")
    crystall.inputs[5].default_value = 1.4500000476837158
    crystall.inputs[5].min_value = 0.0
    crystall.inputs[5].max_value = 1000.0
    crystall.inputs[5].attribute_domain = 'POINT'
    
    #input Bump strength
    crystall.inputs.new('NodeSocketFloatFactor', "Bump strength")
    crystall.inputs[6].default_value = 1.0
    crystall.inputs[6].min_value = 0.0
    crystall.inputs[6].max_value = 1.0
    crystall.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    crystall.inputs.new('NodeSocketVector', "Normal")
    crystall.inputs[7].default_value = (0.0, 0.0, 0.0)
    crystall.inputs[7].min_value = -1.0
    crystall.inputs[7].max_value = 1.0
    crystall.inputs[7].attribute_domain = 'POINT'
    crystall.inputs[7].hide_value = True
    
    
    
    #node ColorRamp
    colorramp = crystall.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.4090912342071533)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = crystall.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = crystall.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    principled_bsdf.location = (518.5, 63.633514404296875)
    voronoi_texture.location = (-298.5, -56.36647033691406)
    math.location = (-518.5, 3.633514404296875)
    group_output.location = (808.5, -0.0)
    invert.location = (-220.0, -280.0)
    invert_001.location = (0.0, -282.8382263183594)
    group_input.location = (-718.5, -0.0)
    colorramp.location = (-80.0, 171.83502197265625)
    mix.location = (199.99993896484375, 100.0)
    bump.location = (255.14727783203125, -118.39306640625)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    invert_001.width, invert_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize crystall links
    #principled_bsdf.BSDF -> group_output.BSDF
    crystall.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    crystall.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Distance -> bump.Height
    crystall.links.new(voronoi_texture.outputs[0], bump.inputs[2])
    #voronoi_texture.Distance -> colorramp.Fac
    crystall.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    crystall.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #math.Value -> voronoi_texture.Scale
    crystall.links.new(math.outputs[0], voronoi_texture.inputs[2])
    #group_input.Scale -> math.Value
    crystall.links.new(group_input.outputs[2], math.inputs[1])
    #group_input.Roughness -> principled_bsdf.Transmission Roughness
    crystall.links.new(group_input.outputs[3], principled_bsdf.inputs[18])
    #group_input.Bump strength -> invert.Fac
    crystall.links.new(group_input.outputs[6], invert.inputs[0])
    #invert_001.Color -> bump.Strength
    crystall.links.new(invert_001.outputs[0], bump.inputs[0])
    #invert.Color -> invert_001.Color
    crystall.links.new(invert.outputs[0], invert_001.inputs[1])
    #group_input.IOR -> principled_bsdf.IOR
    crystall.links.new(group_input.outputs[5], principled_bsdf.inputs[16])
    #group_input.Normal -> bump.Normal
    crystall.links.new(group_input.outputs[7], bump.inputs[3])
    #group_input.Randomness -> voronoi_texture.Randomness
    crystall.links.new(group_input.outputs[4], voronoi_texture.inputs[5])
    #colorramp.Color -> mix.Factor
    crystall.links.new(colorramp.outputs[0], mix.inputs[0])
    #group_input.Color1 -> mix.A
    crystall.links.new(group_input.outputs[0], mix.inputs[6])
    #group_input.Color2 -> mix.B
    crystall.links.new(group_input.outputs[1], mix.inputs[7])
    #voronoi_texture.Distance -> group_output.Mask
    crystall.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    crystall.links.new(mix.outputs[2], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    crystall.links.new(bump.outputs[0], group_output.inputs[3])
    return crystall

crystall = crystall_node_group()

#initialize Crystall node group
def crystall_1_node_group():

    crystall_1 = mat.node_tree
    #start with a clean node tree
    for node in crystall_1.nodes:
        crystall_1.nodes.remove(node)
    #initialize crystall_1 nodes
    #node Material Output
    material_output = crystall_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Crystall
    crystall_2 = crystall_1.nodes.new("ShaderNodeGroup")
    crystall_2.label = "Crystall"
    crystall_2.name = "Crystall"
    crystall_2.use_custom_color = True
    crystall_2.color = (0.055806584656238556, 0.1328810751438141, 0.18446944653987885)
    crystall_2.node_tree = crystall
    #Input_8
    crystall_2.inputs[0].default_value = (0.601329505443573, 0.8318570256233215, 1.0, 1.0)
    #Input_9
    crystall_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_1
    crystall_2.inputs[2].default_value = 1.0
    #Input_2
    crystall_2.inputs[3].default_value = 0.0
    #Input_7
    crystall_2.inputs[4].default_value = 1.0
    #Input_5
    crystall_2.inputs[5].default_value = 1.4500000476837158
    #Input_4
    crystall_2.inputs[6].default_value = 0.15000000596046448
    #Input_6
    crystall_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (694.50830078125, 58.270751953125)
    crystall_2.location = (437.50830078125, 58.270751953125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    crystall_2.width, crystall_2.height = 166.62835693359375, 100.0
    
    #initialize crystall_1 links
    #crystall_2.BSDF -> material_output.Surface
    crystall_1.links.new(crystall_2.outputs[0], material_output.inputs[0])
    return crystall_1

crystall_1 = crystall_1_node_group()

