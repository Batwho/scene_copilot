import bpy, mathutils

mat = bpy.data.materials.new(name = "Marble")
mat.use_nodes = True
#initialize Marble node group
def marble_node_group():

    marble = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Marble")
    
    #initialize marble nodes
    #node Vector Math
    vector_math = marble.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Magic Texture
    magic_texture = marble.nodes.new("ShaderNodeTexMagic")
    magic_texture.name = "Magic Texture"
    magic_texture.turbulence_depth = 4
    #Scale
    magic_texture.inputs[1].default_value = 0.2799999415874481
    
    #node Group Output
    group_output = marble.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #marble outputs
    #output BSDF
    marble.outputs.new('NodeSocketShader', "BSDF")
    marble.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    marble.outputs.new('NodeSocketColor', "Albedo")
    marble.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    marble.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    marble.outputs.new('NodeSocketFloat', "Mask")
    marble.outputs[2].default_value = 0.0
    marble.outputs[2].min_value = -3.4028234663852886e+38
    marble.outputs[2].max_value = 3.4028234663852886e+38
    marble.outputs[2].attribute_domain = 'POINT'
    
    #output Normal
    marble.outputs.new('NodeSocketVector', "Normal")
    marble.outputs[3].default_value = (0.0, 0.0, 0.0)
    marble.outputs[3].min_value = -3.4028234663852886e+38
    marble.outputs[3].max_value = 3.4028234663852886e+38
    marble.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node Math
    math = marble.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Invert
    invert = marble.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Invert.002
    invert_002 = marble.nodes.new("ShaderNodeInvert")
    invert_002.name = "Invert.002"
    #Color
    invert_002.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Bump
    bump = marble.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 0.5
    
    #node Hue Saturation Value
    hue_saturation_value = marble.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Texture Coordinate
    texture_coordinate = marble.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Principled BSDF
    principled_bsdf = marble.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = marble.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #marble inputs
    #input Scale
    marble.inputs.new('NodeSocketFloat', "Scale")
    marble.inputs[0].default_value = 1.0
    marble.inputs[0].min_value = -10000.0
    marble.inputs[0].max_value = 10000.0
    marble.inputs[0].attribute_domain = 'POINT'
    
    #input Hue
    marble.inputs.new('NodeSocketFloatFactor', "Hue")
    marble.inputs[1].default_value = 1.0
    marble.inputs[1].min_value = 0.0
    marble.inputs[1].max_value = 1.0
    marble.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    marble.inputs.new('NodeSocketFloatFactor', "Saturation")
    marble.inputs[2].default_value = 1.0
    marble.inputs[2].min_value = 0.0
    marble.inputs[2].max_value = 1.0
    marble.inputs[2].attribute_domain = 'POINT'
    
    #input Brightness
    marble.inputs.new('NodeSocketFloat', "Brightness")
    marble.inputs[3].default_value = 1.0
    marble.inputs[3].min_value = 0.0
    marble.inputs[3].max_value = 2.0
    marble.inputs[3].attribute_domain = 'POINT'
    
    #input Outer Roughness
    marble.inputs.new('NodeSocketFloatFactor', "Outer Roughness")
    marble.inputs[4].default_value = 0.0
    marble.inputs[4].min_value = 0.0
    marble.inputs[4].max_value = 1.0
    marble.inputs[4].attribute_domain = 'POINT'
    
    #input Inner Roughness
    marble.inputs.new('NodeSocketFloatFactor', "Inner Roughness")
    marble.inputs[5].default_value = 0.33181819319725037
    marble.inputs[5].min_value = 0.0
    marble.inputs[5].max_value = 1.0
    marble.inputs[5].attribute_domain = 'POINT'
    
    #input Distortion
    marble.inputs.new('NodeSocketFloat', "Distortion")
    marble.inputs[6].default_value = 2.370000123977661
    marble.inputs[6].min_value = -1000.0
    marble.inputs[6].max_value = 1000.0
    marble.inputs[6].attribute_domain = 'POINT'
    
    #input IOR
    marble.inputs.new('NodeSocketFloat', "IOR")
    marble.inputs[7].default_value = 1.4500000476837158
    marble.inputs[7].min_value = 0.0
    marble.inputs[7].max_value = 1000.0
    marble.inputs[7].attribute_domain = 'POINT'
    
    #input Bump Strength
    marble.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    marble.inputs[8].default_value = 0.14166668057441711
    marble.inputs[8].min_value = 0.0
    marble.inputs[8].max_value = 1.0
    marble.inputs[8].attribute_domain = 'POINT'
    
    #input Normal
    marble.inputs.new('NodeSocketVector', "Normal")
    marble.inputs[9].default_value = (0.0, 0.0, 0.0)
    marble.inputs[9].min_value = -1.0
    marble.inputs[9].max_value = 1.0
    marble.inputs[9].attribute_domain = 'POINT'
    marble.inputs[9].hide_value = True
    
    
    
    
    #Set locations
    vector_math.location = (-178.9530029296875, 40.88232421875)
    magic_texture.location = (25.0, 90.0)
    group_output.location = (785.0, -0.0)
    math.location = (-42.94336700439453, 238.56085205078125)
    invert.location = (-500.0, 240.0)
    invert_002.location = (-500.0, 140.0)
    bump.location = (325.0, -230.0)
    hue_saturation_value.location = (240.0, 220.0)
    texture_coordinate.location = (-500.0, 20.0)
    principled_bsdf.location = (495.0, 230.0)
    group_input.location = (-695.0, -0.0)
    
    #Set dimensions
    vector_math.width, vector_math.height = 140.0, 100.0
    magic_texture.width, magic_texture.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    invert_002.width, invert_002.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize marble links
    #principled_bsdf.BSDF -> group_output.BSDF
    marble.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    marble.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    marble.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #magic_texture.Color -> bump.Height
    marble.links.new(magic_texture.outputs[0], bump.inputs[2])
    #vector_math.Vector -> magic_texture.Vector
    marble.links.new(vector_math.outputs[0], magic_texture.inputs[0])
    #texture_coordinate.Generated -> vector_math.Vector
    marble.links.new(texture_coordinate.outputs[0], vector_math.inputs[0])
    #group_input.Scale -> vector_math.Scale
    marble.links.new(group_input.outputs[0], vector_math.inputs[3])
    #magic_texture.Color -> hue_saturation_value.Color
    marble.links.new(magic_texture.outputs[0], hue_saturation_value.inputs[4])
    #math.Value -> hue_saturation_value.Hue
    marble.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Hue -> invert.Fac
    marble.links.new(group_input.outputs[1], invert.inputs[0])
    #invert.Color -> math.Value
    marble.links.new(invert.outputs[0], math.inputs[0])
    #group_input.Saturation -> invert_002.Fac
    marble.links.new(group_input.outputs[2], invert_002.inputs[0])
    #invert_002.Color -> hue_saturation_value.Saturation
    marble.links.new(invert_002.outputs[0], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    marble.links.new(group_input.outputs[3], hue_saturation_value.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    marble.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    #magic_texture.Fac -> group_output.Mask
    marble.links.new(magic_texture.outputs[1], group_output.inputs[2])
    #bump.Normal -> group_output.Normal
    marble.links.new(bump.outputs[0], group_output.inputs[3])
    #group_input.Outer Roughness -> principled_bsdf.Roughness
    marble.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Inner Roughness -> principled_bsdf.Transmission Roughness
    marble.links.new(group_input.outputs[5], principled_bsdf.inputs[18])
    #group_input.IOR -> principled_bsdf.IOR
    marble.links.new(group_input.outputs[7], principled_bsdf.inputs[16])
    #group_input.Bump Strength -> bump.Strength
    marble.links.new(group_input.outputs[8], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    marble.links.new(group_input.outputs[9], bump.inputs[3])
    #group_input.Distortion -> magic_texture.Distortion
    marble.links.new(group_input.outputs[6], magic_texture.inputs[2])
    return marble

marble = marble_node_group()

#initialize Marble node group
def marble_1_node_group():

    marble_1 = mat.node_tree
    #start with a clean node tree
    for node in marble_1.nodes:
        marble_1.nodes.remove(node)
    #initialize marble_1 nodes
    #node Material Output
    material_output = marble_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Marble
    marble_2 = marble_1.nodes.new("ShaderNodeGroup")
    marble_2.label = "Marble"
    marble_2.name = "Marble"
    marble_2.node_tree = marble
    #Input_1
    marble_2.inputs[0].default_value = 1.0
    #Input_2
    marble_2.inputs[1].default_value = 1.0
    #Input_3
    marble_2.inputs[2].default_value = 1.0
    #Input_4
    marble_2.inputs[3].default_value = 1.0
    #Input_8
    marble_2.inputs[4].default_value = 0.0
    #Input_9
    marble_2.inputs[5].default_value = 0.33181819319725037
    #Input_13
    marble_2.inputs[6].default_value = 2.370000123977661
    #Input_10
    marble_2.inputs[7].default_value = 1.4500000476837158
    #Input_11
    marble_2.inputs[8].default_value = 0.10000000149011612
    #Input_12
    marble_2.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (508.47406005859375, 9.432281494140625)
    marble_2.location = (264.33160400390625, 9.432281494140625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    marble_2.width, marble_2.height = 204.1424560546875, 100.0
    
    #initialize marble_1 links
    #marble_2.BSDF -> material_output.Surface
    marble_1.links.new(marble_2.outputs[0], material_output.inputs[0])
    return marble_1

marble_1 = marble_1_node_group()

