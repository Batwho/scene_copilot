import bpy, mathutils

mat = bpy.data.materials.new(name = "Alien Skinn")
mat.use_nodes = True
#initialize Alien skinn node group
def alien_skinn_node_group():

    alien_skinn = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Alien skinn")
    
    #initialize alien_skinn nodes
    #node Magic Texture
    magic_texture = alien_skinn.nodes.new("ShaderNodeTexMagic")
    magic_texture.name = "Magic Texture"
    magic_texture.turbulence_depth = 3
    #Scale
    magic_texture.inputs[1].default_value = 4.60999870300293
    
    #node Mapping
    mapping = alien_skinn.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    mapping.inputs[3].default_value = (1.0, 1.0, 1.0)
    
    #node Principled BSDF
    principled_bsdf = alien_skinn.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Bump
    bump = alien_skinn.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp
    colorramp = alien_skinn.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0023929765447974205, 0.030419614166021347, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.28181809186935425)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.23914587497711182, 0.33174994587898254, 0.01503792591392994, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.47162896394729614, 0.0948595330119133, 0.571358859539032, 1.0)

    
    #node Voronoi Texture
    voronoi_texture = alien_skinn.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture.inputs[2].default_value = 57.399993896484375
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.5
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Mix
    mix = alien_skinn.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'DODGE'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.824999988079071
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.001
    colorramp_001 = alien_skinn.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = alien_skinn.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.0
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(1.0)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Vector Math
    vector_math = alien_skinn.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = alien_skinn.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = alien_skinn.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #alien_skinn outputs
    #output BSDF
    alien_skinn.outputs.new('NodeSocketShader', "BSDF")
    alien_skinn.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    alien_skinn.outputs.new('NodeSocketColor', "Albedo")
    alien_skinn.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    alien_skinn.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    alien_skinn.outputs.new('NodeSocketColor', "Mask")
    alien_skinn.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    alien_skinn.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Hue Saturation Value
    hue_saturation_value = alien_skinn.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = alien_skinn.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = alien_skinn.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Group Input
    group_input = alien_skinn.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #alien_skinn inputs
    #input Scale
    alien_skinn.inputs.new('NodeSocketFloat', "Scale")
    alien_skinn.inputs[0].default_value = 1.0
    alien_skinn.inputs[0].min_value = -10000.0
    alien_skinn.inputs[0].max_value = 10000.0
    alien_skinn.inputs[0].attribute_domain = 'POINT'
    
    #input Subsurface
    alien_skinn.inputs.new('NodeSocketFloatFactor', "Subsurface")
    alien_skinn.inputs[1].default_value = 0.5909090638160706
    alien_skinn.inputs[1].min_value = 0.0
    alien_skinn.inputs[1].max_value = 1.0
    alien_skinn.inputs[1].attribute_domain = 'POINT'
    
    #input Roughness
    alien_skinn.inputs.new('NodeSocketFloatFactor', "Roughness")
    alien_skinn.inputs[2].default_value = 0.10000000149011612
    alien_skinn.inputs[2].min_value = 0.0
    alien_skinn.inputs[2].max_value = 1.0
    alien_skinn.inputs[2].attribute_domain = 'POINT'
    
    #input Color Hue
    alien_skinn.inputs.new('NodeSocketFloatFactor', "Color Hue")
    alien_skinn.inputs[3].default_value = 1.0
    alien_skinn.inputs[3].min_value = 0.0
    alien_skinn.inputs[3].max_value = 1.0
    alien_skinn.inputs[3].attribute_domain = 'POINT'
    
    #input Saturation
    alien_skinn.inputs.new('NodeSocketFloat', "Saturation")
    alien_skinn.inputs[4].default_value = 1.0
    alien_skinn.inputs[4].min_value = 0.0
    alien_skinn.inputs[4].max_value = 2.0
    alien_skinn.inputs[4].attribute_domain = 'POINT'
    
    #input Distortion
    alien_skinn.inputs.new('NodeSocketFloat', "Distortion")
    alien_skinn.inputs[5].default_value = 0.44999998807907104
    alien_skinn.inputs[5].min_value = -1000.0
    alien_skinn.inputs[5].max_value = 1000.0
    alien_skinn.inputs[5].attribute_domain = 'POINT'
    
    #input Bump Strength
    alien_skinn.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    alien_skinn.inputs[6].default_value = 1.0
    alien_skinn.inputs[6].min_value = 0.0
    alien_skinn.inputs[6].max_value = 1.0
    alien_skinn.inputs[6].attribute_domain = 'POINT'
    
    #input Normal
    alien_skinn.inputs.new('NodeSocketVector', "Normal")
    alien_skinn.inputs[7].default_value = (0.0, 0.0, 0.0)
    alien_skinn.inputs[7].min_value = -1.0
    alien_skinn.inputs[7].max_value = 1.0
    alien_skinn.inputs[7].attribute_domain = 'POINT'
    alien_skinn.inputs[7].hide_value = True
    
    
    
    #node Wave Texture
    wave_texture = alien_skinn.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 1.200000286102295
    #Distortion
    wave_texture.inputs[2].default_value = 0.0
    #Detail
    wave_texture.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    
    #Set locations
    magic_texture.location = (-429.80072021484375, 60.0)
    mapping.location = (-719.8007202148438, 138.5)
    principled_bsdf.location = (1249.80078125, 200.0)
    bump.location = (963.2584838867188, -200.0)
    colorramp.location = (550.1992797851562, 120.0)
    voronoi_texture.location = (-429.80072021484375, -120.0)
    mix.location = (110.19927978515625, 47.547607421875)
    colorramp_001.location = (-209.80072021484375, -103.2415771484375)
    colorramp_002.location = (643.2584838867188, -120.89620971679688)
    vector_math.location = (-909.8007202148438, 39.999969482421875)
    texture_coordinate_001.location = (-1249.80078125, -40.0)
    group_output.location = (1539.80078125, -0.0)
    hue_saturation_value.location = (901.0619506835938, 156.9874725341797)
    invert.location = (160.0, 260.0)
    math.location = (498.75634765625, 315.65869140625)
    group_input.location = (-1449.80078125, -0.0)
    wave_texture.location = (330.19921875, 120.0)
    
    #Set dimensions
    magic_texture.width, magic_texture.height = 140.0, 100.0
    mapping.width, mapping.height = 240.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    
    #initialize alien_skinn links
    #principled_bsdf.BSDF -> group_output.BSDF
    alien_skinn.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #wave_texture.Color -> colorramp.Fac
    alien_skinn.links.new(wave_texture.outputs[0], colorramp.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    alien_skinn.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #mapping.Vector -> magic_texture.Vector
    alien_skinn.links.new(mapping.outputs[0], magic_texture.inputs[0])
    #mix.Result -> wave_texture.Vector
    alien_skinn.links.new(mix.outputs[2], wave_texture.inputs[0])
    #colorramp_002.Color -> bump.Height
    alien_skinn.links.new(colorramp_002.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    alien_skinn.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #magic_texture.Color -> mix.A
    alien_skinn.links.new(magic_texture.outputs[0], mix.inputs[6])
    #colorramp_001.Color -> mix.B
    alien_skinn.links.new(colorramp_001.outputs[0], mix.inputs[7])
    #voronoi_texture.Distance -> colorramp_001.Fac
    alien_skinn.links.new(voronoi_texture.outputs[0], colorramp_001.inputs[0])
    #wave_texture.Color -> colorramp_002.Fac
    alien_skinn.links.new(wave_texture.outputs[0], colorramp_002.inputs[0])
    #texture_coordinate_001.Object -> vector_math.Vector
    alien_skinn.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mapping.Vector
    alien_skinn.links.new(vector_math.outputs[0], mapping.inputs[0])
    #group_input.Scale -> vector_math.Scale
    alien_skinn.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> hue_saturation_value.Color
    alien_skinn.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #hue_saturation_value.Color -> principled_bsdf.Subsurface Radius
    alien_skinn.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[2])
    #hue_saturation_value.Color -> principled_bsdf.Subsurface Color
    alien_skinn.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[3])
    #math.Value -> hue_saturation_value.Hue
    alien_skinn.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math.Value
    alien_skinn.links.new(invert.outputs[0], math.inputs[0])
    #group_input.Color Hue -> invert.Fac
    alien_skinn.links.new(group_input.outputs[3], invert.inputs[0])
    #group_input.Distortion -> magic_texture.Distortion
    alien_skinn.links.new(group_input.outputs[5], magic_texture.inputs[2])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    alien_skinn.links.new(group_input.outputs[1], principled_bsdf.inputs[1])
    #group_input.Roughness -> principled_bsdf.Roughness
    alien_skinn.links.new(group_input.outputs[2], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    alien_skinn.links.new(group_input.outputs[6], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    alien_skinn.links.new(group_input.outputs[7], bump.inputs[3])
    #group_input.Saturation -> hue_saturation_value.Saturation
    alien_skinn.links.new(group_input.outputs[4], hue_saturation_value.inputs[1])
    #hue_saturation_value.Color -> group_output.Albedo
    alien_skinn.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    #wave_texture.Fac -> group_output.Mask
    alien_skinn.links.new(wave_texture.outputs[1], group_output.inputs[2])
    return alien_skinn

alien_skinn = alien_skinn_node_group()

#initialize Alien Skinn node group
def alien_skinn_1_node_group():

    alien_skinn_1 = mat.node_tree
    #start with a clean node tree
    for node in alien_skinn_1.nodes:
        alien_skinn_1.nodes.remove(node)
    #initialize alien_skinn_1 nodes
    #node Material Output
    material_output = alien_skinn_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Alien skinn
    alien_skinn_2 = alien_skinn_1.nodes.new("ShaderNodeGroup")
    alien_skinn_2.label = "Alien skinn"
    alien_skinn_2.name = "Alien skinn"
    alien_skinn_2.node_tree = alien_skinn
    #Input_1
    alien_skinn_2.inputs[0].default_value = 1.0
    #Input_4
    alien_skinn_2.inputs[1].default_value = 0.5909090638160706
    #Input_5
    alien_skinn_2.inputs[2].default_value = 0.10000000149011612
    #Input_2
    alien_skinn_2.inputs[3].default_value = 0.0
    #Input_8
    alien_skinn_2.inputs[4].default_value = 1.0
    #Input_3
    alien_skinn_2.inputs[5].default_value = 0.44999998807907104
    #Input_6
    alien_skinn_2.inputs[6].default_value = 1.0
    #Input_7
    alien_skinn_2.inputs[7].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (554.5794067382812, 117.8001708984375)
    alien_skinn_2.location = (310.09942626953125, 117.8001708984375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    alien_skinn_2.width, alien_skinn_2.height = 174.8779296875, 100.0
    
    #initialize alien_skinn_1 links
    #alien_skinn_2.BSDF -> material_output.Surface
    alien_skinn_1.links.new(alien_skinn_2.outputs[0], material_output.inputs[0])
    return alien_skinn_1

alien_skinn_1 = alien_skinn_1_node_group()

