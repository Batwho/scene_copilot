import bpy, mathutils

mat = bpy.data.materials.new(name = "Sand Stone")
mat.use_nodes = True
#initialize Sand Stone node group
def sand_stone_node_group():

    sand_stone = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Sand Stone")
    
    #initialize sand_stone nodes
    #node Vector Math
    vector_math = sand_stone.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = sand_stone.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node ColorRamp
    colorramp = sand_stone.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (1.0, 0.3120216131210327, 0.10292971879243851, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.24432386457920074, 0.08041779696941376, 0.04187614843249321, 1.0)

    
    #node Hue Saturation Value
    hue_saturation_value = sand_stone.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = sand_stone.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = sand_stone.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    
    #node Group Output
    group_output = sand_stone.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #sand_stone outputs
    #output BSDF
    sand_stone.outputs.new('NodeSocketShader', "BSDF")
    sand_stone.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    sand_stone.outputs.new('NodeSocketColor', "Albedo")
    sand_stone.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    sand_stone.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    sand_stone.outputs.new('NodeSocketFloat', "Mask")
    sand_stone.outputs[2].default_value = 0.0
    sand_stone.outputs[2].min_value = -3.4028234663852886e+38
    sand_stone.outputs[2].max_value = 3.4028234663852886e+38
    sand_stone.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Mix
    mix = sand_stone.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Mix.001
    mix_001 = sand_stone.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.0
    #B_Color
    mix_001.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    
    #node Principled BSDF
    principled_bsdf = sand_stone.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Voronoi Texture
    voronoi_texture = sand_stone.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 3.6000001430511475
    
    #node Noise Texture
    noise_texture = sand_stone.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 3.6000001430511475
    #Roughness
    noise_texture.inputs[4].default_value = 0.6941666603088379
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = sand_stone.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #sand_stone inputs
    #input Scale
    sand_stone.inputs.new('NodeSocketFloat', "Scale")
    sand_stone.inputs[0].default_value = 1.0
    sand_stone.inputs[0].min_value = -10000.0
    sand_stone.inputs[0].max_value = 10000.0
    sand_stone.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    sand_stone.inputs.new('NodeSocketFloatFactor', "Color Hue")
    sand_stone.inputs[1].default_value = 1.0
    sand_stone.inputs[1].min_value = 0.0
    sand_stone.inputs[1].max_value = 1.0
    sand_stone.inputs[1].attribute_domain = 'POINT'
    
    #input Specular
    sand_stone.inputs.new('NodeSocketFloatFactor', "Specular")
    sand_stone.inputs[2].default_value = 0.054545462131500244
    sand_stone.inputs[2].min_value = 0.0
    sand_stone.inputs[2].max_value = 1.0
    sand_stone.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    sand_stone.inputs.new('NodeSocketFloatFactor', "Roughness")
    sand_stone.inputs[3].default_value = 0.800000011920929
    sand_stone.inputs[3].min_value = 0.0
    sand_stone.inputs[3].max_value = 1.0
    sand_stone.inputs[3].attribute_domain = 'POINT'
    
    #input Saturation
    sand_stone.inputs.new('NodeSocketFloat', "Saturation")
    sand_stone.inputs[4].default_value = 1.0
    sand_stone.inputs[4].min_value = 0.0
    sand_stone.inputs[4].max_value = 2.0
    sand_stone.inputs[4].attribute_domain = 'POINT'
    
    #input Brightness
    sand_stone.inputs.new('NodeSocketFloat', "Brightness")
    sand_stone.inputs[5].default_value = 1.0
    sand_stone.inputs[5].min_value = 0.0
    sand_stone.inputs[5].max_value = 2.0
    sand_stone.inputs[5].attribute_domain = 'POINT'
    
    #input Mix Textures
    sand_stone.inputs.new('NodeSocketFloatFactor', "Mix Textures")
    sand_stone.inputs[6].default_value = 0.19499996304512024
    sand_stone.inputs[6].min_value = 0.0
    sand_stone.inputs[6].max_value = 1.0
    sand_stone.inputs[6].attribute_domain = 'POINT'
    
    #input Randomness
    sand_stone.inputs.new('NodeSocketFloatFactor', "Randomness")
    sand_stone.inputs[7].default_value = 1.0
    sand_stone.inputs[7].min_value = 0.0
    sand_stone.inputs[7].max_value = 1.0
    sand_stone.inputs[7].attribute_domain = 'POINT'
    
    #input Detail
    sand_stone.inputs.new('NodeSocketFloat', "Detail")
    sand_stone.inputs[8].default_value = 10.0
    sand_stone.inputs[8].min_value = 0.0
    sand_stone.inputs[8].max_value = 15.0
    sand_stone.inputs[8].attribute_domain = 'POINT'
    
    #input Bump Strength
    sand_stone.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    sand_stone.inputs[9].default_value = 1.0
    sand_stone.inputs[9].min_value = 0.0
    sand_stone.inputs[9].max_value = 1.0
    sand_stone.inputs[9].attribute_domain = 'POINT'
    
    #input Normal
    sand_stone.inputs.new('NodeSocketVector', "Normal")
    sand_stone.inputs[10].default_value = (0.0, 0.0, 0.0)
    sand_stone.inputs[10].min_value = -1.0
    sand_stone.inputs[10].max_value = 1.0
    sand_stone.inputs[10].attribute_domain = 'POINT'
    sand_stone.inputs[10].hide_value = True
    
    
    
    #node Bump
    bump = sand_stone.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    vector_math.location = (-410.0159606933594, 69.99996948242188)
    texture_coordinate_001.location = (-750.0159912109375, -10.0)
    colorramp.location = (305.4969482421875, 288.5497131347656)
    hue_saturation_value.location = (560.0, 200.00003051757812)
    invert.location = (-440.0, 240.0)
    math.location = (-125.9921875, 309.2486572265625)
    group_output.location = (1411.9840087890625, -63.8609619140625)
    mix.location = (-110.01596069335938, 90.0)
    mix_001.location = (794.4173583984375, 219.30360412597656)
    principled_bsdf.location = (1121.9840087890625, 166.1390380859375)
    voronoi_texture.location = (129.98397827148438, 130.0)
    noise_texture.location = (-310.0159606933594, -130.0)
    group_input.location = (-987.3621215820312, 4.67523193359375)
    bump.location = (449.9839782714844, -230.0)
    
    #Set dimensions
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize sand_stone links
    #principled_bsdf.BSDF -> group_output.BSDF
    sand_stone.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix_001.Result -> principled_bsdf.Base Color
    sand_stone.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #voronoi_texture.Distance -> colorramp.Fac
    sand_stone.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> voronoi_texture.Vector
    sand_stone.links.new(mix.outputs[2], voronoi_texture.inputs[0])
    #noise_texture.Fac -> mix.B
    sand_stone.links.new(noise_texture.outputs[0], mix.inputs[7])
    #voronoi_texture.Distance -> bump.Height
    sand_stone.links.new(voronoi_texture.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    sand_stone.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #texture_coordinate_001.Object -> vector_math.Vector
    sand_stone.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mix.A
    sand_stone.links.new(vector_math.outputs[0], mix.inputs[6])
    #vector_math.Vector -> noise_texture.Vector
    sand_stone.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    sand_stone.links.new(group_input.outputs[0], vector_math.inputs[3])
    #colorramp.Color -> hue_saturation_value.Color
    sand_stone.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #math.Value -> hue_saturation_value.Hue
    sand_stone.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Color Hue -> invert.Fac
    sand_stone.links.new(group_input.outputs[1], invert.inputs[0])
    #invert.Color -> math.Value
    sand_stone.links.new(invert.outputs[0], math.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    sand_stone.links.new(group_input.outputs[4], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    sand_stone.links.new(group_input.outputs[5], hue_saturation_value.inputs[2])
    #hue_saturation_value.Color -> mix_001.A
    sand_stone.links.new(hue_saturation_value.outputs[0], mix_001.inputs[6])
    #group_input.Mix Textures -> mix.Factor
    sand_stone.links.new(group_input.outputs[6], mix.inputs[0])
    #group_input.Specular -> principled_bsdf.Specular
    sand_stone.links.new(group_input.outputs[2], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    sand_stone.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Randomness -> voronoi_texture.Randomness
    sand_stone.links.new(group_input.outputs[7], voronoi_texture.inputs[5])
    #group_input.Detail -> noise_texture.Detail
    sand_stone.links.new(group_input.outputs[8], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    sand_stone.links.new(group_input.outputs[9], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    sand_stone.links.new(group_input.outputs[10], bump.inputs[3])
    #voronoi_texture.Distance -> group_output.Mask
    sand_stone.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #mix_001.Result -> group_output.Albedo
    sand_stone.links.new(mix_001.outputs[2], group_output.inputs[1])
    return sand_stone

sand_stone = sand_stone_node_group()

#initialize Sand Stone node group
def sand_stone_1_node_group():

    sand_stone_1 = mat.node_tree
    #start with a clean node tree
    for node in sand_stone_1.nodes:
        sand_stone_1.nodes.remove(node)
    #initialize sand_stone_1 nodes
    #node Material Output
    material_output = sand_stone_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Sand Stone
    sand_stone_2 = sand_stone_1.nodes.new("ShaderNodeGroup")
    sand_stone_2.label = "Sand Stone"
    sand_stone_2.name = "Sand Stone"
    sand_stone_2.node_tree = sand_stone
    #Input_1
    sand_stone_2.inputs[0].default_value = 1.0
    #Input_2
    sand_stone_2.inputs[1].default_value = 0.0
    #Input_6
    sand_stone_2.inputs[2].default_value = 0.054545462131500244
    #Input_7
    sand_stone_2.inputs[3].default_value = 0.800000011920929
    #Input_3
    sand_stone_2.inputs[4].default_value = 1.0
    #Input_4
    sand_stone_2.inputs[5].default_value = 1.0
    #Input_5
    sand_stone_2.inputs[6].default_value = 0.19499996304512024
    #Input_8
    sand_stone_2.inputs[7].default_value = 1.0
    #Input_9
    sand_stone_2.inputs[8].default_value = 10.0
    #Input_10
    sand_stone_2.inputs[9].default_value = 1.0
    #Input_11
    sand_stone_2.inputs[10].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (679.44189453125, 101.66796875)
    sand_stone_2.location = (389.82080078125, 101.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    sand_stone_2.width, sand_stone_2.height = 189.58917236328125, 100.0
    
    #initialize sand_stone_1 links
    #sand_stone_2.BSDF -> material_output.Surface
    sand_stone_1.links.new(sand_stone_2.outputs[0], material_output.inputs[0])
    return sand_stone_1

sand_stone_1 = sand_stone_1_node_group()

