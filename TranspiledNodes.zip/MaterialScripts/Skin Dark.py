import bpy, mathutils

mat = bpy.data.materials.new(name = "Skin Dark")
mat.use_nodes = True
#initialize Skin dark node group
def skin_dark_node_group():

    skin_dark = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Skin dark")
    
    #initialize skin_dark nodes
    #node Bump
    bump = skin_dark.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = True
    #Distance
    bump.inputs[1].default_value = 0.10000000149011612
    
    #node ColorRamp
    colorramp = skin_dark.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.559090793132782
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.6863635778427124)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.8181819915771484)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Voronoi Texture
    voronoi_texture = skin_dark.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 60.0
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Mix.001
    mix_001 = skin_dark.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Mix.002
    mix_002 = skin_dark.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node Texture Coordinate.001
    texture_coordinate_001 = skin_dark.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = skin_dark.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #skin_dark outputs
    #output BSDF
    skin_dark.outputs.new('NodeSocketShader', "BSDF")
    skin_dark.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    skin_dark.outputs.new('NodeSocketColor', "Albedo")
    skin_dark.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    skin_dark.outputs[1].attribute_domain = 'POINT'
    
    #output Mask Pimples
    skin_dark.outputs.new('NodeSocketColor', "Mask Pimples")
    skin_dark.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    skin_dark.outputs[2].attribute_domain = 'POINT'
    
    #output Mask 2
    skin_dark.outputs.new('NodeSocketFloat', "Mask 2")
    skin_dark.outputs[3].default_value = 0.0
    skin_dark.outputs[3].min_value = -3.4028234663852886e+38
    skin_dark.outputs[3].max_value = 3.4028234663852886e+38
    skin_dark.outputs[3].attribute_domain = 'POINT'
    
    
    
    #node ColorRamp.001
    colorramp_001 = skin_dark.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.22727341949939728)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Vector Math
    vector_math = skin_dark.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Mix
    mix = skin_dark.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Mix.003
    mix_003 = skin_dark.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'BURN'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #B_Color
    mix_003.inputs[7].default_value = (0.0010000000474974513, 0.0010000000474974513, 0.0010000000474974513, 1.0)
    
    #node Group Input
    group_input = skin_dark.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #skin_dark inputs
    #input Scale
    skin_dark.inputs.new('NodeSocketFloat', "Scale")
    skin_dark.inputs[0].default_value = 1.0
    skin_dark.inputs[0].min_value = -10000.0
    skin_dark.inputs[0].max_value = 10000.0
    skin_dark.inputs[0].attribute_domain = 'POINT'
    
    #input Skin Color
    skin_dark.inputs.new('NodeSocketColor', "Skin Color")
    skin_dark.inputs[1].default_value = (0.010022828355431557, 0.005915332585573196, 0.0038977493532001972, 1.0)
    skin_dark.inputs[1].attribute_domain = 'POINT'
    
    #input Subsurfacescattering
    skin_dark.inputs.new('NodeSocketFloatFactor', "Subsurfacescattering")
    skin_dark.inputs[2].default_value = 0.30000001192092896
    skin_dark.inputs[2].min_value = 0.0
    skin_dark.inputs[2].max_value = 1.0
    skin_dark.inputs[2].attribute_domain = 'POINT'
    
    #input Specular
    skin_dark.inputs.new('NodeSocketFloatFactor', "Specular")
    skin_dark.inputs[3].default_value = 0.054545462131500244
    skin_dark.inputs[3].min_value = 0.0
    skin_dark.inputs[3].max_value = 1.0
    skin_dark.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    skin_dark.inputs.new('NodeSocketFloatFactor', "Roughness")
    skin_dark.inputs[4].default_value = 0.5
    skin_dark.inputs[4].min_value = 0.0
    skin_dark.inputs[4].max_value = 1.0
    skin_dark.inputs[4].attribute_domain = 'POINT'
    
    #input Pimple Amount
    skin_dark.inputs.new('NodeSocketFloatFactor', "Pimple Amount")
    skin_dark.inputs[5].default_value = 0.0
    skin_dark.inputs[5].min_value = 0.0
    skin_dark.inputs[5].max_value = 1.0
    skin_dark.inputs[5].attribute_domain = 'POINT'
    
    #input Pimple Strength
    skin_dark.inputs.new('NodeSocketFloatFactor', "Pimple Strength")
    skin_dark.inputs[6].default_value = 0.5
    skin_dark.inputs[6].min_value = 0.0
    skin_dark.inputs[6].max_value = 1.0
    skin_dark.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    skin_dark.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    skin_dark.inputs[7].default_value = 0.20000000298023224
    skin_dark.inputs[7].min_value = 0.0
    skin_dark.inputs[7].max_value = 1.0
    skin_dark.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    skin_dark.inputs.new('NodeSocketVector', "Normal")
    skin_dark.inputs[8].default_value = (0.0, 0.0, 0.0)
    skin_dark.inputs[8].min_value = -1.0
    skin_dark.inputs[8].max_value = 1.0
    skin_dark.inputs[8].attribute_domain = 'POINT'
    skin_dark.inputs[8].hide_value = True
    
    
    
    #node Principled BSDF
    principled_bsdf = skin_dark.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.4070702791213989, 0.06148352846503258, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    bump.location = (235.03125, -215.19549560546875)
    colorramp.location = (-84.96875, -195.19549560546875)
    voronoi_texture.location = (-324.96875, 4.80450439453125)
    mix_001.location = (645.03125, 32.089630126953125)
    mix_002.location = (644.086669921875, 177.79043579101562)
    texture_coordinate_001.location = (-864.96875, -95.19549560546875)
    group_output.location = (1154.968994140625, -0.0)
    colorramp_001.location = (-144.96875, 184.80450439453125)
    vector_math.location = (-524.96875, -15.19549560546875)
    mix.location = (175.03125, 215.19549560546875)
    mix_003.location = (366.7894592285156, 237.2805633544922)
    group_input.location = (-1064.96875, -0.0)
    principled_bsdf.location = (864.968994140625, 164.80450439453125)
    
    #Set dimensions
    bump.width, bump.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    
    #initialize skin_dark links
    #principled_bsdf.BSDF -> group_output.BSDF
    skin_dark.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    skin_dark.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #colorramp.Color -> bump.Height
    skin_dark.links.new(colorramp.outputs[0], bump.inputs[2])
    #voronoi_texture.Distance -> colorramp.Fac
    skin_dark.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #mix_001.Result -> principled_bsdf.Subsurface Color
    skin_dark.links.new(mix_001.outputs[2], principled_bsdf.inputs[3])
    #mix_002.Result -> principled_bsdf.Base Color
    skin_dark.links.new(mix_002.outputs[2], principled_bsdf.inputs[0])
    #voronoi_texture.Color -> colorramp_001.Fac
    skin_dark.links.new(voronoi_texture.outputs[1], colorramp_001.inputs[0])
    #colorramp_001.Color -> mix.Factor
    skin_dark.links.new(colorramp_001.outputs[0], mix.inputs[0])
    #voronoi_texture.Distance -> mix.A
    skin_dark.links.new(voronoi_texture.outputs[0], mix.inputs[6])
    #mix_003.Result -> mix_002.B
    skin_dark.links.new(mix_003.outputs[2], mix_002.inputs[7])
    #texture_coordinate_001.Object -> vector_math.Vector
    skin_dark.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> voronoi_texture.Vector
    skin_dark.links.new(vector_math.outputs[0], voronoi_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    skin_dark.links.new(group_input.outputs[0], vector_math.inputs[3])
    #group_input.Skin Color -> mix_002.A
    skin_dark.links.new(group_input.outputs[1], mix_002.inputs[6])
    #group_input.Skin Color -> mix_001.A
    skin_dark.links.new(group_input.outputs[1], mix_001.inputs[6])
    #mix.Result -> mix_003.A
    skin_dark.links.new(mix.outputs[2], mix_003.inputs[6])
    #mix_003.Result -> mix_001.B
    skin_dark.links.new(mix_003.outputs[2], mix_001.inputs[7])
    #group_input.Pimple Amount -> mix_003.Factor
    skin_dark.links.new(group_input.outputs[5], mix_003.inputs[0])
    #group_input.Pimple Strength -> mix_002.Factor
    skin_dark.links.new(group_input.outputs[6], mix_002.inputs[0])
    #group_input.Pimple Strength -> mix_001.Factor
    skin_dark.links.new(group_input.outputs[6], mix_001.inputs[0])
    #group_input.Subsurfacescattering -> principled_bsdf.Subsurface
    skin_dark.links.new(group_input.outputs[2], principled_bsdf.inputs[1])
    #group_input.Specular -> principled_bsdf.Specular
    skin_dark.links.new(group_input.outputs[3], principled_bsdf.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    skin_dark.links.new(group_input.outputs[4], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    skin_dark.links.new(group_input.outputs[7], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    skin_dark.links.new(group_input.outputs[8], bump.inputs[3])
    #mix_002.Result -> group_output.Albedo
    skin_dark.links.new(mix_002.outputs[2], group_output.inputs[1])
    #mix.Result -> group_output.Mask Pimples
    skin_dark.links.new(mix.outputs[2], group_output.inputs[2])
    #voronoi_texture.Distance -> group_output.Mask 2
    skin_dark.links.new(voronoi_texture.outputs[0], group_output.inputs[3])
    return skin_dark

skin_dark = skin_dark_node_group()

#initialize Skin Dark node group
def skin_dark_1_node_group():

    skin_dark_1 = mat.node_tree
    #start with a clean node tree
    for node in skin_dark_1.nodes:
        skin_dark_1.nodes.remove(node)
    #initialize skin_dark_1 nodes
    #node Material Output
    material_output = skin_dark_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Skin dark
    skin_dark_2 = skin_dark_1.nodes.new("ShaderNodeGroup")
    skin_dark_2.label = "Skin dark"
    skin_dark_2.name = "Skin dark"
    skin_dark_2.node_tree = skin_dark
    #Input_1
    skin_dark_2.inputs[0].default_value = 1.0
    #Input_2
    skin_dark_2.inputs[1].default_value = (0.010022828355431557, 0.005915332585573196, 0.0038977493532001972, 1.0)
    #Input_5
    skin_dark_2.inputs[2].default_value = 0.30000001192092896
    #Input_6
    skin_dark_2.inputs[3].default_value = 0.05000000074505806
    #Input_7
    skin_dark_2.inputs[4].default_value = 0.5
    #Input_3
    skin_dark_2.inputs[5].default_value = 0.0
    #Input_4
    skin_dark_2.inputs[6].default_value = 0.5
    #Input_8
    skin_dark_2.inputs[7].default_value = 0.20000000298023224
    #Input_9
    skin_dark_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (733.37060546875, 80.87451171875)
    skin_dark_2.location = (423.79248046875, 80.87451171875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    skin_dark_2.width, skin_dark_2.height = 201.943359375, 100.0
    
    #initialize skin_dark_1 links
    #skin_dark_2.BSDF -> material_output.Surface
    skin_dark_1.links.new(skin_dark_2.outputs[0], material_output.inputs[0])
    return skin_dark_1

skin_dark_1 = skin_dark_1_node_group()

