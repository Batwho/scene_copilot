import bpy, mathutils

mat = bpy.data.materials.new(name = "Fire'ish Volume")
mat.use_nodes = True
#initialize Fire'ish Volume node group
def fire_ish_volume_node_group():

    fire_ish_volume = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Fire'ish Volume")
    
    #initialize fire_ish_volume nodes
    #node Voronoi Texture
    voronoi_texture = fire_ish_volume.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Scale
    voronoi_texture.inputs[2].default_value = 4.900000095367432
    #Smoothness
    voronoi_texture.inputs[3].default_value = 0.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.5
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node ColorRamp.001
    colorramp_001 = fire_ish_volume.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.6363635659217834
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 0.004544968716800213, 0.002662943210452795, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.763636589050293)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 0.621849536895752, 0.05086548998951912, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(0.8318183422088623)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Texture Coordinate.001
    texture_coordinate_001 = fire_ish_volume.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Group Output
    group_output = fire_ish_volume.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #fire_ish_volume outputs
    #output Emission
    fire_ish_volume.outputs.new('NodeSocketShader', "Emission")
    fire_ish_volume.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    fire_ish_volume.outputs.new('NodeSocketColor', "Albedo")
    fire_ish_volume.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    fire_ish_volume.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    fire_ish_volume.outputs.new('NodeSocketFloat', "Mask")
    fire_ish_volume.outputs[2].default_value = 0.0
    fire_ish_volume.outputs[2].min_value = -3.4028234663852886e+38
    fire_ish_volume.outputs[2].max_value = 3.4028234663852886e+38
    fire_ish_volume.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Vector Math
    vector_math = fire_ish_volume.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Hue Saturation Value
    hue_saturation_value = fire_ish_volume.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = fire_ish_volume.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.001
    math_001 = fire_ish_volume.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    #node Group Input
    group_input = fire_ish_volume.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #fire_ish_volume inputs
    #input Scale
    fire_ish_volume.inputs.new('NodeSocketFloat', "Scale")
    fire_ish_volume.inputs[0].default_value = 1.0
    fire_ish_volume.inputs[0].min_value = -10000.0
    fire_ish_volume.inputs[0].max_value = 10000.0
    fire_ish_volume.inputs[0].attribute_domain = 'POINT'
    
    #input Detail
    fire_ish_volume.inputs.new('NodeSocketFloat', "Detail")
    fire_ish_volume.inputs[1].default_value = 10.399999618530273
    fire_ish_volume.inputs[1].min_value = 0.0
    fire_ish_volume.inputs[1].max_value = 15.0
    fire_ish_volume.inputs[1].attribute_domain = 'POINT'
    
    #input Fac
    fire_ish_volume.inputs.new('NodeSocketFloatFactor', "Fac")
    fire_ish_volume.inputs[2].default_value = 1.0
    fire_ish_volume.inputs[2].min_value = 0.0
    fire_ish_volume.inputs[2].max_value = 1.0
    fire_ish_volume.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    fire_ish_volume.inputs.new('NodeSocketFloat', "Saturation")
    fire_ish_volume.inputs[3].default_value = 1.0
    fire_ish_volume.inputs[3].min_value = 0.0
    fire_ish_volume.inputs[3].max_value = 2.0
    fire_ish_volume.inputs[3].attribute_domain = 'POINT'
    
    #input Glow Strength
    fire_ish_volume.inputs.new('NodeSocketFloat', "Glow Strength")
    fire_ish_volume.inputs[4].default_value = 1.0
    fire_ish_volume.inputs[4].min_value = 0.0
    fire_ish_volume.inputs[4].max_value = 2.0
    fire_ish_volume.inputs[4].attribute_domain = 'POINT'
    
    #input Distortion
    fire_ish_volume.inputs.new('NodeSocketFloat', "Distortion")
    fire_ish_volume.inputs[5].default_value = 0.0
    fire_ish_volume.inputs[5].min_value = -1000.0
    fire_ish_volume.inputs[5].max_value = 1000.0
    fire_ish_volume.inputs[5].attribute_domain = 'POINT'
    
    
    
    #node Math
    math = fire_ish_volume.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node ColorRamp
    colorramp = fire_ish_volume.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.6363639831542969
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.9136364459991455)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = fire_ish_volume.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.48181837797164917
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.6409091353416443)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_002_cre_2 = colorramp_002.color_ramp.elements.new(0.6636366248130798)
    colorramp_002_cre_2.alpha = 1.0
    colorramp_002_cre_2.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Math.004
    math_004 = fire_ish_volume.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MULTIPLY'
    math_004.use_clamp = False
    #Value_001
    math_004.inputs[1].default_value = 5.0
    #Value_002
    math_004.inputs[2].default_value = 0.5
    
    #node Math.003
    math_003 = fire_ish_volume.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'ADD'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 1.0
    #Value_002
    math_003.inputs[2].default_value = 0.5
    
    #node Math.002
    math_002 = fire_ish_volume.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    #Value_002
    math_002.inputs[2].default_value = 0.5
    
    #node Emission
    emission = fire_ish_volume.nodes.new("ShaderNodeEmission")
    emission.name = "Emission"
    #Weight
    emission.inputs[2].default_value = 0.0
    
    #node Noise Texture
    noise_texture = fire_ish_volume.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 8.899999618530273
    #Roughness
    noise_texture.inputs[4].default_value = 0.5499999523162842
    
    
    #Set locations
    voronoi_texture.location = (-90.0, 50.0)
    colorramp_001.location = (130.0, -110.00001525878906)
    texture_coordinate_001.location = (-949.9999389648438, -9.999969482421875)
    group_output.location = (1140.0, -0.0)
    vector_math.location = (-609.9999389648438, 69.99996948242188)
    hue_saturation_value.location = (471.5478515625, -73.49288940429688)
    invert.location = (-420.0, 240.0)
    math_001.location = (-72.6761474609375, 219.24935913085938)
    group_input.location = (-1150.0, -0.0)
    math.location = (450.0, 90.0)
    colorramp.location = (120.0, 120.0)
    colorramp_002.location = (219.99996948242188, 337.285888671875)
    math_004.location = (499.9999694824219, 360.0)
    math_003.location = (520.0, 200.0)
    math_002.location = (692.354248046875, 152.15887451171875)
    emission.location = (950.0, 110.0)
    noise_texture.location = (-410.0, 50.0)
    
    #Set dimensions
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    emission.width, emission.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize fire_ish_volume links
    #noise_texture.Fac -> voronoi_texture.Vector
    fire_ish_volume.links.new(noise_texture.outputs[0], voronoi_texture.inputs[0])
    #voronoi_texture.Distance -> colorramp.Fac
    fire_ish_volume.links.new(voronoi_texture.outputs[0], colorramp.inputs[0])
    #colorramp.Color -> math.Value
    fire_ish_volume.links.new(colorramp.outputs[0], math.inputs[0])
    #voronoi_texture.Distance -> colorramp_001.Fac
    fire_ish_volume.links.new(voronoi_texture.outputs[0], colorramp_001.inputs[0])
    #hue_saturation_value.Color -> emission.Color
    fire_ish_volume.links.new(hue_saturation_value.outputs[0], emission.inputs[0])
    #math_002.Value -> emission.Strength
    fire_ish_volume.links.new(math_002.outputs[0], emission.inputs[1])
    #texture_coordinate_001.Object -> vector_math.Vector
    fire_ish_volume.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> noise_texture.Vector
    fire_ish_volume.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math.Scale
    fire_ish_volume.links.new(group_input.outputs[0], vector_math.inputs[3])
    #group_input.Detail -> noise_texture.Detail
    fire_ish_volume.links.new(group_input.outputs[1], noise_texture.inputs[3])
    #colorramp_001.Color -> hue_saturation_value.Color
    fire_ish_volume.links.new(colorramp_001.outputs[0], hue_saturation_value.inputs[4])
    #math_001.Value -> hue_saturation_value.Hue
    fire_ish_volume.links.new(math_001.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Fac -> invert.Fac
    fire_ish_volume.links.new(group_input.outputs[2], invert.inputs[0])
    #invert.Color -> math_001.Value
    fire_ish_volume.links.new(invert.outputs[0], math_001.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    fire_ish_volume.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Glow Strength -> math.Value
    fire_ish_volume.links.new(group_input.outputs[4], math.inputs[1])
    #math.Value -> math_002.Value
    fire_ish_volume.links.new(math.outputs[0], math_002.inputs[0])
    #math_003.Value -> math_002.Value
    fire_ish_volume.links.new(math_003.outputs[0], math_002.inputs[1])
    #voronoi_texture.Distance -> colorramp_002.Fac
    fire_ish_volume.links.new(voronoi_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> math_004.Value
    fire_ish_volume.links.new(colorramp_002.outputs[0], math_004.inputs[0])
    #math_004.Value -> math_003.Value
    fire_ish_volume.links.new(math_004.outputs[0], math_003.inputs[0])
    #emission.Emission -> group_output.Emission
    fire_ish_volume.links.new(emission.outputs[0], group_output.inputs[0])
    #group_input.Distortion -> noise_texture.Distortion
    fire_ish_volume.links.new(group_input.outputs[5], noise_texture.inputs[5])
    #math_002.Value -> group_output.Mask
    fire_ish_volume.links.new(math_002.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    fire_ish_volume.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return fire_ish_volume

fire_ish_volume = fire_ish_volume_node_group()

#initialize Fire'ish Volume node group
def fire_ish_volume_1_node_group():

    fire_ish_volume_1 = mat.node_tree
    #start with a clean node tree
    for node in fire_ish_volume_1.nodes:
        fire_ish_volume_1.nodes.remove(node)
    #initialize fire_ish_volume_1 nodes
    #node Material Output
    material_output = fire_ish_volume_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Fire'ish Volume
    fire_ish_volume_2 = fire_ish_volume_1.nodes.new("ShaderNodeGroup")
    fire_ish_volume_2.label = "Fire'ish Volume"
    fire_ish_volume_2.name = "Fire'ish Volume"
    fire_ish_volume_2.node_tree = fire_ish_volume
    #Input_1
    fire_ish_volume_2.inputs[0].default_value = 0.5
    #Input_2
    fire_ish_volume_2.inputs[1].default_value = 10.399999618530273
    #Input_3
    fire_ish_volume_2.inputs[2].default_value = 1.0
    #Input_4
    fire_ish_volume_2.inputs[3].default_value = 1.0
    #Input_5
    fire_ish_volume_2.inputs[4].default_value = 200.0
    #Input_7
    fire_ish_volume_2.inputs[5].default_value = 0.0
    
    
    #Set locations
    material_output.location = (661.35888671875, 132.858154296875)
    fire_ish_volume_2.location = (405.26708984375, 132.858154296875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    fire_ish_volume_2.width, fire_ish_volume_2.height = 185.438232421875, 100.0
    
    #initialize fire_ish_volume_1 links
    #fire_ish_volume_2.Emission -> material_output.Volume
    fire_ish_volume_1.links.new(fire_ish_volume_2.outputs[0], material_output.inputs[1])
    return fire_ish_volume_1

fire_ish_volume_1 = fire_ish_volume_1_node_group()

