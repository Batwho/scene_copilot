import bpy, mathutils

mat = bpy.data.materials.new(name = "Full Gras")
mat.use_nodes = True
#initialize Full_Gras node group
def full_gras_node_group():

    full_gras = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Full_Gras")
    
    #initialize full_gras nodes
    #node ColorRamp
    colorramp = full_gras.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.2954544126987457
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.3540004789829254, 1.0, 0.02761031500995159, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.6818184852600098)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.12702906131744385, 1.0, 0.007368852850049734, 1.0)

    
    #node ColorRamp.002
    colorramp_002 = full_gras.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.20454531908035278
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.7454547882080078)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.003
    colorramp_003 = full_gras.nodes.new("ShaderNodeValToRGB")
    colorramp_003.name = "ColorRamp.003"
    colorramp_003.color_ramp.color_mode = 'RGB'
    colorramp_003.color_ramp.hue_interpolation = 'NEAR'
    colorramp_003.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_003.color_ramp.elements.remove(colorramp_003.color_ramp.elements[0])
    colorramp_003_cre_0 = colorramp_003.color_ramp.elements[0]
    colorramp_003_cre_0.position = 0.3727271258831024
    colorramp_003_cre_0.alpha = 1.0
    colorramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_003_cre_1 = colorramp_003.color_ramp.elements.new(0.48181819915771484)
    colorramp_003_cre_1.alpha = 1.0
    colorramp_003_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_003_cre_2 = colorramp_003.color_ramp.elements.new(0.6318185329437256)
    colorramp_003_cre_2.alpha = 1.0
    colorramp_003_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Texture Coordinate.001
    texture_coordinate_001 = full_gras.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math.018
    vector_math_018 = full_gras.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    #Vector_001
    vector_math_018.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math_018.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Hue Saturation Value
    hue_saturation_value = full_gras.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Invert
    invert = full_gras.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = full_gras.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Bump.001
    bump_001 = full_gras.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Bump
    bump = full_gras.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = full_gras.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Math.001
    math_001 = full_gras.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    #node Reroute
    reroute = full_gras.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Group Input
    group_input = full_gras.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #full_gras inputs
    #input Color Hue
    full_gras.inputs.new('NodeSocketFloatFactor', "Color Hue")
    full_gras.inputs[0].default_value = 1.0
    full_gras.inputs[0].min_value = 0.0
    full_gras.inputs[0].max_value = 1.0
    full_gras.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    full_gras.inputs.new('NodeSocketFloat', "Scale")
    full_gras.inputs[1].default_value = 1.0
    full_gras.inputs[1].min_value = -10000.0
    full_gras.inputs[1].max_value = 10000.0
    full_gras.inputs[1].attribute_domain = 'POINT'
    
    #input Subsurface
    full_gras.inputs.new('NodeSocketFloatFactor', "Subsurface")
    full_gras.inputs[2].default_value = 0.20000000298023224
    full_gras.inputs[2].min_value = 0.0
    full_gras.inputs[2].max_value = 1.0
    full_gras.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    full_gras.inputs.new('NodeSocketFloatFactor', "Roughness")
    full_gras.inputs[3].default_value = 0.30000001192092896
    full_gras.inputs[3].min_value = 0.0
    full_gras.inputs[3].max_value = 1.0
    full_gras.inputs[3].attribute_domain = 'POINT'
    
    #input Saturation
    full_gras.inputs.new('NodeSocketFloat', "Saturation")
    full_gras.inputs[4].default_value = 1.0
    full_gras.inputs[4].min_value = 0.0
    full_gras.inputs[4].max_value = 2.0
    full_gras.inputs[4].attribute_domain = 'POINT'
    
    #input Brightness
    full_gras.inputs.new('NodeSocketFloat', "Brightness")
    full_gras.inputs[5].default_value = 1.0
    full_gras.inputs[5].min_value = 0.0
    full_gras.inputs[5].max_value = 2.0
    full_gras.inputs[5].attribute_domain = 'POINT'
    
    #input Detail
    full_gras.inputs.new('NodeSocketFloat', "Detail")
    full_gras.inputs[6].default_value = 10.0
    full_gras.inputs[6].min_value = 0.0
    full_gras.inputs[6].max_value = 15.0
    full_gras.inputs[6].attribute_domain = 'POINT'
    
    #input Bump Strength
    full_gras.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    full_gras.inputs[7].default_value = 1.0
    full_gras.inputs[7].min_value = 0.0
    full_gras.inputs[7].max_value = 1.0
    full_gras.inputs[7].attribute_domain = 'POINT'
    
    #input Normal
    full_gras.inputs.new('NodeSocketVector', "Normal")
    full_gras.inputs[8].default_value = (0.0, 0.0, 0.0)
    full_gras.inputs[8].min_value = -1.0
    full_gras.inputs[8].max_value = 1.0
    full_gras.inputs[8].attribute_domain = 'POINT'
    full_gras.inputs[8].hide_value = True
    
    
    
    #node Noise Texture
    noise_texture = full_gras.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5650001764297485
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mix
    mix = full_gras.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.001
    colorramp_001 = full_gras.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.0
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(1.0)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Noise Texture.001
    noise_texture_001 = full_gras.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #W
    noise_texture_001.inputs[1].default_value = 0.0
    #Scale
    noise_texture_001.inputs[2].default_value = 150.0
    #Detail
    noise_texture_001.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.8816668391227722
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0
    
    #node Mix.002
    mix_002 = full_gras.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = full_gras.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #full_gras outputs
    #output BSDF
    full_gras.outputs.new('NodeSocketShader', "BSDF")
    full_gras.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    full_gras.outputs.new('NodeSocketColor', "Albedo")
    full_gras.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    full_gras.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    full_gras.outputs.new('NodeSocketColor', "Mask")
    full_gras.outputs[2].default_value = (0.0, 0.0, 0.0, 0.0)
    full_gras.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Mix.001
    mix_001 = full_gras.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MULTIPLY'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 0.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #B_Color
    mix_001.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    
    
    #Set locations
    colorramp.location = (110.0001220703125, 120.0)
    colorramp_002.location = (426.7191162109375, 324.1829833984375)
    colorramp_003.location = (110.0001220703125, -340.0)
    texture_coordinate_001.location = (-1210.0, 80.0)
    vector_math_018.location = (-869.9999389648438, 160.0)
    hue_saturation_value.location = (930.0001220703125, 280.0)
    invert.location = (-260.0, 520.0)
    math.location = (180.0001220703125, 540.0)
    bump_001.location = (670.0001220703125, -20.00006103515625)
    bump.location = (650.0001220703125, -200.0)
    principled_bsdf.location = (1210.0001220703125, 251.4219970703125)
    math_001.location = (-320.0, -280.0)
    reroute.location = (-440.0, -280.0)
    group_input.location = (-1410.0, 0.0)
    noise_texture.location = (-309.9998779296875, -40.0)
    mix.location = (746.6666259765625, 197.0782470703125)
    colorramp_001.location = (110.0, -120.0)
    noise_texture_001.location = (190.0001220703125, 340.0)
    mix_002.location = (462.6414794921875, -137.0729217529297)
    group_output.location = (1500.0001220703125, 0.0)
    mix_001.location = (990.0001220703125, 100.0)
    
    #Set dimensions
    colorramp.width, colorramp.height = 240.0, 100.0
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    colorramp_003.width, colorramp_003.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    
    #initialize full_gras links
    #principled_bsdf.BSDF -> group_output.BSDF
    full_gras.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    full_gras.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> hue_saturation_value.Color
    full_gras.links.new(mix.outputs[2], hue_saturation_value.inputs[4])
    #bump.Normal -> principled_bsdf.Normal
    full_gras.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> colorramp_001.Fac
    full_gras.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #colorramp_001.Color -> bump.Height
    full_gras.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #colorramp_002.Color -> mix.B
    full_gras.links.new(colorramp_002.outputs[0], mix.inputs[7])
    #noise_texture_001.Fac -> colorramp_002.Fac
    full_gras.links.new(noise_texture_001.outputs[0], colorramp_002.inputs[0])
    #noise_texture.Fac -> colorramp_003.Fac
    full_gras.links.new(noise_texture.outputs[0], colorramp_003.inputs[0])
    #colorramp_003.Color -> mix.Factor
    full_gras.links.new(colorramp_003.outputs[0], mix.inputs[0])
    #colorramp.Color -> mix.A
    full_gras.links.new(colorramp.outputs[0], mix.inputs[6])
    #noise_texture_001.Fac -> bump_001.Height
    full_gras.links.new(noise_texture_001.outputs[0], bump_001.inputs[2])
    #bump_001.Normal -> bump.Normal
    full_gras.links.new(bump_001.outputs[0], bump.inputs[3])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    full_gras.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    full_gras.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #vector_math_018.Vector -> noise_texture_001.Vector
    full_gras.links.new(vector_math_018.outputs[0], noise_texture_001.inputs[0])
    #hue_saturation_value.Color -> mix_001.A
    full_gras.links.new(hue_saturation_value.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> principled_bsdf.Base Color
    full_gras.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #mix_001.Result -> principled_bsdf.Subsurface Color
    full_gras.links.new(mix_001.outputs[2], principled_bsdf.inputs[3])
    #group_input.Scale -> vector_math_018.Scale
    full_gras.links.new(group_input.outputs[1], vector_math_018.inputs[3])
    #group_input.Color Hue -> invert.Fac
    full_gras.links.new(group_input.outputs[0], invert.inputs[0])
    #invert.Color -> math.Value
    full_gras.links.new(invert.outputs[0], math.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    full_gras.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    full_gras.links.new(group_input.outputs[4], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    full_gras.links.new(group_input.outputs[5], hue_saturation_value.inputs[2])
    #group_input.Detail -> noise_texture.Detail
    full_gras.links.new(group_input.outputs[6], noise_texture.inputs[3])
    #group_input.Subsurface -> principled_bsdf.Subsurface
    full_gras.links.new(group_input.outputs[2], principled_bsdf.inputs[1])
    #mix_001.Result -> principled_bsdf.Subsurface Radius
    full_gras.links.new(mix_001.outputs[2], principled_bsdf.inputs[2])
    #group_input.Roughness -> principled_bsdf.Roughness
    full_gras.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #math_001.Value -> bump.Strength
    full_gras.links.new(math_001.outputs[0], bump.inputs[0])
    #reroute.Output -> bump_001.Strength
    full_gras.links.new(reroute.outputs[0], bump_001.inputs[0])
    #reroute.Output -> math_001.Value
    full_gras.links.new(reroute.outputs[0], math_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    full_gras.links.new(group_input.outputs[8], bump_001.inputs[3])
    #group_input.Bump Strength -> reroute.Input
    full_gras.links.new(group_input.outputs[7], reroute.inputs[0])
    #colorramp_001.Color -> mix_002.A
    full_gras.links.new(colorramp_001.outputs[0], mix_002.inputs[6])
    #noise_texture_001.Fac -> mix_002.B
    full_gras.links.new(noise_texture_001.outputs[0], mix_002.inputs[7])
    #mix_002.Result -> group_output.Mask
    full_gras.links.new(mix_002.outputs[2], group_output.inputs[2])
    #mix_001.Result -> group_output.Albedo
    full_gras.links.new(mix_001.outputs[2], group_output.inputs[1])
    return full_gras

full_gras = full_gras_node_group()

#initialize Full Gras node group
def full_gras_1_node_group():

    full_gras_1 = mat.node_tree
    #start with a clean node tree
    for node in full_gras_1.nodes:
        full_gras_1.nodes.remove(node)
    #initialize full_gras_1 nodes
    #node Material Output
    material_output = full_gras_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Full_Gras
    full_gras_2 = full_gras_1.nodes.new("ShaderNodeGroup")
    full_gras_2.label = "Full_Gras"
    full_gras_2.name = "Full_Gras"
    full_gras_2.node_tree = full_gras
    #Input_2
    full_gras_2.inputs[0].default_value = 0.0
    #Input_1
    full_gras_2.inputs[1].default_value = 1.0
    #Input_10
    full_gras_2.inputs[2].default_value = 0.20000000298023224
    #Input_11
    full_gras_2.inputs[3].default_value = 0.4000000059604645
    #Input_3
    full_gras_2.inputs[4].default_value = 1.0
    #Input_4
    full_gras_2.inputs[5].default_value = 1.0
    #Input_5
    full_gras_2.inputs[6].default_value = 8.0
    #Input_12
    full_gras_2.inputs[7].default_value = 1.0
    #Input_13
    full_gras_2.inputs[8].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (667.50439453125, 102.693115234375)
    full_gras_2.location = (447.50439453125, 91.27099609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    full_gras_2.width, full_gras_2.height = 160.74755859375, 100.0
    
    #initialize full_gras_1 links
    #full_gras_2.BSDF -> material_output.Surface
    full_gras_1.links.new(full_gras_2.outputs[0], material_output.inputs[0])
    return full_gras_1

full_gras_1 = full_gras_1_node_group()

