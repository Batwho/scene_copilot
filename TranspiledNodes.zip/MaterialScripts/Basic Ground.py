import bpy, mathutils

mat = bpy.data.materials.new(name = "Basic Ground")
mat.use_nodes = True
#initialize Basic_Ground node group
def basic_ground_node_group():

    basic_ground = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Basic_Ground")
    
    #initialize basic_ground nodes
    #node Principled BSDF
    principled_bsdf = basic_ground.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node ColorRamp.001
    colorramp_001 = basic_ground.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.31363633275032043
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.15620823204517365, 0.15620823204517365, 0.15620823204517365, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.7545456886291504)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = basic_ground.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Texture Coordinate.001
    texture_coordinate_001 = basic_ground.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math.018
    vector_math_018 = basic_ground.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    #Vector_001
    vector_math_018.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math_018.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp
    colorramp = basic_ground.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.4454544186592102
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.01024255994707346, 0.00681916531175375, 0.0050509958527982235, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.10055502504110336, 0.05107226222753525, 0.03123525343835354, 1.0)

    
    #node Group Input
    group_input = basic_ground.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #basic_ground inputs
    #input Scale
    basic_ground.inputs.new('NodeSocketFloat', "Scale")
    basic_ground.inputs[0].default_value = 1.0
    basic_ground.inputs[0].min_value = -10000.0
    basic_ground.inputs[0].max_value = 10000.0
    basic_ground.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    basic_ground.inputs.new('NodeSocketFloatFactor', "Color Hue")
    basic_ground.inputs[1].default_value = 1.0
    basic_ground.inputs[1].min_value = 0.0
    basic_ground.inputs[1].max_value = 1.0
    basic_ground.inputs[1].attribute_domain = 'POINT'
    
    #input Saturation
    basic_ground.inputs.new('NodeSocketFloat', "Saturation")
    basic_ground.inputs[2].default_value = 1.0
    basic_ground.inputs[2].min_value = 0.0
    basic_ground.inputs[2].max_value = 2.0
    basic_ground.inputs[2].attribute_domain = 'POINT'
    
    #input Brightness
    basic_ground.inputs.new('NodeSocketFloat', "Brightness")
    basic_ground.inputs[3].default_value = 1.0
    basic_ground.inputs[3].min_value = 0.0
    basic_ground.inputs[3].max_value = 2.0
    basic_ground.inputs[3].attribute_domain = 'POINT'
    
    #input Detail
    basic_ground.inputs.new('NodeSocketFloat', "Detail")
    basic_ground.inputs[4].default_value = 9.0
    basic_ground.inputs[4].min_value = 0.0
    basic_ground.inputs[4].max_value = 15.0
    basic_ground.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    basic_ground.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    basic_ground.inputs[5].default_value = 0.5
    basic_ground.inputs[5].min_value = 0.0
    basic_ground.inputs[5].max_value = 1.0
    basic_ground.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    basic_ground.inputs.new('NodeSocketVector', "Normal")
    basic_ground.inputs[6].default_value = (0.0, 0.0, 0.0)
    basic_ground.inputs[6].min_value = -1.0
    basic_ground.inputs[6].max_value = 1.0
    basic_ground.inputs[6].attribute_domain = 'POINT'
    basic_ground.inputs[6].hide_value = True
    
    
    
    #node Group Output
    group_output = basic_ground.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #basic_ground outputs
    #output BSDF
    basic_ground.outputs.new('NodeSocketShader', "BSDF")
    basic_ground.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    basic_ground.outputs.new('NodeSocketColor', "Albedo")
    basic_ground.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    basic_ground.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    basic_ground.outputs.new('NodeSocketFloat', "Mask")
    basic_ground.outputs[2].default_value = 0.0
    basic_ground.outputs[2].min_value = -3.4028234663852886e+38
    basic_ground.outputs[2].max_value = 3.4028234663852886e+38
    basic_ground.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Invert
    invert = basic_ground.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Math
    math = basic_ground.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.5
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Hue Saturation Value
    hue_saturation_value = basic_ground.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Noise Texture
    noise_texture = basic_ground.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 5.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.7749999761581421
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    
    #Set locations
    principled_bsdf.location = (729.7711181640625, 240.0)
    colorramp_001.location = (170.228759765625, -3.0517578125e-05)
    bump.location = (250.22900390625, -240.0)
    texture_coordinate_001.location = (-729.7711181640625, -80.0)
    vector_math_018.location = (-389.77117919921875, -3.0517578125e-05)
    colorramp.location = (190.2288818359375, 199.99996948242188)
    group_input.location = (-929.7711181640625, -0.0)
    group_output.location = (1019.7711181640625, -0.0)
    invert.location = (-180.0, 260.0)
    math.location = (120.0, 360.0)
    hue_saturation_value.location = (510.228759765625, 199.99996948242188)
    noise_texture.location = (-49.7711181640625, 39.999969482421875)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize basic_ground links
    #principled_bsdf.BSDF -> group_output.BSDF
    basic_ground.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #colorramp.Color -> hue_saturation_value.Color
    basic_ground.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #noise_texture.Fac -> colorramp.Fac
    basic_ground.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #colorramp_001.Color -> principled_bsdf.Roughness
    basic_ground.links.new(colorramp_001.outputs[0], principled_bsdf.inputs[9])
    #noise_texture.Fac -> colorramp_001.Fac
    basic_ground.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    basic_ground.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    basic_ground.links.new(noise_texture.outputs[0], bump.inputs[2])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    basic_ground.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> noise_texture.Vector
    basic_ground.links.new(vector_math_018.outputs[0], noise_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    basic_ground.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #group_input.Saturation -> hue_saturation_value.Saturation
    basic_ground.links.new(group_input.outputs[2], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    basic_ground.links.new(group_input.outputs[3], hue_saturation_value.inputs[2])
    #group_input.Detail -> noise_texture.Detail
    basic_ground.links.new(group_input.outputs[4], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    basic_ground.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    basic_ground.links.new(group_input.outputs[6], bump.inputs[3])
    #group_input.Color Hue -> invert.Fac
    basic_ground.links.new(group_input.outputs[1], invert.inputs[0])
    #invert.Color -> math.Value
    basic_ground.links.new(invert.outputs[0], math.inputs[0])
    #math.Value -> hue_saturation_value.Hue
    basic_ground.links.new(math.outputs[0], hue_saturation_value.inputs[0])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    basic_ground.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #noise_texture.Fac -> group_output.Mask
    basic_ground.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #hue_saturation_value.Color -> group_output.Albedo
    basic_ground.links.new(hue_saturation_value.outputs[0], group_output.inputs[1])
    return basic_ground

basic_ground = basic_ground_node_group()

#initialize Basic Ground node group
def basic_ground_1_node_group():

    basic_ground_1 = mat.node_tree
    #start with a clean node tree
    for node in basic_ground_1.nodes:
        basic_ground_1.nodes.remove(node)
    #initialize basic_ground_1 nodes
    #node Material Output
    material_output = basic_ground_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Basic_Ground
    basic_ground_2 = basic_ground_1.nodes.new("ShaderNodeGroup")
    basic_ground_2.label = "Basic_Ground"
    basic_ground_2.name = "Basic_Ground"
    basic_ground_2.node_tree = basic_ground
    #Input_1
    basic_ground_2.inputs[0].default_value = 1.0
    #Input_8
    basic_ground_2.inputs[1].default_value = 0.0
    #Input_3
    basic_ground_2.inputs[2].default_value = 1.0
    #Input_4
    basic_ground_2.inputs[3].default_value = 1.0
    #Input_5
    basic_ground_2.inputs[4].default_value = 9.0
    #Input_6
    basic_ground_2.inputs[5].default_value = 0.699999988079071
    #Input_7
    basic_ground_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (714.4990234375, 70.4775390625)
    basic_ground_2.location = (474.95703125, 70.4775390625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    basic_ground_2.width, basic_ground_2.height = 155.18402099609375, 100.0
    
    #initialize basic_ground_1 links
    #basic_ground_2.BSDF -> material_output.Surface
    basic_ground_1.links.new(basic_ground_2.outputs[0], material_output.inputs[0])
    return basic_ground_1

basic_ground_1 = basic_ground_1_node_group()

