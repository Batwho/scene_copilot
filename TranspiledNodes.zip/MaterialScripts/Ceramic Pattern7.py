import bpy, mathutils

mat = bpy.data.materials.new(name = "Ceramic Pattern7")
mat.use_nodes = True
#initialize Ceramic Pattern7 node group
def ceramic_pattern7_node_group():

    ceramic_pattern7 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Ceramic Pattern7")
    
    #initialize ceramic_pattern7 nodes
    #node Noise Texture
    noise_texture = ceramic_pattern7.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Scale
    noise_texture.inputs[2].default_value = 1.4600000381469727
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Mapping
    mapping = ceramic_pattern7.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    mapping.inputs[3].default_value = (1.0, 1.0, 1.0)
    
    #node ColorRamp
    colorramp = ceramic_pattern7.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5454549789428711)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Checker Texture
    checker_texture = ceramic_pattern7.nodes.new("ShaderNodeTexChecker")
    checker_texture.name = "Checker Texture"
    #Color1
    checker_texture.inputs[1].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Color2
    checker_texture.inputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    #Scale
    checker_texture.inputs[3].default_value = 5.0
    
    #node Group Output
    group_output = ceramic_pattern7.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #ceramic_pattern7 outputs
    #output BSDF
    ceramic_pattern7.outputs.new('NodeSocketShader', "BSDF")
    ceramic_pattern7.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    ceramic_pattern7.outputs.new('NodeSocketColor', "Albedo")
    ceramic_pattern7.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    ceramic_pattern7.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    ceramic_pattern7.outputs.new('NodeSocketFloat', "Mask")
    ceramic_pattern7.outputs[2].default_value = 0.0
    ceramic_pattern7.outputs[2].min_value = -3.4028234663852886e+38
    ceramic_pattern7.outputs[2].max_value = 3.4028234663852886e+38
    ceramic_pattern7.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Vector Math
    vector_math = ceramic_pattern7.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    #Vector_001
    vector_math.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Texture Coordinate
    texture_coordinate = ceramic_pattern7.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Mix
    mix = ceramic_pattern7.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.7749999761581421
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.001
    mix_001 = ceramic_pattern7.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.001
    colorramp_001 = ceramic_pattern7.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'B_SPLINE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.4090907573699951
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5545452237129211)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_2 = colorramp_001.color_ramp.elements.new(0.6272727847099304)
    colorramp_001_cre_2.alpha = 1.0
    colorramp_001_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_001_cre_3 = colorramp_001.color_ramp.elements.new(0.7772724628448486)
    colorramp_001_cre_3.alpha = 1.0
    colorramp_001_cre_3.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Bump
    bump = ceramic_pattern7.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = ceramic_pattern7.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Group Input
    group_input = ceramic_pattern7.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #ceramic_pattern7 inputs
    #input Color1
    ceramic_pattern7.inputs.new('NodeSocketColor', "Color1")
    ceramic_pattern7.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    ceramic_pattern7.inputs[0].attribute_domain = 'POINT'
    
    #input Color2
    ceramic_pattern7.inputs.new('NodeSocketColor', "Color2")
    ceramic_pattern7.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    ceramic_pattern7.inputs[1].attribute_domain = 'POINT'
    
    #input Scale
    ceramic_pattern7.inputs.new('NodeSocketFloat', "Scale")
    ceramic_pattern7.inputs[2].default_value = 1.0
    ceramic_pattern7.inputs[2].min_value = -10000.0
    ceramic_pattern7.inputs[2].max_value = 10000.0
    ceramic_pattern7.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    ceramic_pattern7.inputs.new('NodeSocketFloatFactor', "Roughness")
    ceramic_pattern7.inputs[3].default_value = 0.0
    ceramic_pattern7.inputs[3].min_value = 0.0
    ceramic_pattern7.inputs[3].max_value = 1.0
    ceramic_pattern7.inputs[3].attribute_domain = 'POINT'
    
    #input Detail
    ceramic_pattern7.inputs.new('NodeSocketFloat', "Detail")
    ceramic_pattern7.inputs[4].default_value = 2.0
    ceramic_pattern7.inputs[4].min_value = 0.0
    ceramic_pattern7.inputs[4].max_value = 15.0
    ceramic_pattern7.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    ceramic_pattern7.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    ceramic_pattern7.inputs[5].default_value = 1.0
    ceramic_pattern7.inputs[5].min_value = 0.0
    ceramic_pattern7.inputs[5].max_value = 1.0
    ceramic_pattern7.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    ceramic_pattern7.inputs.new('NodeSocketVector', "Normal")
    ceramic_pattern7.inputs[6].default_value = (0.0, 0.0, 0.0)
    ceramic_pattern7.inputs[6].min_value = -1.0
    ceramic_pattern7.inputs[6].max_value = 1.0
    ceramic_pattern7.inputs[6].attribute_domain = 'POINT'
    ceramic_pattern7.inputs[6].hide_value = True
    
    
    
    
    #Set locations
    noise_texture.location = (-200.043212890625, -10.0)
    mapping.location = (-489.32623291015625, 94.77618408203125)
    colorramp.location = (421.956787109375, 129.99996948242188)
    checker_texture.location = (260.956787109375, 150.0)
    group_output.location = (1298.4990234375, -0.0)
    vector_math.location = (-687.448974609375, 162.07882690429688)
    texture_coordinate.location = (-1008.4990234375, 88.34512329101562)
    mix.location = (40.956787109375, 160.270751953125)
    mix_001.location = (770.0533447265625, 166.40057373046875)
    colorramp_001.location = (359.956787109375, -90.0)
    bump.location = (719.9568481445312, -210.0)
    principled_bsdf.location = (1008.4990234375, 210.0)
    group_input.location = (-1208.4990234375, -0.0)
    
    #Set dimensions
    noise_texture.width, noise_texture.height = 140.0, 100.0
    mapping.width, mapping.height = 240.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    checker_texture.width, checker_texture.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize ceramic_pattern7 links
    #principled_bsdf.BSDF -> group_output.BSDF
    ceramic_pattern7.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #mix_001.Result -> principled_bsdf.Base Color
    ceramic_pattern7.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #colorramp_001.Color -> bump.Height
    ceramic_pattern7.links.new(colorramp_001.outputs[0], bump.inputs[2])
    #bump.Normal -> principled_bsdf.Normal
    ceramic_pattern7.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #mapping.Vector -> noise_texture.Vector
    ceramic_pattern7.links.new(mapping.outputs[0], noise_texture.inputs[0])
    #mix.Result -> checker_texture.Vector
    ceramic_pattern7.links.new(mix.outputs[2], checker_texture.inputs[0])
    #noise_texture.Fac -> mix.B
    ceramic_pattern7.links.new(noise_texture.outputs[0], mix.inputs[7])
    #mapping.Vector -> mix.A
    ceramic_pattern7.links.new(mapping.outputs[0], mix.inputs[6])
    #checker_texture.Color -> colorramp.Fac
    ceramic_pattern7.links.new(checker_texture.outputs[0], colorramp.inputs[0])
    #checker_texture.Color -> colorramp_001.Fac
    ceramic_pattern7.links.new(checker_texture.outputs[0], colorramp_001.inputs[0])
    #texture_coordinate.Object -> vector_math.Vector
    ceramic_pattern7.links.new(texture_coordinate.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mapping.Vector
    ceramic_pattern7.links.new(vector_math.outputs[0], mapping.inputs[0])
    #group_input.Scale -> vector_math.Scale
    ceramic_pattern7.links.new(group_input.outputs[2], vector_math.inputs[3])
    #colorramp.Color -> mix_001.Factor
    ceramic_pattern7.links.new(colorramp.outputs[0], mix_001.inputs[0])
    #group_input.Color1 -> mix_001.A
    ceramic_pattern7.links.new(group_input.outputs[0], mix_001.inputs[6])
    #group_input.Color2 -> mix_001.B
    ceramic_pattern7.links.new(group_input.outputs[1], mix_001.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    ceramic_pattern7.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Detail -> noise_texture.Detail
    ceramic_pattern7.links.new(group_input.outputs[4], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    ceramic_pattern7.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    ceramic_pattern7.links.new(group_input.outputs[6], bump.inputs[3])
    #checker_texture.Fac -> group_output.Mask
    ceramic_pattern7.links.new(checker_texture.outputs[1], group_output.inputs[2])
    #mix_001.Result -> group_output.Albedo
    ceramic_pattern7.links.new(mix_001.outputs[2], group_output.inputs[1])
    return ceramic_pattern7

ceramic_pattern7 = ceramic_pattern7_node_group()

#initialize Ceramic Pattern7 node group
def ceramic_pattern7_1_node_group():

    ceramic_pattern7_1 = mat.node_tree
    #start with a clean node tree
    for node in ceramic_pattern7_1.nodes:
        ceramic_pattern7_1.nodes.remove(node)
    #initialize ceramic_pattern7_1 nodes
    #node Material Output
    material_output = ceramic_pattern7_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output.inputs[3].default_value = 0.0
    
    #node Ceramic Pattern7
    ceramic_pattern7_2 = ceramic_pattern7_1.nodes.new("ShaderNodeGroup")
    ceramic_pattern7_2.label = "Ceramic Pattern7"
    ceramic_pattern7_2.name = "Ceramic Pattern7"
    ceramic_pattern7_2.node_tree = ceramic_pattern7
    #Input_2
    ceramic_pattern7_2.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_3
    ceramic_pattern7_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_1
    ceramic_pattern7_2.inputs[2].default_value = 1.0
    #Input_4
    ceramic_pattern7_2.inputs[3].default_value = 0.0
    #Input_5
    ceramic_pattern7_2.inputs[4].default_value = 2.0
    #Input_11
    ceramic_pattern7_2.inputs[5].default_value = 1.0
    #Input_12
    ceramic_pattern7_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (707.521484375, 89.676513671875)
    ceramic_pattern7_2.location = (420.8134765625, 91.27099609375)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    ceramic_pattern7_2.width, ceramic_pattern7_2.height = 172.0166015625, 100.0
    
    #initialize ceramic_pattern7_1 links
    #ceramic_pattern7_2.BSDF -> material_output.Surface
    ceramic_pattern7_1.links.new(ceramic_pattern7_2.outputs[0], material_output.inputs[0])
    return ceramic_pattern7_1

ceramic_pattern7_1 = ceramic_pattern7_1_node_group()

