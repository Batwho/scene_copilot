import bpy, mathutils

mat = bpy.data.materials.new(name = "Scifi Stars2")
mat.use_nodes = True
#initialize Scifi_Stars2 node group
def scifi_stars2_node_group():

    scifi_stars2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Scifi_Stars2")
    
    #initialize scifi_stars2 nodes
    #node Texture Coordinate.001
    texture_coordinate_001 = scifi_stars2.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math.018
    vector_math_018 = scifi_stars2.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Bump
    bump = scifi_stars2.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Invert
    invert = scifi_stars2.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Group Input
    group_input = scifi_stars2.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #scifi_stars2 inputs
    #input Scale
    scifi_stars2.inputs.new('NodeSocketFloat', "Scale")
    scifi_stars2.inputs[0].default_value = 1.0
    scifi_stars2.inputs[0].min_value = -10000.0
    scifi_stars2.inputs[0].max_value = 10000.0
    scifi_stars2.inputs[0].attribute_domain = 'POINT'
    
    #input Roughness
    scifi_stars2.inputs.new('NodeSocketFloatFactor', "Roughness")
    scifi_stars2.inputs[1].default_value = 0.0
    scifi_stars2.inputs[1].min_value = 0.0
    scifi_stars2.inputs[1].max_value = 1.0
    scifi_stars2.inputs[1].attribute_domain = 'POINT'
    
    #input Emission Color
    scifi_stars2.inputs.new('NodeSocketColor', "Emission Color")
    scifi_stars2.inputs[2].default_value = (1.0, 0.49543899297714233, 0.13897870481014252, 1.0)
    scifi_stars2.inputs[2].attribute_domain = 'POINT'
    
    #input Metall Color
    scifi_stars2.inputs.new('NodeSocketColor', "Metall Color")
    scifi_stars2.inputs[3].default_value = (0.5, 0.5, 0.5, 1.0)
    scifi_stars2.inputs[3].attribute_domain = 'POINT'
    
    #input Emission Strength
    scifi_stars2.inputs.new('NodeSocketFloat', "Emission Strength")
    scifi_stars2.inputs[4].default_value = 10.0
    scifi_stars2.inputs[4].min_value = -10000.0
    scifi_stars2.inputs[4].max_value = 10000.0
    scifi_stars2.inputs[4].attribute_domain = 'POINT'
    
    #input Emission Mask
    scifi_stars2.inputs.new('NodeSocketFloatFactor', "Emission Mask")
    scifi_stars2.inputs[5].default_value = 0.06666672229766846
    scifi_stars2.inputs[5].min_value = 0.0
    scifi_stars2.inputs[5].max_value = 1.0
    scifi_stars2.inputs[5].attribute_domain = 'POINT'
    
    #input Exponent
    scifi_stars2.inputs.new('NodeSocketFloat', "Exponent")
    scifi_stars2.inputs[6].default_value = 0.28000056743621826
    scifi_stars2.inputs[6].min_value = 0.0
    scifi_stars2.inputs[6].max_value = 32.0
    scifi_stars2.inputs[6].attribute_domain = 'POINT'
    
    #input Randomness
    scifi_stars2.inputs.new('NodeSocketFloatFactor', "Randomness")
    scifi_stars2.inputs[7].default_value = 1.0
    scifi_stars2.inputs[7].min_value = 0.0
    scifi_stars2.inputs[7].max_value = 1.0
    scifi_stars2.inputs[7].attribute_domain = 'POINT'
    
    #input Bump Strength
    scifi_stars2.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    scifi_stars2.inputs[8].default_value = 1.0
    scifi_stars2.inputs[8].min_value = 0.0
    scifi_stars2.inputs[8].max_value = 1.0
    scifi_stars2.inputs[8].attribute_domain = 'POINT'
    
    #input Normal
    scifi_stars2.inputs.new('NodeSocketVector', "Normal")
    scifi_stars2.inputs[9].default_value = (0.0, 0.0, 0.0)
    scifi_stars2.inputs[9].min_value = -1.0
    scifi_stars2.inputs[9].max_value = 1.0
    scifi_stars2.inputs[9].attribute_domain = 'POINT'
    scifi_stars2.inputs[9].hide_value = True
    
    
    
    #node Reroute
    reroute = scifi_stars2.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Voronoi Texture
    voronoi_texture = scifi_stars2.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 2.5
    
    #node ColorRamp
    colorramp = scifi_stars2.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Reroute.001
    reroute_001 = scifi_stars2.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Mix
    mix = scifi_stars2.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'BURN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #B_Color
    mix.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Mix.001
    mix_001 = scifi_stars2.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'COLOR'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    
    #node Math
    math = scifi_stars2.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    
    #node Principled BSDF
    principled_bsdf = scifi_stars2.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Mix.002
    mix_002 = scifi_stars2.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    
    #node Group Output
    group_output = scifi_stars2.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #scifi_stars2 outputs
    #output BSDF
    scifi_stars2.outputs.new('NodeSocketShader', "BSDF")
    scifi_stars2.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    scifi_stars2.outputs.new('NodeSocketColor', "Albedo")
    scifi_stars2.outputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    scifi_stars2.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    scifi_stars2.outputs.new('NodeSocketFloat', "Mask")
    scifi_stars2.outputs[2].default_value = 0.0
    scifi_stars2.outputs[2].min_value = -3.4028234663852886e+38
    scifi_stars2.outputs[2].max_value = 3.4028234663852886e+38
    scifi_stars2.outputs[2].attribute_domain = 'POINT'
    
    
    
    
    #Set locations
    texture_coordinate_001.location = (-1295.0770263671875, -141.71368408203125)
    vector_math_018.location = (-955.0770263671875, -61.7137451171875)
    bump.location = (460.0001220703125, -320.0)
    invert.location = (-260.0, 0.0)
    group_input.location = (-1495.0770263671875, -0.0)
    reroute.location = (604.2799682617188, 117.65215301513672)
    voronoi_texture.location = (-15.0770263671875, 78.2862548828125)
    colorramp.location = (204.9229736328125, 261.7137451171875)
    reroute_001.location = (649.2603759765625, -283.94427490234375)
    mix.location = (520.0, 20.0)
    mix_001.location = (679.9998779296875, 330.4207763671875)
    math.location = (1074.9251708984375, -51.000335693359375)
    principled_bsdf.location = (1295.0770263671875, 218.2862548828125)
    mix_002.location = (1120.000244140625, 371.7076416015625)
    group_output.location = (1585.0770263671875, -0.0)
    
    #Set dimensions
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    
    #initialize scifi_stars2 links
    #principled_bsdf.BSDF -> group_output.BSDF
    scifi_stars2.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    scifi_stars2.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Color -> bump.Height
    scifi_stars2.links.new(voronoi_texture.outputs[1], bump.inputs[2])
    #mix_001.Result -> principled_bsdf.Base Color
    scifi_stars2.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #voronoi_texture.Color -> colorramp.Fac
    scifi_stars2.links.new(voronoi_texture.outputs[1], colorramp.inputs[0])
    #math.Value -> principled_bsdf.Emission Strength
    scifi_stars2.links.new(math.outputs[0], principled_bsdf.inputs[20])
    #mix.Result -> math.Value
    scifi_stars2.links.new(mix.outputs[2], math.inputs[0])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    scifi_stars2.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> voronoi_texture.Vector
    scifi_stars2.links.new(vector_math_018.outputs[0], voronoi_texture.inputs[0])
    #group_input.Scale -> vector_math_018.Scale
    scifi_stars2.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #reroute_001.Output -> principled_bsdf.Emission
    scifi_stars2.links.new(reroute_001.outputs[0], principled_bsdf.inputs[19])
    #colorramp.Color -> mix_001.A
    scifi_stars2.links.new(colorramp.outputs[0], mix_001.inputs[6])
    #reroute.Output -> mix_001.B
    scifi_stars2.links.new(reroute.outputs[0], mix_001.inputs[7])
    #group_input.Emission Strength -> math.Value
    scifi_stars2.links.new(group_input.outputs[4], math.inputs[1])
    #group_input.Roughness -> principled_bsdf.Roughness
    scifi_stars2.links.new(group_input.outputs[1], principled_bsdf.inputs[9])
    #group_input.Bump Strength -> bump.Strength
    scifi_stars2.links.new(group_input.outputs[8], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    scifi_stars2.links.new(group_input.outputs[9], bump.inputs[3])
    #voronoi_texture.Color -> mix.A
    scifi_stars2.links.new(voronoi_texture.outputs[1], mix.inputs[6])
    #invert.Color -> mix.Factor
    scifi_stars2.links.new(invert.outputs[0], mix.inputs[0])
    #group_input.Emission Mask -> invert.Color
    scifi_stars2.links.new(group_input.outputs[5], invert.inputs[1])
    #group_input.Exponent -> voronoi_texture.Exponent
    scifi_stars2.links.new(group_input.outputs[6], voronoi_texture.inputs[4])
    #group_input.Randomness -> voronoi_texture.Randomness
    scifi_stars2.links.new(group_input.outputs[7], voronoi_texture.inputs[5])
    #voronoi_texture.Distance -> group_output.Mask
    scifi_stars2.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #group_input.Metall Color -> reroute.Input
    scifi_stars2.links.new(group_input.outputs[3], reroute.inputs[0])
    #reroute.Output -> mix_002.A
    scifi_stars2.links.new(reroute.outputs[0], mix_002.inputs[6])
    #group_input.Emission Color -> reroute_001.Input
    scifi_stars2.links.new(group_input.outputs[2], reroute_001.inputs[0])
    #reroute_001.Output -> mix_002.B
    scifi_stars2.links.new(reroute_001.outputs[0], mix_002.inputs[7])
    #math.Value -> mix_002.Factor
    scifi_stars2.links.new(math.outputs[0], mix_002.inputs[0])
    #mix_002.Result -> group_output.Albedo
    scifi_stars2.links.new(mix_002.outputs[2], group_output.inputs[1])
    return scifi_stars2

scifi_stars2 = scifi_stars2_node_group()

#initialize Scifi Stars2 node group
def scifi_stars2_1_node_group():

    scifi_stars2_1 = mat.node_tree
    #start with a clean node tree
    for node in scifi_stars2_1.nodes:
        scifi_stars2_1.nodes.remove(node)
    #initialize scifi_stars2_1 nodes
    #node Material Output
    material_output = scifi_stars2_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Scifi_Stars2
    scifi_stars2_2 = scifi_stars2_1.nodes.new("ShaderNodeGroup")
    scifi_stars2_2.label = "Scifi_Stars2"
    scifi_stars2_2.name = "Scifi_Stars2"
    scifi_stars2_2.node_tree = scifi_stars2
    #Input_1
    scifi_stars2_2.inputs[0].default_value = 1.0
    #Input_5
    scifi_stars2_2.inputs[1].default_value = 0.0
    #Input_2
    scifi_stars2_2.inputs[2].default_value = (1.0, 0.49543899297714233, 0.13897870481014252, 1.0)
    #Input_3
    scifi_stars2_2.inputs[3].default_value = (0.015065829269587994, 0.44617989659309387, 1.0, 1.0)
    #Input_4
    scifi_stars2_2.inputs[4].default_value = 5.0
    #Input_8
    scifi_stars2_2.inputs[5].default_value = 0.28888893127441406
    #Input_9
    scifi_stars2_2.inputs[6].default_value = 0.28000056743621826
    #Input_10
    scifi_stars2_2.inputs[7].default_value = 1.0
    #Input_6
    scifi_stars2_2.inputs[8].default_value = 1.0
    #Input_7
    scifi_stars2_2.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (646.55126953125, 60.080810546875)
    scifi_stars2_2.location = (331.1806640625, 60.080810546875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    scifi_stars2_2.width, scifi_stars2_2.height = 245.575927734375, 100.0
    
    #initialize scifi_stars2_1 links
    #scifi_stars2_2.BSDF -> material_output.Surface
    scifi_stars2_1.links.new(scifi_stars2_2.outputs[0], material_output.inputs[0])
    return scifi_stars2_1

scifi_stars2_1 = scifi_stars2_1_node_group()

