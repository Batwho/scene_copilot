import bpy, mathutils

mat = bpy.data.materials.new(name = "Indian Pattern3")
mat.use_nodes = True
#initialize Fabric_Pattern3 node group
def fabric_pattern3_node_group():

    fabric_pattern3 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Fabric_Pattern3")
    
    #initialize fabric_pattern3 nodes
    #node ColorRamp.002
    colorramp_002 = fabric_pattern3.nodes.new("ShaderNodeValToRGB")
    colorramp_002.name = "ColorRamp.002"
    colorramp_002.color_ramp.color_mode = 'RGB'
    colorramp_002.color_ramp.hue_interpolation = 'NEAR'
    colorramp_002.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_002.color_ramp.elements.remove(colorramp_002.color_ramp.elements[0])
    colorramp_002_cre_0 = colorramp_002.color_ramp.elements[0]
    colorramp_002_cre_0.position = 0.3954545855522156
    colorramp_002_cre_0.alpha = 1.0
    colorramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_002_cre_1 = colorramp_002.color_ramp.elements.new(0.6363639831542969)
    colorramp_002_cre_1.alpha = 1.0
    colorramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Noise Texture
    noise_texture = fabric_pattern3.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node ColorRamp.005
    colorramp_005 = fabric_pattern3.nodes.new("ShaderNodeValToRGB")
    colorramp_005.name = "ColorRamp.005"
    colorramp_005.color_ramp.color_mode = 'RGB'
    colorramp_005.color_ramp.hue_interpolation = 'NEAR'
    colorramp_005.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_005.color_ramp.elements.remove(colorramp_005.color_ramp.elements[0])
    colorramp_005_cre_0 = colorramp_005.color_ramp.elements[0]
    colorramp_005_cre_0.position = 0.24090909957885742
    colorramp_005_cre_0.alpha = 1.0
    colorramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_005_cre_1 = colorramp_005.color_ramp.elements.new(0.6636365652084351)
    colorramp_005_cre_1.alpha = 1.0
    colorramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.006
    colorramp_006 = fabric_pattern3.nodes.new("ShaderNodeValToRGB")
    colorramp_006.name = "ColorRamp.006"
    colorramp_006.color_ramp.color_mode = 'RGB'
    colorramp_006.color_ramp.hue_interpolation = 'NEAR'
    colorramp_006.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_006.color_ramp.elements.remove(colorramp_006.color_ramp.elements[0])
    colorramp_006_cre_0 = colorramp_006.color_ramp.elements[0]
    colorramp_006_cre_0.position = 0.29545459151268005
    colorramp_006_cre_0.alpha = 1.0
    colorramp_006_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_006_cre_1 = colorramp_006.color_ramp.elements.new(0.6818183660507202)
    colorramp_006_cre_1.alpha = 1.0
    colorramp_006_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node ColorRamp.001
    colorramp_001 = fabric_pattern3.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.40454524755477905
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.7181820273399353)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.004
    mix_004 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 1.0
    
    #node Mix.005
    mix_005 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MULTIPLY'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_005.inputs[0].default_value = 1.0
    #A_Color
    mix_005.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    
    #node Mix
    mix = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'ADD'
    mix.clamp_factor = True
    mix.clamp_result = True
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Mix.001
    mix_001 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'ADD'
    mix_001.clamp_factor = True
    mix_001.clamp_result = True
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    
    #node Wave Texture.001
    wave_texture_001 = fabric_pattern3.nodes.new("ShaderNodeTexWave")
    wave_texture_001.name = "Wave Texture.001"
    wave_texture_001.bands_direction = 'Y'
    wave_texture_001.rings_direction = 'X'
    wave_texture_001.wave_profile = 'SIN'
    wave_texture_001.wave_type = 'BANDS'
    #Distortion
    wave_texture_001.inputs[2].default_value = 1.5
    #Detail
    wave_texture_001.inputs[3].default_value = 2.0
    #Detail Scale
    wave_texture_001.inputs[4].default_value = 1.6200000047683716
    #Detail Roughness
    wave_texture_001.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture_001.inputs[6].default_value = 0.0
    
    #node Wave Texture.002
    wave_texture_002 = fabric_pattern3.nodes.new("ShaderNodeTexWave")
    wave_texture_002.name = "Wave Texture.002"
    wave_texture_002.bands_direction = 'X'
    wave_texture_002.rings_direction = 'X'
    wave_texture_002.wave_profile = 'SIN'
    wave_texture_002.wave_type = 'BANDS'
    #Distortion
    wave_texture_002.inputs[2].default_value = 1.5
    #Detail
    wave_texture_002.inputs[3].default_value = 1.2000000476837158
    #Detail Scale
    wave_texture_002.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture_002.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture_002.inputs[6].default_value = 0.0
    
    #node ColorRamp
    colorramp = fabric_pattern3.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix.003
    mix_003 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MULTIPLY'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    
    #node Texture Coordinate.002
    texture_coordinate_002 = fabric_pattern3.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_002.name = "Texture Coordinate.002"
    texture_coordinate_002.from_instancer = False
    
    #node Wave Texture
    wave_texture = fabric_pattern3.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Distortion
    wave_texture.inputs[2].default_value = 1.5
    #Detail
    wave_texture.inputs[3].default_value = 1.2000000476837158
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Combine XYZ
    combine_xyz = fabric_pattern3.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"
    
    #node Mix.007
    mix_007 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_007.name = "Mix.007"
    mix_007.blend_type = 'MIX'
    mix_007.clamp_factor = True
    mix_007.clamp_result = False
    mix_007.data_type = 'RGBA'
    mix_007.factor_mode = 'UNIFORM'
    
    #node Separate XYZ
    separate_xyz = fabric_pattern3.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"
    
    #node Group Output
    group_output = fabric_pattern3.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #fabric_pattern3 outputs
    #output BSDF
    fabric_pattern3.outputs.new('NodeSocketShader', "BSDF")
    fabric_pattern3.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    fabric_pattern3.outputs.new('NodeSocketColor', "Albedo")
    fabric_pattern3.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    fabric_pattern3.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    fabric_pattern3.outputs.new('NodeSocketColor', "Mask")
    fabric_pattern3.outputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    fabric_pattern3.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Principled BSDF
    principled_bsdf = fabric_pattern3.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 1.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 1.5
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (1.0, 1.0, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node ColorRamp.004
    colorramp_004 = fabric_pattern3.nodes.new("ShaderNodeValToRGB")
    colorramp_004.name = "ColorRamp.004"
    colorramp_004.color_ramp.color_mode = 'RGB'
    colorramp_004.color_ramp.hue_interpolation = 'NEAR'
    colorramp_004.color_ramp.interpolation = 'CONSTANT'
    
    #initialize color ramp elements
    colorramp_004.color_ramp.elements.remove(colorramp_004.color_ramp.elements[0])
    colorramp_004_cre_0 = colorramp_004.color_ramp.elements[0]
    colorramp_004_cre_0.position = 0.0
    colorramp_004_cre_0.alpha = 1.0
    colorramp_004_cre_0.color = (1.0, 0.0010965407127514482, 0.0, 1.0)

    colorramp_004_cre_1 = colorramp_004.color_ramp.elements.new(0.07727279514074326)
    colorramp_004_cre_1.alpha = 1.0
    colorramp_004_cre_1.color = (1.0, 0.2780982255935669, 0.041549935936927795, 1.0)

    colorramp_004_cre_2 = colorramp_004.color_ramp.elements.new(0.7159091830253601)
    colorramp_004_cre_2.alpha = 1.0
    colorramp_004_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    colorramp_004_cre_3 = colorramp_004.color_ramp.elements.new(0.8318184614181519)
    colorramp_004_cre_3.alpha = 1.0
    colorramp_004_cre_3.color = (0.00794481672346592, 0.22937750816345215, 0.05898689478635788, 1.0)

    
    #node Invert
    invert = fabric_pattern3.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Color
    invert.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math.001
    math_001 = fabric_pattern3.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 0.5
    
    #node Hue Saturation Value
    hue_saturation_value = fabric_pattern3.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Mix.002
    mix_002 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.9994000196456909
    
    #node Wave Texture.004
    wave_texture_004 = fabric_pattern3.nodes.new("ShaderNodeTexWave")
    wave_texture_004.name = "Wave Texture.004"
    wave_texture_004.bands_direction = 'Y'
    wave_texture_004.rings_direction = 'X'
    wave_texture_004.wave_profile = 'SIN'
    wave_texture_004.wave_type = 'BANDS'
    #Distortion
    wave_texture_004.inputs[2].default_value = 0.0
    #Detail
    wave_texture_004.inputs[3].default_value = 0.0
    #Detail Scale
    wave_texture_004.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture_004.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture_004.inputs[6].default_value = 0.0
    
    #node Invert.001
    invert_001 = fabric_pattern3.nodes.new("ShaderNodeInvert")
    invert_001.name = "Invert.001"
    #Color
    invert_001.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Math
    math = fabric_pattern3.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    
    #node Math.002
    math_002 = fabric_pattern3.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    #Value_001
    math_002.inputs[1].default_value = 0.019999999552965164
    
    #node Math.003
    math_003 = fabric_pattern3.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'SUBTRACT'
    math_003.use_clamp = False
    #Value
    math_003.inputs[0].default_value = 1.0
    
    #node Vector Math.002
    vector_math_002 = fabric_pattern3.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SCALE'
    
    #node Noise Texture.002
    noise_texture_002 = fabric_pattern3.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #Detail
    noise_texture_002.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.9166666269302368
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node Math.004
    math_004 = fabric_pattern3.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MULTIPLY'
    math_004.use_clamp = False
    #Value_001
    math_004.inputs[1].default_value = 8.0
    
    #node Math.005
    math_005 = fabric_pattern3.nodes.new("ShaderNodeMath")
    math_005.name = "Math.005"
    math_005.operation = 'MULTIPLY'
    math_005.use_clamp = False
    #Value_001
    math_005.inputs[1].default_value = 9.0
    
    #node Mix.006
    mix_006 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_006.name = "Mix.006"
    mix_006.blend_type = 'MULTIPLY'
    mix_006.clamp_factor = True
    mix_006.clamp_result = True
    mix_006.data_type = 'RGBA'
    mix_006.factor_mode = 'UNIFORM'
    
    #node Bump.001
    bump_001 = fabric_pattern3.nodes.new("ShaderNodeBump")
    bump_001.name = "Bump.001"
    bump_001.invert = False
    #Distance
    bump_001.inputs[1].default_value = 1.0
    
    #node Group Input
    group_input = fabric_pattern3.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #fabric_pattern3 inputs
    #input Scale
    fabric_pattern3.inputs.new('NodeSocketFloat', "Scale")
    fabric_pattern3.inputs[0].default_value = 1.0
    fabric_pattern3.inputs[0].min_value = -10000.0
    fabric_pattern3.inputs[0].max_value = 10000.0
    fabric_pattern3.inputs[0].attribute_domain = 'POINT'
    
    #input Color Hue
    fabric_pattern3.inputs.new('NodeSocketFloatFactor', "Color Hue")
    fabric_pattern3.inputs[1].default_value = 1.0
    fabric_pattern3.inputs[1].min_value = 0.0
    fabric_pattern3.inputs[1].max_value = 1.0
    fabric_pattern3.inputs[1].attribute_domain = 'POINT'
    
    #input Specular
    fabric_pattern3.inputs.new('NodeSocketFloatFactor', "Specular")
    fabric_pattern3.inputs[2].default_value = 0.20000000298023224
    fabric_pattern3.inputs[2].min_value = 0.0
    fabric_pattern3.inputs[2].max_value = 1.0
    fabric_pattern3.inputs[2].attribute_domain = 'POINT'
    
    #input Saturation
    fabric_pattern3.inputs.new('NodeSocketFloat', "Saturation")
    fabric_pattern3.inputs[3].default_value = 1.0
    fabric_pattern3.inputs[3].min_value = 0.0
    fabric_pattern3.inputs[3].max_value = 2.0
    fabric_pattern3.inputs[3].attribute_domain = 'POINT'
    
    #input Brightness
    fabric_pattern3.inputs.new('NodeSocketFloat', "Brightness")
    fabric_pattern3.inputs[4].default_value = 1.0
    fabric_pattern3.inputs[4].min_value = 0.0
    fabric_pattern3.inputs[4].max_value = 2.0
    fabric_pattern3.inputs[4].attribute_domain = 'POINT'
    
    #input Bands Pattern Scale
    fabric_pattern3.inputs.new('NodeSocketFloat', "Bands Pattern Scale")
    fabric_pattern3.inputs[5].default_value = 10.0
    fabric_pattern3.inputs[5].min_value = -1000.0
    fabric_pattern3.inputs[5].max_value = 1000.0
    fabric_pattern3.inputs[5].attribute_domain = 'POINT'
    
    #input Waviness
    fabric_pattern3.inputs.new('NodeSocketFloatFactor', "Waviness")
    fabric_pattern3.inputs[6].default_value = 1.0
    fabric_pattern3.inputs[6].min_value = 0.0
    fabric_pattern3.inputs[6].max_value = 1.0
    fabric_pattern3.inputs[6].attribute_domain = 'POINT'
    
    #input Rows
    fabric_pattern3.inputs.new('NodeSocketFloat', "Rows")
    fabric_pattern3.inputs[7].default_value = 30.0
    fabric_pattern3.inputs[7].min_value = -1000.0
    fabric_pattern3.inputs[7].max_value = 1000.0
    fabric_pattern3.inputs[7].attribute_domain = 'POINT'
    
    #input Fabric Scale
    fabric_pattern3.inputs.new('NodeSocketFloat', "Fabric Scale")
    fabric_pattern3.inputs[8].default_value = 200.0
    fabric_pattern3.inputs[8].min_value = -1000.0
    fabric_pattern3.inputs[8].max_value = 1000.0
    fabric_pattern3.inputs[8].attribute_domain = 'POINT'
    
    #input Noise Scale
    fabric_pattern3.inputs.new('NodeSocketFloat', "Noise Scale")
    fabric_pattern3.inputs[9].default_value = 0.5
    fabric_pattern3.inputs[9].min_value = -10000.0
    fabric_pattern3.inputs[9].max_value = 10000.0
    fabric_pattern3.inputs[9].attribute_domain = 'POINT'
    
    #input Dirt
    fabric_pattern3.inputs.new('NodeSocketFloatFactor', "Dirt")
    fabric_pattern3.inputs[10].default_value = 1.0
    fabric_pattern3.inputs[10].min_value = 0.0
    fabric_pattern3.inputs[10].max_value = 1.0
    fabric_pattern3.inputs[10].attribute_domain = 'POINT'
    
    #input Bump Strength
    fabric_pattern3.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    fabric_pattern3.inputs[11].default_value = 0.20000000298023224
    fabric_pattern3.inputs[11].min_value = 0.0
    fabric_pattern3.inputs[11].max_value = 1.0
    fabric_pattern3.inputs[11].attribute_domain = 'POINT'
    
    #input Normal
    fabric_pattern3.inputs.new('NodeSocketVector', "Normal")
    fabric_pattern3.inputs[12].default_value = (0.0, 0.0, 0.0)
    fabric_pattern3.inputs[12].min_value = -1.0
    fabric_pattern3.inputs[12].max_value = 1.0
    fabric_pattern3.inputs[12].attribute_domain = 'POINT'
    fabric_pattern3.inputs[12].hide_value = True
    
    
    
    #node Wave Texture.003
    wave_texture_003 = fabric_pattern3.nodes.new("ShaderNodeTexWave")
    wave_texture_003.name = "Wave Texture.003"
    wave_texture_003.bands_direction = 'X'
    wave_texture_003.rings_direction = 'X'
    wave_texture_003.wave_profile = 'SIN'
    wave_texture_003.wave_type = 'BANDS'
    #Distortion
    wave_texture_003.inputs[2].default_value = 0.0
    #Detail
    wave_texture_003.inputs[3].default_value = 0.0
    #Detail Scale
    wave_texture_003.inputs[4].default_value = 1.0
    #Detail Roughness
    wave_texture_003.inputs[5].default_value = 0.5134615302085876
    #Phase Offset
    wave_texture_003.inputs[6].default_value = 0.0
    
    #node Mix.008
    mix_008 = fabric_pattern3.nodes.new("ShaderNodeMix")
    mix_008.name = "Mix.008"
    mix_008.blend_type = 'MULTIPLY'
    mix_008.clamp_factor = True
    mix_008.clamp_result = False
    mix_008.data_type = 'RGBA'
    mix_008.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_008.inputs[0].default_value = 0.5
    
    
    #Set locations
    colorramp_002.location = (-161.76708984375, 117.68328857421875)
    noise_texture.location = (-161.76708984375, -402.3166809082031)
    colorramp_005.location = (98.23291015625, -362.3166809082031)
    colorramp_006.location = (98.23291015625, -582.316650390625)
    colorramp_001.location = (-161.76708984375, -122.31669616699219)
    mix_004.location = (1118.23291015625, -142.3166961669922)
    mix_005.location = (1338.23291015625, -130.47689819335938)
    mix.location = (898.23291015625, 137.683349609375)
    mix_001.location = (898.23291015625, -42.31663513183594)
    wave_texture_001.location = (-381.76708984375, -202.3166961669922)
    wave_texture_002.location = (-1161.76708984375, -182.3166961669922)
    colorramp.location = (1462.0546875, 166.80645751953125)
    mix_003.location = (1242.0546875, 146.80645751953125)
    texture_coordinate_002.location = (-2217.9453125, 106.80645751953125)
    wave_texture.location = (-381.76708984375, 117.68328857421875)
    combine_xyz.location = (-687.69384765625, 441.41180419921875)
    mix_007.location = (-907.9453125, 555.67529296875)
    separate_xyz.location = (-1500.84375, 355.16619873046875)
    group_output.location = (2507.94580078125, -0.0)
    principled_bsdf.location = (2217.94580078125, 177.683349609375)
    colorramp_004.location = (-216.81201171875, 622.3167114257812)
    invert.location = (-1245.656005859375, 774.0479736328125)
    math_001.location = (-804.6591796875, 769.6630859375)
    hue_saturation_value.location = (207.078125, 643.4500732421875)
    mix_002.location = (-716.41845703125, -144.82810974121094)
    wave_texture_004.location = (-1677.9453125, 538.9432983398438)
    invert_001.location = (-2000.0, 419.9999694824219)
    math.location = (-1127.9453125, 493.32708740234375)
    math_002.location = (-1829.6163330078125, 522.6651611328125)
    math_003.location = (-1298.1318359375, 563.1796875)
    vector_math_002.location = (-1877.9453125, 186.80645751953125)
    noise_texture_002.location = (-161.76708984375, -622.3167114257812)
    math_004.location = (-740.0, -640.0)
    math_005.location = (-740.0, -800.0)
    mix_006.location = (2002.0546875, 326.80645751953125)
    bump_001.location = (1582.0546875, -293.19354248046875)
    group_input.location = (-2417.9453125, -0.0)
    wave_texture_003.location = (-464.9453125, 546.8064575195312)
    mix_008.location = (1239.9998779296875, 660.0)
    
    #Set dimensions
    colorramp_002.width, colorramp_002.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    colorramp_005.width, colorramp_005.height = 240.0, 100.0
    colorramp_006.width, colorramp_006.height = 240.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    wave_texture_001.width, wave_texture_001.height = 150.0, 100.0
    wave_texture_002.width, wave_texture_002.height = 150.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    mix_007.width, mix_007.height = 140.0, 100.0
    separate_xyz.width, separate_xyz.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    colorramp_004.width, colorramp_004.height = 240.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    wave_texture_004.width, wave_texture_004.height = 150.0, 100.0
    invert_001.width, invert_001.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    mix_006.width, mix_006.height = 140.0, 100.0
    bump_001.width, bump_001.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    wave_texture_003.width, wave_texture_003.height = 150.0, 100.0
    mix_008.width, mix_008.height = 140.0, 100.0
    
    #initialize fabric_pattern3 links
    #principled_bsdf.BSDF -> group_output.BSDF
    fabric_pattern3.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #wave_texture_001.Color -> colorramp_001.Fac
    fabric_pattern3.links.new(wave_texture_001.outputs[0], colorramp_001.inputs[0])
    #wave_texture.Color -> colorramp_002.Fac
    fabric_pattern3.links.new(wave_texture.outputs[0], colorramp_002.inputs[0])
    #colorramp_002.Color -> mix.A
    fabric_pattern3.links.new(colorramp_002.outputs[0], mix.inputs[6])
    #colorramp_005.Color -> mix.B
    fabric_pattern3.links.new(colorramp_005.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> colorramp_005.Fac
    fabric_pattern3.links.new(noise_texture.outputs[0], colorramp_005.inputs[0])
    #mix_002.Result -> wave_texture_001.Vector
    fabric_pattern3.links.new(mix_002.outputs[2], wave_texture_001.inputs[0])
    #colorramp_001.Color -> mix_001.A
    fabric_pattern3.links.new(colorramp_001.outputs[0], mix_001.inputs[6])
    #colorramp_006.Color -> mix_001.B
    fabric_pattern3.links.new(colorramp_006.outputs[0], mix_001.inputs[7])
    #noise_texture_002.Fac -> colorramp_006.Fac
    fabric_pattern3.links.new(noise_texture_002.outputs[0], colorramp_006.inputs[0])
    #mix_005.Result -> bump_001.Height
    fabric_pattern3.links.new(mix_005.outputs[2], bump_001.inputs[2])
    #mix.Result -> mix_004.A
    fabric_pattern3.links.new(mix.outputs[2], mix_004.inputs[6])
    #mix_001.Result -> mix_004.B
    fabric_pattern3.links.new(mix_001.outputs[2], mix_004.inputs[7])
    #mix_004.Result -> mix_005.B
    fabric_pattern3.links.new(mix_004.outputs[2], mix_005.inputs[7])
    #bump_001.Normal -> principled_bsdf.Normal
    fabric_pattern3.links.new(bump_001.outputs[0], principled_bsdf.inputs[22])
    #mix.Result -> mix_003.A
    fabric_pattern3.links.new(mix.outputs[2], mix_003.inputs[6])
    #mix_001.Result -> mix_003.B
    fabric_pattern3.links.new(mix_001.outputs[2], mix_003.inputs[7])
    #mix_003.Result -> colorramp.Fac
    fabric_pattern3.links.new(mix_003.outputs[2], colorramp.inputs[0])
    #wave_texture_002.Color -> mix_002.A
    fabric_pattern3.links.new(wave_texture_002.outputs[0], mix_002.inputs[6])
    #texture_coordinate_002.UV -> vector_math_002.Vector
    fabric_pattern3.links.new(texture_coordinate_002.outputs[2], vector_math_002.inputs[0])
    #vector_math_002.Vector -> wave_texture.Vector
    fabric_pattern3.links.new(vector_math_002.outputs[0], wave_texture.inputs[0])
    #vector_math_002.Vector -> mix_002.B
    fabric_pattern3.links.new(vector_math_002.outputs[0], mix_002.inputs[7])
    #vector_math_002.Vector -> wave_texture_002.Vector
    fabric_pattern3.links.new(vector_math_002.outputs[0], wave_texture_002.inputs[0])
    #colorramp.Color -> mix_006.B
    fabric_pattern3.links.new(colorramp.outputs[0], mix_006.inputs[7])
    #mix_006.Result -> principled_bsdf.Base Color
    fabric_pattern3.links.new(mix_006.outputs[2], principled_bsdf.inputs[0])
    #combine_xyz.Vector -> wave_texture_003.Vector
    fabric_pattern3.links.new(combine_xyz.outputs[0], wave_texture_003.inputs[0])
    #vector_math_002.Vector -> wave_texture_004.Vector
    fabric_pattern3.links.new(vector_math_002.outputs[0], wave_texture_004.inputs[0])
    #mix_007.Result -> combine_xyz.X
    fabric_pattern3.links.new(mix_007.outputs[2], combine_xyz.inputs[0])
    #vector_math_002.Vector -> separate_xyz.Vector
    fabric_pattern3.links.new(vector_math_002.outputs[0], separate_xyz.inputs[0])
    #separate_xyz.Y -> combine_xyz.Y
    fabric_pattern3.links.new(separate_xyz.outputs[1], combine_xyz.inputs[1])
    #separate_xyz.Z -> combine_xyz.Z
    fabric_pattern3.links.new(separate_xyz.outputs[2], combine_xyz.inputs[2])
    #separate_xyz.X -> math.Value
    fabric_pattern3.links.new(separate_xyz.outputs[0], math.inputs[0])
    #wave_texture_004.Color -> math.Value
    fabric_pattern3.links.new(wave_texture_004.outputs[0], math.inputs[1])
    #math.Value -> mix_007.A
    fabric_pattern3.links.new(math.outputs[0], mix_007.inputs[6])
    #separate_xyz.X -> mix_007.B
    fabric_pattern3.links.new(separate_xyz.outputs[0], mix_007.inputs[7])
    #hue_saturation_value.Color -> mix_006.A
    fabric_pattern3.links.new(hue_saturation_value.outputs[0], mix_006.inputs[6])
    #wave_texture_003.Color -> colorramp_004.Fac
    fabric_pattern3.links.new(wave_texture_003.outputs[0], colorramp_004.inputs[0])
    #group_input.Scale -> vector_math_002.Scale
    fabric_pattern3.links.new(group_input.outputs[0], vector_math_002.inputs[3])
    #colorramp_004.Color -> hue_saturation_value.Color
    fabric_pattern3.links.new(colorramp_004.outputs[0], hue_saturation_value.inputs[4])
    #group_input.Color Hue -> invert.Fac
    fabric_pattern3.links.new(group_input.outputs[1], invert.inputs[0])
    #math_001.Value -> hue_saturation_value.Hue
    fabric_pattern3.links.new(math_001.outputs[0], hue_saturation_value.inputs[0])
    #invert.Color -> math_001.Value
    fabric_pattern3.links.new(invert.outputs[0], math_001.inputs[0])
    #group_input.Saturation -> hue_saturation_value.Saturation
    fabric_pattern3.links.new(group_input.outputs[3], hue_saturation_value.inputs[1])
    #group_input.Brightness -> hue_saturation_value.Value
    fabric_pattern3.links.new(group_input.outputs[4], hue_saturation_value.inputs[2])
    #group_input.Bands Pattern Scale -> wave_texture_004.Scale
    fabric_pattern3.links.new(group_input.outputs[5], wave_texture_004.inputs[1])
    #group_input.Waviness -> invert_001.Fac
    fabric_pattern3.links.new(group_input.outputs[6], invert_001.inputs[0])
    #math_003.Value -> mix_007.Factor
    fabric_pattern3.links.new(math_003.outputs[0], mix_007.inputs[0])
    #invert_001.Color -> math_002.Value
    fabric_pattern3.links.new(invert_001.outputs[0], math_002.inputs[0])
    #math_002.Value -> math_003.Value
    fabric_pattern3.links.new(math_002.outputs[0], math_003.inputs[1])
    #group_input.Rows -> wave_texture_003.Scale
    fabric_pattern3.links.new(group_input.outputs[7], wave_texture_003.inputs[1])
    #group_input.Fabric Scale -> wave_texture_002.Scale
    fabric_pattern3.links.new(group_input.outputs[8], wave_texture_002.inputs[1])
    #group_input.Fabric Scale -> wave_texture.Scale
    fabric_pattern3.links.new(group_input.outputs[8], wave_texture.inputs[1])
    #group_input.Fabric Scale -> wave_texture_001.Scale
    fabric_pattern3.links.new(group_input.outputs[8], wave_texture_001.inputs[1])
    #vector_math_002.Vector -> noise_texture.Vector
    fabric_pattern3.links.new(vector_math_002.outputs[0], noise_texture.inputs[0])
    #vector_math_002.Vector -> noise_texture_002.Vector
    fabric_pattern3.links.new(vector_math_002.outputs[0], noise_texture_002.inputs[0])
    #math_005.Value -> noise_texture_002.Scale
    fabric_pattern3.links.new(math_005.outputs[0], noise_texture_002.inputs[2])
    #math_004.Value -> noise_texture.Scale
    fabric_pattern3.links.new(math_004.outputs[0], noise_texture.inputs[2])
    #group_input.Noise Scale -> math_004.Value
    fabric_pattern3.links.new(group_input.outputs[9], math_004.inputs[0])
    #group_input.Noise Scale -> math_005.Value
    fabric_pattern3.links.new(group_input.outputs[9], math_005.inputs[0])
    #group_input.Dirt -> mix_006.Factor
    fabric_pattern3.links.new(group_input.outputs[10], mix_006.inputs[0])
    #group_input.Specular -> principled_bsdf.Specular
    fabric_pattern3.links.new(group_input.outputs[2], principled_bsdf.inputs[7])
    #group_input.Bump Strength -> bump_001.Strength
    fabric_pattern3.links.new(group_input.outputs[11], bump_001.inputs[0])
    #group_input.Normal -> bump_001.Normal
    fabric_pattern3.links.new(group_input.outputs[12], bump_001.inputs[3])
    #mix_006.Result -> group_output.Albedo
    fabric_pattern3.links.new(mix_006.outputs[2], group_output.inputs[1])
    #wave_texture_003.Color -> mix_008.A
    fabric_pattern3.links.new(wave_texture_003.outputs[0], mix_008.inputs[6])
    #mix_003.Result -> mix_008.B
    fabric_pattern3.links.new(mix_003.outputs[2], mix_008.inputs[7])
    #mix_008.Result -> group_output.Mask
    fabric_pattern3.links.new(mix_008.outputs[2], group_output.inputs[2])
    return fabric_pattern3

fabric_pattern3 = fabric_pattern3_node_group()

#initialize Indian Pattern3 node group
def indian_pattern3_node_group():

    indian_pattern3 = mat.node_tree
    #start with a clean node tree
    for node in indian_pattern3.nodes:
        indian_pattern3.nodes.remove(node)
    #initialize indian_pattern3 nodes
    #node Material Output
    material_output = indian_pattern3.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Fabric_Pattern3
    fabric_pattern3_1 = indian_pattern3.nodes.new("ShaderNodeGroup")
    fabric_pattern3_1.label = "Fabric_Pattern3"
    fabric_pattern3_1.name = "Fabric_Pattern3"
    fabric_pattern3_1.node_tree = fabric_pattern3
    #Input_1
    fabric_pattern3_1.inputs[0].default_value = 1.0
    #Input_2
    fabric_pattern3_1.inputs[1].default_value = 0.0
    #Input_11
    fabric_pattern3_1.inputs[2].default_value = 0.20000000298023224
    #Input_3
    fabric_pattern3_1.inputs[3].default_value = 1.0
    #Input_4
    fabric_pattern3_1.inputs[4].default_value = 2.0
    #Input_5
    fabric_pattern3_1.inputs[5].default_value = 10.0
    #Input_6
    fabric_pattern3_1.inputs[6].default_value = 0.25
    #Input_7
    fabric_pattern3_1.inputs[7].default_value = 30.0
    #Input_8
    fabric_pattern3_1.inputs[8].default_value = 200.0
    #Input_9
    fabric_pattern3_1.inputs[9].default_value = 0.5
    #Input_10
    fabric_pattern3_1.inputs[10].default_value = 1.0
    #Input_12
    fabric_pattern3_1.inputs[11].default_value = 0.20000000298023224
    #Input_13
    fabric_pattern3_1.inputs[12].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (642.23876953125, 117.481201171875)
    fabric_pattern3_1.location = (379.93017578125, 117.481201171875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    fabric_pattern3_1.width, fabric_pattern3_1.height = 222.30859375, 100.0
    
    #initialize indian_pattern3 links
    #fabric_pattern3_1.BSDF -> material_output.Surface
    indian_pattern3.links.new(fabric_pattern3_1.outputs[0], material_output.inputs[0])
    return indian_pattern3

indian_pattern3 = indian_pattern3_node_group()

