import bpy, mathutils

mat = bpy.data.materials.new(name = "Metall Pattern4")
mat.use_nodes = True
#initialize Metall_pattern4 node group
def metall_pattern4_node_group():

    metall_pattern4 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Metall_pattern4")
    
    #initialize metall_pattern4 nodes
    #node Bump
    bump = metall_pattern4.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node ColorRamp
    colorramp = metall_pattern4.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5863637328147888)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.12032249569892883, 0.12032249569892883, 0.12032249569892883, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.8045456409454346)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Texture Coordinate.001
    texture_coordinate_001 = metall_pattern4.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node Vector Math
    vector_math = metall_pattern4.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'
    
    #node Group Output
    group_output = metall_pattern4.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #metall_pattern4 outputs
    #output BSDF
    metall_pattern4.outputs.new('NodeSocketShader', "BSDF")
    metall_pattern4.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    metall_pattern4.outputs.new('NodeSocketColor', "Albedo")
    metall_pattern4.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    metall_pattern4.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    metall_pattern4.outputs.new('NodeSocketFloat', "Mask")
    metall_pattern4.outputs[2].default_value = 0.0
    metall_pattern4.outputs[2].min_value = -3.4028234663852886e+38
    metall_pattern4.outputs[2].max_value = 3.4028234663852886e+38
    metall_pattern4.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Mix
    mix = metall_pattern4.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    
    #node Mix.001
    mix_001 = metall_pattern4.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = metall_pattern4.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 1.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.054545462131500244
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.32327327132225037, 0.7885132431983948, 1.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Noise Texture
    noise_texture = metall_pattern4.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 5.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.2750000059604645
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Group Input
    group_input = metall_pattern4.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #metall_pattern4 inputs
    #input Scale
    metall_pattern4.inputs.new('NodeSocketFloat', "Scale")
    metall_pattern4.inputs[0].default_value = 1.0
    metall_pattern4.inputs[0].min_value = -10000.0
    metall_pattern4.inputs[0].max_value = 10000.0
    metall_pattern4.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    metall_pattern4.inputs.new('NodeSocketColor', "Color1")
    metall_pattern4.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    metall_pattern4.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    metall_pattern4.inputs.new('NodeSocketColor', "Color2")
    metall_pattern4.inputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    metall_pattern4.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    metall_pattern4.inputs.new('NodeSocketFloatFactor', "Roughness")
    metall_pattern4.inputs[3].default_value = 0.0
    metall_pattern4.inputs[3].min_value = 0.0
    metall_pattern4.inputs[3].max_value = 1.0
    metall_pattern4.inputs[3].attribute_domain = 'POINT'
    
    #input Noise Detail
    metall_pattern4.inputs.new('NodeSocketFloat', "Noise Detail")
    metall_pattern4.inputs[4].default_value = 7.699999809265137
    metall_pattern4.inputs[4].min_value = 0.0
    metall_pattern4.inputs[4].max_value = 15.0
    metall_pattern4.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    metall_pattern4.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    metall_pattern4.inputs[5].default_value = 1.0
    metall_pattern4.inputs[5].min_value = 0.0
    metall_pattern4.inputs[5].max_value = 1.0
    metall_pattern4.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    metall_pattern4.inputs.new('NodeSocketVector', "Normal")
    metall_pattern4.inputs[6].default_value = (0.0, 0.0, 0.0)
    metall_pattern4.inputs[6].min_value = -1.0
    metall_pattern4.inputs[6].max_value = 1.0
    metall_pattern4.inputs[6].attribute_domain = 'POINT'
    metall_pattern4.inputs[6].hide_value = True
    
    
    
    #node Voronoi Texture
    voronoi_texture = metall_pattern4.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'SMOOTH_F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 5.0
    #Smoothness
    voronoi_texture.inputs[3].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[4].default_value = 0.3500005602836609
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    
    #Set locations
    bump.location = (543.9459228515625, -191.7137451171875)
    colorramp.location = (343.9459228515625, 191.7137451171875)
    texture_coordinate_001.location = (-895.0978393554688, -92.919189453125)
    vector_math.location = (-555.0978393554688, -12.919189453125)
    group_output.location = (1185.0977783203125, -0.0)
    mix.location = (662.3568115234375, 183.19122314453125)
    mix_001.location = (-56.0540771484375, -11.7137451171875)
    principled_bsdf.location = (895.0977783203125, 148.2862548828125)
    noise_texture.location = (-256.0540771484375, -151.71372985839844)
    group_input.location = (-1095.097900390625, -0.0)
    voronoi_texture.location = (123.9459228515625, 8.2862548828125)
    
    #Set dimensions
    bump.width, bump.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    
    #initialize metall_pattern4 links
    #principled_bsdf.BSDF -> group_output.BSDF
    metall_pattern4.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    metall_pattern4.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Color -> bump.Height
    metall_pattern4.links.new(voronoi_texture.outputs[1], bump.inputs[2])
    #voronoi_texture.Color -> colorramp.Fac
    metall_pattern4.links.new(voronoi_texture.outputs[1], colorramp.inputs[0])
    #mix_001.Result -> voronoi_texture.Vector
    metall_pattern4.links.new(mix_001.outputs[2], voronoi_texture.inputs[0])
    #noise_texture.Color -> mix_001.B
    metall_pattern4.links.new(noise_texture.outputs[1], mix_001.inputs[7])
    #texture_coordinate_001.Object -> vector_math.Vector
    metall_pattern4.links.new(texture_coordinate_001.outputs[3], vector_math.inputs[0])
    #vector_math.Vector -> mix_001.A
    metall_pattern4.links.new(vector_math.outputs[0], mix_001.inputs[6])
    #mix.Result -> principled_bsdf.Base Color
    metall_pattern4.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #colorramp.Color -> mix.Factor
    metall_pattern4.links.new(colorramp.outputs[0], mix.inputs[0])
    #group_input.Scale -> vector_math.Scale
    metall_pattern4.links.new(group_input.outputs[0], vector_math.inputs[3])
    #group_input.Color1 -> mix.A
    metall_pattern4.links.new(group_input.outputs[1], mix.inputs[6])
    #group_input.Color2 -> mix.B
    metall_pattern4.links.new(group_input.outputs[2], mix.inputs[7])
    #group_input.Roughness -> principled_bsdf.Roughness
    metall_pattern4.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Noise Detail -> noise_texture.Detail
    metall_pattern4.links.new(group_input.outputs[4], noise_texture.inputs[3])
    #group_input.Bump Strength -> bump.Strength
    metall_pattern4.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    metall_pattern4.links.new(group_input.outputs[6], bump.inputs[3])
    #vector_math.Vector -> noise_texture.Vector
    metall_pattern4.links.new(vector_math.outputs[0], noise_texture.inputs[0])
    #voronoi_texture.Distance -> group_output.Mask
    metall_pattern4.links.new(voronoi_texture.outputs[0], group_output.inputs[2])
    #mix.Result -> group_output.Albedo
    metall_pattern4.links.new(mix.outputs[2], group_output.inputs[1])
    return metall_pattern4

metall_pattern4 = metall_pattern4_node_group()

#initialize Metall Pattern4 node group
def metall_pattern4_1_node_group():

    metall_pattern4_1 = mat.node_tree
    #start with a clean node tree
    for node in metall_pattern4_1.nodes:
        metall_pattern4_1.nodes.remove(node)
    #initialize metall_pattern4_1 nodes
    #node Material Output
    material_output = metall_pattern4_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Metall_pattern4
    metall_pattern4_2 = metall_pattern4_1.nodes.new("ShaderNodeGroup")
    metall_pattern4_2.label = "Metall_pattern4"
    metall_pattern4_2.name = "Metall_pattern4"
    metall_pattern4_2.node_tree = metall_pattern4
    #Input_1
    metall_pattern4_2.inputs[0].default_value = 1.0
    #Input_2
    metall_pattern4_2.inputs[1].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_3
    metall_pattern4_2.inputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_4
    metall_pattern4_2.inputs[3].default_value = 0.0
    #Input_6
    metall_pattern4_2.inputs[4].default_value = 5.0
    #Input_7
    metall_pattern4_2.inputs[5].default_value = 1.0
    #Input_8
    metall_pattern4_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (699.28271484375, 112.064697265625)
    metall_pattern4_2.location = (465.650390625, 112.064697265625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    metall_pattern4_2.width, metall_pattern4_2.height = 162.839599609375, 100.0
    
    #initialize metall_pattern4_1 links
    #metall_pattern4_2.BSDF -> material_output.Surface
    metall_pattern4_1.links.new(metall_pattern4_2.outputs[0], material_output.inputs[0])
    return metall_pattern4_1

metall_pattern4_1 = metall_pattern4_1_node_group()

