import bpy, mathutils

mat = bpy.data.materials.new(name = "Ruby")
mat.use_nodes = True
#initialize Ruby node group
def ruby_node_group():

    ruby = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Ruby")
    
    #initialize ruby nodes
    #node Principled BSDF
    principled_bsdf = ruby.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.0
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #Transmission
    principled_bsdf.inputs[17].default_value = 1.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Math
    math = ruby.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    #Value
    math.inputs[0].default_value = 8.0
    
    #node Group Output
    group_output = ruby.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #ruby outputs
    #output BSDF
    ruby.outputs.new('NodeSocketShader', "BSDF")
    ruby.outputs[0].attribute_domain = 'POINT'
    
    #output Mask
    ruby.outputs.new('NodeSocketFloat', "Mask")
    ruby.outputs[1].default_value = 0.0
    ruby.outputs[1].min_value = -3.4028234663852886e+38
    ruby.outputs[1].max_value = 3.4028234663852886e+38
    ruby.outputs[1].attribute_domain = 'POINT'
    
    #output Normal
    ruby.outputs.new('NodeSocketVector', "Normal")
    ruby.outputs[2].default_value = (0.0, 0.0, 0.0)
    ruby.outputs[2].min_value = -3.4028234663852886e+38
    ruby.outputs[2].max_value = 3.4028234663852886e+38
    ruby.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Group Input
    group_input = ruby.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #ruby inputs
    #input Color
    ruby.inputs.new('NodeSocketColor', "Color")
    ruby.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    ruby.inputs[0].attribute_domain = 'POINT'
    
    #input Scale
    ruby.inputs.new('NodeSocketFloat', "Scale")
    ruby.inputs[1].default_value = 0.5
    ruby.inputs[1].min_value = -10000.0
    ruby.inputs[1].max_value = 10000.0
    ruby.inputs[1].attribute_domain = 'POINT'
    
    #input Randomness
    ruby.inputs.new('NodeSocketFloatFactor', "Randomness")
    ruby.inputs[2].default_value = 1.0
    ruby.inputs[2].min_value = 0.0
    ruby.inputs[2].max_value = 1.0
    ruby.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    ruby.inputs.new('NodeSocketFloatFactor', "Roughness")
    ruby.inputs[3].default_value = 0.0
    ruby.inputs[3].min_value = 0.0
    ruby.inputs[3].max_value = 1.0
    ruby.inputs[3].attribute_domain = 'POINT'
    
    #input IOR
    ruby.inputs.new('NodeSocketFloat', "IOR")
    ruby.inputs[4].default_value = 1.4500000476837158
    ruby.inputs[4].min_value = 0.0
    ruby.inputs[4].max_value = 1000.0
    ruby.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    ruby.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    ruby.inputs[5].default_value = 0.13375015556812286
    ruby.inputs[5].min_value = 0.0
    ruby.inputs[5].max_value = 1.0
    ruby.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    ruby.inputs.new('NodeSocketVector', "Normal")
    ruby.inputs[6].default_value = (0.0, 0.0, 0.0)
    ruby.inputs[6].min_value = -1.0
    ruby.inputs[6].max_value = 1.0
    ruby.inputs[6].attribute_domain = 'POINT'
    ruby.inputs[6].hide_value = True
    
    
    
    #node Voronoi Texture
    voronoi_texture = ruby.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MINKOWSKI'
    voronoi_texture.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture.voronoi_dimensions = '3D'
    #Vector
    voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
    
    #node Bump
    bump = ruby.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    
    #Set locations
    principled_bsdf.location = (368.5, 90.0)
    math.location = (-368.5, -10.0)
    group_output.location = (658.5, -0.0)
    group_input.location = (-568.5, -0.0)
    voronoi_texture.location = (-128.5, -110.0)
    bump.location = (105.14727783203125, -92.02658081054688)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    
    #initialize ruby links
    #principled_bsdf.BSDF -> group_output.BSDF
    ruby.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    ruby.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #voronoi_texture.Distance -> bump.Height
    ruby.links.new(voronoi_texture.outputs[0], bump.inputs[2])
    #math.Value -> voronoi_texture.Scale
    ruby.links.new(math.outputs[0], voronoi_texture.inputs[2])
    #group_input.Color -> principled_bsdf.Base Color
    ruby.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Scale -> math.Value
    ruby.links.new(group_input.outputs[1], math.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    ruby.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Roughness -> principled_bsdf.Transmission Roughness
    ruby.links.new(group_input.outputs[3], principled_bsdf.inputs[18])
    #group_input.IOR -> principled_bsdf.IOR
    ruby.links.new(group_input.outputs[4], principled_bsdf.inputs[16])
    #group_input.Normal -> bump.Normal
    ruby.links.new(group_input.outputs[6], bump.inputs[3])
    #group_input.Randomness -> voronoi_texture.Randomness
    ruby.links.new(group_input.outputs[2], voronoi_texture.inputs[5])
    #voronoi_texture.Distance -> group_output.Mask
    ruby.links.new(voronoi_texture.outputs[0], group_output.inputs[1])
    #bump.Normal -> group_output.Normal
    ruby.links.new(bump.outputs[0], group_output.inputs[2])
    return ruby

ruby = ruby_node_group()

#initialize Ruby node group
def ruby_1_node_group():

    ruby_1 = mat.node_tree
    #start with a clean node tree
    for node in ruby_1.nodes:
        ruby_1.nodes.remove(node)
    #initialize ruby_1 nodes
    #node Material Output
    material_output = ruby_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Ruby
    ruby_2 = ruby_1.nodes.new("ShaderNodeGroup")
    ruby_2.label = "Ruby"
    ruby_2.name = "Ruby"
    ruby_2.use_custom_color = True
    ruby_2.color = (0.08610181510448456, 0.22182655334472656, 0.28100982308387756)
    ruby_2.node_tree = ruby
    #Input_1
    ruby_2.inputs[0].default_value = (1.0, 0.0, 0.0, 1.0)
    #Input_2
    ruby_2.inputs[1].default_value = 1.0
    #Input_7
    ruby_2.inputs[2].default_value = 1.0
    #Input_4
    ruby_2.inputs[3].default_value = 0.0
    #Input_5
    ruby_2.inputs[4].default_value = 1.4500000476837158
    #Input_3
    ruby_2.inputs[5].default_value = 0.15000000596046448
    #Input_6
    ruby_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (666.69384765625, 30.80517578125)
    ruby_2.location = (391.6007995605469, 30.80517578125)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    ruby_2.width, ruby_2.height = 178.09353637695312, 100.0
    
    #initialize ruby_1 links
    #ruby_2.BSDF -> material_output.Surface
    ruby_1.links.new(ruby_2.outputs[0], material_output.inputs[0])
    return ruby_1

ruby_1 = ruby_1_node_group()

