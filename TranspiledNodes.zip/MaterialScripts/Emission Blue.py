import bpy, mathutils

mat = bpy.data.materials.new(name = "Emission Blue")
mat.use_nodes = True
#initialize Emission_blue node group
def emission_blue_node_group():

    emission_blue = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Emission_blue")
    
    #initialize emission_blue nodes
    #node Principled BSDF
    principled_bsdf = emission_blue.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    #Weight
    principled_bsdf.inputs[25].default_value = 0.0
    
    #node Group Output
    group_output = emission_blue.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #emission_blue outputs
    #output BSDF
    emission_blue.outputs.new('NodeSocketShader', "BSDF")
    emission_blue.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node Group Input
    group_input = emission_blue.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #emission_blue inputs
    #input Emission
    emission_blue.inputs.new('NodeSocketColor', "Emission")
    emission_blue.inputs[0].default_value = (1.0, 0.44432228803634644, 0.0, 1.0)
    emission_blue.inputs[0].attribute_domain = 'POINT'
    
    #input Emission Strength
    emission_blue.inputs.new('NodeSocketFloat', "Emission Strength")
    emission_blue.inputs[1].default_value = 4.0
    emission_blue.inputs[1].min_value = 0.0
    emission_blue.inputs[1].max_value = 1000000.0
    emission_blue.inputs[1].attribute_domain = 'POINT'
    
    #input Base Color
    emission_blue.inputs.new('NodeSocketColor', "Base Color")
    emission_blue.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    emission_blue.inputs[2].attribute_domain = 'POINT'
    
    #input Roughness
    emission_blue.inputs.new('NodeSocketFloatFactor', "Roughness")
    emission_blue.inputs[3].default_value = 0.20000000298023224
    emission_blue.inputs[3].min_value = 0.0
    emission_blue.inputs[3].max_value = 1.0
    emission_blue.inputs[3].attribute_domain = 'POINT'
    
    #input Normal
    emission_blue.inputs.new('NodeSocketVector', "Normal")
    emission_blue.inputs[4].default_value = (0.0, 0.0, 0.0)
    emission_blue.inputs[4].min_value = -3.4028234663852886e+38
    emission_blue.inputs[4].max_value = 3.4028234663852886e+38
    emission_blue.inputs[4].attribute_domain = 'POINT'
    emission_blue.inputs[4].hide_value = True
    
    
    
    
    #Set locations
    principled_bsdf.location = (88.22991943359375, 24.99188232421875)
    group_output.location = (378.22991943359375, -0.0)
    group_input.location = (-280.0, -40.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    
    #initialize emission_blue links
    #principled_bsdf.BSDF -> group_output.BSDF
    emission_blue.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #group_input.Emission -> principled_bsdf.Emission
    emission_blue.links.new(group_input.outputs[0], principled_bsdf.inputs[19])
    #group_input.Emission Strength -> principled_bsdf.Emission Strength
    emission_blue.links.new(group_input.outputs[1], principled_bsdf.inputs[20])
    #group_input.Base Color -> principled_bsdf.Base Color
    emission_blue.links.new(group_input.outputs[2], principled_bsdf.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    emission_blue.links.new(group_input.outputs[3], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    emission_blue.links.new(group_input.outputs[4], principled_bsdf.inputs[22])
    return emission_blue

emission_blue = emission_blue_node_group()

#initialize Emission Blue node group
def emission_blue_1_node_group():

    emission_blue_1 = mat.node_tree
    #start with a clean node tree
    for node in emission_blue_1.nodes:
        emission_blue_1.nodes.remove(node)
    #initialize emission_blue_1 nodes
    #node Emission_blue
    emission_blue_2 = emission_blue_1.nodes.new("ShaderNodeGroup")
    emission_blue_2.label = "Emission_blue"
    emission_blue_2.name = "Emission_blue"
    emission_blue_2.node_tree = emission_blue
    #Input_1
    emission_blue_2.inputs[0].default_value = (0.0, 0.7990638613700867, 1.0, 1.0)
    #Input_2
    emission_blue_2.inputs[1].default_value = 4.0
    #Input_3
    emission_blue_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    emission_blue_2.inputs[3].default_value = 0.20000000298023224
    #Input_5
    emission_blue_2.inputs[4].default_value = (0.0, 0.0, 0.0)
    
    #node Material Output.001
    material_output_001 = emission_blue_1.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = True
    material_output_001.target = 'ALL'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Thickness
    material_output_001.inputs[3].default_value = 0.0
    
    
    #Set locations
    emission_blue_2.location = (397.9521484375, 108.4649658203125)
    material_output_001.location = (674.9521484375, 108.4649658203125)
    
    #Set dimensions
    emission_blue_2.width, emission_blue_2.height = 200.16009521484375, 100.0
    material_output_001.width, material_output_001.height = 140.0, 100.0
    
    #initialize emission_blue_1 links
    #emission_blue_2.BSDF -> material_output_001.Surface
    emission_blue_1.links.new(emission_blue_2.outputs[0], material_output_001.inputs[0])
    return emission_blue_1

emission_blue_1 = emission_blue_1_node_group()

