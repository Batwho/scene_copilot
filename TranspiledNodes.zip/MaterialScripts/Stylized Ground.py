import bpy, mathutils

mat = bpy.data.materials.new(name = "Stylized Ground")
mat.use_nodes = True
#initialize Stylized Ground node group
def stylized_ground_node_group():

    stylized_ground = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Stylized Ground")
    
    #initialize stylized_ground nodes
    #node ColorRamp
    colorramp = stylized_ground.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.45454537868499756
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.6181820631027222)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Mix
    mix = stylized_ground.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.17833353579044342
    
    #node Mapping
    mapping = stylized_ground.nodes.new("ShaderNodeMapping")
    mapping.name = "Mapping"
    mapping.vector_type = 'POINT'
    #Location
    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Rotation
    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    mapping.inputs[3].default_value = (0.1899999976158142, 0.1899999976158142, 1.2699999809265137)
    
    #node Texture Coordinate.001
    texture_coordinate_001 = stylized_ground.nodes.new("ShaderNodeTexCoord")
    texture_coordinate_001.name = "Texture Coordinate.001"
    texture_coordinate_001.from_instancer = False
    
    #node ColorRamp.001
    colorramp_001 = stylized_ground.nodes.new("ShaderNodeValToRGB")
    colorramp_001.name = "ColorRamp.001"
    colorramp_001.color_ramp.color_mode = 'RGB'
    colorramp_001.color_ramp.hue_interpolation = 'NEAR'
    colorramp_001.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
    colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
    colorramp_001_cre_0.position = 0.38181814551353455
    colorramp_001_cre_0.alpha = 1.0
    colorramp_001_cre_0.color = (0.35148632526397705, 0.35148632526397705, 0.35148632526397705, 1.0)

    colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.5318186283111572)
    colorramp_001_cre_1.alpha = 1.0
    colorramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Vector Math.018
    vector_math_018 = stylized_ground.nodes.new("ShaderNodeVectorMath")
    vector_math_018.name = "Vector Math.018"
    vector_math_018.operation = 'SCALE'
    
    #node Principled BSDF
    principled_bsdf = stylized_ground.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 1.0, 1.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Output
    group_output = stylized_ground.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #stylized_ground outputs
    #output BSDF
    stylized_ground.outputs.new('NodeSocketShader', "BSDF")
    stylized_ground.outputs[0].attribute_domain = 'POINT'
    
    #output Albedo
    stylized_ground.outputs.new('NodeSocketColor', "Albedo")
    stylized_ground.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    stylized_ground.outputs[1].attribute_domain = 'POINT'
    
    #output Mask
    stylized_ground.outputs.new('NodeSocketFloat', "Mask")
    stylized_ground.outputs[2].default_value = 0.0
    stylized_ground.outputs[2].min_value = -3.4028234663852886e+38
    stylized_ground.outputs[2].max_value = 3.4028234663852886e+38
    stylized_ground.outputs[2].attribute_domain = 'POINT'
    
    
    
    #node Mix.001
    mix_001 = stylized_ground.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    
    #node Voronoi Texture
    voronoi_texture = stylized_ground.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'MANHATTAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0
    
    #node Bump
    bump = stylized_ground.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Distance
    bump.inputs[1].default_value = 1.0
    
    #node Mix.002
    mix_002 = stylized_ground.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MULTIPLY'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #B_Color
    mix_002.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)
    
    #node Group Input
    group_input = stylized_ground.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #stylized_ground inputs
    #input Scale Global
    stylized_ground.inputs.new('NodeSocketFloat', "Scale Global")
    stylized_ground.inputs[0].default_value = 1.0
    stylized_ground.inputs[0].min_value = -10000.0
    stylized_ground.inputs[0].max_value = 10000.0
    stylized_ground.inputs[0].attribute_domain = 'POINT'
    
    #input Color1
    stylized_ground.inputs.new('NodeSocketColor', "Color1")
    stylized_ground.inputs[1].default_value = (0.5, 0.5, 0.5, 1.0)
    stylized_ground.inputs[1].attribute_domain = 'POINT'
    
    #input Color2
    stylized_ground.inputs.new('NodeSocketColor', "Color2")
    stylized_ground.inputs[2].default_value = (0.5, 0.5, 0.5, 1.0)
    stylized_ground.inputs[2].attribute_domain = 'POINT'
    
    #input Scale Texture1
    stylized_ground.inputs.new('NodeSocketFloat', "Scale Texture1")
    stylized_ground.inputs[3].default_value = 4.0
    stylized_ground.inputs[3].min_value = -1000.0
    stylized_ground.inputs[3].max_value = 1000.0
    stylized_ground.inputs[3].attribute_domain = 'POINT'
    
    #input Roughness
    stylized_ground.inputs.new('NodeSocketFloatFactor', "Roughness")
    stylized_ground.inputs[4].default_value = 0.0
    stylized_ground.inputs[4].min_value = 0.0
    stylized_ground.inputs[4].max_value = 1.0
    stylized_ground.inputs[4].attribute_domain = 'POINT'
    
    #input Bump Strength
    stylized_ground.inputs.new('NodeSocketFloatFactor', "Bump Strength")
    stylized_ground.inputs[5].default_value = 1.0
    stylized_ground.inputs[5].min_value = 0.0
    stylized_ground.inputs[5].max_value = 1.0
    stylized_ground.inputs[5].attribute_domain = 'POINT'
    
    #input Normal
    stylized_ground.inputs.new('NodeSocketVector', "Normal")
    stylized_ground.inputs[6].default_value = (0.0, 0.0, 0.0)
    stylized_ground.inputs[6].min_value = -1.0
    stylized_ground.inputs[6].max_value = 1.0
    stylized_ground.inputs[6].attribute_domain = 'POINT'
    stylized_ground.inputs[6].hide_value = True
    
    
    
    #node Invert
    invert = stylized_ground.nodes.new("ShaderNodeInvert")
    invert.name = "Invert"
    #Fac
    invert.inputs[0].default_value = 1.0
    
    #node Noise Texture
    noise_texture = stylized_ground.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 5.0
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.7462498545646667
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    
    #Set locations
    colorramp.location = (581.0684204101562, 220.00001525878906)
    mix.location = (241.06842041015625, 39.99998474121094)
    mapping.location = (-98.93157958984375, 219.99998474121094)
    texture_coordinate_001.location = (-858.9317016601562, 40.0)
    colorramp_001.location = (596.3683471679688, -8.774139404296875)
    vector_math_018.location = (-518.9317016601562, 119.99996948242188)
    principled_bsdf.location = (1020.0, 219.99996948242188)
    group_output.location = (1320.0, 0.0)
    mix_001.location = (860.0, 219.99996948242188)
    voronoi_texture.location = (1.06842041015625, -140.00001525878906)
    bump.location = (581.0684204101562, -220.00001525878906)
    mix_002.location = (850.59423828125, -21.796234130859375)
    group_input.location = (-1058.931640625, -0.0)
    invert.location = (-420.0, -80.0)
    noise_texture.location = (401.06842041015625, 39.99998474121094)
    
    #Set dimensions
    colorramp.width, colorramp.height = 240.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    mapping.width, mapping.height = 240.0, 100.0
    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
    colorramp_001.width, colorramp_001.height = 240.0, 100.0
    vector_math_018.width, vector_math_018.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    invert.width, invert.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    
    #initialize stylized_ground links
    #principled_bsdf.BSDF -> group_output.BSDF
    stylized_ground.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #noise_texture.Fac -> colorramp.Fac
    stylized_ground.links.new(noise_texture.outputs[0], colorramp.inputs[0])
    #mix.Result -> noise_texture.Vector
    stylized_ground.links.new(mix.outputs[2], noise_texture.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    stylized_ground.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #noise_texture.Fac -> bump.Height
    stylized_ground.links.new(noise_texture.outputs[0], bump.inputs[2])
    #mapping.Vector -> mix.A
    stylized_ground.links.new(mapping.outputs[0], mix.inputs[6])
    #voronoi_texture.Distance -> mix.B
    stylized_ground.links.new(voronoi_texture.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> colorramp_001.Fac
    stylized_ground.links.new(noise_texture.outputs[0], colorramp_001.inputs[0])
    #colorramp_001.Color -> mix_002.A
    stylized_ground.links.new(colorramp_001.outputs[0], mix_002.inputs[6])
    #texture_coordinate_001.Object -> vector_math_018.Vector
    stylized_ground.links.new(texture_coordinate_001.outputs[3], vector_math_018.inputs[0])
    #vector_math_018.Vector -> mapping.Vector
    stylized_ground.links.new(vector_math_018.outputs[0], mapping.inputs[0])
    #vector_math_018.Vector -> voronoi_texture.Vector
    stylized_ground.links.new(vector_math_018.outputs[0], voronoi_texture.inputs[0])
    #group_input.Scale Global -> vector_math_018.Scale
    stylized_ground.links.new(group_input.outputs[0], vector_math_018.inputs[3])
    #mix_001.Result -> principled_bsdf.Base Color
    stylized_ground.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
    #colorramp.Color -> mix_001.Factor
    stylized_ground.links.new(colorramp.outputs[0], mix_001.inputs[0])
    #group_input.Color1 -> mix_001.A
    stylized_ground.links.new(group_input.outputs[1], mix_001.inputs[6])
    #group_input.Color2 -> mix_001.B
    stylized_ground.links.new(group_input.outputs[2], mix_001.inputs[7])
    #group_input.Scale Texture1 -> voronoi_texture.Scale
    stylized_ground.links.new(group_input.outputs[3], voronoi_texture.inputs[2])
    #mix_002.Result -> principled_bsdf.Roughness
    stylized_ground.links.new(mix_002.outputs[2], principled_bsdf.inputs[9])
    #group_input.Roughness -> invert.Color
    stylized_ground.links.new(group_input.outputs[4], invert.inputs[1])
    #group_input.Bump Strength -> bump.Strength
    stylized_ground.links.new(group_input.outputs[5], bump.inputs[0])
    #group_input.Normal -> bump.Normal
    stylized_ground.links.new(group_input.outputs[6], bump.inputs[3])
    #invert.Color -> mix_002.Factor
    stylized_ground.links.new(invert.outputs[0], mix_002.inputs[0])
    #noise_texture.Fac -> group_output.Mask
    stylized_ground.links.new(noise_texture.outputs[0], group_output.inputs[2])
    #mix_001.Result -> group_output.Albedo
    stylized_ground.links.new(mix_001.outputs[2], group_output.inputs[1])
    return stylized_ground

stylized_ground = stylized_ground_node_group()

#initialize Stylized Ground node group
def stylized_ground_1_node_group():

    stylized_ground_1 = mat.node_tree
    #start with a clean node tree
    for node in stylized_ground_1.nodes:
        stylized_ground_1.nodes.remove(node)
    #initialize stylized_ground_1 nodes
    #node Material Output
    material_output = stylized_ground_1.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Stylized Ground
    stylized_ground_2 = stylized_ground_1.nodes.new("ShaderNodeGroup")
    stylized_ground_2.label = "Stylized Ground"
    stylized_ground_2.name = "Stylized Ground"
    stylized_ground_2.node_tree = stylized_ground
    #Input_1
    stylized_ground_2.inputs[0].default_value = 1.0
    #Input_2
    stylized_ground_2.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
    #Input_3
    stylized_ground_2.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
    #Input_4
    stylized_ground_2.inputs[3].default_value = 5.0
    #Input_5
    stylized_ground_2.inputs[4].default_value = 1.0
    #Input_6
    stylized_ground_2.inputs[5].default_value = 1.0
    #Input_7
    stylized_ground_2.inputs[6].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (674.9501953125, 101.66796875)
    stylized_ground_2.location = (447.0869140625, 101.66796875)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    stylized_ground_2.width, stylized_ground_2.height = 166.95703125, 100.0
    
    #initialize stylized_ground_1 links
    #stylized_ground_2.BSDF -> material_output.Surface
    stylized_ground_1.links.new(stylized_ground_2.outputs[0], material_output.inputs[0])
    return stylized_ground_1

stylized_ground_1 = stylized_ground_1_node_group()

