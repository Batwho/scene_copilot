import bpy, mathutils

mat = bpy.data.materials.new(name = "Red Shiny Thick")
mat.use_nodes = True
#initialize plastic red shiny thick node group
def plastic_red_shiny_thick_node_group():

    plastic_red_shiny_thick = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "plastic red shiny thick")
    
    #initialize plastic_red_shiny_thick nodes
    #node Principled BSDF
    principled_bsdf = plastic_red_shiny_thick.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK_FIXED_RADIUS'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (1.0, 0.0, 0.0, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.0099999904632568
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Group Input
    group_input = plastic_red_shiny_thick.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #plastic_red_shiny_thick inputs
    #input Base Color
    plastic_red_shiny_thick.inputs.new('NodeSocketColor', "Base Color")
    plastic_red_shiny_thick.inputs[0].default_value = (1.0, 0.0, 0.0, 1.0)
    plastic_red_shiny_thick.inputs[0].attribute_domain = 'POINT'
    
    #input Roughness
    plastic_red_shiny_thick.inputs.new('NodeSocketFloatFactor', "Roughness")
    plastic_red_shiny_thick.inputs[1].default_value = 0.15000000596046448
    plastic_red_shiny_thick.inputs[1].min_value = 0.0
    plastic_red_shiny_thick.inputs[1].max_value = 1.0
    plastic_red_shiny_thick.inputs[1].attribute_domain = 'POINT'
    
    #input Normal
    plastic_red_shiny_thick.inputs.new('NodeSocketVector', "Normal")
    plastic_red_shiny_thick.inputs[2].default_value = (0.0, 0.0, 0.0)
    plastic_red_shiny_thick.inputs[2].min_value = -3.4028234663852886e+38
    plastic_red_shiny_thick.inputs[2].max_value = 3.4028234663852886e+38
    plastic_red_shiny_thick.inputs[2].attribute_domain = 'POINT'
    plastic_red_shiny_thick.inputs[2].hide_value = True
    
    
    
    #node Group Output
    group_output = plastic_red_shiny_thick.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #plastic_red_shiny_thick outputs
    #output BSDF
    plastic_red_shiny_thick.outputs.new('NodeSocketShader', "BSDF")
    plastic_red_shiny_thick.outputs[0].attribute_domain = 'POINT'
    
    
    
    #node RGB
    rgb = plastic_red_shiny_thick.nodes.new("ShaderNodeRGB")
    rgb.name = "RGB"
    
    rgb.outputs[0].default_value = (1.0, 0.0, 0.0, 1.0)
    
    #Set locations
    principled_bsdf.location = (99.7711181640625, 40.0)
    group_input.location = (-299.7711181640625, -0.0)
    group_output.location = (389.7711181640625, -0.0)
    rgb.location = (-99.7711181640625, -39.99998474121094)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    rgb.width, rgb.height = 140.0, 100.0
    
    #initialize plastic_red_shiny_thick links
    #principled_bsdf.BSDF -> group_output.BSDF
    plastic_red_shiny_thick.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
    #rgb.Color -> principled_bsdf.Subsurface Radius
    plastic_red_shiny_thick.links.new(rgb.outputs[0], principled_bsdf.inputs[2])
    #group_input.Base Color -> principled_bsdf.Base Color
    plastic_red_shiny_thick.links.new(group_input.outputs[0], principled_bsdf.inputs[0])
    #group_input.Roughness -> principled_bsdf.Roughness
    plastic_red_shiny_thick.links.new(group_input.outputs[1], principled_bsdf.inputs[9])
    #group_input.Normal -> principled_bsdf.Normal
    plastic_red_shiny_thick.links.new(group_input.outputs[2], principled_bsdf.inputs[22])
    return plastic_red_shiny_thick

plastic_red_shiny_thick = plastic_red_shiny_thick_node_group()

#initialize Red Shiny Thick node group
def red_shiny_thick_node_group():

    red_shiny_thick = mat.node_tree
    #start with a clean node tree
    for node in red_shiny_thick.nodes:
        red_shiny_thick.nodes.remove(node)
    #initialize red_shiny_thick nodes
    #node Material Output
    material_output = red_shiny_thick.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node plastic red shiny thick
    plastic_red_shiny_thick_1 = red_shiny_thick.nodes.new("ShaderNodeGroup")
    plastic_red_shiny_thick_1.label = "plastic red shiny thick"
    plastic_red_shiny_thick_1.name = "plastic red shiny thick"
    plastic_red_shiny_thick_1.use_custom_color = True
    plastic_red_shiny_thick_1.color = (0.09850428998470306, 0.09850428998470306, 0.09850428998470306)
    plastic_red_shiny_thick_1.node_tree = plastic_red_shiny_thick
    #Input_1
    plastic_red_shiny_thick_1.inputs[0].default_value = (1.0, 0.0, 0.0, 1.0)
    #Input_2
    plastic_red_shiny_thick_1.inputs[1].default_value = 0.15000000596046448
    #Input_3
    plastic_red_shiny_thick_1.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    
    #Set locations
    material_output.location = (702.0478515625, 45.779541015625)
    plastic_red_shiny_thick_1.location = (422.505859375, 45.779541015625)
    
    #Set dimensions
    material_output.width, material_output.height = 140.0, 100.0
    plastic_red_shiny_thick_1.width, plastic_red_shiny_thick_1.height = 169.050048828125, 100.0
    
    #initialize red_shiny_thick links
    #plastic_red_shiny_thick_1.BSDF -> material_output.Surface
    red_shiny_thick.links.new(plastic_red_shiny_thick_1.outputs[0], material_output.inputs[0])
    return red_shiny_thick

red_shiny_thick = red_shiny_thick_node_group()

