import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_polen2(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.0908, 0.0085, 0.0000, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_polen1(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.1282, 0.0332, 0.0000, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_sepal(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.1384, 0.5489, 0.0491, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_petal(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.4869, 0.1693, 0.0000, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    spiral = nw.new_node('GeometryNodeCurveSpiral',
        input_kwargs={'Resolution': 19, 'Rotations': 5.0000, 'End Radius': 0.0000, 'Height': 1.0000})
    
    index = nw.new_node(Nodes.Index)
    
    pingpong = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 1.0000}, attrs={'operation': 'PINGPONG'})
    
    delete_geometry = nw.new_node(Nodes.DeleteGeometry, input_kwargs={'Geometry': spiral, 'Selection': pingpong})
    
    index_1 = nw.new_node(Nodes.Index)
    
    less_than = nw.new_node(Nodes.Math, input_kwargs={0: index_1, 1: 23.0000}, attrs={'operation': 'LESS_THAN'})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (0.0000, 0.0000, 3.0000)})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line, 'Count': 20})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.2682, 0.5187), (0.7636, 0.6500), (1.0000, 1.0000)])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': resample_curve, 'Offset': combine_xyz})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_1.outputs["Factor"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0182, 0.6188), (0.5091, 0.9063), (0.9909, 0.3062)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': set_position, 'Radius': float_curve_1})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Height': 0.0800})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': quadrilateral, 'Count': 20})
    
    position = nw.new_node(Nodes.InputPosition)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': resample_curve_1, 2: position})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': capture_attribute.outputs["Geometry"], 'Fill Caps': True})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: capture_attribute.outputs[2], 1: 16.8000}, attrs={'operation': 'MULTIPLY'})
    
    pingpong_1 = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: 1.0000}, attrs={'operation': 'PINGPONG'})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': pingpong_1})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.2545, 0.1063), (0.6182, 0.4250), (1.0000, 0.4188)])
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: normal, 1: float_curve_2}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_1})
    
    set_position_for_wrinkles = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': curve_to_mesh, 'Offset': combine_xyz_1},
        label='Set Position for Wrinkles')
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 1.0000, 'Distortion': 1.0000})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': noise_texture.outputs["Color"], 1: -2.0000, 2: 0.5000, 3: 1.0000, 4: 0.0000})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: map_range.outputs["Result"]})
    
    set_position_for_disp_m_ap = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_position_for_wrinkles, 'Position': add.outputs["Vector"]},
        label='Set Position for Disp MAp')
    
    spline_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_2.outputs["Factor"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.7000), (0.6273, 0.6438), (0.9909, 0.0125)])
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': delete_geometry, 'Selection': less_than, 'Instance': set_position_for_disp_m_ap, 'Scale': float_curve_3})
    
    position_2 = nw.new_node(Nodes.InputPosition)
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': position_2}, attrs={'pivot_axis': 'Z'})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points, 'Rotation': align_euler_to_vector})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': rotate_instances, 'Rotation': (0.0000, 0.6981, 0.0000)})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': rotate_instances_1, 'Material': surface.shaderfunc_to_material(shader_petal)})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 5, 'Radius': 0.7000})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.5000, 3: 0.7000})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_circle.outputs["Curve"], 'Instance': set_position_for_wrinkles, 'Scale': random_value.outputs[1]})
    
    position_3 = nw.new_node(Nodes.InputPosition)
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': position_3})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_1, 'Rotation': align_euler_to_vector_1})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': rotate_instances_2, 'Translation': (0.0000, 0.0000, 0.1000), 'Rotation': (0.0000, 3.1416, 0.0000)})
    
    rotate_instances_3 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': transform, 'Rotation': (0.0000, 0.4189, 0.0000)})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': rotate_instances_3, 'Material': surface.shaderfunc_to_material(shader_sepal)})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material, set_material_1]})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine)
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1})
    
    spline_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_3.outputs["Factor"]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0045, 0.1437), (0.7000, 0.2938), (1.0000, 1.0000)])
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve_2, 'Radius': float_curve_4})
    
    position_4 = nw.new_node(Nodes.InputPosition)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': set_curve_radius_1, 2: position_4})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle)
    
    capture_attribute_2 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': curve_circle_1.outputs["Curve"], 2: position_4})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute_1.outputs["Geometry"], 'Profile Curve': capture_attribute_2.outputs["Geometry"]})
    
    normal_1 = nw.new_node(Nodes.InputNormal)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': normal_1})
    
    float_curve_6 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': capture_attribute_1.outputs[2]})
    node_utils.assign_curve(float_curve_6.mapping.curves[0], [(0.0000, 0.0000), (0.6545, 0.1938), (1.0000, 1.0000)])
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: capture_attribute_2.outputs[2], 1: 12.0000},
        attrs={'operation': 'MULTIPLY'})
    
    pingpong_2 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_2, 1: 1.0000}, attrs={'operation': 'PINGPONG'})
    
    float_curve_5 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': pingpong_2})
    node_utils.assign_curve(float_curve_5.mapping.curves[0], [(0.0000, 0.0000), (0.2500, 0.9313), (0.7455, 0.3063), (1.0000, 1.0000)])
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_6, 1: float_curve_5}, attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["X"], 1: multiply_3}, attrs={'operation': 'MULTIPLY'})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"], 1: multiply_3}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4, 'Y': multiply_5})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': curve_to_mesh_1, 'Offset': combine_xyz_2})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_position_3, 'Translation': (0.0000, 0.0000, -1.0000)})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': transform_1, 'Material': surface.shaderfunc_to_material(shader_sepal)})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [join_geometry, set_material_2]})
    
    uv_sphere = nw.new_node(Nodes.MeshUVSphere)
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': uv_sphere.outputs["Mesh"], 'Name': 'uv_map', 3: uv_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    transform_2 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_1, 'Translation': (0.0000, 0.0000, 0.4000), 'Scale': (1.0000, 1.0000, 0.5000)})
    
    index_2 = nw.new_node(Nodes.Index)
    
    less_than_1 = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: 65.0000}, attrs={'operation': 'LESS_THAN'})
    
    set_position_4 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': transform_2, 'Selection': less_than_1, 'Offset': (0.0000, 0.0000, -0.2000)})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_position_4, 'Material': surface.shaderfunc_to_material(shader_polen1)})
    
    index_3 = nw.new_node(Nodes.Index)
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: index_3, 1: 223.0000}, attrs={'operation': 'GREATER_THAN'})
    
    distribute_points_on_faces = nw.new_node(Nodes.DistributePointsOnFaces,
        input_kwargs={'Mesh': set_position_4, 'Selection': greater_than, 'Density': 500.0000},
        attrs={'use_legacy_normal': True})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': 0.0400})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': distribute_points_on_faces.outputs["Points"], 'Instance': store_named_attribute})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points_2, 'Material': surface.shaderfunc_to_material(shader_polen2)})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [join_geometry_1, set_material_4, set_material_3]})
    
    transform_3 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': join_geometry_2, 'Rotation': (0.0000, 0.6981, 0.0000)})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (0.0000, 0.0000, 7.0000)})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_2})
    
    transform_4 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': resample_curve_3, 'Translation': (-1.0500, 0.0000, -7.7000)})
    
    spline_parameter_4 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_7 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_4.outputs["Factor"]})
    node_utils.assign_curve(float_curve_7.mapping.curves[0], [(0.0000, 0.0000), (0.2045, 0.6062), (0.7545, 0.0063), (1.0000, 0.4000)])
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve_7})
    
    set_position_5 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': transform_4, 'Offset': combine_xyz_3})
    
    curve_circle_2 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Radius': 0.0500})
    
    curve_to_mesh_2 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_5, 'Profile Curve': curve_circle_2.outputs["Curve"]})
    
    set_material_5 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh_2, 'Material': surface.shaderfunc_to_material(shader_sepal)})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [transform_3, set_material_5]})
    
    subdivision_surface = nw.new_node(Nodes.SubdivisionSurface, input_kwargs={'Mesh': join_geometry_3, 'Level': 2})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': subdivision_surface}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
apply(bpy.context.active_object)