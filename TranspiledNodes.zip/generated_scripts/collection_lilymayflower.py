import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_a_s_t_rotate_x_y_z_002', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_rotate_x_y_z_002(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Direction', 0),
            ('NodeSocketString', '#', '0=X, 1=Y and 2=Z')])
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Direction"]})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2, 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 90.0000
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={0: equal, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    equal_1 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2}, attrs={'operation': 'EQUAL'})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={0: equal_1, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    equal_2 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2, 1: 2.0000}, attrs={'operation': 'EQUAL'})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: equal_2, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': switch.outputs["Output"], 'Y': switch_2.outputs["Output"], 'Z': switch_1.outputs["Output"]})
    
    divide = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_3, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Rotation': divide.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': transform}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_index_selection_004', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_index_selection_004(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    index_2 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: 2.0000}, attrs={'operation': 'MODULO'})
    
    less_equal = nw.new_node(Nodes.Compare, input_kwargs={0: modulo}, attrs={'operation': 'LESS_EQUAL'})
    
    greater_equal = nw.new_node(Nodes.Compare, input_kwargs={0: modulo, 1: 1.0000}, attrs={'operation': 'GREATER_EQUAL'})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketInt', '%', 2)])
    
    modulo_1 = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: group_input.outputs["%"]}, attrs={'operation': 'MODULO'})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={2: modulo_1}, attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_1 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 1},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_2 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 2},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_3 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 3},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_4 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 4},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Even Selection': less_equal, 'Odd Selection': greater_equal, '1st': equal, '2nd': equal_1, '3rd': equal_2, '4th': equal_3, '5th': equal_4},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_mono_directional_bezier_002', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_mono_directional_bezier_002(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 16),
            ('NodeSocketVectorEuler', 'Start', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Center', 0.0000),
            ('NodeSocketFloat', 'Middle X', 0.0000),
            ('NodeSocketFloat', 'Middle Y', 0.0000),
            ('NodeSocketFloat', 'Length', 1.0000),
            ('NodeSocketFloat', 'End X', 0.0000),
            ('NodeSocketFloat', 'End Y', 0.0000),
            ('NodeSocketInt', 'Direction', 0)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Center"], 1: 2.0000})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute, 1: add}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["Middle X"], 'Y': group_input.outputs["Middle Y"], 'Z': divide})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["End X"], 'Y': group_input.outputs["End Y"], 'Z': reroute})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Start': group_input.outputs["Start"], 'Middle': combine_xyz_1, 'End': combine_xyz})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': quadratic_bezier, 2: spline_parameter.outputs["Length"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: spline_parameter.outputs["Factor"]})
    
    ast_rotate_xyz_002 = nw.new_node(nodegroup_a_s_t_rotate_x_y_z_002().name,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Direction': group_input.outputs["Direction"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': ast_rotate_xyz_002, 'Length': capture_attribute.outputs[2], 'Factor': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_value', singleton=False, type='GeometryNodeTree')
def nodegroup_value(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Value', 0.0000),
            ('NodeSocketInt', 'Seed', 0),
            ('NodeSocketFloat', '%%', 1.5000)])
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000, 1: group_input.outputs["Value"]}, attrs={'operation': 'SUBTRACT'})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: subtract, 3: group_input.outputs["Value"], 'Seed': group_input.outputs["Seed"]})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Value"], 1: group_input.outputs["%%"]},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: group_input.outputs["Value"], 3: multiply, 'Seed': group_input.outputs["Seed"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Positive': group_input.outputs["Value"], 'Negative': subtract, 'Random in Range{+-}': random_value.outputs[1], 'Value to %%': random_value_1.outputs[1]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_n_th__selection', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_n_th__selection(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    index = nw.new_node(Nodes.Index)
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketInt', 'nTH', 2)])
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: group_input.outputs["nTH"]}, attrs={'operation': 'MODULO'})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={2: modulo, 3: 1}, attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Result': equal}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_gimble_to_mean_001', singleton=False, type='GeometryNodeTree')
def nodegroup_gimble_to_mean_001(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', ' 0 (Origen)', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'X', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Y', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Z', (0.0000, 0.0000, 0.0000))])
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input.outputs[" 0 (Origen)"]})
    
    distance = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs[" 0 (Origen)"], 1: group_input.outputs["Y"]},
        attrs={'operation': 'DISTANCE'})
    
    half = nw.new_node(Nodes.Math,
        input_kwargs={0: distance.outputs["Value"], 1: 2.0000},
        label='Half',
        attrs={'operation': 'DIVIDE'})
    
    x = nw.new_node(Nodes.Reroute, input_kwargs={'Input': half}, label='X')
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["X"], 1: x})
    
    distance_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs[" 0 (Origen)"], 1: group_input.outputs["X"]},
        attrs={'operation': 'DISTANCE'})
    
    half_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: distance_1.outputs["Value"], 1: 2.0000},
        label='Half',
        attrs={'operation': 'DIVIDE'})
    
    y = nw.new_node(Nodes.Reroute, input_kwargs={'Input': half_1}, label='Y')
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"], 1: y})
    
    distance_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs[" 0 (Origen)"], 1: group_input.outputs["Z"]},
        attrs={'operation': 'DISTANCE'})
    
    half_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: distance_2.outputs["Value"], 1: 2.0000},
        label='Half',
        attrs={'operation': 'DIVIDE'})
    
    z = nw.new_node(Nodes.Reroute, input_kwargs={'Input': half_2}, label='Z')
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: z, 1: separate_xyz.outputs["Z"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add, 'Y': add_1, 'Z': add_2})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': distance.outputs["Value"], 'Y': distance_1.outputs["Value"], 'Z': distance_2.outputs["Value"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Mean (XYZ/2)': combine_xyz, 'Scale': combine_xyz_1},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_supporting_leaf_profile', singleton=False, type='GeometryNodeTree')
def nodegroup_supporting_leaf_profile(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 16),
            ('NodeSocketFloat', 'height', 1.0000),
            ('NodeSocketFloat', 'Radius', 1.0000),
            ('NodeSocketInt', 'Profile', 2),
            ('NodeSocketFloat', 'Rotation', 6.2832),
            ('NodeSocketVectorEuler', 'Start', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Center', 0.0000),
            ('NodeSocketFloat', 'Middle X', 0.0000),
            ('NodeSocketFloat', 'End X', 0.0000),
            ('NodeSocketFloat', 'End Y', 0.0000)])
    
    ast_mono_directional_bezier_002 = nw.new_node(nodegroup_a_s_t_mono_directional_bezier_002().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Start': group_input.outputs["Start"], 'Center': group_input.outputs["Center"], 'Middle X': group_input.outputs["Middle X"], 'Length': group_input.outputs["height"], 'End X': group_input.outputs["End X"], 'End Y': group_input.outputs["End Y"], 'Direction': group_input.outputs["Profile"]})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: ast_mono_directional_bezier_002.outputs["Factor"], 1: group_input.outputs["Rotation"]},
        attrs={'operation': 'MULTIPLY'})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: multiply}, attrs={'operation': 'SINE'})
    
    cosine = nw.new_node(Nodes.Math, input_kwargs={0: multiply}, attrs={'operation': 'COSINE'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': sine, 'Y': cosine})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz, 'Scale': group_input.outputs["Radius"]},
        attrs={'operation': 'SCALE'})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': ast_mono_directional_bezier_002.outputs["Curve"], 'Offset': scale.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': set_position_1, 'Length': ast_mono_directional_bezier_002.outputs["Length"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_natural_spiral', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_natural_spiral(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    curve_line = nw.new_node(Nodes.CurveLine)
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketInt', 'resolution', 16),
            ('NodeSocketFloat', 'Roll Over', 0.2500),
            ('NodeSocketFloat', 'Outer Scale', 6.0000),
            ('NodeSocketFloat', 'Scale', 1.0000),
            ('NodeSocketFloatFactor', 'Factor', 0.5000),
            ('NodeSocketFloat', 'Leaning', 0.0000)])
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line, 'Count': group_input.outputs["resolution"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_1})
    
    index = nw.new_node(Nodes.Index)
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': index, 2: group_input.outputs["resolution"], 3: 1.0000, 4: 0.0000})
    
    accumulate_field = nw.new_node(Nodes.AccumulateField, input_kwargs={1: map_range.outputs["Result"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: accumulate_field.outputs[1], 1: accumulate_field.outputs[4]})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: 10.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: 20.0000, 1: group_input.outputs["resolution"]},
        attrs={'operation': 'DIVIDE'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["resolution"], 4: divide_1})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_1.outputs["Result"], 1: group_input.outputs["Outer Scale"]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: multiply}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_1})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute, 'Position': combine_xyz})
    
    position = nw.new_node(Nodes.InputPosition)
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': set_position})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Leaning"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_4, 'Z': 1.0000})
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: bounding_box.outputs["Max"], 1: combine_xyz_1})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Factor"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["resolution"]})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': index, 2: reroute_2})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Factor': reroute_8, 'Value': map_range_2.outputs["Result"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.7500, 0.2500), (1.0000, 1.0000)])
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': float_curve})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Roll Over"]})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: colorramp.outputs["Color"], 1: reroute_1}, attrs={'operation': 'MULTIPLY'})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': position, 'Center': add_1.outputs["Vector"], 'Angle': multiply_2},
        attrs={'rotation_type': 'X_AXIS'})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position, 'Position': vector_rotate})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Scale"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_9, 1: 10.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': divide_2})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_position_2, 'Scale': reroute_3})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range.outputs["Result"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: reroute_3}, attrs={'operation': 'MULTIPLY'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': transform, 'Scale for Instances': multiply_3},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_align_to_3_d_plane', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_align_to_3_d_plane(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Geometry', None)])
    
    bounding_box_1 = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': group_input.outputs["Geometry"]})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': bounding_box_1.outputs["Min"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000, 1: separate_xyz_1.outputs["Z"]}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract})
    
    set_position_4 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Offset': combine_xyz_1})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_4}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_change_spline_type', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_change_spline_type(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Select', 0)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Select"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: reroute_1}, attrs={'data_type': 'INT'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Curve"]})
    
    set_spline_type = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': reroute_4})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    greater_than_1 = nw.new_node(Nodes.Compare, input_kwargs={2: reroute_2, 3: 1}, attrs={'data_type': 'INT'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    set_spline_type_1 = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': reroute_5}, attrs={'spline_type': 'CATMULL_ROM'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    greater_than_2 = nw.new_node(Nodes.Compare, input_kwargs={2: reroute_3, 3: 2}, attrs={'data_type': 'INT'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    set_spline_type_2 = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': reroute_6}, attrs={'spline_type': 'NURBS'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    set_spline_type_3 = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': reroute_7}, attrs={'spline_type': 'BEZIER'})
    
    set_handle_type = nw.new_node(Nodes.SetHandleType, input_kwargs={'Curve': set_spline_type_3})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={1: greater_than_2, 14: set_spline_type_2, 15: set_handle_type})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={1: greater_than_1, 14: set_spline_type_1, 15: switch_2.outputs[6]})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: greater_than, 14: set_spline_type, 15: switch_1.outputs[6]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Curve': switch.outputs[6]}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_recurve', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_recurve(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Merge by Distance', True),
            ('NodeSocketFloatDistance', 'Distance', 0.0010)])
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': group_input.outputs["Curve"]})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance,
        input_kwargs={'Geometry': curve_to_mesh, 'Distance': group_input.outputs["Distance"]})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input.outputs["Merge by Distance"], 14: curve_to_mesh, 15: merge_by_distance})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': switch.outputs[6]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Curve': mesh_to_curve}, attrs={'is_active_output': True})

@node_utils.to_nodegroup("nodegroup_a_s_t_abhays_round_curve_002", singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_abhays_round_curve_002(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 64),
            ('NodeSocketFloatFactor', 'Length', 1.0000),
            ('NodeSocketFloatDistance', 'Radius', 1.0000),
            ('NodeSocketBool', 'Fill', False),
            ('NodeSocketInt', 'Cut', 0),
            ('NodeSocketFloat', 'Rotation', 6.2832),
            ('NodeSocketFloat', 'Edge Scale', 1.0000),
            ('NodeSocketFloat', 'Even Index Z offset', 0.0000)])
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    ast_mono_directional_bezier_002 = nw.new_node(nodegroup_a_s_t_mono_directional_bezier_002().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Length': reroute_4})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: group_input.outputs["Cut"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute_4, 1: spline_parameter.outputs["Factor"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute, 1: group_input.outputs["Rotation"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1}, attrs={'operation': 'SINE'})
    
    sine_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1}, attrs={'operation': 'SINE', 'use_clamp': True})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: greater_than, 2: sine, 3: sine_1}, attrs={'input_type': 'FLOAT'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: switch_1.outputs["Output"], 1: reroute}, attrs={'operation': 'SUBTRACT'})
    
    greater_than_1 = nw.new_node(Nodes.Compare, input_kwargs={0: group_input.outputs["Cut"], 1: 1.0000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    cosine = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2}, attrs={'operation': 'COSINE'})
    
    cosine_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2}, attrs={'operation': 'COSINE', 'use_clamp': True})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={0: greater_than_1, 2: cosine, 3: cosine_1}, attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': subtract, 'Y': switch_2.outputs["Output"]})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': ast_mono_directional_bezier_002.outputs["Curve"], 'Offset': combine_xyz})
    
    ast_index_selection_004 = nw.new_node(nodegroup_a_s_t_index_selection_004().name)
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Even Index Z offset"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_position, 'Selection': ast_index_selection_004.outputs["Even Selection"], 'Offset': combine_xyz_1})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_position_1, 'Scale': group_input.outputs["Radius"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': transform})
    
    scale_elements = nw.new_node(Nodes.ScaleElements,
        input_kwargs={'Geometry': curve_to_mesh, 'Selection': ast_index_selection_004.outputs["Even Selection"], 'Scale': group_input.outputs["Edge Scale"], 'Axis': (0.0000, 0.0000, 0.0000)},
        attrs={'domain': 'EDGE'})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': scale_elements})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': merge_by_distance})
    
    fill_curve = nw.new_node(Nodes.FillCurve, input_kwargs={'Curve': mesh_to_curve}, attrs={'mode': 'NGONS'})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["Fill"], 14: mesh_to_curve, 15: fill_curve})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': switch.outputs[6], 'Length': ast_mono_directional_bezier_002.outputs["Length"], 'Mesh': merge_by_distance},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_alternative_instances_mirrered_rotation', singleton=False, type='GeometryNodeTree')
def nodegroup_alternative_instances_mirrered_rotation(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Instances', None),
            ('NodeSocketVector', 'Rotation', (0.0000, 0.0000, 0.0000))])
    
    ast_nth_selection = nw.new_node(nodegroup_a_s_t_n_th__selection().name)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input.outputs["Rotation"]})
    
    value = nw.new_node(nodegroup_value().name, input_kwargs={'Value': separate_xyz.outputs["X"]})
    
    value_1 = nw.new_node(nodegroup_value().name, input_kwargs={'Value': separate_xyz.outputs["Y"]})
    
    value_2 = nw.new_node(nodegroup_value().name, input_kwargs={'Value': separate_xyz.outputs["Z"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': value.outputs["Positive"], 'Y': value_1.outputs["Positive"], 'Z': value_2.outputs["Positive"]})
    
    divide = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_1, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': group_input.outputs["Instances"], 'Selection': ast_nth_selection, 'Rotation': divide.outputs["Vector"]})
    
    op_not = nw.new_node(Nodes.BooleanMath, input_kwargs={0: ast_nth_selection}, attrs={'operation': 'NOT'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: value.outputs["Positive"], 1: 10.0000}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': subtract, 'Y': value_1.outputs["Negative"], 'Z': value_2.outputs["Negative"]})
    
    divide_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_2, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': rotate_instances_1, 'Selection': op_not, 'Rotation': divide_1.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': rotate_instances_2}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_bound_box_001', singleton=False, type='GeometryNodeTree')
def nodegroup_bound_box_001(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Geometry', None)])
    
    bounding_box_1 = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': group_input.outputs["Geometry"]})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': bounding_box_1.outputs["Min"]})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': bounding_box_1.outputs["Max"]})
    
    d = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz.outputs["X"], 'Y': separate_xyz_1.outputs["Y"], 'Z': separate_xyz.outputs["Z"]},
        label='D')
    
    b = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz_1.outputs["X"], 'Y': separate_xyz.outputs["Y"], 'Z': separate_xyz.outputs["Z"]},
        label='B')
    
    a = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz.outputs["X"], 'Y': separate_xyz.outputs["Y"], 'Z': separate_xyz_1.outputs["Z"]},
        label='A^')
    
    gimble_to_mean_001 = nw.new_node(nodegroup_gimble_to_mean_001().name,
        input_kwargs={' 0 (Origen)': bounding_box_1.outputs["Min"], 'X': d, 'Y': b, 'Z': a})
    
    c = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz_1.outputs["X"], 'Y': separate_xyz_1.outputs["Y"], 'Z': separate_xyz.outputs["Z"]},
        label='C')
    
    c_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz_1.outputs["X"], 'Y': separate_xyz.outputs["Y"], 'Z': separate_xyz_1.outputs["Z"]},
        label='C^')
    
    d_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz.outputs["X"], 'Y': separate_xyz_1.outputs["Y"], 'Z': separate_xyz_1.outputs["Z"]},
        label='D^')
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': gimble_to_mean_001.outputs["Mean (XYZ/2)"]})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': separate_xyz_2.outputs["X"], 'Y': separate_xyz_2.outputs["Y"], 'Z': separate_xyz.outputs["Z"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Bounding Box': bounding_box_1.outputs["Bounding Box"], 'Center': gimble_to_mean_001.outputs["Mean (XYZ/2)"], 'A (min)': bounding_box_1.outputs["Min"], 'B': b, 'C': c, 'D': d, "A'": a, "B'": c_1, "C' (max)": bounding_box_1.outputs["Max"], "D'": d_1, 'Base (Center Bottom)': combine_xyz_6, 'Scale': gimble_to_mean_001.outputs["Scale"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_triplanner_projection_mapping', singleton=False, type='ShaderNodeTree')
def nodegroup_triplanner_projection_mapping(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_3 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloatFactor', 'Position/Object', 0.0000),
            ('NodeSocketFloat', 'Scale', 1.0000),
            ('NodeSocketFloatFactor', 'Normal/Object ', 1.0000),
            ('NodeSocketFloatFactor', 'Blend', 1.0000),
            ('NodeSocketFloatFactor', 'Blend uglyness', 0.6000)])
    
    geometry_2 = nw.new_node(Nodes.NewGeometry)
    
    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord)
    
    mix_11 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input_3.outputs["Normal/Object "], 4: geometry_2.outputs["True Normal"], 5: texture_coordinate_1.outputs["Object"]},
        attrs={'data_type': 'VECTOR'})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': mix_11.outputs[1]})
    
    absolute = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_1.outputs["Z"], 1: 0.7390}, attrs={'operation': 'ABSOLUTE'})
    
    absolute_1 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_1.outputs["X"], 1: 0.7390}, attrs={'operation': 'ABSOLUTE'})
    
    geometry_1 = nw.new_node(Nodes.NewGeometry)
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input_3.outputs["Position/Object"], 4: geometry_1.outputs["Position"], 5: texture_coordinate_1.outputs["Object"]},
        attrs={'data_type': 'VECTOR'})
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: mix_5.outputs[1]}, attrs={'operation': 'SCALE'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': scale.outputs["Vector"]})
    
    absolute_2 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["X"]}, attrs={'operation': 'ABSOLUTE'})
    
    absolute_3 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Z"]}, attrs={'operation': 'ABSOLUTE'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': absolute_2, 'Y': absolute_3})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    absolute_4 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"]}, attrs={'operation': 'ABSOLUTE'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': absolute_4, 'Y': absolute_3})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_2})
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: absolute_1, 4: reroute, 5: reroute_1}, attrs={'data_type': 'VECTOR'})
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': mix_11.outputs[1]})
    
    absolute_5 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_2.outputs["X"], 1: 0.7390}, attrs={'operation': 'ABSOLUTE'})
    
    colorramp_8 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': absolute_5})
    colorramp_8.color_ramp.interpolation = "CARDINAL"
    colorramp_8.color_ramp.elements[0].position = 0.5000
    colorramp_8.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_8.color_ramp.elements[1].position = 1.0000
    colorramp_8.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_10 = nw.new_node(Nodes.Mix, input_kwargs={0: group_input_3.outputs["Blend uglyness"], 2: 1.0000})
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': colorramp_8.outputs["Color"], 1: mix_10.outputs["Result"]},
        attrs={'interpolation_type': 'SMOOTHERSTEP'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': absolute_2, 'Y': absolute_4})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': absolute_4, 'Y': absolute_2})
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: map_range_3.outputs["Result"], 4: combine_xyz_3, 5: combine_xyz_4},
        attrs={'data_type': 'VECTOR'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_9.outputs[1]})
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={0: absolute, 4: mix.outputs[1], 5: reroute_2}, attrs={'data_type': 'VECTOR'})
    
    absolute_6 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_2.outputs["Z"], 1: 0.7390}, attrs={'operation': 'ABSOLUTE'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: absolute_6}, attrs={'operation': 'GREATER_THAN'})
    
    greater_than_1 = nw.new_node(Nodes.Math, input_kwargs={0: absolute_5}, attrs={'operation': 'GREATER_THAN'})
    
    mix_3 = nw.new_node(Nodes.Mix, input_kwargs={0: greater_than_1, 4: reroute, 5: reroute_1}, attrs={'data_type': 'VECTOR'})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than, 4: mix_3.outputs[1], 5: reroute_2},
        attrs={'data_type': 'VECTOR'})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input_3.outputs["Normal/Object "], 4: mix_1.outputs[1], 5: mix_2.outputs[1]},
        attrs={'data_type': 'VECTOR'})
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': absolute_6})
    colorramp_5.color_ramp.elements[0].position = 0.4000
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.6000
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': absolute_5})
    colorramp_1.color_ramp.elements[0].position = 0.4000
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.6000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_1.outputs["Color"], 4: reroute, 5: reroute_1},
        attrs={'data_type': 'VECTOR'})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_5.outputs["Color"], 4: mix_7.outputs[1], 5: reroute_2},
        attrs={'data_type': 'VECTOR'})
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input_3.outputs["Blend"], 4: mix_4.outputs[1], 5: mix_6.outputs[1]},
        attrs={'data_type': 'VECTOR'})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: mix_8.outputs[1], 'Scale': group_input_3.outputs["Scale"]},
        attrs={'operation': 'SCALE'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Result': scale_1.outputs["Vector"]}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_add_noise', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_add_noise(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Factor', (1.0000, 1.0000, 1.0000)),
            ('NodeSocketFloat', 'W', 0.0000),
            ('NodeSocketFloat', 'Scale', 2.0000),
            ('NodeSocketFloat', 'Detail', 2.0000),
            ('NodeSocketFloatFactor', 'Roughness', 0.0000),
            ('NodeSocketFloat', 'Distortion', 0.0000)])
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["W"], 'Scale': group_input.outputs["Scale"], 'Detail': group_input.outputs["Detail"], 'Roughness': group_input.outputs["Roughness"], 'Distortion': group_input.outputs["Distortion"]},
        attrs={'noise_dimensions': '4D'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_1.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: group_input.outputs["Factor"]},
        attrs={'operation': 'MULTIPLY'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Vector': multiply.outputs["Vector"]}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_supporting_leaf', singleton=False, type='GeometryNodeTree')
def nodegroup_supporting_leaf(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketInt', 'Resolution V', 16),
            ('NodeSocketIntUnsigned', 'Resolution U', 12),
            ('NodeSocketFloat', 'Roll Over', -2.0000),
            ('NodeSocketFloat', 'Outer Scale', 5.0000),
            ('NodeSocketFloat', 'Scale', 0.2000),
            ('NodeSocketFloatFactor', 'Width', 0.5000),
            ('NodeSocketFloat', 'Leaning', 2.5000),
            ('NodeSocketFloatFactor', 'Factor', 0.2500),
            ('NodeSocketFloat', 'Wrap', 6.2832),
            ('NodeSocketInt', 'Profile', 1),
            ('NodeSocketMaterial', 'Material', None),
            ('NodeSocketString', 'Name', 'uvmap')])
    
    ast_natural_spiral = nw.new_node(nodegroup_a_s_t_natural_spiral().name,
        input_kwargs={'resolution': group_input.outputs["Resolution V"], 'Roll Over': group_input.outputs["Roll Over"], 'Outer Scale': group_input.outputs["Outer Scale"], 'Scale': group_input.outputs["Scale"], 'Factor': group_input.outputs["Width"], 'Leaning': group_input.outputs["Leaning"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': ast_natural_spiral.outputs["Curve"], 2: spline_parameter.outputs["Length"]})
    
    spline_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_3.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.4750), (0.3182, 0.3938), (0.6955, 0.5750), (1.0000, 0.0750)])
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': capture_attribute.outputs["Geometry"], 'Radius': float_curve})
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: group_input.outputs["Factor"], 3: 0.1000})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix.outputs["Result"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000, 1: divide}, attrs={'operation': 'SUBTRACT'})
    
    supporting_leaf_profile = nw.new_node(nodegroup_supporting_leaf_profile().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution U"], 'height': reroute, 'Radius': reroute, 'Profile': group_input.outputs["Profile"], 'Rotation': group_input.outputs["Wrap"], 'End X': subtract})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius_1, 'Profile Curve': supporting_leaf_profile.outputs["Geometry"]})
    
    ast_align_to_3d_plane = nw.new_node(nodegroup_a_s_t_align_to_3_d_plane().name, input_kwargs={'Geometry': curve_to_mesh})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute.outputs[2], 'Y': supporting_leaf_profile.outputs["Length"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ast_align_to_3d_plane, 'Name': group_input.outputs["Name"], 3: combine_xyz},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': store_named_attribute, 'Material': group_input.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': set_material, 'Vector': combine_xyz},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_scale_geometry', singleton=False, type='GeometryNodeTree')
def nodegroup_scale_geometry(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Scale', 1.0000)])
    
    position = nw.new_node(Nodes.InputPosition)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 1: position},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: capture_attribute_1.outputs["Attribute"], 'Scale': group_input.outputs["Scale"]},
        attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Position': scale.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_adjust_instances', singleton=False, type='GeometryNodeTree')
def nodegroup_adjust_instances(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Instances', None),
            ('NodeSocketVectorXYZ', 'Scale', (1.0000, 1.0000, 1.0000)),
            ('NodeSocketVector', 'Rotation', (5.0000, 20.0000, 0.0000)),
            ('NodeSocketVectorTranslation', 'Translation', (0.0000, -0.0020, 0.0000))])
    
    alternative_instances_mirrered_rotation = nw.new_node(nodegroup_alternative_instances_mirrered_rotation().name,
        input_kwargs={'Instances': group_input.outputs["Instances"], 'Rotation': group_input.outputs["Rotation"]})
    
    scale_instances_1 = nw.new_node(Nodes.ScaleInstances,
        input_kwargs={'Instances': alternative_instances_mirrered_rotation, 'Scale': group_input.outputs["Scale"]})
    
    translate_instances = nw.new_node(Nodes.TranslateInstances,
        input_kwargs={'Instances': scale_instances_1, 'Translation': group_input.outputs["Translation"]})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': translate_instances})
    
    separate_components = nw.new_node(Nodes.SeparateComponents, input_kwargs={'Geometry': realize_instances_1})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Mesh': separate_components.outputs["Mesh"], 'Point Cloud': separate_components.outputs["Point Cloud"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_spline_adjustment', singleton=False, type='GeometryNodeTree')
def nodegroup_spline_adjustment(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Points Count', 32),
            ('NodeSocketInt', 'Select type', 3)])
    
    reverse_curve = nw.new_node(Nodes.ReverseCurve, input_kwargs={'Curve': group_input.outputs["Curve"]})
    
    ast_change_spline_type = nw.new_node(nodegroup_a_s_t_change_spline_type().name,
        input_kwargs={'Curve': reverse_curve, 'Select': group_input.outputs["Select type"]})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': ast_change_spline_type, 'Count': group_input.outputs["Points Count"], 'Length': 0.0250})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': resample_curve_2, 2: spline_parameter_1.outputs["Factor"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: spline_parameter_1.outputs["Length"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': capture_attribute_1.outputs["Geometry"], 'Points Count': group_input.outputs["Points Count"], 'Factor': capture_attribute.outputs[2], 'Length': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_skin_curve', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_skin_curve(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Resolution', 32),
            ('NodeSocketFloatDistance', 'Radius', 1.0000),
            ('NodeSocketBool', 'Fill Caps', False),
            ('NodeSocketBool', 'Shade Smooth', True),
            ('NodeSocketString', 'UVMap', 'UVMap'),
            ('NodeSocketFloat', 'Adjust U', 1.0000),
            ('NodeSocketFloat', 'Adjust V', 1.0000)])
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': group_input.outputs["Curve"], 2: spline_parameter.outputs["Length"]})
    
    ast_abhay_s_round_curve_002 = nw.new_node(nodegroup_a_s_t_abhays_round_curve_002().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Radius': group_input.outputs["Radius"]})
    
    ast_re_curve = nw.new_node(nodegroup_a_s_t_recurve().name, input_kwargs={'Curve': ast_abhay_s_round_curve_002.outputs["Curve"]})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input.outputs["Fill Caps"], 14: ast_abhay_s_round_curve_002.outputs["Curve"], 15: ast_re_curve})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute.outputs["Geometry"], 'Profile Curve': switch.outputs[6], 'Fill Caps': group_input.outputs["Fill Caps"]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth,
        input_kwargs={'Geometry': curve_to_mesh_1, 'Shade Smooth': group_input.outputs["Shade Smooth"]})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: capture_attribute.outputs[2], 1: group_input.outputs["Adjust U"]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: ast_abhay_s_round_curve_002.outputs["Length"], 1: group_input.outputs["Adjust V"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply, 'Y': multiply_1})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': set_shade_smooth, 'Name': group_input.outputs["UVMap"], 3: combine_xyz},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': store_named_attribute})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Mesh': merge_by_distance, 'UV': combine_xyz},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_random_vecter_3_seeds', singleton=False, type='GeometryNodeTree')
def nodegroup_random_vecter_3_seeds(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Min', (-75.0000, 135.0000, -80.0000)),
            ('NodeSocketVector', 'Max', (-105.0000, 225.0000, -100.0000)),
            ('NodeSocketInt', 'Seed', 4),
            ('NodeSocketInt', 'Seed1', 3),
            ('NodeSocketInt', 'Seed2', 4),
            ('NodeSocketInt', 'ID', 0)])
    
    min = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input.outputs["Min"]}, label='min')
    
    max = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input.outputs["Max"]}, label='max')
    
    less_equal = nw.new_node(Nodes.Compare,
        input_kwargs={2: group_input.outputs["ID"]},
        attrs={'operation': 'LESS_EQUAL', 'data_type': 'INT'})
    
    index = nw.new_node(Nodes.Index)
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: less_equal, 4: group_input.outputs["ID"], 5: index},
        attrs={'input_type': 'INT'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: min.outputs["X"], 3: max.outputs["X"], 'ID': switch.outputs[1], 'Seed': group_input.outputs["Seed"]})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: min.outputs["Y"], 3: max.outputs["Y"], 'ID': switch.outputs[1], 'Seed': group_input.outputs["Seed1"]})
    
    random_value_2 = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: min.outputs["Z"], 3: max.outputs["Z"], 'ID': switch.outputs[1], 'Seed': group_input.outputs["Seed2"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': random_value_1.outputs[1], 'Y': random_value.outputs[1], 'Z': random_value_2.outputs[1]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Vector': combine_xyz}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_scale_instances', singleton=False, type='GeometryNodeTree')
def nodegroup_scale_instances(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Exponent', 1.0000),
            ('NodeSocketFloat', 'To Min', 0.5000),
            ('NodeSocketFloat', 'To Max', 1.0000)])
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': spline_parameter_1.outputs["Factor"], 1: 1.0000, 2: 0.0000, 3: group_input.outputs["To Min"], 4: group_input.outputs["To Max"]})
    
    power = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range.outputs["Result"], 1: group_input.outputs["Exponent"]},
        attrs={'operation': 'POWER'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': power}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_base_stem_curve', singleton=False, type='GeometryNodeTree')
def nodegroup_base_stem_curve(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketFloat', 'SEED', 0.0000),
            ('NodeSocketFloat', 'Scale', 0.1000),
            ('NodeSocketFloat', 'Noise Scale', 2.0000)])
    
    resample_curve = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': group_input.outputs["Curve"], 'Length': 0.0500},
        attrs={'mode': 'LENGTH'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["SEED"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Noise Scale"]})
    
    ast_add_noise = nw.new_node(nodegroup_a_s_t_add_noise().name,
        input_kwargs={'Factor': spline_parameter.outputs["Factor"], 'W': reroute_4, 'Scale': reroute_3})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Scale"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: ast_add_noise, 'Scale': reroute}, attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': resample_curve, 'Offset': scale.outputs["Vector"]})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_position, 2: spline_parameter_1.outputs["Factor"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: spline_parameter_1.outputs["Length"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Factor': capture_attribute.outputs[2], 'Length': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_curve_adjustment_2', singleton=False, type='GeometryNodeTree')
def nodegroup_curve_adjustment_2(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketFloatFactor', 'Start', 0.3500),
            ('NodeSocketFloatFactor', 'End', 1.0000),
            ('NodeSocketInt', 'Points Count', 10)])
    
    trim_curve = nw.new_node(Nodes.TrimCurve,
        input_kwargs={'Curve': group_input.outputs["Curve"], 2: group_input.outputs["Start"], 3: group_input.outputs["End"]})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': trim_curve, 'Count': group_input.outputs["Points Count"]})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': resample_curve_1, 2: spline_parameter_1.outputs["Factor"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: spline_parameter_1.outputs["Length"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': capture_attribute_1.outputs["Geometry"], 'Points Count': group_input.outputs["Points Count"], 'Factor': capture_attribute.outputs[2], 'Length': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_adjust_instance_0', singleton=False, type='GeometryNodeTree')
def nodegroup_adjust_instance_0(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Instances', None),
            ('NodeSocketVector', 'Rotation', (5.0000, 20.0000, 0.0000)),
            ('NodeSocketFloat', 'Value', 0.5000)])
    
    alternative_instances_mirrered_rotation = nw.new_node(nodegroup_alternative_instances_mirrered_rotation().name,
        input_kwargs={'Instances': group_input.outputs["Instances"], 'Rotation': group_input.outputs["Rotation"]})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Value"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances,
        input_kwargs={'Instances': alternative_instances_mirrered_rotation, 'Scale': divide})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': scale_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_realise_geometry', singleton=False, type='GeometryNodeTree')
def nodegroup_realise_geometry(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketBool', 'Switch', False)])
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': group_input.outputs["Geometry"]})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input.outputs["Switch"], 14: group_input.outputs["Geometry"], 15: realize_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Output': switch.outputs[6]}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_store_edge_angle', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_store_edge_angle(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketString', 'Unsigned', 'Unsigned'),
            ('NodeSocketString', 'Signed', 'Signed')])
    
    edge_angle = nw.new_node(Nodes.InputEdgeAngle)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 2: edge_angle.outputs["Unsigned Angle"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: edge_angle.outputs["Signed Angle"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Name': group_input.outputs["Unsigned"], 4: capture_attribute.outputs[2]})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': store_named_attribute, 'Name': group_input.outputs["Signed"], 4: capture_attribute_1.outputs[2]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': store_named_attribute_1, 'Unsigned': capture_attribute.outputs[2], 'Signed': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_store_bounding_distance_001', singleton=False, type='GeometryNodeTree')
def nodegroup_store_bounding_distance_001(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketString', 'Name', 'bound distances')])
    
    bound_box_001 = nw.new_node(nodegroup_bound_box_001().name, input_kwargs={'Geometry': group_input.outputs["Geometry"]})
    
    distance = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bound_box_001.outputs["A (min)"], 1: bound_box_001.outputs["B"]},
        attrs={'operation': 'DISTANCE'})
    
    distance_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bound_box_001.outputs["A (min)"], 1: bound_box_001.outputs["D"]},
        attrs={'operation': 'DISTANCE'})
    
    distance_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bound_box_001.outputs["A (min)"], 1: bound_box_001.outputs["A'"]},
        attrs={'operation': 'DISTANCE'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': distance.outputs["Value"], 'Y': distance_1.outputs["Value"], 'Z': distance_2.outputs["Value"]})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Name': group_input.outputs["Name"], 3: combine_xyz_1},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': store_named_attribute_1}, attrs={'is_active_output': True})

def shader_budding_leaves(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    light_path = nw.new_node(Nodes.LightPath)
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'bl_uvmap'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: attribute.outputs["Vector"], 1: (1.0000, 3.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': multiply.outputs["Vector"]})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': separate_xyz.outputs["X"]})
    colorramp_2.color_ramp.interpolation = "CARDINAL"
    colorramp_2.color_ramp.elements.new(0)
    colorramp_2.color_ramp.elements[0].position = 0.0000
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.2955
    colorramp_2.color_ramp.elements[1].color = [0.5000, 0.5000, 0.5000, 1.0000]
    colorramp_2.color_ramp.elements[2].position = 1.0000
    colorramp_2.color_ramp.elements[2].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'Unsigned'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute_1.outputs["Color"]})
    colorramp.color_ramp.elements[0].position = 0.1818
    colorramp.color_ramp.elements[0].color = [0.3800, 0.3800, 0.3800, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.3273
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: colorramp_2.outputs["Color"], 1: colorramp.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    fresnel = nw.new_node(Nodes.Fresnel)
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': fresnel})
    colorramp_1.color_ramp.elements[0].position = 0.0273
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: multiply_1, 1: colorramp_1.outputs["Color"]})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (0.5000, 10.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 50.0000, 'Detail': 4.0000, 'Roughness': 1.0000})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0250, 6: multiply_2.outputs["Vector"], 7: noise_texture.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 100.0000, 'Randomness': 0.5750},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 25.0000, 'Randomness': 0.5750},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture.outputs["Distance"], 1: voronoi_texture_1.outputs["Distance"]},
        attrs={'operation': 'MULTIPLY'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: multiply_3})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add_1})
    colorramp_3.color_ramp.interpolation = "EASE"
    colorramp_3.color_ramp.elements[0].position = 0.0750
    colorramp_3.color_ramp.elements[0].color = [0.0097, 0.0500, 0.0075, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 0.5000
    colorramp_3.color_ramp.elements[1].color = [1.0000, 0.9551, 0.4402, 1.0000]
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': separate_xyz.outputs["X"]})
    colorramp_5.color_ramp.elements[0].position = 0.0000
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.5000
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_3, 1: colorramp_5.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply_4})
    colorramp_4.color_ramp.elements[0].position = 0.0227
    colorramp_4.color_ramp.elements[0].color = [0.2500, 0.2500, 0.2500, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.0455
    colorramp_4.color_ramp.elements[1].color = [0.6038, 0.6038, 0.6038, 1.0000]
    
    invert_1 = nw.new_node(Nodes.Invert, input_kwargs={'Color': colorramp_4.outputs["Color"]})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_4, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2500, 'Height': multiply_5}, attrs={'invert': True})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp_3.outputs["Color"], 'Subsurface Radius': (1.0000, 1.0000, 0.7500), 'Specular': invert_1, 'Roughness': colorramp_4.outputs["Color"], 'Transmission': multiply_5, 'Normal': bump})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': colorramp_3.outputs["Color"]})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader,
        input_kwargs={'Fac': light_path.outputs["Is Transmission Ray"], 1: principled_bsdf, 2: translucent_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_1}, attrs={'is_active_output': True})

def shader_receptacle_joint(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    fresnel = nw.new_node(Nodes.Fresnel)
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 10.0000, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': noise_texture_1.outputs["Color"], 'Scale': 10.0000, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    group = nw.new_node(nodegroup_triplanner_projection_mapping().name,
        input_kwargs={'Position/Object': 1.0000, 'Scale': 25.0000, 'Normal/Object ': 0.5441, 'Blend': 0.8162, 'Blend uglyness': 0.1618})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={6: group, 7: noise_texture_1.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 2.5000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_1.outputs["Distance"]})
    colorramp_3.color_ramp.elements[0].position = 0.0000
    colorramp_3.color_ramp.elements[0].color = [0.1706, 0.1706, 0.1706, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 1.0000
    colorramp_3.color_ramp.elements[1].color = [0.5225, 0.5225, 0.5225, 1.0000]
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: noise_texture_2.outputs["Fac"], 1: colorramp_3.outputs["Color"]},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply})
    colorramp_4.color_ramp.elements[0].position = 0.1000
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.1818
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: colorramp_4.outputs["Color"], 1: 0.1000},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: fresnel, 1: multiply_1})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0015, 0.0250, 0.0022, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.6537, 0.9124, 0.1065, 1.0000]
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Scale': 100.0000}, attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_1.color_ramp.interpolation = "EASE"
    colorramp_1.color_ramp.elements[0].position = 0.2455
    colorramp_1.color_ramp.elements[0].color = [0.3464, 0.3464, 0.3464, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.7409
    colorramp_1.color_ramp.elements[1].color = [0.7170, 0.7170, 0.7170, 1.0000]
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Color': colorramp_1.outputs["Color"]})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply})
    colorramp_2.color_ramp.elements[0].position = 0.0500
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.8273
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2000, 'Height': colorramp_1.outputs["Color"]})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.0500, 'Height': colorramp_2.outputs["Color"], 'Normal': bump})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp.outputs["Color"], 'Specular': invert, 'Roughness': colorramp_1.outputs["Color"], 'Normal': bump_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf_1}, attrs={'is_active_output': True})

def shader_receptacle_stem(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'receptacle_uvmap'})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': attribute_1.outputs["Vector"]})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': separate_xyz_1.outputs["X"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.2818, 0.1750), (0.5000, 1.0000)])
    
    fresnel = nw.new_node(Nodes.Fresnel)
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: float_curve, 1: fresnel}, attrs={'use_clamp': True})
    
    group = nw.new_node(nodegroup_triplanner_projection_mapping().name,
        input_kwargs={'Position/Object': 1.0000, 'Scale': 25.0000, 'Blend uglyness': 0.1618})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': group, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': noise_texture_1.outputs["Color"], 'Detail': 3.0000, 'Roughness': 1.0000})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={6: group, 7: noise_texture_1.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 2.5000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_1.outputs["Distance"]})
    colorramp_3.color_ramp.elements[0].position = 0.0000
    colorramp_3.color_ramp.elements[0].color = [0.1706, 0.1706, 0.1706, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 1.0000
    colorramp_3.color_ramp.elements[1].color = [0.5225, 0.5225, 0.5225, 1.0000]
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: noise_texture_2.outputs["Fac"], 1: colorramp_3.outputs["Color"]},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply})
    colorramp_4.color_ramp.elements[0].position = 0.0909
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.1818
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: colorramp_4.outputs["Color"], 1: 0.1000},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: multiply_1})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add_1})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0013, 0.0250, 0.0019, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.4109, 0.5390, 0.1383, 1.0000]
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': attribute_1.outputs["Vector"], 'Scale': 100.0000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_1.color_ramp.interpolation = "EASE"
    colorramp_1.color_ramp.elements[0].position = 0.1409
    colorramp_1.color_ramp.elements[0].color = [0.3464, 0.3464, 0.3464, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.7409
    colorramp_1.color_ramp.elements[1].color = [0.7170, 0.7170, 0.7170, 1.0000]
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Color': colorramp_1.outputs["Color"]})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply})
    colorramp_2.color_ramp.elements[0].position = 0.0500
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.8273
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2000, 'Height': colorramp_1.outputs["Color"]})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.0500, 'Height': colorramp_2.outputs["Color"], 'Normal': bump})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp.outputs["Color"], 'Specular': invert, 'Roughness': colorramp_1.outputs["Color"], 'Normal': bump_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf_1}, attrs={'is_active_output': True})

def shader_stem(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'stem_uvmap'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': attribute.outputs["Vector"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: 1.0000, 1: separate_xyz.outputs["X"]}, attrs={'operation': 'SUBTRACT'})
    
    power = nw.new_node(Nodes.Math, input_kwargs={0: subtract, 1: 25.0000}, attrs={'operation': 'POWER'})
    
    fresnel = nw.new_node(Nodes.Fresnel)
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: power, 1: fresnel}, attrs={'use_clamp': True})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 10.0000, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': noise_texture_1.outputs["Color"], 'Scale': 10.0000, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    group = nw.new_node(nodegroup_triplanner_projection_mapping().name,
        input_kwargs={'Position/Object': 1.0000, 'Scale': 25.0000, 'Normal/Object ': 0.5441, 'Blend': 0.8162, 'Blend uglyness': 0.1618})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={6: group, 7: noise_texture_1.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 2.5000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_1.outputs["Distance"]})
    colorramp_3.color_ramp.elements[0].position = 0.0000
    colorramp_3.color_ramp.elements[0].color = [0.1706, 0.1706, 0.1706, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 1.0000
    colorramp_3.color_ramp.elements[1].color = [0.5225, 0.5225, 0.5225, 1.0000]
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: noise_texture_2.outputs["Fac"], 1: colorramp_3.outputs["Color"]},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply})
    colorramp_4.color_ramp.elements[0].position = 0.1000
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.1818
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: colorramp_4.outputs["Color"], 1: 0.1000},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: multiply_1})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add_1})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0013, 0.0250, 0.0019, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.6688, 0.9000, 0.1800, 1.0000]
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': attribute.outputs["Vector"], 'Scale': 100.0000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_1.color_ramp.interpolation = "EASE"
    colorramp_1.color_ramp.elements[0].position = 0.2455
    colorramp_1.color_ramp.elements[0].color = [0.3464, 0.3464, 0.3464, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.7409
    colorramp_1.color_ramp.elements[1].color = [0.7170, 0.7170, 0.7170, 1.0000]
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Color': colorramp_1.outputs["Color"]})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': multiply})
    colorramp_2.color_ramp.elements[0].position = 0.0500
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.8273
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2000, 'Height': colorramp_1.outputs["Color"]})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.0500, 'Height': colorramp_2.outputs["Color"], 'Normal': bump})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp.outputs["Color"], 'Specular': invert, 'Roughness': colorramp_1.outputs["Color"], 'Normal': bump_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_pollen_tube(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    light_path = nw.new_node(Nodes.LightPath)
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UVMap'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': attribute.outputs["Color"]})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': separate_xyz.outputs["X"], 1: 0.5000})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'Unsigned'})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute_1.outputs["Fac"]})
    colorramp_2.color_ramp.elements[0].position = 0.1273
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.3182
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range.outputs["Result"], 1: colorramp_2.outputs["Color"]},
        attrs={'operation': 'MULTIPLY', 'use_clamp': True})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': attribute.outputs["Vector"], 'Scale': 100.0000, 'Detail': 4.0000, 'Roughness': 1.0000, 'Distortion': 0.1000})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    colorramp_1.color_ramp.elements[0].position = 0.4636
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.6182
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: colorramp_1.outputs["Color"]})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.1682, 0.2637, 0.0114, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.1636
    colorramp.color_ramp.elements[1].color = [0.8000, 0.6643, 0.6000, 1.0000]
    colorramp.color_ramp.elements[2].position = 0.8545
    colorramp.color_ramp.elements[2].color = [0.8500, 0.8137, 0.5961, 1.0000]
    
    group = nw.new_node(nodegroup_triplanner_projection_mapping().name,
        input_kwargs={'Scale': 10.0000, 'Blend uglyness': 0.1333})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': group, 'Scale': 500.0000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture.outputs["Distance"], 1: 0.0025},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': attribute.outputs["Vector"], 'Scale': 100.0000})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': noise_texture.outputs["Fac"]})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_3.color_ramp.elements[0].position = 0.0000
    colorramp_3.color_ramp.elements[0].color = [0.5902, 0.5902, 0.5902, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 0.5091
    colorramp_3.color_ramp.elements[1].color = [0.0133, 0.0133, 0.0133, 1.0000]
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp.outputs["Color"], 'Subsurface': multiply_1, 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Subsurface Color': (0.8000, 0.5524, 0.2653, 1.0000), 'Specular': reroute, 'Roughness': reroute, 'Sheen': colorramp_3.outputs["Color"]})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF)
    
    mix_shader = nw.new_node(Nodes.MixShader,
        input_kwargs={'Fac': light_path.outputs["Is Transmission Ray"], 1: principled_bsdf, 2: translucent_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def shader_pollen_leaf(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'pollen_leaf_map'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': attribute_1.outputs["Vector"]})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': separate_xyz.outputs["Y"]})
    colorramp_1.color_ramp.elements[0].position = 0.2500
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.4000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'pollen_leaf_arc'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    colorramp.color_ramp.interpolation = "B_SPLINE"
    colorramp.color_ramp.elements[0].position = 0.7864
    colorramp.color_ramp.elements[0].color = [0.0062, 0.1606, 0.0052, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.6519, 1.0000, 0.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_1.outputs["Color"], 6: colorramp.outputs["Color"], 7: (1.0000, 0.1000, 0.3472, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': attribute_1.outputs["Vector"], 'Scale': 100.0000})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp_2.color_ramp.elements[0].position = 0.6000
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.7500
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: noise_texture.outputs["Fac"], 1: colorramp_2.outputs["Color"]},
        attrs={'operation': 'SUBTRACT'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Subsurface': 0.0100, 'Metallic': colorramp_2.outputs["Color"], 'Specular': noise_texture.outputs["Fac"], 'Roughness': subtract})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_may_lily_flower_petals(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'Unsigned'})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute_1.outputs["Color"]})
    colorramp_2.color_ramp.elements[0].position = 0.0000
    colorramp_2.color_ramp.elements[0].color = [0.6868, 0.7500, 0.5625, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.6773
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    group = nw.new_node(nodegroup_triplanner_projection_mapping().name,
        input_kwargs={'Position/Object': 1.0000, 'Scale': 25.0000, 'Blend': 0.0000, 'Blend uglyness': 0.0000})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 50.0000, 'Detail': 5.0000, 'Roughness': 1.0000})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.2000, 6: group, 7: noise_texture_1.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 10.0000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture.outputs["Distance"], 1: 0.0050},
        attrs={'operation': 'MULTIPLY'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_4.color_ramp.elements[0].position = 0.0000
    colorramp_4.color_ramp.elements[0].color = [0.2500, 0.2500, 0.2500, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 1.0000
    colorramp_4.color_ramp.elements[1].color = [0.7500, 0.7500, 0.7500, 1.0000]
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': noise_texture_1.outputs["Color"], 'Scale': 10.0000, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp_2.outputs["Color"], 'Subsurface': multiply, 'Subsurface Radius': (1.0000, 1.0000, 0.8000), 'Specular': colorramp_4.outputs["Color"], 'Roughness': noise_texture_2.outputs["Fac"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf_1}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketBool', 'Realise', False),
            ('NodeSocketString', '_1', 'stem controls'),
            ('NodeSocketInt', 'Resolusion V', 32),
            ('NodeSocketInt', 'Resolution U', 6),
            ('NodeSocketFloatDistance', 'Radius', 0.0100),
            ('NodeSocketString', 'UVMap', 'stem_uvmap'),
            ('NodeSocketFloat', 'Randomise', 0.0000),
            ('NodeSocketFloat', 'Noise Scale', 2.0000),
            ('NodeSocketFloat', 'Noise factor', 0.1000),
            ('NodeSocketMaterial', 'Material', None),
            ('NodeSocketString', '_2', 'flower controls'),
            ('NodeSocketInt', 'Flower Count', 10),
            ('NodeSocketFloat', 'Flower Scale', 1.0000),
            ('NodeSocketFloat', 'Scale Exponent', 1.0000),
            ('NodeSocketFloatFactor', 'Start', 0.3500),
            ('NodeSocketFloatFactor', 'End', 1.0000),
            ('NodeSocketVector', 'Rotation', (5.0000, 20.0000, 0.0000)),
            ('NodeSocketVector', 'Rotation Min', (-75.0000, 135.0000, -80.0000)),
            ('NodeSocketVector', 'Rotation Max', (-105.0000, 225.0000, -100.0000)),
            ('NodeSocketString', '_3', 'supporting leaves'),
            ('NodeSocketFloat', 'Scale', 0.1500),
            ('NodeSocketFloat', 'align rotation', 30.0000),
            ('NodeSocketInt', 'Resolution V_1', 16),
            ('NodeSocketIntUnsigned', 'Resolution U_1', 12),
            ('NodeSocketFloat', 'Roll Over', -2.0000),
            ('NodeSocketFloat', 'Outer Scale', 5.0000),
            ('NodeSocketFloat', 'Scale_1', 0.2000),
            ('NodeSocketFloatFactor', 'Width', 0.5000),
            ('NodeSocketFloat', 'Leaning', 2.5000),
            ('NodeSocketFloatFactor', 'Factor', 0.2500),
            ('NodeSocketFloat', 'Wrap', 6.2832),
            ('NodeSocketInt', 'Profile', 1),
            ('NodeSocketMaterial', 'Material_1', None),
            ('NodeSocketString', 'SEEDS', 'SEEDS'),
            ('NodeSocketInt', 'Seed', 4),
            ('NodeSocketInt', 'Seed_1', 3),
            ('NodeSocketInt', 'Seed_2', 4)])
    
    base_stem_curve = nw.new_node(nodegroup_base_stem_curve().name,
        input_kwargs={'Curve': group_input.outputs["Geometry"], 'SEED': group_input.outputs["Randomise"], 'Scale': group_input.outputs["Noise factor"], 'Noise Scale': group_input.outputs["Noise Scale"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': base_stem_curve.outputs["Geometry"]})
    
    curve_adjustment_2 = nw.new_node(nodegroup_curve_adjustment_2().name,
        input_kwargs={'Curve': reroute_4, 'Start': group_input.outputs["Start"], 'End': group_input.outputs["End"], 'Points Count': group_input.outputs["Flower Count"]})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_adjustment_2.outputs["Curve"]})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    op_not = nw.new_node(Nodes.BooleanMath, input_kwargs={0: endpoint_selection}, attrs={'operation': 'NOT'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': op_not})
    
    collection_info = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': bpy.data.collections['flower generations'], 'Separate Children': True, 'Reset Children': True})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    scale_instances = nw.new_node(nodegroup_scale_instances().name, input_kwargs={'Exponent': group_input.outputs["Scale Exponent"]})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': scale_instances})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_13, 'Selection': reroute_3, 'Instance': collection_info, 'Pick Instance': True, 'Rotation': reroute_16, 'Scale': reroute_17})
    
    random_vecter_3_seeds = nw.new_node(nodegroup_random_vecter_3_seeds().name,
        input_kwargs={'Min': group_input.outputs["Rotation Min"], 'Max': group_input.outputs["Rotation Max"], 'Seed': group_input.outputs["Seed"], 'Seed1': group_input.outputs["Seed_1"], 'Seed2': group_input.outputs["Seed_2"]})
    
    radians_to_degree = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: random_vecter_3_seeds, 1: (57.2958, 57.2958, 57.2958)},
        label='Radians to Degree',
        attrs={'operation': 'DIVIDE'})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points, 'Rotation': radians_to_degree.outputs["Vector"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Rotation"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Flower Scale"]})
    
    adjust_instance_0 = nw.new_node(nodegroup_adjust_instance_0().name,
        input_kwargs={'Instances': rotate_instances, 'Rotation': reroute_1, 'Value': reroute_2})
    
    spline_adjustment = nw.new_node(nodegroup_spline_adjustment().name,
        input_kwargs={'Curve': reroute_4, 'Points Count': group_input.outputs["Resolusion V"]})
    
    power = nw.new_node(Nodes.Math, input_kwargs={0: spline_adjustment.outputs["Length"]}, attrs={'operation': 'POWER'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': power, 4: 0.7500})
    
    modulo = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_adjustment.outputs["Factor"], 1: 0.0475},
        attrs={'operation': 'MODULO'})
    
    modulo_1 = nw.new_node(Nodes.Math, input_kwargs={0: modulo, 1: 0.0200}, attrs={'operation': 'MODULO', 'use_clamp': True})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': spline_adjustment.outputs["Factor"]})
    
    snap = nw.new_node(Nodes.Math, input_kwargs={0: reroute_12, 1: 0.6650}, attrs={'operation': 'SNAP'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: modulo_1, 1: snap}, attrs={'operation': 'SUBTRACT', 'use_clamp': True})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: subtract, 1: 3.0000}, attrs={'operation': 'MULTIPLY'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"], 1: multiply})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': spline_adjustment.outputs["Curve"], 'Radius': add})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Resolution U"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Radius"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_11})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["UVMap"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_10})
    
    ast_skin_curve = nw.new_node(nodegroup_a_s_t_skin_curve().name,
        input_kwargs={'Curve': set_curve_radius, 'Resolution': reroute_5, 'Radius': reroute_8, 'UVMap': reroute_7})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Material"]})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': ast_skin_curve.outputs["Mesh"], 'Material': reroute_6})
    
    flip_faces = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': set_material})
    
    supporting_leaf = nw.new_node(nodegroup_supporting_leaf().name,
        input_kwargs={'Resolution V': group_input.outputs["Resolution V_1"], 'Resolution U': group_input.outputs["Resolution U_1"], 'Roll Over': group_input.outputs["Roll Over"], 'Outer Scale': group_input.outputs["Outer Scale"], 'Scale': group_input.outputs["Scale_1"], 'Width': group_input.outputs["Width"], 'Leaning': group_input.outputs["Leaning"], 'Factor': group_input.outputs["Factor"], 'Wrap': group_input.outputs["Wrap"], 'Profile': group_input.outputs["Profile"], 'Material': group_input.outputs["Material_1"], 'Name': 'bl_uvmap'})
    
    points = nw.new_node('GeometryNodePoints', input_kwargs={'Radius': 0.0100})
    
    curve_circle = nw.new_node(Nodes.CurveCircle)
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [supporting_leaf.outputs["Geometry"], points, curve_circle.outputs["Curve"]]})
    
    scale_geometry = nw.new_node(nodegroup_scale_geometry().name,
        input_kwargs={'Geometry': join_geometry_1, 'Scale': group_input.outputs["Scale"]})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_13, 'Selection': reroute_3, 'Instance': scale_geometry, 'Rotation': reroute_15, 'Scale': reroute_14})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_1, 'Rotation': radians_to_degree.outputs["Vector"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input.outputs["align rotation"]})
    
    subtract_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_1, 1: combine_xyz}, attrs={'operation': 'SUBTRACT'})
    
    adjust_instances = nw.new_node(nodegroup_adjust_instances().name,
        input_kwargs={'Instances': rotate_instances_1, 'Scale': reroute_2, 'Rotation': subtract_1.outputs["Vector"]})
    
    flip_faces_1 = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': adjust_instances.outputs["Mesh"]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': flip_faces_1})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': supporting_leaf.outputs["Vector"]})
    
    ast_add_noise = nw.new_node(nodegroup_a_s_t_add_noise().name,
        input_kwargs={'Factor': separate_xyz.outputs["X"], 'Scale': 100.0000, 'Detail': 3.0000, 'Roughness': 1.0000})
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: ast_add_noise, 'Scale': 0.0100}, attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': realize_instances, 'Offset': scale.outputs["Vector"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [adjust_instance_0, flip_faces, set_position]})
    
    realise_geometry = nw.new_node(nodegroup_realise_geometry().name,
        input_kwargs={'Geometry': join_geometry, 'Switch': group_input.outputs["Realise"]})
    
    ast_store_edge_angle = nw.new_node(nodegroup_a_s_t_store_edge_angle().name, input_kwargs={'Geometry': realise_geometry})
    
    store_bounding_distance_001 = nw.new_node(nodegroup_store_bounding_distance_001().name,
        input_kwargs={'Geometry': ast_store_edge_angle.outputs["Geometry"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': store_bounding_distance_001},
        attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_may_lily_flower_petals, selection=selection)
    surface.add_material(obj, shader_pollen_leaf, selection=selection)
    surface.add_material(obj, shader_pollen_tube, selection=selection)
    surface.add_material(obj, shader_stem, selection=selection)
    surface.add_material(obj, shader_receptacle_stem, selection=selection)
    surface.add_material(obj, shader_receptacle_joint, selection=selection)
    surface.add_material(obj, shader_budding_leaves, selection=selection)

