import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate.outputs["Normal"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mapping, 'Scale': 5.2000})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [0.2708, 0.5171, 0.1485, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [0.3808, 0.4820, 0.2194, 1.0000]
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Color"]})
    colorramp.color_ramp.elements[0].position = 0.3682
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.7909
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.6000, 6: colorramp.outputs["Color"], 7: texture_coordinate.outputs["Normal"]},
        attrs={'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Normal': mix.outputs[2]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp_1.outputs["Color"], 'Subsurface Color': (0.0071, 0.0671, 0.0058, 1.0000), 'Normal': bump},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS'})
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Hue': 0.4000, 'Color': colorramp_1.outputs["Color"]})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': hue_saturation_value})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': 0.7333, 1: principled_bsdf, 2: translucent_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Start': (0.0000, 0.0000, 0.0000), 'Middle': (0.0000, 0.0000, 0.5000), 'End': (0.0000, 0.0000, 1.0000)})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 0.7000})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: spline_parameter.outputs["Factor"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': quadratic_bezier, 'Offset': multiply.outputs["Vector"]})
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloatFactor', 'End', 1.0000),
            ('NodeSocketInt', 'Seed', 215)])
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': set_position, 3: group_input.outputs["End"]})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_1.outputs["Factor"], 1: 1.2500, 2: 0.0000})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': trim_curve, 'Radius': map_range.outputs["Result"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_curve_radius, 'Count': 24})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={'Probability': 0.3083, 'Seed': group_input.outputs["Seed"]},
        attrs={'data_type': 'BOOLEAN'})
    
    object_info = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': bpy.data.objects['Leaf']})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': object_info.outputs["Rotation"], 'Vector': curve_tangent},
        attrs={'axis': 'Y'})
    
    spline_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    power = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_parameter_2.outputs["Factor"], 1: 2.2000},
        attrs={'operation': 'POWER'})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: power, 1: group_input.outputs["End"]}, attrs={'operation': 'MULTIPLY'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': resample_curve, 'Selection': random_value.outputs[3], 'Instance': object_info.outputs["Geometry"], 'Rotation': align_euler_to_vector, 'Scale': multiply_1})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["End"], 3: -1.2700, 4: -0.3200})
    
    index = nw.new_node(Nodes.Index)
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 2.2000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': map_range_1.outputs["Result"], 'Y': multiply_2})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': instance_on_points, 'Rotation': combine_xyz})
    
    instances_to_points = nw.new_node('GeometryNodeInstancesToPoints', input_kwargs={'Instances': rotate_instances})
    
    points_to_volume_1 = nw.new_node(Nodes.PointsToVolume,
        input_kwargs={'Points': instances_to_points, 'Density': 25.5000, 'Voxel Amount': 134.9600, 'Radius': 0.0150})
    
    volume_to_mesh_1 = nw.new_node(Nodes.VolumeToMesh, input_kwargs={'Volume': points_to_volume_1})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 12, 'Radius': 0.0200})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [volume_to_mesh_1, curve_to_mesh]})
    
    mesh_to_volume = nw.new_node('GeometryNodeMeshToVolume',
        input_kwargs={'Mesh': join_geometry_1, 'Density': 71.9000, 'Voxel Amount': 487.3399, 'Exterior Band Width': 0.0000, 'Interior Band Width': 0.0000})
    
    volume_to_mesh_2 = nw.new_node(Nodes.VolumeToMesh,
        input_kwargs={'Volume': mesh_to_volume, 'Voxel Size': 0.0100, 'Voxel Amount': 500.0000, 'Threshold': 0.0900, 'Adaptivity': 1.0000})
    
    subdivision_surface = nw.new_node(Nodes.SubdivisionSurface, input_kwargs={'Mesh': volume_to_mesh_2})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': subdivision_surface})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_material)})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material, rotate_instances]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_material, selection=selection)
apply(bpy.context.active_object)