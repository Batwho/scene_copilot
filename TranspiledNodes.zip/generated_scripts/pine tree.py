import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_node_group', singleton=False, type='GeometryNodeTree')
def nodegroup_node_group(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    curve_tangent_2 = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector_4 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent_2})
    
    align_euler_to_vector_5 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector_4, 'Vector': (0.0000, 0.0000, -1.0000)},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': align_euler_to_vector_5})
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Value', 1.0000),
            ('NodeSocketInt', 'ID', 0)])
    
    random_value_5 = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: -0.5000, 3: 1.2400, 4: -9, 'Probability': 0.5275, 'ID': group_input.outputs["ID"], 'Seed': 31})
    
    multiply_add = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz_1.outputs["X"], 1: random_value_5.outputs[1], 2: -1.0000},
        attrs={'operation': 'MULTIPLY_ADD'})
    
    map_range_9 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["Value"], 3: -0.1000}, attrs={'clamp': False})
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz_1.outputs["Y"], 1: map_range_9.outputs["Result"], 2: 0.0000},
        attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_add, 'Y': subtract, 'Z': separate_xyz_1.outputs["Z"]})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_3})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Output': reroute_39}, attrs={'is_active_output': True})

def shader_pine_tree_01_dead_branches(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UVMap'})
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': attribute_1.outputs["Vector"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mapping})
    
    base_color = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Base Color',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_diff.jpg']
    
    roughness = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Roughness',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_rough.jpg']
    
    normal = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Normal',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_nor_gl.jpg']
    
    normal_map = nw.new_node(Nodes.ShaderNodeNormalMap, input_kwargs={'Color': normal.outputs["Color"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': base_color.outputs["Color"], 'Specular': 0.0200, 'Roughness': roughness.outputs["Color"], 'Normal': normal_map})
    
    displacement = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Displacement',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_disp.jpg']
    
    displacement_1 = nw.new_node(Nodes.Displacement, input_kwargs={'Height': displacement.outputs["Color"], 'Scale': 0.1000})
    
    material_output = nw.new_node(Nodes.MaterialOutput,
        input_kwargs={'Surface': principled_bsdf, 'Displacement': displacement_1},
        attrs={'is_active_output': True})

def shader_pine_tree_01_twig(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UVMap'})
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': attribute.outputs["Vector"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mapping})
    
    base_color = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Base Color',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_twig_diff.jpg']
    
    roughness = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Roughness',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_twig_rough.jpg']
    
    alpha = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Alpha',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_twig_alpha.jpg']
    
    normal = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Normal',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_twig_nor_gl.jpg']
    
    normal_map = nw.new_node(Nodes.ShaderNodeNormalMap, input_kwargs={'Color': normal.outputs["Color"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': base_color.outputs["Color"], 'Specular': 0.0100, 'Roughness': roughness.outputs["Color"], 'Alpha': alpha.outputs["Color"], 'Normal': normal_map})
    
    alpha_1 = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Alpha',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_twig_mask.jpg']
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: alpha_1.outputs["Color"], 1: 0.8000}, attrs={'operation': 'MULTIPLY'})
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Color': multiply})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: invert, 6: base_color.outputs["Color"], 7: (0.0000, 0.0000, 0.0000, 1.0000)},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': mix.outputs[2], 'Normal': normal_map})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={2: translucent_bsdf})
    
    add_shader = nw.new_node('ShaderNodeAddShader', input_kwargs={0: principled_bsdf, 1: mix_shader})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': add_shader}, attrs={'is_active_output': True})

def shader_pine_tree_01_bark(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UVMap'})
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': attribute.outputs["Vector"], 'Scale': (1.2000, 0.1000, 1.0000)})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mapping})
    
    base_color = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Base Color',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_diff.jpg']
    
    roughness = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Roughness',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_rough.jpg']
    
    normal = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Normal',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_nor_gl.jpg']
    
    normal_map = nw.new_node(Nodes.ShaderNodeNormalMap, input_kwargs={'Color': normal.outputs["Color"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': base_color.outputs["Color"], 'Specular': 0.0200, 'Roughness': roughness.outputs["Color"], 'Normal': normal_map})
    
    displacement = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': reroute},
        label='Displacement',
        attrs={'image': None}) #bpy.data.images['pine_tree_01_bark_disp.jpg']
    
    displacement_1 = nw.new_node(Nodes.Displacement, input_kwargs={'Height': displacement.outputs["Color"], 'Scale': 0.2000})
    
    material_output = nw.new_node(Nodes.MaterialOutput,
        input_kwargs={'Surface': principled_bsdf, 'Displacement': displacement_1},
        attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'trunk_disp_val', 0.2700),
            ('NodeSocketInt', 'trunk_res', 0),
            ('NodeSocketInt', 'trunk_circle_res', 13),
            ('NodeSocketFloatDistance', 'branch_density', 0.1000),
            ('NodeSocketInt', 'branch_seed', 40),
            ('NodeSocketInt', 'branch_res', 9),
            ('NodeSocketFloat', 'branc_noise', 0.4800),
            ('NodeSocketFloat', 'branch_overall_length', 1.0000),
            ('NodeSocketFloatFactor', 'branch_shorten_percentage', 1.0000),
            ('NodeSocketFloat', 'branch_shorten_amount', -0.8000),
            ('NodeSocketFloatFactor', 'random_rotation_percentage', 0.4954),
            ('NodeSocketFloat', 'random_rotation_amount', 0.3200),
            ('NodeSocketFloat', 'small_branches_probability', 0.4900)])
    
    resample_curve = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': group_input.outputs["Geometry"], 'Length': group_input.outputs["branch_density"]},
        attrs={'mode': 'LENGTH'})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': resample_curve, 2: spline_parameter_1.outputs["Factor"]})
    
    musgrave_texture = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'W': 1.5000, 'Scale': 0.3000, 'Detail': 4.0000},
        attrs={'musgrave_type': 'MULTIFRACTAL', 'musgrave_dimensions': '4D'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 0.7200, 'Roughness': 0.5833})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: musgrave_texture, 1: noise_texture.outputs["Fac"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: subtract, 1: group_input.outputs["trunk_disp_val"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_1.outputs[2]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_4})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': map_range_1.outputs["Result"]})
    colorramp.color_ramp.interpolation = "CARDINAL"
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0200
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.5250
    colorramp.color_ramp.elements[1].color = [0.5626, 0.5626, 0.5626, 1.0000]
    colorramp.color_ramp.elements[2].position = 1.0000
    colorramp.color_ramp.elements[2].color = [0.0959, 0.0959, 0.0959, 1.0000]
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': colorramp.outputs["Color"]})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute, 1: reroute_2}, attrs={'operation': 'MULTIPLY'})
    
    musgrave_texture_1 = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'W': 1.5000, 'Scale': 0.7000, 'Detail': 4.0000},
        attrs={'musgrave_dimensions': '4D'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'W': -1.5200, 'Scale': 0.5200, 'Randomness': 0.8333},
        attrs={'voronoi_dimensions': '4D', 'feature': 'F2'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: musgrave_texture_1, 1: voronoi_texture.outputs["Distance"]})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: add_1, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: subtract_1, 1: group_input.outputs["trunk_disp_val"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_2})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: reroute_2}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_1, 'Y': multiply_3})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Offset': combine_xyz})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    reroute_119 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_44})
    
    reroute_115 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["trunk_res"]})
    
    resample_curve_9 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': reroute_119, 'Count': reroute_115})
    
    spline_parameter_20 = nw.new_node(Nodes.SplineParameter)
    
    map_range_26 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_20.outputs["Factor"], 3: 0.0800, 4: 0.0200})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_26.outputs["Result"], 1: 1.3000}, attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius_5 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve_9, 'Radius': multiply_4})
    
    spline_parameter_19 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_19 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_curve_radius_5, 2: spline_parameter_19.outputs["Factor"]})
    
    arc_6 = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Resolution': group_input.outputs["trunk_circle_res"], 'Radius': 1.4900, 'Sweep Angle': 6.2832})
    
    capture_attribute_18 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': arc_6.outputs["Curve"], 2: spline_parameter_19.outputs["Factor"]})
    
    curve_to_mesh_5 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute_19.outputs["Geometry"], 'Profile Curve': capture_attribute_18.outputs["Geometry"]})
    
    merge_by_distance_6 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': curve_to_mesh_5, 'Distance': 0.0000})
    
    reroute_116 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_19.outputs[2]})
    
    reroute_117 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_18.outputs[2]})
    
    combine_xyz_11 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_116, 'Y': reroute_117})
    
    store_named_attribute_6 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': merge_by_distance_6, 'Name': 'UVMap', 3: combine_xyz_11},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    switch_4 = nw.new_node(Nodes.Switch, input_kwargs={1: True, 14: store_named_attribute_6})
    
    reroute_118 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_4.outputs[6]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_16})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_2.outputs["Result"]})
    
    whole_branches_probability = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_17}, label='whole Branches probability')
    whole_branches_probability.color_ramp.elements.new(0)
    whole_branches_probability.color_ramp.elements[0].position = 0.2000
    whole_branches_probability.color_ramp.elements[0].color = [0.0060, 0.0060, 0.0060, 1.0000]
    whole_branches_probability.color_ramp.elements[1].position = 0.8010
    whole_branches_probability.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    whole_branches_probability.color_ramp.elements[2].position = 1.0000
    whole_branches_probability.color_ramp.elements[2].color = [0.3792, 0.3792, 0.3792, 1.0000]
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={'Probability': whole_branches_probability.outputs["Color"], 'Seed': group_input.outputs["branch_seed"]},
        attrs={'data_type': 'BOOLEAN'})
    
    multiply_5 = nw.new_node(Nodes.Math,
        input_kwargs={0: random_value.outputs[3], 1: whole_branches_probability.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_85 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_5})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_85})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    curve_line = nw.new_node(Nodes.CurveLine,
        input_kwargs={'End': (0.0000, 0.0000, 1.3000), 'Length': 2.9700},
        attrs={'mode': 'DIRECTION'})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={4: -360, 5: 360, 'Probability': 0.0000, 'Seed': 23},
        attrs={'data_type': 'INT'})
    
    degrees = nw.new_node(Nodes.Math, input_kwargs={0: random_value_1.outputs[2]}, attrs={'operation': 'DEGREES'})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate, input_kwargs={'Vector': normal, 'Axis': curve_tangent, 'Angle': degrees})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': vector_rotate}, attrs={'axis': 'Z'})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    main_branches_rot = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_8}, label='main branches rot')
    main_branches_rot.color_ramp.interpolation = "B_SPLINE"
    main_branches_rot.color_ramp.elements.new(0)
    main_branches_rot.color_ramp.elements.new(0)
    main_branches_rot.color_ramp.elements[0].position = 0.1946
    main_branches_rot.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    main_branches_rot.color_ramp.elements[1].position = 0.5201
    main_branches_rot.color_ramp.elements[1].color = [0.0943, 0.0943, 0.0943, 1.0000]
    main_branches_rot.color_ramp.elements[2].position = 0.7843
    main_branches_rot.color_ramp.elements[2].color = [0.1197, 0.1197, 0.1197, 1.0000]
    main_branches_rot.color_ramp.elements[3].position = 0.9765
    main_branches_rot.color_ramp.elements[3].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    random_value_6 = nw.new_node(Nodes.RandomValue,
        input_kwargs={3: 0.0000, 'Probability': group_input.outputs["random_rotation_percentage"], 'Seed': 57},
        attrs={'data_type': 'BOOLEAN'})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["random_rotation_amount"]})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: random_value_6.outputs[3], 1: reroute_42}, attrs={'operation': 'MULTIPLY'})
    
    subtract_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: main_branches_rot.outputs["Color"], 1: multiply_6},
        attrs={'operation': 'SUBTRACT'})
    
    random_value_3 = nw.new_node(Nodes.RandomValue, input_kwargs={2: main_branches_rot.outputs["Color"], 3: subtract_2, 'Seed': 32})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_3.outputs[1]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_tangent})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector, 'Factor': reroute_55, 'Vector': reroute_7},
        attrs={'axis': 'Z'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_1})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_10, 'Selection': reroute_18, 'Instance': curve_line, 'Rotation': reroute_11, 'Scale': (1.0000, 1.0000, 1.3700)})
    
    spline_parameter_8 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': instance_on_points, 2: spline_parameter_8.outputs["Factor"]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': capture_attribute.outputs["Geometry"]})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': realize_instances, 'Count': 17, 'Length': 0.1800})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_3})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_32})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_34})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_35})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_36})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_37})
    
    voronoi_texture_2 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'W': 2.7000, 'Scale': 0.6500, 'Smoothness': 0.7248, 'Randomness': 0.6606},
        attrs={'voronoi_dimensions': '4D', 'feature': 'SMOOTH_F1'})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: voronoi_texture_2.outputs["Color"]}, attrs={'operation': 'SUBTRACT'})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["branc_noise"]})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_31, 1: 2.4500}, attrs={'operation': 'MULTIPLY'})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_3, 1: multiply_7}, attrs={'operation': 'MULTIPLY'})
    
    spline_parameter_6 = nw.new_node(Nodes.SplineParameter)
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': spline_parameter_6.outputs["Factor"]})
    colorramp_5.color_ramp.interpolation = "EASE"
    colorramp_5.color_ramp.elements.new(0)
    colorramp_5.color_ramp.elements[0].position = 0.0000
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.5025
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_5.color_ramp.elements[2].position = 1.0000
    colorramp_5.color_ramp.elements[2].color = [0.5366, 0.5366, 0.5366, 1.0000]
    
    multiply_9 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_8, 1: colorramp_5.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_9})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_24})
    colorramp_2.color_ramp.interpolation = "EASE"
    colorramp_2.color_ramp.elements[0].position = 0.1151
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.7800
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    spline_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_3.outputs["Factor"]})
    
    lower_branches = nw.new_node(Nodes.RGBCurve, input_kwargs={'Color': map_range_5.outputs["Result"]}, label='lower branches')
    node_utils.assign_curve(lower_branches.mapping.curves[0], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(lower_branches.mapping.curves[1], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(lower_branches.mapping.curves[2], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(lower_branches.mapping.curves[3], [(0.0000, 1.0000), (0.3094, 0.8800), (0.7122, 0.1300), (1.0000, 0.0000)])
    
    subtract_4 = nw.new_node(Nodes.Math, input_kwargs={0: lower_branches}, attrs={'operation': 'SUBTRACT'})
    
    spline_parameter_4 = nw.new_node(Nodes.SplineParameter)
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_4.outputs["Factor"]})
    
    upper_branches = nw.new_node(Nodes.RGBCurve, input_kwargs={'Color': map_range_6.outputs["Result"]}, label='upper branches')
    node_utils.assign_curve(upper_branches.mapping.curves[0], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(upper_branches.mapping.curves[1], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(upper_branches.mapping.curves[2], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(upper_branches.mapping.curves[3], [(0.0000, 0.3600), (0.2786, 0.6613), (0.5303, 0.5899), (0.8049, 0.3238), (1.0000, 0.0000)])
    
    subtract_5 = nw.new_node(Nodes.Math, input_kwargs={0: upper_branches}, attrs={'operation': 'SUBTRACT'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_2.outputs["Color"], 6: subtract_4, 7: subtract_5},
        attrs={'data_type': 'RGBA'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Scale': 1.0300},
        attrs={'voronoi_dimensions': '4D', 'feature': 'F2'})
    
    subtract_6 = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture_1.outputs["Distance"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_10 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_6, 1: reroute_31}, attrs={'operation': 'MULTIPLY'})
    
    spline_parameter_5 = nw.new_node(Nodes.SplineParameter)
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': spline_parameter_5.outputs["Factor"]})
    colorramp_4.color_ramp.interpolation = "EASE"
    colorramp_4.color_ramp.elements.new(0)
    colorramp_4.color_ramp.elements[0].position = 0.0000
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.5572
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_4.color_ramp.elements[2].position = 1.0000
    colorramp_4.color_ramp.elements[2].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    multiply_11 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_10, 1: colorramp_4.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: mix.outputs[2], 1: multiply_11})
    
    random_value_8 = nw.new_node(Nodes.RandomValue, input_kwargs={'Seed': 4})
    
    multiply_12 = nw.new_node(Nodes.Math,
        input_kwargs={0: colorramp_4.outputs["Color"], 1: random_value_8.outputs[1]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_13 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_12, 1: 0.1500}, attrs={'operation': 'MULTIPLY'})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: add_2, 1: multiply_13})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_29, 'Y': reroute_29, 'Z': add_3})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_33, 'Offset': combine_xyz_1})
    
    resample_curve_4 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': set_position_1, 'Count': group_input.outputs["branch_res"], 'Length': 0.3700})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_4})
    
    random_value_4 = nw.new_node(Nodes.RandomValue,
        input_kwargs={'Probability': group_input.outputs["branch_shorten_percentage"], 'Seed': 27},
        attrs={'data_type': 'BOOLEAN'})
    
    multiply_add = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["branch_shorten_amount"], 1: random_value_4.outputs[3], 2: group_input.outputs["branch_overall_length"]},
        attrs={'operation': 'MULTIPLY_ADD'})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    map_range_8 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_23}, attrs={'clamp': False})
    
    branch_length_curve = nw.new_node(Nodes.RGBCurve, input_kwargs={'Color': map_range_8.outputs["Result"]}, label='branch length curve')
    node_utils.assign_curve(branch_length_curve.mapping.curves[0], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(branch_length_curve.mapping.curves[1], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(branch_length_curve.mapping.curves[2], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(branch_length_curve.mapping.curves[3], [(0.0000, 0.2500), (0.2266, 0.4200), (0.5180, 0.5350), (0.7410, 0.9350), (1.0000, 0.4700)])
    
    multiply_14 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_add, 1: branch_length_curve},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': reroute_41, 3: multiply_14, 5: 4.0000})
    
    resample_curve_6 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': trim_curve, 'Count': 30, 'Length': 0.3700})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_6})
    
    spline_parameter_12 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_4 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_48, 2: spline_parameter_12.outputs["Factor"]})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute.outputs[2]})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_50})
    
    map_range_13 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_47, 1: 1.0000, 2: 0.0000, 3: 1.0000, 4: 0.0000},
        attrs={'clamp': False})
    
    small_branches_overall_probability = nw.new_node(Nodes.ColorRamp,
        input_kwargs={'Fac': map_range_13.outputs["Result"]},
        label='small branches overall probability')
    small_branches_overall_probability.color_ramp.elements.new(0)
    small_branches_overall_probability.color_ramp.elements[0].position = 0.0791
    small_branches_overall_probability.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    small_branches_overall_probability.color_ramp.elements[1].position = 0.4342
    small_branches_overall_probability.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    small_branches_overall_probability.color_ramp.elements[2].position = 1.0000
    small_branches_overall_probability.color_ramp.elements[2].color = [0.5479, 0.5479, 0.5479, 1.0000]
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    reroute_95 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_54})
    
    map_range_14 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_95, 1: 1.0000, 2: 0.0000, 3: 1.0000, 4: 0.0000},
        attrs={'clamp': False})
    
    small_branches_probability = nw.new_node(Nodes.ColorRamp,
        input_kwargs={'Fac': map_range_14.outputs["Result"]},
        label='small branches probability')
    small_branches_probability.color_ramp.elements.new(0)
    small_branches_probability.color_ramp.elements.new(0)
    small_branches_probability.color_ramp.elements[0].position = 0.0252
    small_branches_probability.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    small_branches_probability.color_ramp.elements[1].position = 0.5017
    small_branches_probability.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    small_branches_probability.color_ramp.elements[2].position = 0.8159
    small_branches_probability.color_ramp.elements[2].color = [0.7766, 0.7766, 0.7766, 1.0000]
    small_branches_probability.color_ramp.elements[3].position = 1.0000
    small_branches_probability.color_ramp.elements[3].color = [0.4720, 0.4720, 0.4720, 1.0000]
    
    multiply_15 = nw.new_node(Nodes.Math,
        input_kwargs={0: small_branches_overall_probability.outputs["Color"], 1: small_branches_probability.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_16 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_15, 1: group_input.outputs["small_branches_probability"]},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_7 = nw.new_node(Nodes.RandomValue, input_kwargs={'Probability': multiply_16, 'Seed': 2}, attrs={'data_type': 'BOOLEAN'})
    
    multiply_17 = nw.new_node(Nodes.Math, input_kwargs={0: random_value_7.outputs[3], 1: multiply_15}, attrs={'operation': 'MULTIPLY'})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine,
        input_kwargs={'Direction': (1.0000, 2.0000, 0.0000), 'Length': 0.9200},
        attrs={'mode': 'DIRECTION'})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_4.outputs[2]})
    
    reroute_88 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_62})
    
    reroute_96 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': spline_parameter_12.outputs["Index"]})
    
    nodegroup = nw.new_node(nodegroup_node_group().name, input_kwargs={'Value': reroute_88, 'ID': reroute_96})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': capture_attribute_4.outputs["Geometry"], 'Selection': multiply_17, 'Instance': curve_line_1, 'Rotation': nodegroup, 'Scale': (1.0000, 1.2900, 1.0000)})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_2})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': realize_instances_1, 'Count': 9})
    
    spline_parameter_10 = nw.new_node(Nodes.SplineParameter)
    
    voronoi_texture_5 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Scale': 1.5000, 'Randomness': 0.5596},
        attrs={'voronoi_dimensions': '4D'})
    
    subtract_7 = nw.new_node(Nodes.Math, input_kwargs={0: voronoi_texture_5.outputs["Distance"]}, attrs={'operation': 'SUBTRACT'})
    
    multiply_18 = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_parameter_10.outputs["Factor"], 1: subtract_7},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_19 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_18, 1: 0.3700}, attrs={'operation': 'MULTIPLY'})
    
    voronoi_texture_4 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Scale': 2.1800, 'Randomness': 0.7890},
        attrs={'voronoi_dimensions': '4D'})
    
    subtract_8 = nw.new_node(Nodes.Math, input_kwargs={0: voronoi_texture_4.outputs["Distance"]}, attrs={'operation': 'SUBTRACT'})
    
    multiply_20 = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_parameter_10.outputs["Factor"], 1: subtract_8},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_21 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_20, 1: 0.5600}, attrs={'operation': 'MULTIPLY'})
    
    voronoi_texture_3 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Scale': 1.4800}, attrs={'voronoi_dimensions': '4D'})
    
    subtract_9 = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture_3.outputs["Distance"], 1: 0.6000},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_22 = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_parameter_10.outputs["Factor"], 1: subtract_9},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_23 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_22, 1: 0.3600}, attrs={'operation': 'MULTIPLY'})
    
    rgb_curves_3 = nw.new_node(Nodes.RGBCurve, input_kwargs={'Color': spline_parameter_10.outputs["Factor"]})
    node_utils.assign_curve(rgb_curves_3.mapping.curves[0], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(rgb_curves_3.mapping.curves[1], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(rgb_curves_3.mapping.curves[2], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(rgb_curves_3.mapping.curves[3], [(0.0000, 0.0000), (0.2886, 0.0000), (0.6716, 0.0855), (1.0000, 0.4724)])
    
    multiply_24 = nw.new_node(Nodes.Math, input_kwargs={0: rgb_curves_3, 1: 0.3900, 2: 0.0000}, attrs={'operation': 'MULTIPLY'})
    
    add_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_23, 1: multiply_24})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_19, 'Y': multiply_21, 'Z': add_4})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': resample_curve_2, 'Offset': combine_xyz_4})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_47})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_53})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_51})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_49, 1: 1.0000, 2: 0.0000}, attrs={'clamp': False})
    
    multiply_25 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_12.outputs["Result"], 1: 3.4700}, attrs={'operation': 'MULTIPLY'})
    
    trim_curve_1 = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': set_position_2, 3: multiply_25})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': trim_curve_1})
    
    reroute_93 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_57})
    
    reroute_107 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_93})
    
    spline_parameter_17 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_7 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_107, 2: spline_parameter_17.outputs["Factor"]})
    
    map_range_22 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': capture_attribute_7.outputs[2], 3: 0.0080, 4: 0.0020})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_54})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_52})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    map_range_23 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_67, 1: 1.0000, 2: 0.0000, 3: 0.4600, 4: 1.7800},
        attrs={'clamp': False})
    
    multiply_26 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_22.outputs["Result"], 1: map_range_23.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius_3 = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': capture_attribute_7.outputs["Geometry"], 'Radius': multiply_26})
    
    spline_parameter_16 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_14 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_curve_radius_3, 2: spline_parameter_16.outputs["Factor"]})
    
    integer_4 = nw.new_node(Nodes.Integer)
    integer_4.integer = 4
    
    arc_4 = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Resolution': integer_4, 'Radius': 2.4400, 'Sweep Angle': 6.2832})
    
    capture_attribute_15 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': arc_4.outputs["Curve"], 2: spline_parameter_16.outputs["Factor"]})
    
    curve_to_mesh_3 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute_14.outputs["Geometry"], 'Profile Curve': capture_attribute_15.outputs["Geometry"]})
    
    merge_by_distance_4 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': curve_to_mesh_3, 'Distance': 0.0000})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute_14.outputs[2], 'Y': capture_attribute_15.outputs[2]})
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': merge_by_distance_4, 'Name': 'UVMap', 3: combine_xyz_9},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={14: store_named_attribute_4})
    
    reroute_97 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_2.outputs[6]})
    
    reroute_87 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_97})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': trim_curve})
    
    reroute_113 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_46})
    
    spline_parameter_7 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_3 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_113, 2: spline_parameter_7.outputs["Factor"]})
    
    map_range_25 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': capture_attribute_3.outputs[2], 3: 0.0250, 4: 0.0050})
    
    reroute_112 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_67})
    
    map_range_24 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_112, 1: 0.1000, 3: 0.8900, 4: 0.3300})
    
    rgb_curves_4 = nw.new_node(Nodes.RGBCurve, input_kwargs={'Color': map_range_24.outputs["Result"]})
    node_utils.assign_curve(rgb_curves_4.mapping.curves[0], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(rgb_curves_4.mapping.curves[1], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(rgb_curves_4.mapping.curves[2], [(0.0000, 0.0000), (1.0000, 1.0000)])
    node_utils.assign_curve(rgb_curves_4.mapping.curves[3], [(0.0000, 0.3450), (0.2482, 0.5100), (0.5504, 0.6800), (0.7878, 0.6250), (1.0000, 0.0000)])
    
    multiply_27 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_25.outputs["Result"], 1: rgb_curves_4},
        attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius_4 = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': capture_attribute_3.outputs["Geometry"], 'Radius': multiply_27})
    
    spline_parameter_18 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_16 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_curve_radius_4, 2: spline_parameter_18.outputs["Factor"]})
    
    integer_5 = nw.new_node(Nodes.Integer)
    integer_5.integer = 6
    
    arc_5 = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Resolution': integer_5, 'Radius': 3.0900, 'Sweep Angle': 6.2832})
    
    capture_attribute_17 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': arc_5.outputs["Curve"], 2: spline_parameter_18.outputs["Factor"]})
    
    curve_to_mesh_4 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute_16.outputs["Geometry"], 'Profile Curve': capture_attribute_17.outputs["Geometry"]})
    
    merge_by_distance_5 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': curve_to_mesh_4, 'Distance': 0.0000})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute_16.outputs[2], 'Y': capture_attribute_17.outputs[2]})
    
    store_named_attribute_5 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': merge_by_distance_5, 'Name': 'UVMap', 3: combine_xyz_10},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_111 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_5})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_111})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_39})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_118, reroute_87, reroute_13]})
    
    set_bark_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry, 'Material': surface.shaderfunc_to_material(shader_pine_tree_01_bark)},
        label='set bark material')
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_10})
    
    resample_curve_7 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': reroute_25, 'Count': 160})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': whole_branches_probability.outputs["Color"]})
    
    map_range_7 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_27, 3: 0.0500, 4: -0.1200}, attrs={'clamp': False})
    
    random_value_2 = nw.new_node(Nodes.RandomValue, input_kwargs={'Probability': 0.4700, 'Seed': 48}, attrs={'data_type': 'BOOLEAN'})
    
    multiply_28 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_7.outputs["Result"], 1: random_value_2.outputs[3]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_28})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_38})
    
    collection_info_1 = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': None, 'Separate Children': True, 'Reset Children': True}) #bpy.data.collections['pine_tree_01_dead_branches']
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': collection_info_1, 'Translation': (0.0000, 0.0000, 0.0600)})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': transform})
    
    normal_1 = nw.new_node(Nodes.InputNormal)
    
    curve_tangent_1 = nw.new_node(Nodes.CurveTangent)
    
    random_value_9 = nw.new_node(Nodes.RandomValue,
        input_kwargs={4: -9999, 5: 9999, 'Probability': 0.0000, 'Seed': 23},
        attrs={'data_type': 'INT'})
    
    degrees_1 = nw.new_node(Nodes.Math, input_kwargs={0: random_value_9.outputs[2]}, attrs={'operation': 'DEGREES'})
    
    vector_rotate_1 = nw.new_node(Nodes.VectorRotate, input_kwargs={'Vector': normal_1, 'Axis': curve_tangent_1, 'Angle': degrees_1})
    
    align_euler_to_vector_3 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': vector_rotate_1}, attrs={'axis': 'Z'})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_55})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_89 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_45})
    
    map_range_21 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_89, 3: 0.2400, 4: 0.4900}, attrs={'clamp': False})
    
    subtract_10 = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute_56, 1: map_range_21.outputs["Result"]},
        attrs={'operation': 'SUBTRACT'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_tangent_1})
    
    align_euler_to_vector_2 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector_3, 'Factor': subtract_10, 'Vector': reroute_6},
        attrs={'axis': 'Z'})
    
    reroute_92 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_2})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_92})
    
    random_value_10 = nw.new_node(Nodes.RandomValue, input_kwargs={0: (0.5000, 0.5000, 0.5000)}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_90 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_89})
    
    colorramp_9 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_90})
    colorramp_9.color_ramp.elements.new(0)
    colorramp_9.color_ramp.elements[0].position = 0.0000
    colorramp_9.color_ramp.elements[0].color = [0.1289, 0.1289, 0.1289, 1.0000]
    colorramp_9.color_ramp.elements[1].position = 0.4552
    colorramp_9.color_ramp.elements[1].color = [0.4132, 0.4132, 0.4132, 1.0000]
    colorramp_9.color_ramp.elements[2].position = 1.0000
    colorramp_9.color_ramp.elements[2].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply_29 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: colorramp_9.outputs["Color"], 1: (5.0000, 5.0000, 5.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_30 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: random_value_10.outputs["Value"], 1: multiply_29.outputs["Vector"]},
        attrs={'operation': 'MULTIPLY'})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': resample_curve_7, 'Selection': reroute_40, 'Instance': reroute_22, 'Pick Instance': True, 'Rotation': reroute_12, 'Scale': multiply_30.outputs["Vector"]})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_1})
    
    reroute_82 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_28})
    
    reroute_83 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_82})
    
    reroute_84 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_83})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_84})
    
    reroute_86 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_43})
    
    set_dry_branches_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_86, 'Material': surface.shaderfunc_to_material(shader_pine_tree_01_dead_branches)},
        label='set dry branches material')
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_57})
    
    integer = nw.new_node(Nodes.Integer)
    integer.integer = 6
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': integer})
    
    resample_curve_5 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': reroute_59, 'Count': reroute_81, 'Length': 0.6200})
    
    spline_parameter_14 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_6 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': resample_curve_5, 2: spline_parameter_14.outputs["Factor"]})
    
    reroute_74 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_6.outputs["Geometry"]})
    
    map_range_16 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': capture_attribute_6.outputs[2], 3: 1.0000},
        attrs={'clamp': False})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection)
    
    subtract_11 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_16.outputs["Result"], 1: endpoint_selection},
        attrs={'operation': 'SUBTRACT'})
    
    reroute_76 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_11})
    
    reroute_68 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_67})
    
    reroute_77 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_68})
    
    reroute_78 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_77})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_78})
    
    leaf_growth = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': map_range_15.outputs["Result"]}, label='leaf growth')
    leaf_growth.color_ramp.interpolation = "CONSTANT"
    leaf_growth.color_ramp.elements.new(0)
    leaf_growth.color_ramp.elements[0].position = 0.0000
    leaf_growth.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    leaf_growth.color_ramp.elements[1].position = 0.2985
    leaf_growth.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    leaf_growth.color_ramp.elements[2].position = 0.7562
    leaf_growth.color_ramp.elements[2].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': leaf_growth.outputs["Color"]})
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_70})
    
    multiply_31 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_76, 1: reroute_80}, attrs={'operation': 'MULTIPLY'})
    
    collection_info = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': None, 'Separate Children': True, 'Reset Children': True}) #bpy.data.collections['pine_tree_01_twigs']
    
    curve_tangent_3 = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector_6 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Vector': curve_tangent_3},
        attrs={'pivot_axis': 'Z', 'axis': 'Y'})
    
    align_euler_to_vector_7 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector_6},
        attrs={'pivot_axis': 'Y', 'axis': 'Z'})
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': align_euler_to_vector_7})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_62})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_63})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_64})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_69})
    
    reroute_75 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    map_range_18 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_75, 3: 0.5000}, attrs={'clamp': False})
    
    map_range_20 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_68, 3: -0.2000, 4: 1.6900}, attrs={'clamp': False})
    
    multiply_add_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_18.outputs["Result"], 1: map_range_20.outputs["Result"], 2: -0.3800},
        attrs={'operation': 'MULTIPLY_ADD'})
    
    add_5 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_2.outputs["X"], 1: multiply_add_1, 2: -0.1000})
    
    random_value_12 = nw.new_node(Nodes.RandomValue, input_kwargs={2: -1.0000, 4: -6, 5: 45})
    
    subtract_12 = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz_2.outputs["Y"], 1: random_value_12.outputs[1], 2: 0.8000},
        attrs={'operation': 'SUBTRACT'})
    
    random_value_11 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.8100, 3: 1.2500})
    
    multiply_32 = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz_2.outputs["Z"], 1: random_value_11.outputs[1], 2: 0.0000},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_5, 'Y': subtract_12, 'Z': multiply_32})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_71})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_72})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    map_range_19 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_66, 3: 0.5500, 4: 0.2900})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_19.outputs["Result"]})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_61})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 0.5000
    
    add_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_73, 1: value})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_74, 'Selection': multiply_31, 'Instance': collection_info, 'Pick Instance': True, 'Rotation': reroute_60, 'Scale': add_6})
    
    reroute_79 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_74})
    
    map_range_17 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': capture_attribute_6.outputs[2], 3: 1.0000},
        attrs={'clamp': False})
    
    subtract_13 = nw.new_node(Nodes.Math, input_kwargs={0: integer, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    endpoint_selection_1 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': subtract_13, 'End Size': 0})
    
    subtract_14 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_17.outputs["Result"], 1: endpoint_selection_1},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_33 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_14, 1: reroute_80}, attrs={'operation': 'MULTIPLY'})
    
    collection_info_2 = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': None, 'Separate Children': True, 'Reset Children': True}) #bpy.data.collections['pine_tree_01_twigs']
    
    add_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_61, 1: value})
    
    instance_on_points_4 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_79, 'Selection': multiply_33, 'Instance': collection_info_2, 'Pick Instance': True, 'Rotation': reroute_72, 'Scale': add_7})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points_3, instance_on_points_4]})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_3})
    
    reroute_98 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_58})
    
    twig_switch = nw.new_node(Nodes.Switch, input_kwargs={1: True, 15: reroute_98}, label='twig switch')
    
    set_twig_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': twig_switch.outputs[6], 'Material': surface.shaderfunc_to_material(shader_pine_tree_01_twig)},
        label='set twig material')
    
    reroute_99 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_twig_material})
    
    reroute_100 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_99})
    
    reroute_91 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_100})
    
    object_info_1 = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': None}) #bpy.data.objects['pine_tree_01_trunk_a']
    
    switch_5 = nw.new_node(Nodes.Switch, input_kwargs={14: object_info_1.outputs["Geometry"]})
    
    join_geometry_4 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [set_bark_material, set_dry_branches_material, reroute_91, switch_5.outputs[6]]})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': join_geometry_4})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': realize_instances_2}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_pine_tree_01_bark, selection=selection)
    surface.add_material(obj, shader_pine_tree_01_twig, selection=selection)
    surface.add_material(obj, shader_pine_tree_01_dead_branches, selection=selection)
apply(bpy.context.active_object)
