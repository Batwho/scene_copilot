import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_asteroid(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion)
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': ambient_occlusion.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.9318
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    geometry = nw.new_node(Nodes.NewGeometry)
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': geometry.outputs["Pointiness"]})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.4909
    colorramp.color_ramp.elements[0].color = [0.0546, 0.1125, 0.1500, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.5818
    colorramp.color_ramp.elements[1].color = [0.5049, 0.3805, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_1.outputs["Color"], 6: (0.0009, 0.0018, 0.0040, 1.0000), 7: colorramp.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': geometry.outputs["Pointiness"]})
    colorramp_2.color_ramp.interpolation = "EASE"
    colorramp_2.color_ramp.elements[0].position = 0.4909
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.5818
    colorramp_2.color_ramp.elements[1].color = [0.2702, 0.2702, 0.2702, 1.0000]
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Detail': 15.0000, 'Roughness': 1.0000})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.1879, 'Height': noise_texture.outputs["Fac"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Subsurface': colorramp_2.outputs["Color"], 'Subsurface Radius': (0.4000, 0.7500, 0.7100), 'Subsurface Color': (0.4536, 0.0730, 1.0000, 1.0000), 'Roughness': 0.5668, 'Normal': bump})
    
    glossy_bsdf = nw.new_node(Nodes.GlossyBSDF, input_kwargs={'Color': mix.outputs[2], 'Roughness': 0.1538})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': 0.2833, 1: principled_bsdf, 2: glossy_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Subdivisions': 2})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    dual_mesh = nw.new_node(Nodes.DualMesh, input_kwargs={'Mesh': store_named_attribute})
    
    random_value_1 = nw.new_node(Nodes.RandomValue, input_kwargs={2: -0.5300, 'Seed': 92})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.3000})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': random_value.outputs[1], 1: 0.0900, 2: 0.6300, 3: 0.0800, 4: 0.1300})
    
    extrude_mesh = nw.new_node(Nodes.ExtrudeMesh,
        input_kwargs={'Mesh': dual_mesh, 'Selection': random_value_1.outputs[1], 'Offset Scale': map_range.outputs["Result"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value.outputs[1]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    scale_elements = nw.new_node(Nodes.ScaleElements,
        input_kwargs={'Geometry': extrude_mesh.outputs["Mesh"], 'Selection': extrude_mesh.outputs["Top"], 'Scale': reroute_3})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': extrude_mesh.outputs["Top"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    extrude_mesh_1 = nw.new_node(Nodes.ExtrudeMesh,
        input_kwargs={'Mesh': scale_elements, 'Selection': reroute_2, 'Offset Scale': -0.0900, 'Individual': False})
    
    scale_elements_1 = nw.new_node(Nodes.ScaleElements,
        input_kwargs={'Geometry': extrude_mesh_1.outputs["Mesh"], 'Selection': extrude_mesh_1.outputs["Top"], 'Scale': 0.8000})
    
    subdivision_surface = nw.new_node(Nodes.SubdivisionSurface, input_kwargs={'Mesh': scale_elements_1, 'Level': 3})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': subdivision_surface})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_asteroid)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_material}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_asteroid, selection=selection)