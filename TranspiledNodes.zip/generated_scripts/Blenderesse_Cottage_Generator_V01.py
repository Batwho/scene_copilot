import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_s_n_o_w_t_o_p', singleton=False, type='ShaderNodeTree')
def nodegroup_s_n_o_w_t_o_p(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorDirection', 'Normal', (0.0000, 0.0000, 1.0000)),
            ('NodeSocketFloatFactor', 'SNOW_AMOUNT', 1.0000)])
    
    normal = nw.new_node('ShaderNodeNormal', input_kwargs={'Normal': group_input.outputs["Normal"]})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': normal.outputs["Dot"]})
    colorramp_1.color_ramp.elements[0].position = 0.3061
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.6818
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    texture_coordinate_2 = nw.new_node(Nodes.TextureCoord)
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate_2.outputs["Generated"], 'Location': (0.8400, 0.0000, 0.0000), 'Rotation': (0.0000, -1.5708, 0.0000)})
    
    gradient_texture = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping}, attrs={'gradient_type': 'QUADRATIC'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture.outputs["Fac"]})
    colorramp.color_ramp.elements[0].position = 0.2333
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.7394
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': colorramp.outputs["Color"]})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_1.outputs["Color"], 7: reroute_1},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord)
    
    mapping_1 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Generated"], 'Scale': (4.4900, 4.4900, 4.4900)})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mapping_1})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute, 'Scale': 38.3000, 'Detail': 4.0000, 'Roughness': 1.0000})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp_2.color_ramp.elements[0].position = 0.3212
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.5788
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_4.outputs[2], 7: colorramp_2.outputs["Color"]},
        attrs={'blend_type': 'BURN', 'data_type': 'RGBA'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute, 'Scale': 0.4200, 'Detail': 8.0000, 'Roughness': 1.0000})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    colorramp_3.color_ramp.elements[0].position = 0.5424
    colorramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 0.6970
    colorramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': colorramp_3.outputs["Color"]})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_1.outputs[2], 7: reroute_2},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    mix_3 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input.outputs["SNOW_AMOUNT"], 6: (0.0000, 0.0000, 0.0000, 1.0000), 7: mix_2.outputs[2]},
        attrs={'data_type': 'RGBA'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Color': mix_3.outputs[2]}, attrs={'is_active_output': True})

def shader_blackness(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0000, 0.0000, 0.0000, 1.0000), 'Specular': 0.0000, 'Roughness': 1.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_d_o_o_r_s', singleton=False, type='GeometryNodeTree')
def nodegroup_d_o_o_r_s(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'X', 1.0000),
            ('NodeSocketFloat', 'Z', 2.0000),
            ('NodeSocketFloat', 'Value', 0.5000),
            ('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000))])
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_80, 'Y': 0.2500, 'Z': reroute_81})
    
    reroute_90 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_8})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_90, 1: (0.5500, 0.5500, 0.5500)},
        attrs={'operation': 'SUBTRACT'})
    
    cube = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': subtract.outputs["Vector"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube.outputs["Mesh"], 'Name': 'uv_map', 3: cube.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_80})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: 0.0800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_1})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_5, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_37 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply})
    
    combine_xyz_36 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_5})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_37, 'End': combine_xyz_36})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': curve_line, 'Length': 0.2000}, attrs={'mode': 'LENGTH'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_81})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_6, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_2 = nw.new_node(Nodes.Math, input_kwargs={0: divide_1, 1: 0.0800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_2})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_39 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_1})
    
    combine_xyz_38 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_7})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_39, 'End': combine_xyz_38})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-0.0200, -0.0200, -0.1000), 1: (0.0200, 0.0200, 0.1000)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Value"]})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_9, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_2, 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Vector"]})
    
    multiply_4 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_8, 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_4 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_3.outputs["Vector"], 1: multiply_4.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': random_value.outputs["Value"], 'Rotate By': random_value_4.outputs["Value"]})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': curve_line_1, 'Rotation': rotate_euler})
    
    transform_4 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': instance_on_points, 'Translation': (0.0000, 0.1600, 0.0000)})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.2000, 'Height': 0.1200})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve, input_kwargs={'Curve': quadrilateral, 'Radius': 0.0100, 'Limit Radius': True})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': transform_4, 'Profile Curve': fillet_curve, 'Fill Caps': True})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh, 'Shade Smooth': False})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_shade_smooth})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.0800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_3})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_29, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 0.1900
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    subtract_4 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: -0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_4})
    
    divide_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_28, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_13 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_2, 'Y': reroute_36, 'Z': divide_3})
    
    divide_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_29, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_28, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_14 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_4, 'Y': reroute_36, 'Z': divide_5})
    
    curve_line_4 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_13, 'End': combine_xyz_14})
    
    set_curve_tilt_2 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_4})
    
    subtract_5 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_5})
    
    divide_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_33, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_36})
    
    subtract_6 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: -0.1200}, attrs={'operation': 'SUBTRACT'})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_6})
    
    divide_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_32, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_15 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_6, 'Y': reroute_37, 'Z': divide_7})
    
    divide_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_33, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_32, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_16 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_8, 'Y': reroute_37, 'Z': divide_9})
    
    curve_line_5 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_15, 'End': combine_xyz_16})
    
    set_curve_tilt_3 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_5})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_60})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    subtract_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_22, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_7})
    
    divide_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_16, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_66})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_13})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_61})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_64})
    
    subtract_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_23, 1: -0.7000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_8})
    
    divide_11 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_10, 'Y': reroute_2, 'Z': divide_11})
    
    divide_12 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_16, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_13 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_12, 'Y': reroute_2, 'Z': divide_13})
    
    curve_line_6 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_9, 'End': combine_xyz_10})
    
    set_curve_tilt_5 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_6, 'Tilt': 1.5708})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_5, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    subtract_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_26, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_9})
    
    divide_14 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_24, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    subtract_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_27, 1: -0.7000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_10})
    
    divide_15 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_25, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_11 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_14, 'Y': reroute_3, 'Z': divide_15})
    
    divide_16 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_24, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_17 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_25, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_12 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_16, 'Y': reroute_3, 'Z': divide_17})
    
    curve_line_7 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_11, 'End': combine_xyz_12})
    
    set_curve_tilt_4 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_7, 'Tilt': 1.5708})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_4, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    join_geometry_9 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [set_curve_tilt_2, set_curve_tilt_3, transform, transform_1]})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_9})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_34})
    
    subtract_11 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_40, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_11})
    
    divide_18 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_38, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    value_1 = nw.new_node(Nodes.Value)
    value_1.outputs[0].default_value = -0.1700
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value_1})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_35})
    
    subtract_12 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_41, 1: -0.2200}, attrs={'operation': 'SUBTRACT'})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_12})
    
    divide_19 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_39, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_22 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_18, 'Y': reroute_54, 'Z': divide_19})
    
    divide_20 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_38, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_21 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_39, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_23 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_20, 'Y': reroute_54, 'Z': divide_21})
    
    curve_line_10 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_22, 'End': combine_xyz_23})
    
    set_curve_tilt_9 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_10, 'Tilt': 1.5708})
    
    transform_3 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_9, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_40})
    
    subtract_13 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_44, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_13})
    
    divide_22 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_42, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_54})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_41})
    
    subtract_14 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_45, 1: -0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_14})
    
    divide_23 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_43, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_24 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_22, 'Y': reroute_55, 'Z': divide_23})
    
    divide_24 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_42, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_25 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_43, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_17 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_24, 'Y': reroute_55, 'Z': divide_25})
    
    curve_line_11 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_24, 'End': combine_xyz_17})
    
    set_curve_tilt_8 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_11, 'Tilt': 1.5708})
    
    transform_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_8, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    subtract_15 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_49, 1: -0.0800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_15})
    
    divide_26 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_47, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_55})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    subtract_16 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_48, 1: -0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_16})
    
    divide_27 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_46, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_18 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_26, 'Y': reroute_56, 'Z': divide_27})
    
    divide_28 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_47, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_29 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_46, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_19 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_28, 'Y': reroute_56, 'Z': divide_29})
    
    curve_line_8 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_18, 'End': combine_xyz_19})
    
    set_curve_tilt_7 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_8})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    subtract_17 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_53, 1: -0.8700}, attrs={'operation': 'SUBTRACT'})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_17})
    
    divide_30 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_51, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_56})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    subtract_18 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_52, 1: -0.0300}, attrs={'operation': 'SUBTRACT'})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_18})
    
    divide_31 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_50, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_20 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_30, 'Y': reroute_57, 'Z': divide_31})
    
    divide_32 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_51, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_33 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_50, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_21 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_32, 'Y': reroute_57, 'Z': divide_33})
    
    curve_line_9 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_20, 'End': combine_xyz_21})
    
    set_curve_tilt_6 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_9, 'Tilt': -1.5708})
    
    transform_5 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_6, 'Scale': (1.0000, 1.9600, 1.0000)})
    
    join_geometry_10 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [transform_3, transform_2, set_curve_tilt_7, transform_5]})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_10})
    
    subtract_19 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_17, 1: 0.0000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_19})
    
    divide_34 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_20 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_18, 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_20})
    
    divide_35 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_15, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_34, 'Z': divide_35})
    
    divide_36 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_37 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_15, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_36, 'Z': divide_37})
    
    curve_line_13 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_2, 'End': combine_xyz_3})
    
    subtract_21 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_12, 1: 0.0000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_21})
    
    divide_38 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_22 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_13, 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_22})
    
    divide_39 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_11, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_38, 'Z': divide_39})
    
    divide_40 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_41 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_11, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_40, 'Z': divide_41})
    
    curve_line_12 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_1, 'End': combine_xyz})
    
    subtract_23 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_23})
    
    divide_42 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_20, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_24 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.1300}, attrs={'operation': 'SUBTRACT'})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_24})
    
    divide_43 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_19, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_42, 'Z': divide_43})
    
    divide_44 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_20, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_45 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_19, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_44, 'Z': divide_45})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_4, 'End': combine_xyz_5})
    
    set_curve_tilt = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_2, 'Tilt': 1.5708})
    
    subtract_25 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_25})
    
    divide_46 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_63, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_26 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.1300}, attrs={'operation': 'SUBTRACT'})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_26})
    
    divide_47 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_62, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_46, 'Z': divide_47})
    
    divide_48 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_63, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_49 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_62, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_48, 'Z': divide_49})
    
    curve_line_3 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_6, 'End': combine_xyz_7})
    
    set_curve_tilt_1 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_3, 'Tilt': 1.5708})
    
    join_geometry_11 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [curve_line_13, curve_line_12, set_curve_tilt, set_curve_tilt_1]})
    
    join_geometry_8 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_59, reroute_58, join_geometry_11]})
    
    quadrilateral_1 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1100, 'Height': 0.2600})
    
    fillet_curve_1 = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': quadrilateral_1, 'Count': 2, 'Radius': 0.0100, 'Limit Radius': True})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': join_geometry_8, 'Profile Curve': fillet_curve_1, 'Fill Caps': True})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_1, 'Shade Smooth': False})
    
    join_geometry_7 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute, set_shade_smooth_1]})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_7, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_vertical)})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'BOOLEON': store_named_attribute, 'DOORS': set_material_4},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_w_i_n_d_o_w_s', singleton=False, type='GeometryNodeTree')
def nodegroup_w_i_n_d_o_w_s(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'X', 1.0000),
            ('NodeSocketFloat', 'Z', 2.0000),
            ('NodeSocketFloat', 'if_destruction_0.1->', 0.0000)])
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_80, 'Y': 0.2500, 'Z': reroute_81})
    
    reroute_90 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_8})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_90, 1: (0.5500, 0.5500, 0.5500)},
        attrs={'operation': 'SUBTRACT'})
    
    cube = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': subtract.outputs["Vector"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube.outputs["Mesh"], 'Name': 'uv_map', 3: cube.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_78 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.0800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_1})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_29, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 0.1900
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    subtract_2 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: -0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_2})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_28, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_13 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide, 'Y': reroute_36, 'Z': divide_1})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_29, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_28, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_14 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_2, 'Y': reroute_36, 'Z': divide_3})
    
    curve_line_4 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_13, 'End': combine_xyz_14})
    
    set_curve_tilt_2 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_4})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_3})
    
    divide_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_33, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_36})
    
    subtract_4 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: -0.1200}, attrs={'operation': 'SUBTRACT'})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_4})
    
    divide_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_32, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_15 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_4, 'Y': reroute_37, 'Z': divide_5})
    
    divide_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_33, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_32, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_16 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_6, 'Y': reroute_37, 'Z': divide_7})
    
    curve_line_5 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_15, 'End': combine_xyz_16})
    
    set_curve_tilt_3 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_5})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_62})
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_66})
    
    reroute_77 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_70})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_77})
    
    subtract_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_22, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_5})
    
    divide_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_16, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_63})
    
    reroute_76 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_67})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_76})
    
    subtract_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_23, 1: -0.7000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_6})
    
    divide_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_8, 'Y': reroute_2, 'Z': divide_9})
    
    divide_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_16, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_11 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_10, 'Y': reroute_2, 'Z': divide_11})
    
    curve_line_6 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_9, 'End': combine_xyz_10})
    
    set_curve_tilt_5 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_6, 'Tilt': 1.5708})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_5, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    subtract_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_26, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_7})
    
    divide_12 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_24, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    subtract_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_27, 1: -0.7000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_8})
    
    divide_13 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_25, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_11 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_12, 'Y': reroute_3, 'Z': divide_13})
    
    divide_14 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_24, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_15 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_25, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_12 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_14, 'Y': reroute_3, 'Z': divide_15})
    
    curve_line_7 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_11, 'End': combine_xyz_12})
    
    set_curve_tilt_4 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_7, 'Tilt': 1.5708})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_4, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    join_geometry_9 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [set_curve_tilt_2, set_curve_tilt_3, transform, transform_1]})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': join_geometry_9, 'Count': 5, 'Length': 0.4500},
        attrs={'mode': 'LENGTH'})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_1})
    
    subtract_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_9, 1: 0.0000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_9})
    
    divide_16 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8, 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_10})
    
    divide_17 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_11, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_16, 'Z': divide_17})
    
    divide_18 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_19 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_11, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_18, 'Z': divide_19})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_2, 'End': combine_xyz_3})
    
    subtract_11 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: 0.0000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_11})
    
    divide_20 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_5, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_12 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_6, 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_12})
    
    divide_21 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_20, 'Z': divide_21})
    
    divide_22 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_5, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_23 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_22, 'Z': divide_23})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_1, 'End': combine_xyz})
    
    subtract_13 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_13})
    
    divide_24 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_13, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_14 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.1300}, attrs={'operation': 'SUBTRACT'})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_14})
    
    divide_25 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_12, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_24, 'Z': divide_25})
    
    divide_26 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_13, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_27 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_12, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_26, 'Z': divide_27})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_4, 'End': combine_xyz_5})
    
    set_curve_tilt = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_2, 'Tilt': 1.5708})
    
    subtract_15 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_15})
    
    divide_28 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_15, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_16 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.1300}, attrs={'operation': 'SUBTRACT'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_16})
    
    divide_29 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_28, 'Z': divide_29})
    
    divide_30 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_15, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_31 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_30, 'Z': divide_31})
    
    curve_line_3 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_6, 'End': combine_xyz_7})
    
    set_curve_tilt_1 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_3, 'Tilt': 1.5708})
    
    join_geometry_8 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [curve_line_1, curve_line, set_curve_tilt, set_curve_tilt_1]})
    
    join_geometry_7 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_59, join_geometry_8]})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1100, 'Height': 0.2600})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': quadrilateral, 'Count': 2, 'Radius': 0.0100, 'Limit Radius': True})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': join_geometry_7, 'Profile Curve': fillet_curve, 'Fill Caps': True})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh, 'Shade Smooth': False})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_window_frames_inside)})
    
    subtract_17 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_62, 1: 0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_17})
    
    divide_32 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_60, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_18 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_63, 1: 0.2400}, attrs={'operation': 'SUBTRACT'})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_18})
    
    divide_33 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_61, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_25 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_32, 'Z': divide_33})
    
    divide_34 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_60, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_35 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_61, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_26 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_34, 'Z': divide_35})
    
    curve_line_14 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_25, 'End': combine_xyz_26})
    
    subtract_19 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_66, 1: 0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_19})
    
    divide_36 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_64, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_20 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_67, 1: 0.2400}, attrs={'operation': 'SUBTRACT'})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_20})
    
    divide_37 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_65, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_27 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_36, 'Z': divide_37})
    
    divide_38 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_64, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_39 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_65, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_28 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_38, 'Z': divide_39})
    
    curve_line_15 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_27, 'End': combine_xyz_28})
    
    subtract_21 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_21})
    
    divide_40 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_69, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_22 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.3100}, attrs={'operation': 'SUBTRACT'})
    
    reroute_68 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_22})
    
    divide_41 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_68, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_29 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_40, 'Z': divide_41})
    
    divide_42 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_69, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_43 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_68, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_30 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_42, 'Z': divide_43})
    
    curve_line_12 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_29, 'End': combine_xyz_30})
    
    set_curve_tilt_10 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_12, 'Tilt': 1.5708})
    
    subtract_23 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_23})
    
    divide_44 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_73, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_24 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.3100}, attrs={'operation': 'SUBTRACT'})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_24})
    
    divide_45 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_72, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_31 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_44, 'Z': divide_45})
    
    divide_46 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_73, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_47 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_72, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_32 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_46, 'Z': divide_47})
    
    curve_line_13 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_31, 'End': combine_xyz_32})
    
    set_curve_tilt_11 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_13, 'Tilt': 1.5708})
    
    join_geometry_11 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [curve_line_14, curve_line_15, set_curve_tilt_10, set_curve_tilt_11]})
    
    quadrilateral_1 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0700, 'Height': 0.1000})
    
    fillet_curve_1 = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': quadrilateral_1, 'Count': 2, 'Radius': 0.0050, 'Limit Radius': True})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': join_geometry_11, 'Profile Curve': fillet_curve_1, 'Fill Caps': True})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_1, 'Shade Smooth': False})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth_1, 'Material': surface.shaderfunc_to_material(shader_window_frames_outside)})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: group_input.outputs["if_destruction_0.1->"], 1: 0.1000})
    
    reroute_84 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': greater_than})
    
    combine_xyz_37 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_80, 'Y': 0.0100, 'Z': reroute_81})
    
    cube_1 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': combine_xyz_37})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_1.outputs["Mesh"], 'Name': 'uv_map', 3: cube_1.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_83 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_1})
    
    reroute_82 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_83})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': 0.3000, 'Subdivisions': 2})
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture)
    
    subtract_25 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract_25.outputs["Vector"], 1: (2.0000, 2.0000, 2.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (0.4400, 0.4400, 0.4400)},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': store_named_attribute_2, 'Offset': multiply_1.outputs["Vector"]})
    
    combine_xyz_38 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_80, 'Y': 1.0000, 'Z': reroute_81})
    
    transform_4 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_position, 'Scale': combine_xyz_38})
    
    reroute_79 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': transform_4})
    
    difference = nw.new_node(Nodes.MeshBoolean, input_kwargs={'Mesh 1': store_named_attribute_1, 'Mesh 2': reroute_79})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_84, 14: reroute_82, 15: difference.outputs["Mesh"]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': switch.outputs[6], 'Material': surface.shaderfunc_to_material(shader_window_glass)})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material})
    
    subtract_26 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X"], 1: 0.2500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_74 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_26})
    
    divide_48 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_74, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_34 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_48})
    
    divide_49 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_74, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_33 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_49})
    
    curve_line_16 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_34, 'End': combine_xyz_33})
    
    set_curve_tilt_12 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_16, 'Tilt': 1.5708})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': set_curve_tilt_12, 'Length': 0.4000},
        attrs={'mode': 'LENGTH'})
    
    subtract_27 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.3800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_75 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_27})
    
    divide_50 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_75, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_36 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': divide_50})
    
    divide_51 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_75, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_35 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': divide_51})
    
    curve_line_18 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_36, 'End': combine_xyz_35})
    
    reroute_85 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["if_destruction_0.1->"]})
    
    reroute_87 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_85})
    
    reroute_86 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_87})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_86, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_2, 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_86, 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_2 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_3.outputs["Vector"], 1: multiply_4.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': curve_line_18, 'Rotation': random_value_2.outputs["Value"]})
    
    curve_line_17 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_36, 'End': combine_xyz_35})
    
    set_curve_tilt_13 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_17})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': set_curve_tilt_13, 'Length': 0.4000},
        attrs={'mode': 'LENGTH'})
    
    curve_line_19 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_34, 'End': combine_xyz_33})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': curve_line_19, 'Rotation': random_value_2.outputs["Value"]})
    
    join_geometry_13 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points, instance_on_points_1]})
    
    quadrilateral_2 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0700, 'Height': 0.1000})
    
    fillet_curve_2 = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': quadrilateral_2, 'Count': 2, 'Radius': 0.0050, 'Limit Radius': True})
    
    curve_to_mesh_2 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': join_geometry_13, 'Profile Curve': fillet_curve_2, 'Fill Caps': True})
    
    set_shade_smooth_2 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_2, 'Shade Smooth': False})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth_2, 'Material': surface.shaderfunc_to_material(shader_window_frames_outside)})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_34})
    
    subtract_28 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_40, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_28})
    
    divide_52 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_38, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    value_1 = nw.new_node(Nodes.Value)
    value_1.outputs[0].default_value = -0.1700
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value_1})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_35})
    
    subtract_29 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_41, 1: -0.7000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_29})
    
    divide_53 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_39, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_22 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_52, 'Y': reroute_54, 'Z': divide_53})
    
    divide_54 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_38, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_55 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_39, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_23 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_54, 'Y': reroute_54, 'Z': divide_55})
    
    curve_line_10 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_22, 'End': combine_xyz_23})
    
    set_curve_tilt_9 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_10, 'Tilt': 1.5708})
    
    transform_3 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_9, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_40})
    
    subtract_30 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_44, 1: -0.3500}, attrs={'operation': 'SUBTRACT'})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_30})
    
    divide_56 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_42, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_54})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_41})
    
    subtract_31 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_45, 1: -0.7000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_31})
    
    divide_57 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_43, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_24 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_56, 'Y': reroute_55, 'Z': divide_57})
    
    divide_58 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_42, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_59 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_43, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_17 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_58, 'Y': reroute_55, 'Z': divide_59})
    
    curve_line_11 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_24, 'End': combine_xyz_17})
    
    set_curve_tilt_8 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_11, 'Tilt': 1.5708})
    
    transform_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_curve_tilt_8, 'Translation': (0.0000, 0.0000, -0.1500)})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    subtract_32 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_49, 1: -0.0800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_32})
    
    divide_60 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_47, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_55})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    subtract_33 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_48, 1: -0.1800}, attrs={'operation': 'SUBTRACT'})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_33})
    
    divide_61 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_46, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_18 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_60, 'Y': reroute_56, 'Z': divide_61})
    
    divide_62 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_47, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_63 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_46, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_19 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_62, 'Y': reroute_56, 'Z': divide_63})
    
    curve_line_8 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_18, 'End': combine_xyz_19})
    
    set_curve_tilt_7 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_8})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X"]})
    
    subtract_34 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_53, 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_34})
    
    divide_64 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_51, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_56})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    subtract_35 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_52, 1: -0.0300}, attrs={'operation': 'SUBTRACT'})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_35})
    
    divide_65 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_50, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_20 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_64, 'Y': reroute_57, 'Z': divide_65})
    
    divide_66 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_51, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    divide_67 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_50, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_21 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_66, 'Y': reroute_57, 'Z': divide_67})
    
    curve_line_9 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_20, 'End': combine_xyz_21})
    
    set_curve_tilt_6 = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': curve_line_9, 'Tilt': -0.8727})
    
    join_geometry_10 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [transform_3, transform_2, set_curve_tilt_7, set_curve_tilt_6]})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': join_geometry_10, 'Count': 5, 'Length': 0.4500},
        attrs={'mode': 'LENGTH'})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_2})
    
    reroute_88 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_58})
    
    quadrilateral_3 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1100, 'Height': 0.2600})
    
    fillet_curve_3 = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': quadrilateral_3, 'Count': 2, 'Radius': 0.0100, 'Limit Radius': True})
    
    curve_to_mesh_3 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': reroute_88, 'Profile Curve': fillet_curve_3, 'Fill Caps': True})
    
    set_shade_smooth_3 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_3, 'Shade Smooth': False})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth_3, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_vertical)})
    
    join_geometry_12 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [set_material_1, set_material_2, reroute_71, set_material_3, set_material_4]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'BOOLEON': reroute_78, 'WINDOW': join_geometry_12},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_array_doors_windows', singleton=False, type='GeometryNodeTree')
def nodegroup_array_doors_windows(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Value', 0.5000),
            ('NodeSocketFloat', 'Value_1', 0.5000),
            ('NodeSocketInt', 'Count', 3),
            ('NodeSocketFloat', 'hole width', 0.5000)])
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Count"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    less_than = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_1, 1: 2.0000}, attrs={'operation': 'LESS_THAN'})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': less_than})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Value"]})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_6, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    absolute = nw.new_node(Nodes.Math, input_kwargs={0: divide}, attrs={'operation': 'ABSOLUTE'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Value_1"]})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_5, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    absolute_1 = nw.new_node(Nodes.Math, input_kwargs={0: divide_1}, attrs={'operation': 'ABSOLUTE'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: absolute, 1: absolute_1})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["hole width"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Count"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_13, 1: reroute_8}, attrs={'operation': 'MULTIPLY'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: reroute_7}, attrs={'operation': 'SUBTRACT'})
    
    less_than_1 = nw.new_node(Nodes.Compare, input_kwargs={0: subtract_1, 1: 7.0000}, attrs={'operation': 'LESS_THAN'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': less_than_1})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    subtract_2 = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: 3.0000}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_24 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': subtract_2})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: divide_1, 1: -3.0000}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_25 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': subtract_3})
    
    curve_line_7 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_24, 'End': combine_xyz_25})
    
    resample_curve_8 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_7, 'Count': reroute_1, 'Length': 5.0000})
    
    reroute_100 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_8})
    
    resample_curve_9 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_7, 'Count': 3, 'Length': 5.0000})
    
    index = nw.new_node(Nodes.Index)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': resample_curve_9, 2: index})
    
    equal = nw.new_node(Nodes.Compare,
        input_kwargs={0: capture_attribute.outputs[2], 1: 1.0000, 'Epsilon': 0.1000},
        attrs={'operation': 'EQUAL'})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 'Selection': equal})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': separate_geometry.outputs["Selection"]})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_3, 14: reroute_100, 15: reroute_9})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': separate_geometry.outputs["Selection"]})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_10, 14: switch.outputs[6], 15: reroute_11})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Curve': switch_1.outputs[6]}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_main_logs', singleton=False, type='ShaderNodeTree')
def nodegroup_main_logs(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    geometry = nw.new_node(Nodes.NewGeometry)
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Vector1', (0.0000, 0.0000, 0.0000))])
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': group_input.outputs["Vector"], 'Scale': 1.0000, 'Distortion': 6.0000, 'Detail': 6.0000, 'Detail Scale': 13.4200, 'Detail Roughness': 0.7769},
        attrs={'rings_direction': 'Y', 'bands_direction': 'Z'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': wave_texture.outputs["Fac"]})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_1})
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.3395, 0.2084, 0.1556, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.6864
    colorramp.color_ramp.elements[1].color = [0.0863, 0.0563, 0.0339, 1.0000]
    colorramp.color_ramp.elements[2].position = 1.0000
    colorramp.color_ramp.elements[2].color = [0.1574, 0.1149, 0.0840, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: geometry.outputs["Random Per Island"], 6: colorramp.outputs["Color"], 7: (1.0000, 0.8097, 0.8097, 1.0000)},
        attrs={'blend_type': 'SATURATION', 'data_type': 'RGBA'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': group_input.outputs[1], 'Scale': 6.9000, 'Detail': 5.0000, 'Roughness': 1.0000})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_1.outputs[2], 7: noise_texture.outputs["Fac"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_1})
    colorramp_1.color_ramp.elements[0].position = 0.0091
    colorramp_1.color_ramp.elements[0].color = [0.1800, 0.1800, 0.1800, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [0.7808, 0.7808, 0.7808, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0100, 'Height': colorramp_1.outputs["Color"]})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Normal': bump},
        attrs={'subsurface_method': 'BURLEY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': bump})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'BSDF': principled_bsdf_1, 'Normal': reroute_2},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_snow_on_buildings', singleton=False, type='ShaderNodeTree')
def nodegroup_snow_on_buildings(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketShader', 'Shader', None),
            ('NodeSocketVectorDirection', 'Normal', (0.0000, 0.0000, 1.0000)),
            ('NodeSocketColor', 'Normal Map', (0.5000, 0.5000, 1.0000, 1.0000))])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Normal"]})
    
    group = nw.new_node(nodegroup_s_n_o_w_t_o_p().name, input_kwargs={'Normal': reroute})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Normal Map"]})
    
    group_1 = nw.new_node(nodegroup_s_n_o_w_m_a_i_n().name, input_kwargs={'Color': reroute_1})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_1})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': reroute_3, 1: group_input.outputs["Shader"], 2: reroute_2})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Shader': mix_shader}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_s_n_o_w_m_a_i_n', singleton=False, type='ShaderNodeTree')
def nodegroup_s_n_o_w_m_a_i_n(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 250.0000, 'Detail': 4.0000, 'Roughness': 0.6778})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.6178, 0.6178, 0.6178, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Scale': 500.0000})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': voronoi_texture.outputs["Distance"], 2: 0.3500, 4: 0.5000})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketColor', 'Color', (0.5000, 0.5000, 1.0000, 1.0000))])
    
    normal_map = nw.new_node(Nodes.ShaderNodeNormalMap, input_kwargs={'Color': group_input.outputs["Color"]})
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Distance': 0.0500, 'Height': noise_texture.outputs["Color"], 'Normal': normal_map})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp.outputs["Color"], 'Specular': 2.0000, 'Roughness': map_range.outputs["Result"], 'Clearcoat': 0.2500, 'Clearcoat Roughness': 0.3330, 'Normal': bump})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'BSDF': principled_bsdf_1}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_s_n_o_w', singleton=False, type='GeometryNodeTree')
def nodegroup_s_n_o_w(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketBool', 'Switch', True),
            ('NodeSocketGeometry', 'True', None)])
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["Switch"], 15: group_input.outputs["True"]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': switch.outputs[6]}, attrs={'legacy_behavior': True})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    dot_product = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal, 1: (0.0000, 0.0000, 2.0000)},
        attrs={'operation': 'DOT_PRODUCT'})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': dot_product.outputs["Value"], 1: 0.9000})
    
    distribute_points_on_faces = nw.new_node(Nodes.DistributePointsOnFaces,
        input_kwargs={'Mesh': realize_instances, 'Selection': map_range.outputs["Result"], 'Density': 150.0000},
        attrs={'use_legacy_normal': True})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': distribute_points_on_faces.outputs["Points"], 'Translation': (0.0000, 0.0000, 0.1000)})
    
    points_to_volume = nw.new_node(Nodes.PointsToVolume, input_kwargs={'Points': transform, 'Voxel Amount': 156.0000, 'Radius': 0.1500})
    
    volume_to_mesh = nw.new_node(Nodes.VolumeToMesh, input_kwargs={'Volume': points_to_volume, 'Threshold': 0.3400})
    
    position = nw.new_node(Nodes.InputPosition)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': volume_to_mesh, 1: position},
        attrs={'domain': 'FACE', 'data_type': 'FLOAT_VECTOR'})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 1: position_1},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute.outputs["Attribute"]})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: capture_attribute_1.outputs["Attribute"], 1: reroute},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (-2.0000, -2.0000, -2.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Offset': multiply.outputs["Vector"]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_position})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_snow)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_material_3}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_chimney', singleton=False, type='GeometryNodeTree')
def nodegroup_chimney(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Mesh', None),
            ('NodeSocketFloat', 'height', 0.5000),
            ('NodeSocketFloat', 'length', 0.5000),
            ('NodeSocketBool', 'Switch', False)])
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Switch"]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    grid_1 = nw.new_node(Nodes.MeshGrid, input_kwargs={'Vertices X': 2, 'Vertices Y': 2})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid_1.outputs["Mesh"], 'Name': 'uv_map', 3: grid_1.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_7, 15: store_named_attribute})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["height"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: reroute_33, 1: 2.3000})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': add})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': switch_1.outputs[6], 'Offset': combine_xyz_1})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["length"]})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_34, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': subtract})
    
    transform_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_position_3, 'Translation': combine_xyz_2})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': transform_2, 'Material': surface.shaderfunc_to_material(shader_blackness)})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Mesh"]})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_8, 15: reroute_2})
    
    mesh_to_points_1 = nw.new_node(Nodes.MeshToPoints, input_kwargs={'Mesh': switch.outputs[6]}, attrs={'mode': 'FACES'})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': mesh_to_points_1, 'Translation': combine_xyz_2})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 1.1500, 'Height': 1.0000})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': quadrilateral, 'Length': 0.2000}, attrs={'mode': 'LENGTH'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': transform_1, 'Instance': resample_curve_2})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_3, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: 2.8300}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': subtract_1})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line}, attrs={'mode': 'LENGTH'})
    
    index = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 2.0000}, attrs={'operation': 'MODULO'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': resample_curve, 'Selection': modulo, 'Offset': (0.0000, 0.0000, 0.1000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': instance_on_points, 'Profile Curve': set_position})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': curve_to_mesh, 1: normal},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"]},
        attrs={'legacy_behavior': True})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    normal_1 = nw.new_node(Nodes.InputNormal)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture)
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.6900, 0.6900, 0.5000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal_1, 1: multiply_1.outputs["Vector"]},
        attrs={'operation': 'MULTIPLY'})
    
    position = nw.new_node(Nodes.InputPosition)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["height"], 1: 2.0000})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': separate_xyz.outputs["Z"], 2: add_1},
        attrs={'interpolation_type': 'SMOOTHERSTEP'})
    
    multiply_3 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_2.outputs["Vector"], 1: map_range.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    add_2 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: multiply_3.outputs["Vector"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': realize_instances_1, 'Position': add_2.outputs["Vector"]})
    
    mesh_to_points_2 = nw.new_node(Nodes.MeshToPoints, input_kwargs={'Mesh': set_position_1})
    
    cube = nw.new_node(Nodes.MeshCube,
        input_kwargs={'Size': (0.2100, 0.1900, 0.0900), 'Vertices X': 6, 'Vertices Y': 6, 'Vertices Z': 6})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube.outputs["Mesh"], 'Name': 'uv_map', 3: cube.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_1, 'Translation': (0.0300, 0.0000, 0.0000)})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': capture_attribute.outputs["Attribute"]})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-0.0400, -0.0400, -0.1600), 1: (0.0300, 0.0300, 0.1800)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': random_value.outputs["Value"]})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotation': rotate_euler})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.2300, 0.9600, 1.0000), 1: (1.1700, 1.0500, 1.0100)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_to_points_2, 'Instance': transform, 'Rotation': rotate_euler_1, 'Scale': random_value_1.outputs["Value"]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_1}, attrs={'legacy_behavior': True})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture)
    
    subtract_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_1.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_4 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract_2.outputs["Vector"], 1: (2.0000, 2.0000, 2.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_5 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_4.outputs["Vector"], 1: (0.0350, 0.0350, 0.0350)},
        attrs={'operation': 'MULTIPLY'})
    
    set_position_2 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances, 'Offset': multiply_5.outputs["Vector"]})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_position_2, 'Material': surface.shaderfunc_to_material(shader_bricks)})
    
    join_geometry_6 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_1, set_material_3]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': transform_2})
    
    mesh_to_points = nw.new_node(Nodes.MeshToPoints, input_kwargs={'Mesh': reroute_4}, attrs={'mode': 'FACES'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Chimney': join_geometry_6, 'Chimney Points': mesh_to_points},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_floor', singleton=False, type='GeometryNodeTree')
def nodegroup_floor(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Value', 0.5000),
            ('NodeSocketFloat', 'Portch', 0.0000)])
    
    index = nw.new_node(Nodes.Index)
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={0: index, 1: 2.0000}, attrs={'operation': 'EQUAL'})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Selection': equal},
        attrs={'domain': 'EDGE'})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': separate_geometry.outputs["Selection"]})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': mesh_to_curve, 'Length': 0.3500}, attrs={'mode': 'LENGTH'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': group_input.outputs["Portch"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Value"], 1: -0.1500})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': add})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_1, 'End': combine_xyz})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-0.0010, -0.0010, -0.0010), 1: (0.0010, 0.0010, 0.0010)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': curve_line, 'Rotation': random_value.outputs["Value"]})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.4100, 'Height': 0.0500})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve, input_kwargs={'Curve': quadrilateral, 'Radius': 0.0100, 'Limit Radius': True})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': instance_on_points, 'Profile Curve': fillet_curve, 'Fill Caps': True})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh, 'Shade Smooth': False})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_shade_smooth_1}, attrs={'legacy_behavior': True})
    
    transform_1 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Scale': (1.0200, 1.0200, 1.0200)})
    
    mesh_to_curve_1 = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': transform_1})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': mesh_to_curve_1, 'Count': 20, 'Length': 0.8200},
        attrs={'mode': 'LENGTH'})
    
    cube = nw.new_node(Nodes.MeshCube)
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube.outputs["Mesh"], 'Name': 'uv_map', 3: cube.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute, 'Translation': (0.4400, 0.1800, 0.0000)})
    
    subdivide_mesh = nw.new_node(Nodes.SubdivideMesh, input_kwargs={'Mesh': transform, 'Level': 2})
    
    subdivision_surface = nw.new_node(Nodes.SubdivisionSurface, input_kwargs={'Mesh': subdivide_mesh, 'Level': 2})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subdivision_surface})
    
    random_value_2 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0000, -0.3600, 0.0000), 1: (0.0000, 0.3200, 0.0000), 2: 0.6400},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_1.outputs["Rotation"], 'Rotate By': random_value_2.outputs["Value"]},
        attrs={'space': 'LOCAL'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.7000, 0.6300, 0.7500), 1: (1.2700, 0.6700, 1.0000), 2: 0.6400},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': reroute, 'Rotation': rotate_euler, 'Scale': random_value_1.outputs["Value"]})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_1}, attrs={'legacy_behavior': True})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 2.0000})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.0000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (2.0000, 2.0000, 0.5100)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (0.2500, 0.2500, 0.2500)},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances_1, 'Offset': multiply_1.outputs["Vector"]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_position})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'FLOOR': realize_instances_2, 'ROCKS': set_shade_smooth},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_floor_materials_with_dot_product', singleton=False, type='GeometryNodeTree')
def nodegroup_floor_materials_with_dot_product(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    normal = nw.new_node(Nodes.InputNormal)
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal, 1: (-1.0000, -1.0000, -1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketVector', 'Vector_1', (0.0000, 0.0000, 0.0000))])
    
    dot_product = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: group_input.outputs["Vector_1"]},
        attrs={'operation': 'DOT_PRODUCT'})
    
    less_than = nw.new_node(Nodes.Compare,
        input_kwargs={0: dot_product.outputs["Value"], 1: -0.1000},
        attrs={'operation': 'LESS_THAN'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Result': less_than}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_edge_normal', singleton=False, type='GeometryNodeTree')
def nodegroup_edge_normal(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Geometry', None)])
    
    position = nw.new_node(Nodes.InputPosition)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 1: position},
        attrs={'domain': 'FACE', 'data_type': 'FLOAT_VECTOR'})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 1: position_1},
        attrs={'domain': 'EDGE', 'data_type': 'FLOAT_VECTOR'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute.outputs["Attribute"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_1.outputs["Attribute"]})
    
    subtract = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute, 1: reroute_1}, attrs={'operation': 'SUBTRACT'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'edge normal': subtract.outputs["Vector"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_w_a_l_l_s_f', singleton=False, type='GeometryNodeTree')
def nodegroup_w_a_l_l_s_f(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Points', None),
            ('NodeSocketFloat', 'X/Y', 0.5000),
            ('NodeSocketFloat', 'X/Y Invert', 0.5000),
            ('NodeSocketFloat', 'Z', 1.0000),
            ('NodeSocketFloat', 'WALLS', 1.0000),
            ('NodeSocketVector', 'ROTATE', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Wall Z Offset', 0.0000),
            ('NodeSocketFloat', 'Random Scale', 1.0600),
            ('NodeSocketFloat', 'hole width', 1.0000),
            ('NodeSocketFloat', 'hole height', 2.0000),
            ('NodeSocketFloat', 'hole x pos', 0.0000),
            ('NodeSocketFloat', 'hole z pos', 0.0000),
            ('NodeSocketBool', 'Switch holepos xy', False),
            ('NodeSocketBool', 'Roof Switch', False),
            ('NodeSocketFloat', 'Roof Height', 2.4000),
            ('NodeSocketFloat', 'Roof Extend', 1.0000),
            ('NodeSocketBool', 'Roof_Flip_When_needed', False),
            ('NodeSocketFloat', 'destruction value', 0.5000),
            ('NodeSocketFloat', 'Roof Holders Extend', 1.0000),
            ('NodeSocketBool', 'DOOR / WINDOW', False),
            ('NodeSocketInt', 'Count', 2)])
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Points"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Wall Z Offset"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_11})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_2})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': reroute_8, 'Translation': combine_xyz})
    
    index_3 = nw.new_node(Nodes.Index)
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["WALLS"]})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    not_equal = nw.new_node(Nodes.Compare,
        input_kwargs={0: index_3, 1: reroute_18, 'Epsilon': 1.0000},
        attrs={'operation': 'NOT_EQUAL'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': not_equal})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Z"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    snap = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: 0.2200}, attrs={'operation': 'SNAP'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': snap})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_3})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line, 'Count': 3, 'Length': 0.0800})
    
    index_2 = nw.new_node(Nodes.Index)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': resample_curve, 2: index_2})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["ROTATE"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': reroute_1}, attrs={'axis': 'Y'})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_1})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': transform, 'Selection': reroute_9, 'Instance': capture_attribute_1.outputs["Geometry"], 'Rotation': reroute_13})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': instance_on_points, 'Count': 14, 'Length': 0.2200},
        attrs={'mode': 'LENGTH'})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X/Y"]})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_17, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: 0.4700})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_2})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': reroute_52, 'End': reroute_51})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 3})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["destruction value"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_1, 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["destruction value"], 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_2 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_2.outputs["Vector"], 1: multiply_3.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Random Scale"]})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={2: 1.0000, 3: reroute_15})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': random_value.outputs[1], 'Y': 1.0000, 'Z': 1.0000})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': resample_curve_1, 'Rotation': random_value_2.outputs["Value"], 'Scale': reroute_6})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': instance_on_points_1, 'Count': 12, 'Length': 0.0500},
        attrs={'mode': 'LENGTH'})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': resample_curve_2})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': curve_to_mesh}, attrs={'legacy_behavior': True})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    equal = nw.new_node(Nodes.Compare,
        input_kwargs={0: capture_attribute_1.outputs[2], 1: 1.0000, 'Epsilon': 0.0100},
        attrs={'operation': 'EQUAL'})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X/Y"]})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_53, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': divide_1})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: divide_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_11 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_10, 'End': combine_xyz_11})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_2, 'Count': 3, 'Length': 1.0000})
    
    index = nw.new_node(Nodes.Index)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': resample_curve_3, 2: index})
    
    instance_on_points_5 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_26, 'Selection': reroute_27, 'Instance': capture_attribute.outputs["Geometry"]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_5})
    
    equal_1 = nw.new_node(Nodes.Compare,
        input_kwargs={0: capture_attribute.outputs[2], 1: 1.0000, 'Epsilon': 0.0200},
        attrs={'operation': 'EQUAL'})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal_1})
    
    reroute_102 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X/Y"]})
    
    reroute_101 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_102})
    
    array_doors_windows = nw.new_node(nodegroup_array_doors_windows().name,
        input_kwargs={'Value': reroute_101, 'Value_1': reroute_101, 'Count': group_input.outputs["Count"], 'hole width': group_input.outputs["hole width"]})
    
    reroute_100 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': array_doors_windows})
    
    reroute_103 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_100})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_10, 'Selection': reroute_28, 'Instance': reroute_103})
    
    reroute_106 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': None})
    
    reroute_84 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR / WINDOW"]})
    
    reroute_85 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_84})
    
    reroute_83 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_85})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["hole width"]})
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["hole height"]})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    windows = nw.new_node(nodegroup_w_i_n_d_o_w_s().name,
        input_kwargs={'X': reroute_80, 'Z': reroute_29, 'if_destruction_0.1->': group_input.outputs["destruction value"]})
    
    doors = nw.new_node(nodegroup_d_o_o_r_s().name,
        input_kwargs={'X': reroute_80, 'Z': reroute_29, 'Value': group_input.outputs["destruction value"], 'Vector': group_input.outputs["destruction value"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: reroute_83, 14: windows.outputs["BOOLEON"], 15: doors.outputs["BOOLEON"]})
    
    reroute_109 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_4.outputs[6]})
    
    instance_on_points_12 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': instance_on_points_3, 'Selection': reroute_106, 'Instance': reroute_109})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["hole x pos"]})
    
    reroute_87 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_55})
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["hole z pos"]})
    
    reroute_86 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_54})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_87, 'Z': reroute_86})
    
    combine_xyz_12 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_87, 'Z': reroute_86})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch holepos xy"], 8: combine_xyz_9, 9: combine_xyz_12},
        attrs={'input_type': 'VECTOR'})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_6.outputs[3]})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    transform_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': instance_on_points_12, 'Translation': reroute_25})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': transform_2}, attrs={'legacy_behavior': True})
    
    geometry_proximity = nw.new_node(Nodes.Proximity, input_kwargs={'Target': realize_instances})
    
    less_than = nw.new_node(Nodes.Compare,
        input_kwargs={0: geometry_proximity.outputs["Distance"], 1: 0.2900, 'Epsilon': 1.0000},
        attrs={'operation': 'LESS_THAN'})
    
    delete_geometry = nw.new_node(Nodes.DeleteGeometry, input_kwargs={'Geometry': realize_instances_1, 'Selection': less_than})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': delete_geometry})
    
    reroute_104 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_103})
    
    multiply_5 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["destruction value"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_6 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_5, 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_7 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["destruction value"], 1: (1.0000, 0.7500, 0.7500)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_4 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_6.outputs["Vector"], 1: multiply_7.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points_4 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_10, 'Selection': reroute_28, 'Instance': reroute_104, 'Rotation': random_value_4.outputs["Value"]})
    
    reroute_107 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_106})
    
    switch_5 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_85, 14: windows.outputs["WINDOW"], 15: doors.outputs["DOORS"]})
    
    reroute_108 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_5.outputs[6]})
    
    instance_on_points_13 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': instance_on_points_4, 'Selection': reroute_107, 'Instance': reroute_108})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': instance_on_points_13, 'Translation': reroute_24})
    
    realize_instances_5 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': transform_1}, attrs={'legacy_behavior': True})
    
    reroute_68 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': realize_instances_5})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_68})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_35})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_32})
    
    equal_2 = nw.new_node(Nodes.Compare,
        input_kwargs={0: capture_attribute_1.outputs[2], 1: 2.0000, 'Epsilon': 0.0100},
        attrs={'operation': 'EQUAL'})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal_2})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_38})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_37})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X/Y"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: divide_2})
    
    combine_xyz_13 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_1})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: divide_2, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_8, 1: -0.5000})
    
    combine_xyz_14 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_2})
    
    curve_line_3 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_13, 'End': combine_xyz_14})
    
    resample_curve_4 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_3, 'Count': 3, 'Length': 1.0000})
    
    index_1 = nw.new_node(Nodes.Index)
    
    capture_attribute_3 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': resample_curve_4, 2: index_1})
    
    reroute_78 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_3.outputs["Geometry"]})
    
    curve_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_2 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': reroute_78, 2: curve_parameter.outputs["Factor"]})
    
    instance_on_points_6 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_34, 'Selection': reroute_36, 'Instance': capture_attribute_2.outputs["Geometry"]})
    
    resample_curve_5 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': instance_on_points_6, 'Length': 0.2000},
        attrs={'mode': 'LENGTH'})
    
    curve_line_4 = nw.new_node(Nodes.CurveLine)
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-0.0050, -0.0050, -0.1500), 1: (0.0050, 0.0050, 0.1500)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    multiply_9 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["destruction value"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_10 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_9, 1: (1.9700, 0.0000, 0.5000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_11 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["destruction value"], 1: (0.5000, 0.1500, 0.5000)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_3 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_10.outputs["Vector"], 1: multiply_11.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_76 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_3.outputs["Value"]})
    
    reroute_75 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_76})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_75})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_63})
    
    rotate_euler_3 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotation': random_value_1.outputs["Value"], 'Rotate By': reroute_64})
    
    reroute_91 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Roof Switch"]})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_91})
    
    combine_xyz_16 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 1.0000, 'Y': 1.0000, 'Z': 0.2500})
    
    random_value_8 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.8000, 3: 1.5000})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_2.outputs[2]})
    
    pingpong = nw.new_node(Nodes.Math, input_kwargs={0: reroute_33}, attrs={'operation': 'PINGPONG'})
    
    reroute_90 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Roof Height"]})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_90})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_47})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': pingpong, 3: 0.2500, 4: reroute_48})
    
    combine_xyz_15 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': 1.0000, 'Y': random_value_8.outputs[1], 'Z': map_range.outputs["Result"]})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_42, 8: combine_xyz_16, 9: combine_xyz_15},
        attrs={'input_type': 'VECTOR'})
    
    instance_on_points_7 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': resample_curve_5, 'Instance': curve_line_4, 'Rotation': rotate_euler_3, 'Scale': switch.outputs[3]})
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["destruction value"]})
    
    multiply_12 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_81, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_13 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_12, 1: (0.0000, -1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_14 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_81, 1: (0.0000, 2.0000, -1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_10 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_13.outputs["Vector"], 1: multiply_14.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_94 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_10.outputs["Value"]})
    
    reroute_93 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_94})
    
    reroute_99 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_93})
    
    reroute_98 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_99})
    
    set_position_6 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': instance_on_points_7, 'Offset': reroute_98})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1990, 'Height': 0.0600})
    
    fillet_curve_1 = nw.new_node(Nodes.FilletCurve, input_kwargs={'Curve': quadrilateral, 'Radius': 0.0100, 'Limit Radius': True})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_6, 'Profile Curve': fillet_curve_1, 'Fill Caps': True})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_34})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_36})
    
    transform_4 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': capture_attribute_2.outputs["Geometry"], 'Scale': (1.1000, 1.0000, 1.0000)})
    
    instance_on_points_8 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_40, 'Selection': reroute_41, 'Instance': transform_4})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_8}, attrs={'legacy_behavior': True})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_3.outputs[2]})
    
    equal_3 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_45, 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal_3})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_46})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_42})
    
    combine_xyz_17 = nw.new_node(Nodes.CombineXYZ)
    
    combine_xyz_18 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range.outputs["Result"]})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_43, 8: combine_xyz_17, 9: combine_xyz_18},
        attrs={'input_type': 'VECTOR'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances_2, 'Selection': reroute_44, 'Offset': switch_1.outputs[3]})
    
    set_position_7 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position, 'Offset': reroute_99})
    
    quadrilateral_1 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1400, 'Height': 0.3500})
    
    fillet_curve_2 = nw.new_node(Nodes.FilletCurve, input_kwargs={'Curve': quadrilateral_1, 'Radius': 0.0250, 'Limit Radius': True})
    
    transform_3 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': fillet_curve_2, 'Translation': (0.0000, -0.0400, 0.0000)})
    
    curve_to_mesh_2 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_7, 'Profile Curve': transform_3, 'Fill Caps': True})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh_2})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_to_mesh_1, reroute_39]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': join_geometry_3, 'Shade Smooth': False})
    
    realize_instances_4 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_shade_smooth}, attrs={'legacy_behavior': True})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': realize_instances_4, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_vertical)})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_1})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_43})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_50, 15: set_position})
    
    resample_curve_6 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': switch_2.outputs[6], 'Count': 3, 'Length': 0.2500})
    
    realize_instances_3 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': resample_curve_6}, attrs={'legacy_behavior': True})
    
    index_4 = nw.new_node(Nodes.Index)
    
    capture_attribute_4 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': realize_instances_3, 2: index_4})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_4.outputs["Geometry"]})
    
    resample_curve_8 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': reroute_19, 'Count': 5, 'Length': 0.2400})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_8})
    
    reroute_74 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_73})
    
    index_5 = nw.new_node(Nodes.Index)
    
    capture_attribute_5 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': reroute_74, 2: index_5})
    
    curve_to_points_3 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': capture_attribute_5.outputs["Geometry"], 'Count': 7, 'Length': 0.2500})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Roof_Flip_When_needed"]})
    
    less_than_1 = nw.new_node(Nodes.Compare,
        input_kwargs={0: capture_attribute_4.outputs[2], 1: 3.0000},
        attrs={'operation': 'LESS_THAN'})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: capture_attribute_4.outputs[2], 1: 2.9900})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_58, 6: less_than_1, 7: greater_than},
        attrs={'input_type': 'BOOLEAN'})
    
    equal_4 = nw.new_node(Nodes.Compare,
        input_kwargs={0: capture_attribute_5.outputs[2], 'Epsilon': 0.0000},
        attrs={'operation': 'EQUAL'})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal_4})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: switch_3.outputs[2], 1: reroute_21}, attrs={'operation': 'SUBTRACT'})
    
    equal_5 = nw.new_node(Nodes.Compare, input_kwargs={0: capture_attribute_5.outputs[2], 1: 4.0000}, attrs={'operation': 'EQUAL'})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal_5})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: subtract, 1: reroute_20}, attrs={'operation': 'SUBTRACT'})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["X/Y Invert"]})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Roof Extend"]})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_59, 1: reroute_57})
    
    add_4 = nw.new_node(Nodes.Math, input_kwargs={0: add_3, 1: group_input.outputs["Roof Holders Extend"]})
    
    combine_xyz_21 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_4})
    
    add_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_57, 1: group_input.outputs["Roof Holders Extend"]})
    
    multiply_15 = nw.new_node(Nodes.Math, input_kwargs={0: add_5, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_22 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_15})
    
    curve_line_6 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_21, 'End': combine_xyz_22})
    
    transform_7 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_line_6, 'Translation': (0.0000, 0.1500, 0.0500)})
    
    reroute_77 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': transform_7})
    
    rotate_euler_6 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_3.outputs["Rotation"], 'Rotate By': (1.5708, 0.0000, 0.0000)},
        attrs={'space': 'LOCAL'})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Rotation': rotate_euler_6}, attrs={'axis': 'Z'})
    
    multiply_16 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_81, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_17 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_16, 1: (2.0000, 0.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_18 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_81, 1: (2.0000, 2.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_9 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_17.outputs["Vector"], 1: multiply_18.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_82 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_9.outputs["Value"]})
    
    rotate_euler_7 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': reroute_82},
        attrs={'space': 'LOCAL'})
    
    instance_on_points_11 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_3.outputs["Points"], 'Selection': subtract_1, 'Instance': reroute_77, 'Rotation': rotate_euler_7})
    
    reroute_95 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_93})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': instance_on_points_11, 'Offset': reroute_95})
    
    quadrilateral_3 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1700, 'Height': 0.3000})
    
    fillet_curve_3 = nw.new_node(Nodes.FilletCurve, input_kwargs={'Curve': quadrilateral_3, 'Radius': 0.0150, 'Limit Radius': True})
    
    transform_8 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': fillet_curve_3, 'Translation': (-0.2000, 0.1500, 0.0000)})
    
    curve_to_mesh_4 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_3, 'Profile Curve': transform_8, 'Fill Caps': True})
    
    realize_instances_8 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': curve_to_mesh_4}, attrs={'legacy_behavior': True})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': realize_instances_8, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_inside_walls)})
    
    reroute_89 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_2})
    
    reroute_88 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_89})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_3, reroute_49, reroute_88]})
    
    resample_curve_7 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': reroute_19, 'Count': 5, 'Length': 0.2400},
        attrs={'mode': 'LENGTH'})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': resample_curve_7, 'Count': 35, 'Length': 0.2400},
        attrs={'mode': 'EVALUATED'})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_3.outputs[2]})
    
    add_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_59, 1: reroute_57})
    
    combine_xyz_19 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_6})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_19})
    
    multiply_19 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_57, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_20 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_19})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_20})
    
    curve_line_5 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': reroute_61, 'End': reroute_60})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_1.outputs["Rotation"]})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_3.outputs["Value"]})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotation': reroute_69, 'Rotate By': reroute_62})
    
    instance_on_points_9 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Selection': reroute_56, 'Instance': curve_line_5, 'Rotation': rotate_euler_2})
    
    multiply_20 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["destruction value"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_21 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_20, 1: (-5.0000, 0.0000, 5.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_22 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["destruction value"], 1: (-5.0000, 0.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_5 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply_21.outputs["Vector"], 1: multiply_22.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    multiply_23 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: random_value_5.outputs["Value"], 1: (0.0000, 0.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_23.outputs["Vector"]})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': instance_on_points_9, 'Offset': reroute_66})
    
    quadrilateral_2 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0900, 'Height': 0.2400})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve, input_kwargs={'Curve': quadrilateral_2, 'Radius': 0.0100, 'Limit Radius': True})
    
    transform_5 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': fillet_curve, 'Translation': (-0.2000, 0.0000, 0.0000)})
    
    curve_to_mesh_3 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_2, 'Profile Curve': transform_5, 'Fill Caps': True})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_3, 'Shade Smooth': False})
    
    reroute_97 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_95})
    
    set_position_4 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_shade_smooth_1, 'Offset': reroute_97})
    
    realize_instances_9 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_position_4}, attrs={'legacy_behavior': True})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': realize_instances_9})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    divide_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["X/Y Invert"], 1: 2.0000},
        attrs={'operation': 'DIVIDE'})
    
    add_7 = nw.new_node(Nodes.Math, input_kwargs={0: divide_3, 1: group_input.outputs["Roof Extend"]})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_7})
    
    multiply_24 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_67, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    snap_1 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Z"], 1: 0.2200}, attrs={'operation': 'SNAP'})
    
    add_8 = nw.new_node(Nodes.Math, input_kwargs={0: snap_1, 1: 0.1000})
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_8})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_24, 'Z': reroute_70})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_67, 'Z': reroute_70})
    
    curve_line_9 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_4, 'End': combine_xyz_6})
    
    resample_curve_9 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_9, 'Length': 0.4000}, attrs={'mode': 'LENGTH'})
    
    curve_to_points_2 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': resample_curve_9, 'Count': 30, 'Length': 2.2800},
        attrs={'mode': 'EVALUATED'})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_3.outputs[2]})
    
    reroute_79 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_72})
    
    reroute_92 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_79})
    
    divide_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Roof Height"], 1: 2.0000},
        attrs={'operation': 'DIVIDE'})
    
    add_9 = nw.new_node(Nodes.Math, input_kwargs={0: divide_4, 1: 0.2500})
    
    reroute_96 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_9})
    
    combine_xyz_23 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 0.2500, 'Z': reroute_96})
    
    divide_5 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["X/Y"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add_10 = nw.new_node(Nodes.Math, input_kwargs={0: divide_5, 1: 0.2500})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_10, 'Z': 0.2500})
    
    curve_line_7 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_23, 'End': combine_xyz_8})
    
    combine_xyz_24 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': -0.2500, 'Z': reroute_96})
    
    multiply_25 = nw.new_node(Nodes.Math, input_kwargs={0: add_10, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_25, 'Z': 0.2500})
    
    curve_line_8 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_24, 'End': combine_xyz_7})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_line_7, curve_line_8]})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_2.outputs["Points"], 'Selection': reroute_92, 'Instance': join_geometry_1, 'Scale': (1.2000, 1.0000, 1.0000)})
    
    curve_to_points_5 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': instance_on_points_2, 'Count': 15, 'Length': 0.4000},
        attrs={'mode': 'LENGTH'})
    
    realize_instances_6 = nw.new_node(Nodes.RealizeInstances,
        input_kwargs={'Geometry': curve_to_points_5.outputs["Points"]},
        attrs={'legacy_behavior': True})
    
    position = nw.new_node(Nodes.InputPosition)
    
    vector = nw.new_node(Nodes.Vector)
    vector.vector = (1.0000, 1.0000, 1.0000)
    
    reroute_122 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["destruction value"]})
    
    map_range_8 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_122, 2: 0.1300, 3: 1.0000, 4: 0.6900})
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_122, 2: 0.9500, 3: 1.0000, 4: -0.3000})
    
    combine_xyz_29 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': map_range_8.outputs["Result"], 'Y': map_range_8.outputs["Result"], 'Z': map_range_6.outputs["Result"]})
    
    multiply_26 = nw.new_node(Nodes.VectorMath, input_kwargs={0: vector, 1: combine_xyz_29}, attrs={'operation': 'MULTIPLY'})
    
    multiply_27 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: position, 1: multiply_26.outputs["Vector"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_123 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_27.outputs["Vector"]})
    
    reroute_124 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_123})
    
    reroute_125 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_124})
    
    reroute_111 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_122})
    
    random_value_13 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0000, 0.0000, -5.0000), 1: (0.0000, 0.0000, -25.0000), 3: -6.6800})
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_111, 4: random_value_13.outputs[1]})
    
    combine_xyz_28 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_5.outputs["Result"]})
    
    reroute_121 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_28})
    
    reroute_119 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_121})
    
    set_position_5 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances_6, 'Position': reroute_125, 'Offset': reroute_119})
    
    curve_line_10 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': (0.4000, 0.0000, 0.0000), 'End': (-0.4000, -0.0400, 0.0000)})
    
    resample_curve_11 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_10, 'Count': 8})
    
    curve_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': curve_parameter_1.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.2500), (0.3000, 0.2500), (0.7606, 0.0725), (1.0000, 0.2070)], handles=['AUTO', 'VECTOR', 'AUTO', 'AUTO'])
    
    add_11 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve, 1: -0.1500})
    
    combine_xyz_30 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': add_11})
    
    set_position_8 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': resample_curve_11, 'Offset': combine_xyz_30})
    
    quadrilateral_5 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0800, 'Height': 1.2500})
    
    transform_9 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': quadrilateral_5, 'Rotation': (0.0000, 0.0000, -0.1204)})
    
    curve_to_mesh_6 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_8, 'Profile Curve': transform_9, 'Fill Caps': True})
    
    set_shade_smooth_3 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_6, 'Shade Smooth': False})
    
    reroute_131 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_shade_smooth_3})
    
    reroute_130 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_131})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_5.outputs["Rotation"], 'Rotate By': (0.1745, 0.0000, 0.0000)},
        attrs={'space': 'LOCAL'})
    
    random_value_6 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0400, -0.0500, -0.0500), 1: (0.2000, 0.0500, 0.0500)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler, 'Rotate By': random_value_6.outputs["Value"]},
        attrs={'space': 'LOCAL'})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["destruction value"], 2: 2.0000, 4: 13.8300})
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["destruction value"], 2: 2.0000, 4: -11.5700})
    
    random_value_11 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: map_range_7.outputs["Result"], 1: map_range_3.outputs["Result"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_117 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_11.outputs["Value"]})
    
    reroute_116 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_117})
    
    reroute_115 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_116})
    
    reroute_114 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_115})
    
    reroute_126 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_114})
    
    rotate_euler_5 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': reroute_126})
    
    random_value_12 = nw.new_node(Nodes.RandomValue, input_kwargs={1: (0.0000, 0.0000, 0.0000), 2: -0.4200, 3: 0.3200})
    
    map_range_4 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_111, 2: 0.5000, 3: 0.5500, 4: random_value_12.outputs[1]})
    
    random_value_14 = nw.new_node(Nodes.RandomValue, input_kwargs={1: (0.0000, 0.0000, 0.0000), 2: 0.8500, 3: 1.1400})
    
    multiply_28 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_4.outputs["Result"], 1: random_value_14.outputs[1]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_127 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_28})
    
    reroute_128 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_127})
    
    instance_on_points_10 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': set_position_5, 'Instance': reroute_130, 'Rotation': rotate_euler_5, 'Scale': reroute_128})
    
    resample_curve_10 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_9, 'Length': 0.7800}, attrs={'mode': 'LENGTH'})
    
    curve_to_points_4 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': resample_curve_10, 'Count': 30, 'Length': 2.2800},
        attrs={'mode': 'EVALUATED'})
    
    reroute_110 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_4.outputs["Points"]})
    
    reroute_105 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_92})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': 8, 'Start': (-0.3000, 0.0000, 0.0000), 'Middle': (0.0000, 0.4400, 0.0000), 'End': (0.3000, 0.0000, 0.0000)})
    
    combine_xyz_25 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_96})
    
    transform_6 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': quadratic_bezier, 'Translation': combine_xyz_25, 'Rotation': (1.5003, 0.0000, 0.0000)})
    
    rotate_euler_4 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotate By': reroute_116})
    
    instance_on_points_14 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_110, 'Selection': reroute_105, 'Instance': transform_6, 'Rotation': rotate_euler_4})
    
    quadrilateral_4 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.9300, 'Height': 0.1200})
    
    curve_to_mesh_5 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': instance_on_points_14, 'Profile Curve': quadrilateral_4, 'Fill Caps': True})
    
    set_shade_smooth_2 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_5, 'Shade Smooth': False})
    
    reroute_113 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_122})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_113, 4: -6.8300})
    
    combine_xyz_27 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_2.outputs["Result"]})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_113, 2: 0.5000, 4: -11.4600})
    
    combine_xyz_26 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_1.outputs["Result"]})
    
    random_value_7 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: combine_xyz_27, 1: combine_xyz_26},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_120 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': random_value_7.outputs["Value"]})
    
    reroute_118 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_120})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_shade_smooth_2, 'Position': reroute_124, 'Offset': reroute_118})
    
    realize_instances_7 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_position_1}, attrs={'legacy_behavior': True})
    
    join_geometry_5 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points_10, realize_instances_7]})
    
    reroute_112 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_5})
    
    reroute_129 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_112})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Base': mesh_to_curve, 'Roof Pilars And Windows': join_geometry_2, 'Roof': reroute_71, 'Roof Tiles': reroute_129},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_l_o_g_p_r_o_f_i_l_e', singleton=False, type='GeometryNodeTree')
def nodegroup_l_o_g_p_r_o_f_i_l_e(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Profiles', 1),
            ('NodeSocketInt', 'Profile Resolution', 16)])
    
    object_info = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': None}) #bpy.data.objects['p1']
    
    integer_2 = nw.new_node(Nodes.Integer)
    integer_2.integer = 1
    
    set_id_2 = nw.new_node(Nodes.SetID, input_kwargs={'Geometry': object_info.outputs["Geometry"], 'ID': integer_2})
    
    object_info_1 = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': None}) #bpy.data.objects['p2']
    
    integer_1 = nw.new_node(Nodes.Integer)
    integer_1.integer = 2
    
    set_id_1 = nw.new_node(Nodes.SetID, input_kwargs={'Geometry': object_info_1.outputs["Geometry"], 'ID': integer_1})
    
    object_info_2 = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': None}) #bpy.data.objects['p3']
    
    integer = nw.new_node(Nodes.Integer)
    integer.integer = 3
    
    set_id = nw.new_node(Nodes.SetID, input_kwargs={'Geometry': object_info_2.outputs["Geometry"], 'ID': integer})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_id_2, set_id_1, set_id]})
    
    id = nw.new_node(Nodes.InputID)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Profiles"]})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={0: id, 1: reroute}, attrs={'operation': 'EQUAL'})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry, input_kwargs={'Geometry': join_geometry, 'Selection': equal})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': separate_geometry.outputs["Selection"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Profile Resolution"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': mesh_to_curve, 'Count': reroute_2})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': group_input.outputs["Curve"], 'Profile Curve': resample_curve, 'Fill Caps': True})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Mesh': curve_to_mesh_1}, attrs={'is_active_output': True})

def shader_rock_base(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    geometry = nw.new_node(Nodes.NewGeometry)
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': geometry.outputs["Random Per Island"]})
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0140, 0.0140, 0.0140, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.5000
    colorramp.color_ramp.elements[1].color = [0.0514, 0.0514, 0.0514, 1.0000]
    colorramp.color_ramp.elements[2].position = 1.0000
    colorramp.color_ramp.elements[2].color = [0.0771, 0.1205, 0.0709, 1.0000]
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Generated"], 'Scale': 32.5000, 'Detail': 6.0000})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp_1.color_ramp.elements.new(0)
    colorramp_1.color_ramp.elements[0].position = 0.3485
    colorramp_1.color_ramp.elements[0].color = [0.1027, 0.0079, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.5091
    colorramp_1.color_ramp.elements[1].color = [0.1586, 0.5000, 0.0920, 1.0000]
    colorramp_1.color_ramp.elements[2].position = 0.5727
    colorramp_1.color_ramp.elements[2].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: colorramp_1.outputs["Color"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.3500, 'Height': noise_texture.outputs["Fac"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': bump})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': mix.outputs[2], 'Normal': reroute})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    group_1 = nw.new_node(nodegroup_snow_on_buildings().name, input_kwargs={'Shader': principled_bsdf, 'Normal': reroute_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group_1}, attrs={'is_active_output': True})

def shader_window_glass(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Roughness': 0.0000, 'Transmission': 1.0000, 'Transmission Roughness': 0.1566})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_window_frames_inside(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Generated"]})
    
    mapping_1 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute_4, 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (1.0000, 8.9000, 0.6400)})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    group = nw.new_node(nodegroup_main_logs().name, input_kwargs={0: mapping_1, 1: reroute_2})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group.outputs["BSDF"]}, attrs={'is_active_output': True})

def shader_window_frames_outside(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate.outputs["Object"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping, 'Scale': 4.3900, 'Detail': 6.0000, 'Roughness': 1.0000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp.color_ramp.elements[0].position = 0.4909
    colorramp.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.5000
    colorramp.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord)
    
    mapping_2 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Generated"], 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (1.0000, 1.0000, 5.4400)})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': mapping_2, 'Scale': 1.0000, 'Distortion': 6.0000, 'Detail': 6.0000, 'Detail Scale': 13.4200, 'Detail Roughness': 0.7769},
        attrs={'rings_direction': 'Y', 'bands_direction': 'Z'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': wave_texture.outputs["Fac"]})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_1})
    colorramp_1.color_ramp.elements.new(0)
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [0.3395, 0.2084, 0.1556, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.6864
    colorramp_1.color_ramp.elements[1].color = [0.0863, 0.0563, 0.0339, 1.0000]
    colorramp_1.color_ramp.elements[2].position = 1.0000
    colorramp_1.color_ramp.elements[2].color = [0.1574, 0.1149, 0.0840, 1.0000]
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Generated"], 'Scale': 20.0000, 'Detail': 5.0000, 'Roughness': 0.8083})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_1.outputs["Color"], 7: noise_texture_1.outputs["Fac"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp.outputs["Color"], 6: mix_1.outputs[2], 7: (0.4525, 0.0153, 0.0000, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_1})
    colorramp_2.color_ramp.elements[0].position = 0.0091
    colorramp_2.color_ramp.elements[0].color = [0.1800, 0.1800, 0.1800, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [0.7808, 0.7808, 0.7808, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0100, 'Height': colorramp_2.outputs["Color"]})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Normal': bump},
        attrs={'subsurface_method': 'BURLEY'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf_1}, attrs={'is_active_output': True})

def shader_cottage_logs_flooring(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Generated"]})
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (8.5500, 1.0000, 5.0000)})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    group = nw.new_node(nodegroup_main_logs().name, input_kwargs={0: mapping, 1: reroute_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group.outputs["BSDF"]}, attrs={'is_active_output': True})

def shader_cottage_logs_inside_walls(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Generated"]})
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': reroute, 'Scale': (1.0000, 1.0000, 8.8300)})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    group = nw.new_node(nodegroup_main_logs().name, input_kwargs={0: mapping, 1: reroute_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group.outputs["BSDF"]}, attrs={'is_active_output': True})

def shader_cottage_logs_horizontal_m_a_i_n(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Generated"]})
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': reroute, 'Scale': (1.0000, 1.0000, 8.8300)})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    group = nw.new_node(nodegroup_main_logs().name, input_kwargs={0: mapping, 1: reroute_1})
    
    group_1 = nw.new_node(nodegroup_snow_on_buildings().name,
        input_kwargs={'Shader': group.outputs["BSDF"], 'Normal': group.outputs["Normal"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group_1}, attrs={'is_active_output': True})

def shader_cottage_logs_vertical(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Generated"]})
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (7.2700, 7.2700, 0.4600)})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': mapping, 'Scale': 1.0000, 'Distortion': 10.7000, 'Detail': 6.0000, 'Detail Scale': 13.4200, 'Detail Roughness': 0.7769},
        attrs={'rings_direction': 'Y', 'bands_direction': 'Z'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': wave_texture.outputs["Fac"]})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_1})
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.5797, 0.4151, 0.3491, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.6864
    colorramp.color_ramp.elements[1].color = [0.2620, 0.2086, 0.1689, 1.0000]
    colorramp.color_ramp.elements[2].position = 1.0000
    colorramp.color_ramp.elements[2].color = [0.2785, 0.2355, 0.2043, 1.0000]
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute, 'Scale': 20.0000, 'Detail': 5.0000, 'Roughness': 0.8083})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: noise_texture.outputs["Fac"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_1})
    colorramp_1.color_ramp.elements[0].position = 0.0091
    colorramp_1.color_ramp.elements[0].color = [0.1800, 0.1800, 0.1800, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [0.7808, 0.7808, 0.7808, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0150, 'Height': colorramp_1.outputs["Color"]})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Normal': bump},
        attrs={'subsurface_method': 'BURLEY'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': bump})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    group_1 = nw.new_node(nodegroup_snow_on_buildings().name, input_kwargs={'Shader': principled_bsdf_1, 'Normal': reroute_3})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group_1}, attrs={'is_active_output': True})

def shader_bricks(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    object_info = nw.new_node(Nodes.ObjectInfo_Shader)
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': object_info.outputs["Random"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0478, 0.0037, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.2873, 0.0910, 0.0615, 1.0000]
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': colorramp.outputs["Color"]})
    
    geometry = nw.new_node(Nodes.NewGeometry)
    
    group_1 = nw.new_node(nodegroup_snow_on_buildings().name,
        input_kwargs={'Shader': principled_bsdf, 'Normal': geometry.outputs["Normal"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group_1}, attrs={'is_active_output': True})

def shader_snow(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_s_n_o_w_m_a_i_n().name)
    
    material_output_1 = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloatDistance', 'Width', 3.0000),
            ('NodeSocketFloatDistance', 'Length', 3.0000),
            ('NodeSocketFloat', 'Height', 3.0000),
            ('NodeSocketFloatDistance', 'Roof Height', 3.0000),
            ('NodeSocketFloat', 'Destroy', 0.0000),
            ('NodeSocketBool', 'Snow', True),
            ('NodeSocketBool', 'Chimney', False),
            ('NodeSocketFloat', 'DOOR z pos', -0.4100),
            ('NodeSocketFloat', 'DOOR width', 0.9600),
            ('NodeSocketFloat', 'DOOR height', 2.1700),
            ('NodeSocketInt', 'DOOR count', 1),
            ('NodeSocketBool', 'DOOR / WINDOW', True),
            ('NodeSocketFloat', 'WINDOW z pos', 0.0000),
            ('NodeSocketFloat', 'WINDOW width', 1.1900),
            ('NodeSocketFloat', 'WINDOW height', 1.6400),
            ('NodeSocketInt', 'WINDOW count', 2),
            ('NodeSocketBool', 'DOOR / WINDOW_1', False),
            ('NodeSocketInt', 'Log Profiles', 3)])
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Width"]})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    grid = nw.new_node(Nodes.MeshGrid,
        input_kwargs={'Size X': reroute_19, 'Size Y': reroute_17, 'Vertices X': 2, 'Vertices Y': 2})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid.outputs["Mesh"], 'Name': 'uv_map', 3: grid.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    edge_normal = nw.new_node(nodegroup_edge_normal().name, input_kwargs={'Geometry': store_named_attribute})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': edge_normal.outputs["Geometry"]})
    
    mesh_to_points = nw.new_node(Nodes.MeshToPoints, input_kwargs={'Mesh': reroute_55}, attrs={'mode': 'EDGES'})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mesh_to_points})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Height"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_25})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': edge_normal.outputs["edge normal"]})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_60})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_56})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["WINDOW width"]})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["WINDOW height"]})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["WINDOW z pos"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Roof Height"]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Destroy"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR / WINDOW_1"]})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["WINDOW count"]})
    
    walls_f = nw.new_node(nodegroup_w_a_l_l_s_f().name,
        input_kwargs={'Points': reroute_4, 'X/Y': reroute, 'X/Y Invert': reroute_6, 'Z': reroute_1, 'WALLS': 2.5000, 'ROTATE': reroute_57, 'Wall Z Offset': 0.1400, 'Random Scale': 1.0400, 'hole width': reroute_39, 'hole height': reroute_43, 'hole z pos': reroute_31, 'Switch holepos xy': True, 'Roof Height': reroute_13, 'Roof_Flip_When_needed': True, 'destruction value': reroute_10, 'Roof Holders Extend': 0.3100, 'DOOR / WINDOW': reroute_69, 'Count': reroute_53})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_25})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR width"]})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR height"]})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR z pos"]})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR / WINDOW"]})
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["DOOR count"]})
    
    walls_f_1 = nw.new_node(nodegroup_w_a_l_l_s_f().name,
        input_kwargs={'Points': reroute_26, 'X/Y': reroute_2, 'X/Y Invert': reroute_5, 'Z': reroute_3, 'WALLS': 0.5000, 'ROTATE': reroute_56, 'Random Scale': 1.1000, 'hole width': reroute_40, 'hole height': reroute_44, 'hole z pos': reroute_30, 'Roof Switch': True, 'Roof Height': reroute_14, 'Roof Extend': 1.5400, 'destruction value': reroute_11, 'Roof Holders Extend': 0.0900, 'DOOR / WINDOW': reroute_70, 'Count': reroute_54})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [walls_f.outputs["Base"], walls_f_1.outputs["Base"]]})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': join_geometry, 'Count': 12, 'Length': 0.3500},
        attrs={'mode': 'LENGTH'})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Log Profiles"]})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_72})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_73})
    
    log_profile = nw.new_node(nodegroup_l_o_g_p_r_o_f_i_l_e().name, input_kwargs={'Curve': resample_curve_1, 'Profiles': reroute_46})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': log_profile, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_horizontal_m_a_i_n)})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material})
    
    sample_nearest = nw.new_node(Nodes.SampleNearest,
        input_kwargs={'Geometry': edge_normal.outputs["Geometry"]},
        attrs={'domain': 'EDGE'})
    
    sample_index = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': edge_normal.outputs["Geometry"], 3: edge_normal.outputs["edge normal"], 'Index': sample_nearest},
        attrs={'domain': 'EDGE', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': sample_index.outputs[2]})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    floor_materials_with_dotproduct = nw.new_node(nodegroup_floor_materials_with_dot_product().name, input_kwargs={'Vector_1': reroute_67})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': floor_materials_with_dotproduct})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_45})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_61, 'Selection': reroute_71, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_inside_walls)})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_1})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': walls_f_1.outputs["Roof Tiles"]})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': walls_f.outputs["Roof Tiles"]})
    
    join_geometry_6 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_47, reroute_49]})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_6, 'Material': surface.shaderfunc_to_material(shader_bricks)})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': walls_f_1.outputs["Roof"]})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': walls_f.outputs["Roof"]})
    
    join_geometry_7 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_52, reroute_51]})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_7, 'Material': surface.shaderfunc_to_material(shader_cottage_logs_horizontal_m_a_i_n)})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_2, set_material_3]})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_3})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_34})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    floor = nw.new_node(nodegroup_floor().name, input_kwargs={'Geometry': reroute_48, 'Value': reroute_42})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': floor.outputs["FLOOR"], 'Material': surface.shaderfunc_to_material(shader_cottage_logs_flooring)})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_4})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_59, reroute_58, reroute_50]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 2.0000, 'Detail': 1.0000, 'Roughness': 0.2500})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (2.0000, 2.0000, 2.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Destroy"]})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_32, 3: 0.0750, 4: 0.1500})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: map_range.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1.outputs["Vector"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': join_geometry_1, 'Offset': reroute_37})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_48})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Height"]})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Chimney"]})
    
    chimney = nw.new_node(nodegroup_chimney().name,
        input_kwargs={'Mesh': reroute_36, 'height': reroute_35, 'length': reroute_34, 'Switch': reroute_38})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': chimney.outputs["Chimney"]})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [walls_f_1.outputs["Roof Pilars And Windows"], walls_f.outputs["Roof Pilars And Windows"]]})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_2})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Snow"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    snow = nw.new_node(nodegroup_s_n_o_w().name, input_kwargs={'Switch': reroute_8, 'True': join_geometry_3})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': snow})
    
    join_geometry_4 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_position_1, reroute_33, reroute_41, reroute_27]})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': join_geometry_4, 'Offset': (0.0000, 0.0000, 0.3000)})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': floor.outputs["ROCKS"]})
    
    set_material_5 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_29, 'Material': surface.shaderfunc_to_material(shader_rock_base)})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_5})
    
    join_geometry_5 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_position_2, reroute_28]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry_5}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_snow, selection=selection)
    surface.add_material(obj, shader_bricks, selection=selection)
    surface.add_material(obj, shader_cottage_logs_vertical, selection=selection)
    surface.add_material(obj, shader_cottage_logs_horizontal_m_a_i_n, selection=selection)
    surface.add_material(obj, shader_cottage_logs_inside_walls, selection=selection)
    surface.add_material(obj, shader_cottage_logs_flooring, selection=selection)
    surface.add_material(obj, shader_window_frames_outside, selection=selection)
    surface.add_material(obj, shader_window_frames_inside, selection=selection)
    surface.add_material(obj, shader_window_glass, selection=selection)
    surface.add_material(obj, shader_rock_base, selection=selection)
apply(bpy.context.active_object)