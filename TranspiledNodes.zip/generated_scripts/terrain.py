import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.8000, 0.5659, 0.2668, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_1 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Seed', 0),
            ('NodeSocketInt', 'Edges per Kink', 3),
            ('NodeSocketBool', 'Add Fringes', False)])
    
    set_spline_cyclic = nw.new_node('GeometryNodeSetSplineCyclic',
        input_kwargs={'Geometry': group_input_1.outputs["Geometry"], 'Cyclic': True})
    
    fill_curve = nw.new_node(Nodes.FillCurve, input_kwargs={'Curve': set_spline_cyclic}, attrs={'mode': 'NGONS'})
    
    random_value_2 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0000, 0.0000, 0.5000), 1: (0.0000, 0.0000, 2.0000), 2: 0.5000, 3: 2.0000, 'Seed': group_input_1.outputs["Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: random_value_2.outputs["Value"], 1: position_1})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': fill_curve, 1: add.outputs["Vector"]},
        attrs={'domain': 'FACE', 'data_type': 'FLOAT_VECTOR'})
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 'Name': 'Peak Position', 3: capture_attribute.outputs["Attribute"]},
        attrs={'domain': 'EDGE', 'data_type': 'FLOAT_VECTOR'})
    
    position = nw.new_node(Nodes.InputPosition)
    
    normalize = nw.new_node(Nodes.VectorMath, input_kwargs={0: position}, attrs={'operation': 'NORMALIZE'})
    
    index = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math,
        input_kwargs={0: index, 1: group_input_1.outputs["Edges per Kink"]},
        attrs={'operation': 'MODULO'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue, input_kwargs={3: 0.1500, 'Seed': group_input_1.outputs["Seed"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: modulo, 1: random_value_1.outputs[1]}, attrs={'operation': 'MULTIPLY'})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normalize.outputs["Vector"], 'Scale': multiply},
        attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': store_named_attribute_2, 'Offset': scale.outputs["Vector"]})
    
    flip_faces = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': set_position})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'Peak Position'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': named_attribute_1.outputs["Attribute"]})
    
    extrude_mesh = nw.new_node(Nodes.ExtrudeMesh,
        input_kwargs={'Mesh': set_position, 'Offset Scale': separate_xyz.outputs["Z"], 'Individual': False})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [flip_faces, extrude_mesh.outputs["Mesh"]]})
    
    merge_by_distance_1 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': join_geometry_1})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Seed"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    random_value_4 = nw.new_node(Nodes.RandomValue,
        input_kwargs={'Probability': 0.6667, 'Seed': reroute_1},
        attrs={'data_type': 'BOOLEAN'})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry,
        input_kwargs={'Geometry': set_position, 'Selection': random_value_4.outputs[3]},
        attrs={'domain': 'EDGE'})
    
    is_shade_smooth = nw.new_node('GeometryNodeInputShadeSmooth')
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': separate_geometry.outputs["Selection"], 4: is_shade_smooth},
        attrs={'domain': 'FACE', 'data_type': 'BOOLEAN'})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'Peak Position'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    position_2 = nw.new_node(Nodes.InputPosition)
    
    multiply_add = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: named_attribute_2.outputs["Attribute"], 1: (-1.0000, -1.0000, 0.0000), 2: position_2},
        attrs={'operation': 'MULTIPLY_ADD'})
    
    random_value_5 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.1000, 3: 0.2000, 'Seed': reroute_1})
    
    extrude_mesh_1 = nw.new_node(Nodes.ExtrudeMesh,
        input_kwargs={'Mesh': capture_attribute_1.outputs["Geometry"], 'Offset': multiply_add.outputs["Vector"], 'Offset Scale': random_value_5.outputs[1]},
        attrs={'mode': 'EDGES'})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth,
        input_kwargs={'Geometry': extrude_mesh_1.outputs["Mesh"], 'Shade Smooth': capture_attribute_1.outputs[4]})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    dot_product = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal, 1: (0.0000, 0.0000, -1.0000)},
        attrs={'operation': 'DOT_PRODUCT'})
    
    flip_faces_1 = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': set_shade_smooth, 'Selection': dot_product.outputs["Value"]})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': named_attribute_2.outputs["Attribute"]})
    
    random_value_6 = nw.new_node(Nodes.RandomValue, input_kwargs={3: separate_xyz_1.outputs["Z"], 'Seed': reroute_1})
    
    extrude_mesh_2 = nw.new_node(Nodes.ExtrudeMesh,
        input_kwargs={'Mesh': flip_faces_1, 'Offset Scale': random_value_6.outputs[1], 'Individual': False})
    
    flip_faces_2 = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': flip_faces_1})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [extrude_mesh_2.outputs["Mesh"], flip_faces_2]})
    
    merge_by_distance_2 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': join_geometry_2})
    
    union = nw.new_node(Nodes.MeshBoolean,
        input_kwargs={'Mesh 2': [merge_by_distance_2, merge_by_distance_1], 'Self Intersection': True},
        attrs={'operation': 'UNION'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_1.outputs["Add Fringes"], 14: merge_by_distance_1, 15: union.outputs["Mesh"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': extrude_mesh.outputs["Top"]})
    
    op_or = nw.new_node(Nodes.BooleanMath,
        input_kwargs={0: reroute_5, 1: extrude_mesh_2.outputs["Top"]},
        attrs={'operation': 'OR'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    random_value_3 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.4100, 3: 0.7100, 'Seed': reroute_3})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'Peak Position'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    random_value_7 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-1.0000, -1.0000, 0.0000), 'ID': reroute_7, 'Seed': reroute_7},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    add_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: named_attribute.outputs["Attribute"], 1: random_value_7.outputs["Value"]})
    
    scale_elements = nw.new_node(Nodes.ScaleElements,
        input_kwargs={'Geometry': switch.outputs[6], 'Selection': op_or, 'Scale': random_value_3.outputs[1], 'Center': add_1.outputs["Vector"], 'Axis': (1.0000, 1.0000, 0.0000)})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': scale_elements})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_material}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_material, selection=selection)
apply(bpy.context.active_object)