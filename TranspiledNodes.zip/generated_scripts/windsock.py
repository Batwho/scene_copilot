import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_windsock_sock_shader', singleton=False, type='ShaderNodeTree')
def nodegroup_windsock_sock_shader(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketColor', 'Base Color', (0.8000, 0.0304, 0.0000, 1.0000))])
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': group_input.outputs["Base Color"]})
    
    uv_map = nw.new_node(Nodes.UVMap)
    
    magic_texture = nw.new_node(Nodes.MagicTexture, input_kwargs={'Vector': uv_map, 'Scale': 250.0000})
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': 0.1000, 'Distance': 0.0100, 'Height': magic_texture.outputs["Fac"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': group_input.outputs["Base Color"], 'Normal': bump})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': 0.9000, 1: translucent_bsdf, 2: principled_bsdf})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'BSDF': mix_shader}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_wind_speed_curve', singleton=False, type='GeometryNodeTree')
def nodegroup_wind_speed_curve(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketFloat', 'Wind Speed', 1.0000)])
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["Wind Speed"], 2: 100.0000},
        attrs={'clamp': False})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.3182, 0.7063), (1.0000, 1.0000)])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 4: 100.0000}, attrs={'clamp': False})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Value': map_range_1.outputs["Result"]},
        attrs={'is_active_output': True})

def shader_windsock_sock_white(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_windsock_sock_shader().name, input_kwargs={'Base Color': (0.8000, 0.8000, 0.8000, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_windsock_sock_red(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_windsock_sock_shader().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_windsock_post(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.1546, 0.1546, 0.1546, 1.0000), 'Metallic': 1.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_windsock_bands(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.0120, 0.0120, 0.0120, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    object_info_1 = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': bpy.data.objects['Windsock.Sock']})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    position = nw.new_node(Nodes.InputPosition)
    
    scene_time = nw.new_node('GeometryNodeInputSceneTime')
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Wind Speed', 25.0000),
            ('NodeSocketFloat', 'Distortion Amount', 1.0000),
            ('NodeSocketFloat', 'Wind Direction', 0.0000)])
    
    windspeedcurve = nw.new_node(nodegroup_wind_speed_curve().name, input_kwargs={'Wind Speed': group_input.outputs["Wind Speed"]})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: scene_time.outputs["Seconds"], 1: windspeedcurve},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: combine_xyz})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': add.outputs["Vector"], 'Scale': 0.2100})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': noise_texture.outputs["Fac"], 3: -0.3000, 4: 0.3000})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range.outputs["Result"], 1: group_input.outputs["Distortion Amount"]},
        attrs={'operation': 'MULTIPLY'})
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal, 'Scale': multiply_1}, attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': object_info_1.outputs["Geometry"], 'Offset': scale.outputs["Vector"]})
    
    scene_time_1 = nw.new_node('GeometryNodeInputSceneTime')
    
    windspeedcurve_1 = nw.new_node(nodegroup_wind_speed_curve().name, input_kwargs={'Wind Speed': group_input.outputs["Wind Speed"]})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: scene_time_1.outputs["Seconds"], 1: windspeedcurve_1},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_2, 1: 0.4000}, attrs={'operation': 'MULTIPLY'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'W': multiply_3, 'Scale': 0.2500}, attrs={'noise_dimensions': '4D'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_1.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 0.6000
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: value, 1: group_input.outputs["Distortion Amount"]},
        attrs={'operation': 'MULTIPLY'})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (0.5000, 0.5000, 0.5000), 'Scale': multiply_4},
        attrs={'operation': 'SCALE'})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position, 'Offset': scale_1.outputs["Vector"]})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    scene_time_2 = nw.new_node('GeometryNodeInputSceneTime')
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["Wind Speed"], 2: 100.0000})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_4.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 1.0000), (0.4364, 0.0000)])
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 4: 10.0000})
    
    multiply_5 = nw.new_node(Nodes.Math,
        input_kwargs={0: scene_time_2.outputs["Seconds"], 1: map_range_5.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_5})
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: combine_xyz_4})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': add_1.outputs["Vector"], 'Scale': 0.1000})
    
    subtract_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_2.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_6 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract_1.outputs["Vector"], 1: (0.1000, 0.1000, 5.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_7 = nw.new_node(Nodes.Math,
        input_kwargs={0: float_curve_2, 1: group_input.outputs["Distortion Amount"]},
        attrs={'operation': 'MULTIPLY'})
    
    scale_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_6.outputs["Vector"], 'Scale': multiply_7},
        attrs={'operation': 'SCALE'})
    
    set_position_4 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_1, 'Offset': scale_2.outputs["Vector"]})
    
    extrude_mesh = nw.new_node(Nodes.ExtrudeMesh, input_kwargs={'Mesh': set_position_4, 'Offset Scale': 0.0100, 'Individual': False})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [extrude_mesh.outputs["Mesh"], set_position_4]})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': join_geometry_2})
    
    object_info = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': bpy.data.objects['Windsock.Bands']})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 0})
    
    geometry_proximity = nw.new_node(Nodes.Proximity, input_kwargs={'Target': set_position}, attrs={'target_element': 'POINTS'})
    
    set_position_2 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': object_info.outputs["Geometry"], 'Selection': endpoint_selection, 'Position': geometry_proximity.outputs["Position"]})
    
    endpoint_selection_1 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 0})
    
    set_position_3 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_position_2, 'Selection': endpoint_selection_1, 'Offset': scale_1.outputs["Vector"]})
    
    endpoint_selection_2 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 0})
    
    set_position_5 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_position_3, 'Selection': endpoint_selection_2, 'Offset': scale_2.outputs["Vector"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_position_5, 'Count': 20})
    
    grid = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 0.0100, 'Size Y': 0.0400, 'Vertices X': 2, 'Vertices Y': 2})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid.outputs["Mesh"], 'Name': 'uv_map', 3: grid.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    mesh_to_curve_1 = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': store_named_attribute})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': resample_curve, 'Profile Curve': mesh_to_curve_1})
    
    flip_faces = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': curve_to_mesh})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': flip_faces, 'Shade Smooth': False})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_windsock_bands)})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_material})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [merge_by_distance, set_shade_smooth_1]})
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["Wind Speed"], 2: 100.0000})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_3.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.2500), (0.1273, 0.6938), (1.0000, 1.0000)])
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 1.0000, 'Y': 1.0000, 'Z': float_curve_1})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': join_geometry, 'Scale': combine_xyz_2})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["Wind Speed"], 2: 100.0000})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_1.outputs["Result"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0200), (0.2318, 0.7313), (1.0000, 1.0000)])
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: -90.0000}, attrs={'operation': 'RADIANS'})
    
    radians_1 = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000}, attrs={'operation': 'RADIANS'})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve, 3: radians, 4: radians_1})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_2.outputs["Result"]})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': transform_1, 'Rotation': combine_xyz_1})
    
    radians_2 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Wind Direction"]}, attrs={'operation': 'RADIANS'})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: radians_2, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_8})
    
    transform_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': transform, 'Rotation': combine_xyz_3})
    
    transform_3 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': transform_2, 'Translation': (0.0000, 0.0000, 10.1000)})
    
    object_info_2 = nw.new_node(Nodes.ObjectInfo, input_kwargs={'Object': bpy.data.objects['Windsock.Post']})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [transform_3, object_info_2.outputs["Geometry"]]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry_1}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_windsock_bands, selection=selection)
    surface.add_material(obj, shader_windsock_post, selection=selection)
    surface.add_material(obj, shader_windsock_sock_red, selection=selection)
    surface.add_material(obj, shader_windsock_sock_white, selection=selection)
apply(bpy.context.active_object)