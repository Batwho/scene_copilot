import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_wall_wood', singleton=False, type='ShaderNodeTree')
def nodegroup_wall_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    geometry_1 = nw.new_node(Nodes.NewGeometry)
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': geometry_1.outputs["Normal"]})
    
    color_ramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': separate_xyz_1.outputs["Z"]})
    color_ramp_1.color_ramp.elements[0].position = 0.7455
    color_ramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_1.color_ramp.elements[1].position = 0.9273
    color_ramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'vector multiply', (2.0000, 2.0000, 0.1000)),
            ('NodeSocketFloat', 'dark marks multiply', 1.0000),
            ('NodeSocketColor', 'color lighter', (0.4120, 0.1625, 0.0639, 1.0000)),
            ('NodeSocketColor', 'color darker', (0.0200, 0.0109, 0.0058, 1.0000)),
            ('NodeSocketFloat', 'color power', 0.7000),
            ('NodeSocketFloat', 'wood roughness dark', 0.3000),
            ('NodeSocketFloat', 'wood roughness light', 0.8000),
            ('NodeSocketFloat', 'clearcoat factor', 1.0000),
            ('NodeSocketFloat', 'clearcoat roughness noise low', 0.2000),
            ('NodeSocketFloat', 'clearcoat roughness noise high', 0.5000),
            ('NodeSocketFloat', 'clearcoat random spot roughness', 0.7000),
            ('NodeSocketColor', 'Coat Tint', (1.0000, 0.6712, 0.3657, 1.0000)),
            ('NodeSocketFloat', 'sheen factor', 1.0000),
            ('NodeSocketFloat', 'clearcoat edge  noise', 3.0000),
            ('NodeSocketFloat', 'clearcoat edge factor', 1.0000)])
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Object"]})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_2, 1: group_input_5.outputs["vector multiply"]},
        attrs={'operation': 'MULTIPLY'})
    
    geometry = nw.new_node(Nodes.NewGeometry)
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 43.7000},
        attrs={'operation': 'MULTIPLY'})
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: multiply_1, 3: 0.7854})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': multiply.outputs["Vector"], 'Rotation': mix.outputs["Result"]},
        attrs={'rotation_type': 'EULER_XYZ'})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 43.7000},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': vector_rotate, 'W': multiply_2, 'Detail': 9.4000, 'Roughness': 0.6167},
        attrs={'noise_dimensions': '4D'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 102.4000},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': noise_texture.outputs["Fac"], 'W': multiply_3},
        attrs={'noise_dimensions': '4D'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    color_ramp.color_ramp.interpolation = "CONSTANT"
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.0000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.3977
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.4261
    color_ramp.color_ramp.elements[2].color = [0.0892, 0.0892, 0.0892, 1.0000]
    color_ramp.color_ramp.elements[3].position = 0.4555
    color_ramp.color_ramp.elements[3].color = [0.3178, 0.3178, 0.3178, 1.0000]
    color_ramp.color_ramp.elements[4].position = 0.4849
    color_ramp.color_ramp.elements[4].color = [0.0669, 0.0669, 0.0669, 1.0000]
    color_ramp.color_ramp.elements[5].position = 0.5166
    color_ramp.color_ramp.elements[5].color = [0.8509, 0.8509, 0.8509, 1.0000]
    color_ramp.color_ramp.elements[6].position = 0.5483
    color_ramp.color_ramp.elements[6].color = [0.5446, 0.5446, 0.5446, 1.0000]
    color_ramp.color_ramp.elements[7].position = 0.5955
    color_ramp.color_ramp.elements[7].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    color_ramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': color_ramp.outputs["Color"]})
    color_ramp_2.color_ramp.elements.new(0)
    color_ramp_2.color_ramp.elements.new(0)
    color_ramp_2.color_ramp.elements[0].position = 0.1909
    color_ramp_2.color_ramp.elements[0].color = [0.1101, 0.1101, 0.1101, 1.0000]
    color_ramp_2.color_ramp.elements[1].position = 0.2182
    color_ramp_2.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_2.color_ramp.elements[2].position = 0.2500
    color_ramp_2.color_ramp.elements[2].color = [0.0727, 0.0727, 0.0727, 1.0000]
    color_ramp_2.color_ramp.elements[3].position = 1.0000
    color_ramp_2.color_ramp.elements[3].color = [0.5410, 0.5410, 0.5410, 1.0000]
    
    power = nw.new_node(Nodes.Math,
        input_kwargs={0: color_ramp_2.outputs["Color"], 1: group_input_5.outputs["color power"]},
        attrs={'operation': 'POWER'})
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 261.1000},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture_5 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'W': multiply_4, 'Detail': 1.7000, 'Roughness': 0.7250, 'Distortion': 0.1000},
        attrs={'noise_dimensions': '4D'})
    
    multiply_5 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 354.3000},
        attrs={'operation': 'MULTIPLY'})
    
    musgrave_texture = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'Vector': noise_texture_5.outputs["Color"], 'W': multiply_5, 'Scale': 0.8000, 'Detail': 7.4000, 'Dimension': 0.1000},
        attrs={'musgrave_dimensions': '4D'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: musgrave_texture, 1: 0.0000}, attrs={'use_clamp': True})
    
    color_ramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add})
    color_ramp_4.color_ramp.interpolation = "CONSTANT"
    color_ramp_4.color_ramp.elements.new(0)
    color_ramp_4.color_ramp.elements.new(0)
    color_ramp_4.color_ramp.elements.new(0)
    color_ramp_4.color_ramp.elements[0].position = 0.0000
    color_ramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_4.color_ramp.elements[1].position = 0.3636
    color_ramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    color_ramp_4.color_ramp.elements[2].position = 0.4241
    color_ramp_4.color_ramp.elements[2].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_4.color_ramp.elements[3].position = 0.4620
    color_ramp_4.color_ramp.elements[3].color = [1.0000, 1.0000, 1.0000, 1.0000]
    color_ramp_4.color_ramp.elements[4].position = 0.5840
    color_ramp_4.color_ramp.elements[4].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    invert_color = nw.new_node(Nodes.Invert, input_kwargs={'Color': color_ramp_4.outputs["Color"]})
    
    mix_15 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input_5.outputs["dark marks multiply"], 6: power, 7: invert_color},
        attrs={'blend_type': 'MULTIPLY', 'clamp_result': True, 'data_type': 'RGBA'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_15.outputs[2]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["color darker"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["color lighter"]})
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute_5, 6: reroute_4, 7: reroute_3}, attrs={'data_type': 'RGBA'})
    
    multiply_6 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 242.9000},
        attrs={'operation': 'MULTIPLY'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': reroute_2, 'W': multiply_6, 'Scale': 5000.0000},
        attrs={'voronoi_dimensions': '4D'})
    
    white_noise_texture = nw.new_node(Nodes.WhiteNoiseTexture, input_kwargs={'Vector': voronoi_texture.outputs["Position"]})
    
    mix_11 = nw.new_node(Nodes.Mix,
        input_kwargs={0: white_noise_texture.outputs["Value"], 6: reroute_4, 7: reroute_3},
        attrs={'data_type': 'RGBA'})
    
    mix_12 = nw.new_node(Nodes.Mix,
        input_kwargs={0: color_ramp_1.outputs["Color"], 6: mix_1.outputs[2], 7: mix_11.outputs[2]},
        attrs={'data_type': 'RGBA'})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: color_ramp_2.outputs["Color"], 7: color_ramp.outputs["Color"]},
        attrs={'blend_type': 'MULTIPLY', 'clamp_result': True, 'data_type': 'RGBA'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: mix_2.outputs[2], 1: 0.0050}, attrs={'operation': 'GREATER_THAN'})
    
    mix_3 = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than, 2: group_input_5.outputs["wood roughness dark"], 3: group_input_5.outputs["wood roughness light"]})
    
    color_ramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    color_ramp_3.color_ramp.elements[0].position = 0.0000
    color_ramp_3.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    color_ramp_3.color_ramp.elements[1].position = 1.0000
    color_ramp_3.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: color_ramp_1.outputs["Color"], 3: 0.8000, 6: mix_3.outputs["Result"], 7: color_ramp_3.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    multiply_7 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: 53.7000},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'W': multiply_7, 'Scale': 5.7000, 'Detail': 1.5000, 'Roughness': 0.7333},
        attrs={'noise_dimensions': '4D'})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0100, 'Height': noise_texture_2.outputs["Fac"]})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0050, 'Height': color_ramp.outputs["Color"], 'Normal': bump_1})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: color_ramp_1.outputs["Color"], 7: color_ramp_3.outputs["Color"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    bump_4 = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0100, 'Height': mix_6.outputs[2], 'Normal': bump_1})
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: color_ramp_1.outputs["Color"], 6: bump, 7: bump_4},
        attrs={'data_type': 'RGBA'})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_12.outputs[2], 'Roughness': mix_9.outputs[2], 'Normal': mix_8.outputs[2]},
        attrs={'distribution': 'MULTI_GGX'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'BSDF': principled_bsdf_1, 'tmp_viewer': principled_bsdf_1},
        attrs={'is_active_output': True})

def shader_wall_fabric(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: texture_coordinate.outputs["Object"], 'Scale': 2000.0000},
        attrs={'operation': 'SCALE'})
    
    fraction = nw.new_node(Nodes.VectorMath, input_kwargs={0: scale.outputs["Vector"]}, attrs={'operation': 'FRACTION'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': fraction.outputs["Vector"]})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': separate_xyz.outputs["X"]})
    colorramp.color_ramp.interpolation = "B_SPLINE"
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.2500
    colorramp.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[2].position = 0.7500
    colorramp.color_ramp.elements[2].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[3].position = 1.0000
    colorramp.color_ramp.elements[3].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': separate_xyz.outputs["Z"]})
    colorramp_2.color_ramp.interpolation = "B_SPLINE"
    colorramp_2.color_ramp.elements.new(0)
    colorramp_2.color_ramp.elements.new(0)
    colorramp_2.color_ramp.elements[0].position = 0.0000
    colorramp_2.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.2500
    colorramp_2.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[2].position = 0.7500
    colorramp_2.color_ramp.elements[2].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[3].position = 1.0000
    colorramp_2.color_ramp.elements[3].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: colorramp_2.outputs["Color"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: divide},
        attrs={'blend_type': 'ADD', 'clamp_result': True, 'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.0020, 'Height': mix.outputs[2]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0000, 0.0000, 0.0000, 1.0000), 'Roughness': 0.5182, 'Normal': bump},
        attrs={'distribution': 'MULTI_GGX'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_wall_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_1 = nw.new_node(nodegroup_wall_wood().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput,
        input_kwargs={'Surface': group_1.outputs["tmp_viewer"]},
        attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketInt', 'quanity', 10),
            ('NodeSocketFloat', 'height', 2.5000),
            ('NodeSocketFloat', 'x dimension', 0.0500),
            ('NodeSocketFloat', 'y dimension', 0.0000),
            ('NodeSocketFloat', 'fabric border', 0.0200),
            ('NodeSocketFloat', 'fabric thickness', 0.0020),
            ('NodeSocketFloat', 'position x', 0.0000),
            ('NodeSocketFloat', 'gap', 0.0250)])
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["quanity"]})
    
    divide = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["x dimension"], 1: 2.0000},
        attrs={'operation': 'DIVIDE'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["position x"], 1: divide})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: group_input.outputs["fabric border"]})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: add_1, 1: 0.0000})
    
    divide_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["y dimension"], 1: -2.0000},
        attrs={'operation': 'DIVIDE'})
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: divide_1, 1: group_input.outputs["fabric thickness"]},
        attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_2, 'Y': subtract})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["gap"]})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8, 1: group_input.outputs["x dimension"]})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_3})
    
    mesh_line = nw.new_node(Nodes.MeshLine,
        input_kwargs={'Count': reroute_11, 'Start Location': combine_xyz_7, 'Offset': combine_xyz_6})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["height"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': divide_2})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': mesh_line, 'Offset': combine_xyz_8})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["x dimension"], 'Y': group_input.outputs["y dimension"], 'Z': group_input.outputs["height"]})
    
    cube_1 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': combine_xyz_1})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': set_position, 'Instance': cube_1.outputs["Mesh"]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points, 'Material': surface.shaderfunc_to_material(shader_wall_wood)})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_material})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': realize_instances})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input.outputs["position x"]})
    
    add_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8, 1: group_input.outputs["x dimension"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: add_4, 1: reroute_11}, attrs={'operation': 'MULTIPLY'})
    
    add_5 = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: group_input.outputs["position x"]})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: add_5, 1: group_input.outputs["gap"]}, attrs={'operation': 'SUBTRACT'})
    
    divide_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["x dimension"], 1: 2.0000},
        attrs={'operation': 'DIVIDE'})
    
    add_6 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_1, 1: divide_3})
    
    add_7 = nw.new_node(Nodes.Math, input_kwargs={0: add_6, 1: group_input.outputs["fabric border"]})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_7})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_10, 'End': combine_xyz_9})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["height"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_11 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_1})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_11})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': curve_line, 'Profile Curve': curve_line_1})
    
    combine_xyz_12 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': -1.0000})
    
    extrude_mesh = nw.new_node(Nodes.ExtrudeMesh,
        input_kwargs={'Mesh': curve_to_mesh, 'Offset': combine_xyz_12, 'Offset Scale': group_input.outputs["fabric thickness"]})
    
    flip_faces = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': extrude_mesh.outputs["Mesh"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_to_mesh, flip_faces]})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': join_geometry_1})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': merge_by_distance, 'Material': surface.shaderfunc_to_material(shader_wall_fabric)})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_shade_smooth, set_material_2]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': join_geometry, 'height': group_input.outputs["height"], 'x dimension': group_input.outputs["x dimension"], 'y dimension': group_input.outputs["y dimension"], 'gap': group_input.outputs["gap"], 'position x': group_input.outputs["position x"], 'quanity': group_input.outputs["quanity"], 'fabric border': group_input.outputs["fabric border"]},
        attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_wall_wood, selection=selection)
    surface.add_material(obj, shader_wall_fabric, selection=selection)
apply(bpy.context.active_object)