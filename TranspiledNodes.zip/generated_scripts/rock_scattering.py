import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_rock_it', singleton=False, type='GeometryNodeTree')
def nodegroup_rock_it(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Detail Level', 4),
            ('NodeSocketFloat', 'Roundness', 0.5000),
            ('NodeSocketInt', 'Seed', 0)])
    
    points = nw.new_node('GeometryNodePoints', input_kwargs={'Count': group_input.outputs["Detail Level"]})
    
    random_360_degrees = nw.new_node(Nodes.RandomValue,
        input_kwargs={1: (6.2832, 6.2832, 6.2832), 'Seed': group_input.outputs["Seed"]},
        label='Random 360 Degrees',
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    random_values_less_than_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: group_input.outputs["Roundness"], 'Seed': group_input.outputs["Seed"]},
        label='Random values less than 1',
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': points, 'Instance': group_input.outputs["Geometry"], 'Rotation': random_360_degrees.outputs["Value"], 'Scale': random_values_less_than_1.outputs["Value"]})
    
    intersect = nw.new_node(Nodes.MeshBoolean, input_kwargs={'Mesh 2': instance_on_points}, attrs={'operation': 'INTERSECT'})
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': group_input.outputs["Geometry"]})
    
    rounded_bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': intersect.outputs["Mesh"]}, label='Rounded Bounding Box')
    
    divide = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bounding_box.outputs["Max"], 1: rounded_bounding_box.outputs["Max"]},
        attrs={'operation': 'DIVIDE'})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': intersect.outputs["Mesh"], 'Scale': divide.outputs["Vector"]},
        label='Transform')
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': transform}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_select_tile_safe_x_y_mask', singleton=False, type='GeometryNodeTree')
def nodegroup_select_tile_safe_x_y_mask(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Mesh', None),
            ('NodeSocketFloatDistance', 'Radius', 0.9000)])
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': group_input.outputs["Mesh"]})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bounding_box.outputs["Min"], 1: (-1.0000, -1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    position = nw.new_node(Nodes.InputPosition)
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: multiply.outputs["Vector"], 1: position})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': add.outputs["Vector"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Radius"]})
    
    greater_than = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz_1.outputs["X"], 1: reroute},
        attrs={'operation': 'GREATER_THAN'})
    
    greater_than_1 = nw.new_node(Nodes.Compare, input_kwargs={0: separate_xyz_1.outputs["Y"], 1: reroute})
    
    op_and = nw.new_node(Nodes.BooleanMath, input_kwargs={0: greater_than, 1: greater_than_1})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Boolean': op_and}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_rock_collection', singleton=False, type='GeometryNodeTree')
def nodegroup_rock_collection(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Seed', 0)])
    
    offset_seed = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Seed"], 1: group_input.outputs["Seed"]},
        label='Offset Seed')
    
    rock_it = nw.new_node(nodegroup_rock_it().name,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Roundness': 0.2000, 'Seed': offset_seed})
    
    rock_it_1 = nw.new_node(nodegroup_rock_it().name,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Roundness': 0.2000, 'Seed': group_input.outputs["Seed"]})
    
    offset_seed_1 = nw.new_node(Nodes.Math, input_kwargs={0: offset_seed, 1: group_input.outputs["Seed"]}, label='Offset Seed')
    
    rock_it_2 = nw.new_node(nodegroup_rock_it().name,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Roundness': 0.2000, 'Seed': offset_seed_1})
    
    offset_seed_2 = nw.new_node(Nodes.Math, input_kwargs={0: offset_seed_1, 1: 1.0000}, label='Offset Seed')
    
    rock_it_3 = nw.new_node(nodegroup_rock_it().name,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Roundness': 0.2000, 'Seed': offset_seed_2})
    
    geometry_to_instance = nw.new_node('GeometryNodeGeometryToInstance',
        input_kwargs={'Geometry': [rock_it, rock_it_1, rock_it_2, rock_it_3]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': geometry_to_instance}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_tile_safe_distribute_instances', singleton=False, type='GeometryNodeTree')
def nodegroup_tile_safe_distribute_instances(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Mesh', None),
            ('NodeSocketBool', 'Selection', True),
            ('NodeSocketFloatFactor', 'Density Factor', 1.0000),
            ('NodeSocketGeometry', 'Instances', None),
            ('NodeSocketFloatDistance', 'Min Diameter', 1.0000),
            ('NodeSocketInt', 'Seed', 0)])
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': group_input.outputs["Instances"]})
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': realize_instances})
    
    length = nw.new_node(Nodes.VectorMath, input_kwargs={0: bounding_box.outputs["Max"]}, attrs={'operation': 'LENGTH'})
    
    select_tile_safe_xy_mask = nw.new_node(nodegroup_select_tile_safe_x_y_mask().name,
        input_kwargs={'Mesh': group_input.outputs["Mesh"], 'Radius': length.outputs["Value"]})
    
    op_and = nw.new_node(Nodes.BooleanMath, input_kwargs={0: select_tile_safe_xy_mask, 1: group_input.outputs["Selection"]})
    
    magic_number = nw.new_node(Nodes.Math,
        input_kwargs={0: 3.1416, 1: group_input.outputs["Min Diameter"]},
        label='Magic Number',
        attrs={'operation': 'DIVIDE'})
    
    distribute_points_on_faces = nw.new_node(Nodes.DistributePointsOnFaces,
        input_kwargs={'Mesh': group_input.outputs["Mesh"], 'Selection': op_and, 'Distance Min': length.outputs["Value"], 'Density Max': magic_number, 'Density': 0.1000, 'Density Factor': group_input.outputs["Density Factor"], 'Seed': group_input.outputs["Seed"]},
        attrs={'distribute_method': 'POISSON', 'use_legacy_normal': True})
    
    random_rotation = nw.new_node(Nodes.RandomValue,
        input_kwargs={3: 6.2832, 'Seed': group_input.outputs["Seed"]},
        label='Random Rotation')
    
    divide = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Min Diameter"], 1: length.outputs["Value"]},
        attrs={'operation': 'DIVIDE'})
    
    random_scale_down = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.7500, 0.7500, 0.7500), 1: (1.5000, 1.5000, 1.5000), 2: divide, 'Seed': group_input.outputs["Seed"]},
        label='Random Scale Down')
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': distribute_points_on_faces.outputs["Points"], 'Instance': group_input.outputs["Instances"], 'Pick Instance': True, 'Rotation': random_rotation.outputs[1], 'Scale': random_scale_down.outputs[1]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': instance_on_points}, attrs={'is_active_output': True})

def shader_rock(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0908, 0.0908, 0.0908, 1.0000), 'Specular': 0.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_ground(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0145, 0.0072, 0.0000, 1.0000), 'Specular': 0.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_cobble(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_1 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloatFactor', 'Density Factor', 1.0000),
            ('NodeSocketFloatDistance', 'Min Cobble Diameter', 0.0640),
            ('NodeSocketFloatDistance', 'Max Cobble Diameter', 0.2560),
            ('NodeSocketMaterial', 'Cobble Material', None), #surface.shaderfunc_to_material(shader_rock)
            ('NodeSocketFloatDistance', 'Max Pebble Diameter', 0.0040),
            ('NodeSocketFloatDistance', 'Min Pebble Diameter', 0.0010),
            ('NodeSocketMaterial', 'Gravel Material', None), #surface.shaderfunc_to_material(shader_rock)
            ('NodeSocketInt', 'Seed', 0)])
    
    diameter_to_radius = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Max Cobble Diameter"]},
        label='Diameter to Radius',
        attrs={'operation': 'MULTIPLY'})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': diameter_to_radius})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': store_named_attribute, 'Material': group_input_1.outputs["Cobble Material"]})
    
    rock_collection = nw.new_node(nodegroup_rock_collection().name,
        input_kwargs={'Geometry': set_material, 'Seed': group_input_1.outputs["Seed"]})
    
    tile_safe_distribute_instances = nw.new_node(nodegroup_tile_safe_distribute_instances().name,
        input_kwargs={'Mesh': group_input_1.outputs["Geometry"], 'Selection': group_input_1.outputs["Max Cobble Diameter"], 'Density Factor': group_input_1.outputs["Density Factor"], 'Instances': rock_collection, 'Min Diameter': group_input_1.outputs["Min Cobble Diameter"], 'Seed': group_input_1.outputs["Seed"]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': tile_safe_distribute_instances})
    
    geometry_proximity_1 = nw.new_node(Nodes.Proximity, input_kwargs={'Target': realize_instances})
    
    diameter_to_radius_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Max Pebble Diameter"]},
        label='Diameter to Radius',
        attrs={'operation': 'MULTIPLY'})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: geometry_proximity_1.outputs["Distance"], 1: diameter_to_radius_1})
    
    instances_to_points = nw.new_node('GeometryNodeInstancesToPoints', input_kwargs={'Instances': tile_safe_distribute_instances})
    
    geometry_proximity = nw.new_node(Nodes.Proximity, input_kwargs={'Target': instances_to_points}, attrs={'target_element': 'POINTS'})
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Max Cobble Diameter"], 1: group_input_1.outputs["Max Pebble Diameter"]},
        attrs={'operation': 'SUBTRACT'})
    
    diameter_to_radius_2 = nw.new_node(Nodes.Math, input_kwargs={0: subtract}, label='Diameter to Radius', attrs={'operation': 'MULTIPLY'})
    
    greater_than_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry_proximity.outputs["Distance"], 1: diameter_to_radius_2},
        attrs={'operation': 'GREATER_THAN'})
    
    op_and = nw.new_node(Nodes.BooleanMath, input_kwargs={0: greater_than, 1: greater_than_1})
    
    diameter_to_radius_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Max Pebble Diameter"]},
        label='Diameter to Radius',
        attrs={'operation': 'MULTIPLY'})
    
    ico_sphere_1 = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': diameter_to_radius_3})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere_1.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere_1.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': store_named_attribute_1, 'Material': group_input_1.outputs["Gravel Material"]})
    
    rock_collection_1 = nw.new_node(nodegroup_rock_collection().name,
        input_kwargs={'Geometry': set_material_1, 'Seed': group_input_1.outputs["Seed"]})
    
    tile_safe_distribute_instances_1 = nw.new_node(nodegroup_tile_safe_distribute_instances().name,
        input_kwargs={'Mesh': group_input_1.outputs["Geometry"], 'Selection': op_and, 'Density Factor': group_input_1.outputs["Density Factor"], 'Instances': rock_collection_1, 'Min Diameter': group_input_1.outputs["Min Pebble Diameter"], 'Seed': group_input_1.outputs["Seed"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [tile_safe_distribute_instances, group_input_1.outputs["Geometry"]]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [tile_safe_distribute_instances_1, join_geometry_1]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry}, attrs={'is_active_output': True})

def geometry_ground(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Displacement', 1.0000)])
    
    normal = nw.new_node(Nodes.InputNormal)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 2.0000, 'Detail': 1.0000, 'Distortion': 0.2000})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: noise_texture.outputs["Fac"]}, attrs={'operation': 'SUBTRACT'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': subtract})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.4136, 0.1938), (0.5864, 0.4625), (0.8227, 0.8063), (1.0000, 1.0000)])
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: float_curve, 1: group_input.outputs["Displacement"]},
        attrs={'operation': 'MULTIPLY'})
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal, 'Scale': multiply}, attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Offset': scale.outputs["Vector"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position, 'Offset': scale.outputs["Vector"]})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_1, 'Offset': scale.outputs["Vector"]})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_2, 'Offset': scale.outputs["Vector"]})
    
    set_position_4 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_3, 'Offset': scale.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_4}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_ground, selection=selection, attributes=[])
    surface.add_geomod(obj, geometry_cobble, selection=selection, attributes=[])
    surface.add_material(obj, shader_ground, selection=selection)
    surface.add_material(obj, shader_rock, selection=selection)
apply(bpy.context.active_object)