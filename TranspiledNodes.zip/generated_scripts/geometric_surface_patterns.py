import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_wood', singleton=False, type='ShaderNodeTree')
def nodegroup_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_3 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketColor', 'Color1', (0.3849, 0.1517, 0.0509, 1.0000)),
            ('NodeSocketColor', 'Color2', (0.6970, 0.4054, 0.0973, 1.0000)),
            ('NodeSocketFloatFactor', 'Panelling', 1.0000),
            ('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000))])
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': group_input_3.outputs["Vector"], 'Scale': 7.0000})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0610, 6: group_input_3.outputs["Vector"], 7: noise_texture_2.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': mix_2.outputs[2], 'Scale': 60.0000, 'Distortion': 6.9000, 'Detail': 5.7000, 'Detail Scale': 1.1100, 'Phase Offset': -6.5200})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': group_input_3.outputs["Vector"], 'Scale': 10.4000})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': noise_texture_1.outputs["Fac"], 1: 0.2000, 2: 8.4200},
        attrs={'clamp': False})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': wave_texture.outputs["Color"], 2: map_range_2.outputs["Result"], 3: 1.2000, 4: 2.5000},
        attrs={'clamp': False})
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': group_input_3.outputs["Vector"], 'Scale': (1.0000, 0.0500, 1.0000)})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mapping, 'Scale': 394.0000})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': noise_texture.outputs["Fac"], 1: 0.3100})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: map_range_1.outputs["Result"], 7: map_range.outputs["Result"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix.outputs[2]})
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Color': group_input_3.outputs["Panelling"]})
    
    mapping_1 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': group_input_3.outputs["Vector"], 'Rotation': (0.0000, 0.0000, 1.5708)})
    
    brick_texture = nw.new_node(Nodes.BrickTexture,
        input_kwargs={'Vector': mapping_1, 'Color2': (0.0601, 0.0601, 0.0601, 1.0000), 'Scale': 10.0000, 'Mortar Smooth': 1.0000, 'Brick Width': 1.7600})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: invert, 6: brick_texture.outputs["Color"], 7: (1.0000, 1.0000, 1.0000, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_6.outputs[2]})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: reroute_3, 7: reroute_2},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: mix_4.outputs[2], 6: group_input_3.outputs["Color1"], 7: group_input_3.outputs["Color2"]},
        attrs={'data_type': 'RGBA'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix.outputs[2]})
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0140, 6: reroute_2, 7: reroute},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Height': mix_5.outputs[2]})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.0200, 'Height': map_range.outputs["Result"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_1.outputs[2], 'Specular': 0.2582, 'Specular Tint': 0.8655, 'Roughness': 1.0000, 'Clearcoat': 0.2909, 'Clearcoat Roughness': 0.1900, 'Normal': bump, 'Clearcoat Normal': bump_1})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'BSDF': principled_bsdf}, attrs={'is_active_output': True})

def shader_dark_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: texture_coordinate.outputs["Generated"], 'Scale': 0.5000},
        attrs={'operation': 'SCALE'})
    
    group = nw.new_node(nodegroup_wood().name,
        input_kwargs={'Color1': (0.0175, 0.0088, 0.0043, 1.0000), 'Color2': (0.0861, 0.0269, 0.0156, 1.0000), 'Panelling': 0.0000, 'Vector': scale.outputs["Vector"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Roughness': 0.4000},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Points 1', 8),
            ('NodeSocketFloatDistance', 'Inner Radius 1', 1.0000),
            ('NodeSocketFloatDistance', 'Outer Radius 1', 1.0000),
            ('NodeSocketFloatAngle', 'Twist 1', 0.0000),
            ('NodeSocketIntUnsigned', 'Points 2', 16),
            ('NodeSocketFloatDistance', 'Inner Radius 2', 1.0000),
            ('NodeSocketFloatDistance', 'Outer Radius 2', 1.0000),
            ('NodeSocketFloatAngle', 'Twist 2', 0.0000),
            ('NodeSocketFloat', 'Fillet curve 2', 0.0000),
            ('NodeSocketInt', 'Subdivision Level', 0)])
    
    star_1 = nw.new_node('GeometryNodeCurveStar',
        input_kwargs={'Points': group_input.outputs["Points 1"], 'Inner Radius': group_input.outputs["Inner Radius 1"], 'Outer Radius': group_input.outputs["Outer Radius 1"], 'Twist': group_input.outputs["Twist 1"]})
    
    star = nw.new_node('GeometryNodeCurveStar',
        input_kwargs={'Points': group_input.outputs["Points 2"], 'Inner Radius': group_input.outputs["Inner Radius 2"], 'Outer Radius': group_input.outputs["Outer Radius 2"], 'Twist': group_input.outputs["Twist 2"]})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Fillet curve 2"], 1: 0.0100},
        attrs={'operation': 'MULTIPLY'})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': star.outputs["Curve"], 'Radius': multiply, 'Limit Radius': True})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': star_1.outputs["Curve"], 'Instance': fillet_curve})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points}, attrs={'legacy_behavior': True})
    
    curve_fill = nw.new_node(Nodes.FillCurve, input_kwargs={'Curve': realize_instances}, attrs={'mode': 'NGONS'})
    
    subdivision_surface_1 = nw.new_node(Nodes.SubdivisionSurface,
        input_kwargs={'Mesh': curve_fill, 'Level': group_input.outputs["Subdivision Level"]})
    
    assign_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': subdivision_surface_1, 'Material': surface.shaderfunc_to_material(shader_dark_wood)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': assign_material}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_material, selection=selection)
apply(bpy.context.active_object)