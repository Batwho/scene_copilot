import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_e_p_a_l_wood', singleton=False, type='ShaderNodeTree')
def nodegroup_e_p_a_l_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, input_kwargs={'Distance': 0.0080}, attrs={'only_local': True, 'inside': True})
    
    invert_color = nw.new_node(Nodes.Invert, input_kwargs={'Color': ambient_occlusion.outputs["Color"]})
    
    texture_coordinate_2 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    noise_texture_3 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': texture_coordinate_2.outputs["Object"], 'Scale': 12.6000, 'Detail': 15.0000, 'Distortion': 5.1100},
        attrs={'noise_dimensions': '4D'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': noise_texture_3.outputs["Fac"], 3: -0.8200, 4: 1.8200})
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={6: invert_color, 7: map_range_1.outputs["Result"]}, attrs={'data_type': 'RGBA'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: mix_1.outputs[2], 1: 0.4500}, attrs={'operation': 'GREATER_THAN'})
    
    invert_color_1 = nw.new_node(Nodes.Invert, input_kwargs={'Color': greater_than})
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 41.5000, 'Detail': 15.0000, 'Distortion': 3.6000})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_4.outputs["Fac"]})
    color_ramp.color_ramp.elements[0].position = 0.0000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.6000
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.8000, 'Height': invert_color_1})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': color_ramp.outputs["Color"], 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Roughness': 0.6000, 'Normal': bump_1})
    
    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    musgrave_texture = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Object"], 'Scale': 3.0000, 'Detail': 1.0000})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': musgrave_texture, 'Scale': 80.0000, 'Detail': 15.0000, 'Distortion': 18.9000})
    
    color_ramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    color_ramp_2.color_ramp.elements.new(0)
    color_ramp_2.color_ramp.elements[0].position = 0.2227
    color_ramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_2.color_ramp.elements[1].position = 0.2591
    color_ramp_2.color_ramp.elements[1].color = [0.4464, 0.2164, 0.0626, 1.0000]
    color_ramp_2.color_ramp.elements[2].position = 0.4182
    color_ramp_2.color_ramp.elements[2].color = [1.0000, 0.5792, 0.2528, 1.0000]
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Object"], 'Scale': 500.0000, 'Detail': 15.0000})
    
    color_ramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    color_ramp_3.color_ramp.elements[0].position = 0.2227
    color_ramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_3.color_ramp.elements[1].position = 1.0000
    color_ramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_2 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.1000, 'Height': color_ramp_3.outputs["Color"]})
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': 0.1000, 'Height': color_ramp_2.outputs["Color"], 'Normal': bump_2})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': color_ramp_2.outputs["Color"], 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Normal': bump})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': invert_color_1, 1: principled_bsdf_1, 2: principled_bsdf})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Shader': mix_shader}, attrs={'is_active_output': True})

def shader_e_p_a_l_wood_logo_right(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, input_kwargs={'Distance': 0.0080}, attrs={'only_local': True, 'inside': True})
    
    invert_color_1 = nw.new_node(Nodes.Invert, input_kwargs={'Color': ambient_occlusion.outputs["Color"]})
    
    texture_coordinate_4 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    noise_texture_3 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': texture_coordinate_4.outputs["Object"], 'Scale': 12.6000, 'Detail': 15.0000, 'Distortion': 3.6000},
        attrs={'noise_dimensions': '4D'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': noise_texture_3.outputs["Fac"], 3: -0.8200, 4: 1.8200})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={6: invert_color_1, 7: map_range_1.outputs["Result"]},
        attrs={'data_type': 'RGBA'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: mix_1.outputs[2], 1: 0.4500}, attrs={'operation': 'GREATER_THAN'})
    
    invert_color_2 = nw.new_node(Nodes.Invert, input_kwargs={'Color': greater_than})
    
    texture_coordinate_2 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_2.outputs["Object"], 'Scale': 41.5000, 'Detail': 15.0000, 'Distortion': 3.6000})
    
    color_ramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_4.outputs["Fac"]})
    color_ramp_1.color_ramp.elements[0].position = 0.0000
    color_ramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_1.color_ramp.elements[1].position = 0.6000
    color_ramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_2 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.8000, 'Height': invert_color_2})
    
    principled_bsdf_2 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': color_ramp_1.outputs["Color"], 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Roughness': 0.6000, 'Normal': bump_2})
    
    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate_1.outputs["UV"], 'Location': (-0.0400, 1.1300, 0.0000), 'Rotation': (0.0000, 0.0000, -1.5708), 'Scale': (1.2500, 1.2500, 1.0000)})
    
    image_texture = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': mapping},
        attrs={'extension': 'CLIP', 'image': None}) #bpy.data.images['epal.png']
    
    invert_color = nw.new_node(Nodes.Invert, input_kwargs={'Color': image_texture.outputs["Alpha"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Object"], 'Scale': 100.0000, 'Detail': 15.0000})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    color_ramp.color_ramp.elements[0].position = 0.4000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.5000
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: invert_color, 6: color_ramp.outputs["Color"], 7: (0.0000, 0.0000, 0.0000, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    invert_color_4 = nw.new_node(Nodes.Invert, input_kwargs={'Color': mix.outputs[2]})
    
    texture_coordinate_3 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    musgrave_texture = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'Vector': texture_coordinate_3.outputs["Object"], 'Scale': 3.0000, 'Detail': 1.0000})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': musgrave_texture, 'Scale': 80.0000, 'Detail': 15.0000})
    
    color_ramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    color_ramp_2.color_ramp.elements.new(0)
    color_ramp_2.color_ramp.elements[0].position = 0.0818
    color_ramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_2.color_ramp.elements[1].position = 0.1318
    color_ramp_2.color_ramp.elements[1].color = [0.4464, 0.2164, 0.0626, 1.0000]
    color_ramp_2.color_ramp.elements[2].position = 0.1909
    color_ramp_2.color_ramp.elements[2].color = [1.0000, 0.5792, 0.2528, 1.0000]
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: invert_color_4, 6: (0.1329, 0.1329, 0.1329, 1.0000), 7: color_ramp_2.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    invert_color_3 = nw.new_node(Nodes.Invert)
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_3.outputs["Object"], 'Scale': 500.0000, 'Detail': 15.0000})
    
    color_ramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    color_ramp_3.color_ramp.elements[0].position = 0.2227
    color_ramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_3.color_ramp.elements[1].position = 1.0000
    color_ramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_3 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.1500, 'Height': color_ramp_3.outputs["Color"]})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2000, 'Height': invert_color_3, 'Normal': bump_3})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_2.outputs[2], 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Normal': bump_1})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': invert_color_2, 1: principled_bsdf_2, 2: principled_bsdf_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_1}, attrs={'is_active_output': True})

def shader_e_p_a_l_wood_logo_left(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, input_kwargs={'Distance': 0.0080}, attrs={'only_local': True, 'inside': True})
    
    invert_color_1 = nw.new_node(Nodes.Invert, input_kwargs={'Color': ambient_occlusion.outputs["Color"]})
    
    texture_coordinate_4 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    noise_texture_3 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': texture_coordinate_4.outputs["Object"], 'Scale': 12.6000, 'Detail': 15.0000, 'Distortion': 3.6000},
        attrs={'noise_dimensions': '4D'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': noise_texture_3.outputs["Fac"], 3: -0.8200, 4: 1.8200})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={6: invert_color_1, 7: map_range_1.outputs["Result"]},
        attrs={'data_type': 'RGBA'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: mix_1.outputs[2], 1: 0.4500}, attrs={'operation': 'GREATER_THAN'})
    
    invert_color_2 = nw.new_node(Nodes.Invert, input_kwargs={'Color': greater_than})
    
    texture_coordinate_2 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_2.outputs["Object"], 'Scale': 41.5000, 'Detail': 15.0000, 'Distortion': 3.6000})
    
    color_ramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_4.outputs["Fac"]})
    color_ramp_1.color_ramp.elements[0].position = 0.0000
    color_ramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_1.color_ramp.elements[1].position = 0.6000
    color_ramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_2 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.8000, 'Height': invert_color_2})
    
    principled_bsdf_2 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': color_ramp_1.outputs["Color"], 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Roughness': 0.6000, 'Normal': bump_2})
    
    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate_1.outputs["UV"], 'Location': (-0.2100, 1.1300, 0.0000), 'Rotation': (0.0000, 0.0000, -1.5708), 'Scale': (1.2500, 1.2500, 1.0000)})
    
    image_texture = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': mapping},
        attrs={'extension': 'CLIP', 'image': None}) #bpy.data.images['epal.png']
    
    invert_color = nw.new_node(Nodes.Invert, input_kwargs={'Color': image_texture.outputs["Alpha"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_1.outputs["Object"], 'Scale': 100.0000, 'Detail': 15.0000})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    color_ramp.color_ramp.elements[0].position = 0.4000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.5000
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: invert_color, 6: color_ramp.outputs["Color"], 7: (0.0000, 0.0000, 0.0000, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    invert_color_4 = nw.new_node(Nodes.Invert, input_kwargs={'Color': mix.outputs[2]})
    
    texture_coordinate_3 = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['EPAL Mover Single Raw']
    
    musgrave_texture = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'Vector': texture_coordinate_3.outputs["Object"], 'Scale': 3.0000, 'Detail': 1.0000})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': musgrave_texture, 'Scale': 80.0000, 'Detail': 15.0000})
    
    color_ramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    color_ramp_2.color_ramp.elements.new(0)
    color_ramp_2.color_ramp.elements[0].position = 0.0818
    color_ramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_2.color_ramp.elements[1].position = 0.1318
    color_ramp_2.color_ramp.elements[1].color = [0.4464, 0.2164, 0.0626, 1.0000]
    color_ramp_2.color_ramp.elements[2].position = 0.1909
    color_ramp_2.color_ramp.elements[2].color = [1.0000, 0.5792, 0.2528, 1.0000]
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: invert_color_4, 6: (0.1329, 0.1329, 0.1329, 1.0000), 7: color_ramp_2.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    invert_color_3 = nw.new_node(Nodes.Invert)
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate_3.outputs["Object"], 'Scale': 500.0000, 'Detail': 15.0000})
    
    color_ramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    color_ramp_3.color_ramp.elements[0].position = 0.2227
    color_ramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_3.color_ramp.elements[1].position = 1.0000
    color_ramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_3 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.1500, 'Height': color_ramp_3.outputs["Color"]})
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2000, 'Height': invert_color_3, 'Normal': bump_3})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_2.outputs[2], 'Subsurface Radius': (1.0000, 1.0000, 1.0000), 'Normal': bump_1})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': invert_color_2, 1: principled_bsdf_2, 2: principled_bsdf_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_1}, attrs={'is_active_output': True})

def shader_e_p_a_l_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_e_p_a_l_wood().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_2 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Count', 3),
            ('NodeSocketInt', 'Min Random Rotation', 0),
            ('NodeSocketInt', 'Max Random rotation', 0),
            ('NodeSocketInt', 'Seed', 0)])
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': group_input_2.outputs["Geometry"]})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bounding_box.outputs["Max"], 1: bounding_box.outputs["Min"]},
        attrs={'operation': 'SUBTRACT'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': subtract.outputs["Vector"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': separate_xyz.outputs["Z"]})
    
    mesh_line = nw.new_node(Nodes.MeshLine, input_kwargs={'Count': group_input_2.outputs["Count"], 'Offset': combine_xyz})
    
    radians = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_2.outputs["Min Random Rotation"]},
        attrs={'operation': 'RADIANS'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': radians})
    
    radians_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_2.outputs["Max Random rotation"]},
        attrs={'operation': 'RADIANS'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': radians_1})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: combine_xyz_1, 1: combine_xyz_2, 'Seed': group_input_2.outputs["Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_line, 'Instance': group_input_2.outputs["Geometry"], 'Rotation': random_value.outputs["Value"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': instance_on_points}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_e_p_a_l_wood, selection=selection)
    surface.add_material(obj, shader_e_p_a_l_wood_logo_left, selection=selection)
    surface.add_material(obj, shader_e_p_a_l_wood_logo_right, selection=selection)
apply(bpy.context.active_object)