import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_base(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate.outputs["Object"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping, 'Scale': 1.0000, 'Detail': 12.0000, 'Roughness': 0.9000})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    color_ramp.color_ramp.elements[0].position = 0.2655
    color_ramp.color_ramp.elements[0].color = [0.0270, 0.0270, 0.0270, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.6182
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.3050, 0.3050, 0.3050, 1.0000), 'Metallic': 1.0000, 'Roughness': color_ramp.outputs["Color"], 'IOR': 1.5000, 'Emission Strength': 0.0000},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS', 'distribution': 'MULTI_GGX'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_random(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    object_info = nw.new_node(Nodes.ObjectInfo_Shader)
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': object_info.outputs["Random"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mapping})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    color_ramp.color_ramp.interpolation = "CONSTANT"
    color_ramp.color_ramp.elements[0].position = 0.0000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.4945
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (1.0000, 1.0000, 1.0000, 1.0000), 'Metallic': 1.0000, 'Roughness': 0.2200, 'IOR': 1.5000, 'Emission Strength': 0.0000},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS', 'distribution': 'MULTI_GGX'})
    
    emission = nw.new_node(Nodes.Emission, input_kwargs={'Color': (1.0000, 0.7563, 0.5903, 1.0000), 'Strength': 20.0000})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': color_ramp.outputs["Color"], 1: principled_bsdf, 2: emission})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def shader_metal_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Detail': 15.0000, 'Roughness': 0.7770})
    
    color_ramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    color_ramp_1.color_ramp.elements[0].position = 0.4145
    color_ramp_1.color_ramp.elements[0].color = [0.0941, 0.0941, 0.0941, 1.0000]
    color_ramp_1.color_ramp.elements[1].position = 0.7273
    color_ramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Scale': 10.0000}, attrs={'distance': 'CHEBYCHEV'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Color"]})
    color_ramp.color_ramp.elements[0].position = 0.1600
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.6073
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.4000, 6: color_ramp_1.outputs["Color"], 7: color_ramp.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Metallic': 1.0000, 'Roughness': mix.outputs[2], 'IOR': 1.5000, 'Emission Strength': 0.0000},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS', 'distribution': 'MULTI_GGX'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    grid = nw.new_node(Nodes.MeshGrid,
        input_kwargs={'Size X': 10.0000, 'Size Y': 10.0000, 'Vertices X': 23, 'Vertices Y': 23})
    
    triangulate = nw.new_node('GeometryNodeTriangulate', input_kwargs={'Mesh': grid.outputs["Mesh"]})
    
    dual_mesh = nw.new_node(Nodes.DualMesh, input_kwargs={'Mesh': triangulate})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={'Probability': 0.4667}, attrs={'data_type': 'BOOLEAN'})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry,
        input_kwargs={'Geometry': dual_mesh, 'Selection': random_value.outputs[3]},
        attrs={'domain': 'FACE'})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': separate_geometry.outputs["Selection"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Radius': 0.0150})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': mesh_to_curve, 'Profile Curve': curve_circle.outputs["Curve"]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': surface.shaderfunc_to_material(shader_base)})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': 0.0500, 'Subdivisions': 4})
    
    random_value_1 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.6800, 3: 1.5700, 'Seed': 1})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': separate_geometry.outputs["Selection"], 'Instance': ico_sphere.outputs["Mesh"], 'Scale': random_value_1.outputs[1]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': instance_on_points})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_random)})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': grid.outputs["Mesh"], 'Translation': (0.0000, 0.0000, -0.1100)})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': transform_geometry, 'Material': surface.shaderfunc_to_material(shader_base)})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material, set_material_1, set_material_2]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_metal_material, selection=selection)
    surface.add_material(obj, shader_random, selection=selection)
apply(bpy.context.active_object)