import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_rotational_array', singleton=False, type='GeometryNodeTree')
def nodegroup_rotational_array(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Count', 5)])
    
    points = nw.new_node('GeometryNodePoints', input_kwargs={'Count': group_input.outputs["Count"]})
    
    index = nw.new_node(Nodes.Index)
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 6.2832}, attrs={'operation': 'MULTIPLY'})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: group_input.outputs["Count"]}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': divide})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': points, 'Instance': group_input.outputs["Geometry"], 'Rotation': combine_xyz})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': instance_on_points}, attrs={'is_active_output': True})

def shader_leaves(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.1070, 0.8000, 0.0970, 1.0000), 'Specular': 0.0000, 'Roughness': 1.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_2 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Branches', 5),
            ('NodeSocketInt', 'Layers', 6),
            ('NodeSocketFloat', 'Bend', 0.2000),
            ('NodeSocketFloat', 'Height', 2.3000),
            ('NodeSocketInt', 'Seed', 0),
            ('NodeSocketVectorTranslation', 'Branch Start', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVectorTranslation', 'Branch Middle', (0.0000, 0.0000, -0.5000)),
            ('NodeSocketVectorTranslation', 'Branch End', (1.0000, 0.0000, -1.0000)),
            ('NodeSocketIntUnsigned', 'Branch Resolution', 7)])
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input_2.outputs["Height"]})
    
    mesh_line = nw.new_node(Nodes.MeshLine,
        input_kwargs={'Count': group_input_2.outputs["Layers"], 'Offset': combine_xyz_2},
        attrs={'mode': 'END_POINTS'})
    
    arc = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Resolution': group_input_2.outputs["Branch Resolution"], 'Start': group_input_2.outputs["Branch Start"], 'Middle': group_input_2.outputs["Branch Middle"], 'End': group_input_2.outputs["Branch End"]},
        attrs={'mode': 'POINTS'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.2727, 0.9937), (0.9955, 0.0125)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': arc.outputs["Curve"], 'Radius': float_curve})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.2000})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_circle.outputs["Curve"]})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_to_mesh, 'Scale': (1.0000, 1.5000, 1.0000)})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': transform})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_material, 'Shade Smooth': False})
    
    grid = nw.new_node(Nodes.MeshGrid,
        input_kwargs={'Size X': 100.0000, 'Size Y': 100.0000, 'Vertices X': 2, 'Vertices Y': 2})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid.outputs["Mesh"], 'Name': 'uv_map', 3: grid.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    divide = nw.new_node(Nodes.Math,
        input_kwargs={0: 3.1416, 1: group_input_2.outputs["Branches"]},
        attrs={'operation': 'DIVIDE'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: -1.5708})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add, 'Y': 1.5708})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': store_named_attribute, 'Rotation': combine_xyz})
    
    transform_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': transform_1, 'Rotation': (3.1416, 0.0000, 0.0000)})
    
    difference = nw.new_node(Nodes.MeshBoolean, input_kwargs={'Mesh 1': set_shade_smooth, 'Mesh 2': [transform_1, transform_2]})
    
    rotational_array = nw.new_node(nodegroup_rotational_array().name,
        input_kwargs={'Geometry': difference.outputs["Mesh"], 'Count': group_input_2.outputs["Branches"]})
    
    random_z_radian = nw.new_node(Nodes.RandomValue,
        input_kwargs={1: (0.0000, 0.0000, 6.2832), 'Seed': group_input_2.outputs["Seed"]},
        label='Random Z Radian',
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    index = nw.new_node(Nodes.Index)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': index, 2: group_input_2.outputs["Layers"]})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 1.0000), (0.3273, 0.8813), (0.7000, 0.3375), (1.0000, 0.0000)])
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1, 1: 0.2500})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_1, 'Y': add_1, 'Z': add_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_line, 'Instance': rotational_array, 'Rotation': random_z_radian.outputs["Value"], 'Scale': combine_xyz_1})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points})
    
    position = nw.new_node(Nodes.InputPosition)
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': realize_instances})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bounding_box.outputs["Min"], 1: (0.0000, 0.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Vector': position, 7: bounding_box.outputs["Min"], 8: bounding_box.outputs["Max"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': map_range_1.outputs["Vector"]})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz.outputs["Z"], 1: group_input_2.outputs["Bend"]},
        attrs={'operation': 'MULTIPLY'})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': position, 'Center': multiply.outputs["Vector"], 'Axis': (1.0000, 0.0000, 0.0000), 'Angle': multiply_1},
        attrs={'rotation_type': 'X_AXIS'})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: bounding_box.outputs["Min"], 1: (0.0000, 0.0000, -1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances, 'Position': vector_rotate, 'Offset': multiply_2.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_leaves, selection=selection)
apply(bpy.context.active_object)