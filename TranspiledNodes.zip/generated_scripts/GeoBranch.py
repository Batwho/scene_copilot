import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_voronoi_crackle', singleton=False, type='ShaderNodeTree')
def nodegroup_voronoi_crackle(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000))])
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Vector"]})
    
    voronoi_texture_2 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': reroute_2}, attrs={'feature': 'F2'})
    
    voronoi_texture_3 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': reroute_2})
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture_2.outputs["Distance"], 1: voronoi_texture_3.outputs["Distance"]},
        attrs={'operation': 'SUBTRACT'})
    
    subtract_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: voronoi_texture_3.outputs["Position"], 1: reroute_2},
        attrs={'operation': 'SUBTRACT'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Fac': subtract, 'Color': voronoi_texture_3.outputs["Color"], 'Position': voronoi_texture_3.outputs["Position"], 'Vector': subtract_1.outputs["Vector"]},
        attrs={'is_active_output': True})

def shader_bark(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: texture_coordinate.outputs["Object"], 1: (1.0000, 3.0000, 1.0000), 'Scale': 0.5900},
        attrs={'operation': 'MULTIPLY'})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (6.0000, 1.0000, 1.0000), 'Scale': 0.3000},
        attrs={'operation': 'SCALE'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: scale.outputs["Vector"], 1: (6.0000, 1.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': scale.outputs["Vector"], 'Scale': 8.0000, 'Detail': 6.0000})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.2000, 6: multiply_1.outputs["Vector"], 7: noise_texture.outputs["Color"]},
        attrs={'blend_type': 'LINEAR_LIGHT', 'data_type': 'RGBA'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix.outputs[2]})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_5, 1: (6.0000, 1.0000, 1.0000), 'Scale': 1.4000},
        attrs={'operation': 'SCALE'})
    
    group = nw.new_node(nodegroup_voronoi_crackle().name, input_kwargs={'Vector': scale_1.outputs["Vector"]})
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group.outputs["Fac"], 2: 0.1100})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group.outputs["Vector"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_1.outputs["Y"], 1: 0.0800})
    
    map_range_4 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group.outputs["Color"], 3: 0.5000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: map_range_4.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    map_range_5 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply_2, 2: 0.1000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_3.outputs["Result"], 1: map_range_5.outputs["Result"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    white_noise_texture_1 = nw.new_node(Nodes.WhiteNoiseTexture,
        input_kwargs={'Vector': group.outputs["Position"]},
        attrs={'noise_dimensions': '2D'})
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_3, 1: white_noise_texture_1.outputs["Value"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    group_1 = nw.new_node(nodegroup_voronoi_crackle().name, input_kwargs={'Vector': reroute})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_1.outputs["Fac"], 2: 0.1100})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_1.outputs["Vector"]})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"], 1: 0.0800})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_1.outputs["Color"], 3: 0.5000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: add_1, 1: map_range_2.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply_5, 2: 0.1000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_6 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range.outputs["Result"], 1: map_range_1.outputs["Result"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    white_noise_texture = nw.new_node(Nodes.WhiteNoiseTexture,
        input_kwargs={'Vector': group_1.outputs["Position"]},
        attrs={'noise_dimensions': '2D'})
    
    multiply_7 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_6, 1: white_noise_texture.outputs["Value"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    maximum = nw.new_node(Nodes.Math, input_kwargs={0: multiply_4, 1: multiply_7}, attrs={'operation': 'MAXIMUM'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': reroute_1, 'Detail': 5.0000})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: maximum, 1: noise_texture_2.outputs["Fac"]})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': reroute_1, 'Scale': 2.0000, 'Distortion': 7.4200, 'Detail': 4.0000, 'Detail Scale': 1.6800})
    
    map_range_6 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': wave_texture.outputs["Color"], 2: 0.5000, 3: 0.9000},
        attrs={'interpolation_type': 'SMOOTHERSTEP'})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: add_2, 1: map_range_6.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_8})
    
    minimum = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_3.outputs["Result"], 1: map_range.outputs["Result"]},
        attrs={'operation': 'MINIMUM'})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={6: reroute_4, 7: minimum}, attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={6: mix_2.outputs[2], 7: noise_texture_2.outputs["Fac"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': mix_4.outputs[2]})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.1728, 0.0608, 0.0137, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.0582
    colorramp.color_ramp.elements[1].color = [0.0296, 0.0091, 0.0080, 1.0000]
    colorramp.color_ramp.elements[2].position = 0.3473
    colorramp.color_ramp.elements[2].color = [0.1972, 0.0706, 0.0139, 1.0000]
    colorramp.color_ramp.elements[3].position = 0.5064
    colorramp.color_ramp.elements[3].color = [0.1517, 0.0521, 0.0137, 1.0000]
    colorramp.color_ramp.elements[4].position = 0.6982
    colorramp.color_ramp.elements[4].color = [0.3036, 0.0979, 0.0211, 1.0000]
    colorramp.color_ramp.elements[5].position = 1.0000
    colorramp.color_ramp.elements[5].color = [0.4642, 0.1481, 0.0323, 1.0000]
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': 0.5950, 'Saturation': 0.5400, 'Value': 0.2300, 'Color': colorramp.outputs["Color"]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    map_range_7 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_6, 1: 0.2500, 3: 1.0000, 4: 0.6000})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.6000, 'Distance': 0.1000, 'Height': reroute_6})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': hue_saturation_value, 'Specular Tint': 0.5000, 'Roughness': map_range_7.outputs["Result"], 'Normal': bump})
    
    displacement = nw.new_node(Nodes.Displacement, input_kwargs={'Height': reroute_6, 'Scale': 0.0100})
    
    material_output = nw.new_node(Nodes.MaterialOutput,
        input_kwargs={'Surface': principled_bsdf, 'Displacement': displacement},
        attrs={'is_active_output': True})

def shader_leaf01(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    transparent_bsdf_1 = nw.new_node(Nodes.TransparentBSDF)
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UVMap'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: attribute_1.outputs["Vector"], 1: (0.5000, 0.5000, 0.0000)},
        attrs={'operation': 'SUBTRACT'})
    
    length = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (0.5000, 0.5000, 0.0000)},
        attrs={'operation': 'LENGTH'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': length.outputs["Value"], 1: -0.1800, 2: 0.3200, 3: 1.8500, 4: -0.0500})
    
    musgrave_texture = nw.new_node(Nodes.MusgraveTexture,
        input_kwargs={'Vector': attribute_1.outputs["Vector"], 'Scale': -4.2700, 'Detail': 5.5000, 'Dimension': 0.8800, 'Lacunarity': 0.0000},
        attrs={'musgrave_type': 'MULTIFRACTAL'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range.outputs["Result"], 1: musgrave_texture},
        attrs={'operation': 'MULTIPLY'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: 0.5300}, attrs={'operation': 'GREATER_THAN'})
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'nrm'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.5283, 0.2088, 0.0502, 1.0000), 'Specular': 0.1947, 'Specular Tint': 1.0000, 'Roughness': 0.7290, 'Alpha': greater_than, 'Normal': attribute.outputs["Vector"]})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': 1.0000, 1: transparent_bsdf_1, 2: principled_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_1}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    integer = nw.new_node(Nodes.Integer)
    integer.integer = 12
    
    quadratic_bezier_1 = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': integer, 'Start': (0.0000, 0.0000, 0.0000), 'Middle': (0.0000, 0.0000, 0.0000), 'End': (5.9700, 0.0000, 0.0000)})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': quadratic_bezier_1})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    vector_rotate_1 = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': position_1, 'Axis': (1.0000, 1.0000, 1.0000), 'Angle': 5.7125})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': vector_rotate_1, 'Scale': -1.0200, 'Detail': 5.6200, 'Roughness': 0.2762, 'Distortion': 0.3000})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_1.outputs["Color"], 1: (0.4700, 0.5600, 0.4900)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (2.0000, 2.0000, 2.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (0.3900, 0.3900, 0.3900)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1.outputs["Vector"]})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_37, 'Offset': reroute_31})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': set_position_3, 'Count': 3, 'Radius': 0.1700},
        attrs={'mode': 'POLY'})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': fillet_curve})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_39})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_40})
    
    spline_parameter_4 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_4.outputs["Factor"]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 1.0000), (0.4847, 0.6146), (0.9962, 0.2500)])
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_4, 1: 1.5700}, attrs={'operation': 'MULTIPLY'})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_2})
    
    set_curve_radius_2 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': reroute_38, 'Radius': reroute_35})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0500})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_circle.outputs["Curve"]})
    
    curve_to_mesh_4 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': set_curve_radius_2, 'Profile Curve': reroute_25})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh_4, 'Material': surface.shaderfunc_to_material(shader_bark)})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: integer, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    endpoint_selection_1 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0, 'End Size': divide})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': endpoint_selection_1})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': 8, 'Start': (0.0000, 0.0000, 0.0000), 'Middle': (0.0000, 0.0000, 0.0000), 'End': (1.5200, 0.0000, 0.0000)})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': quadratic_bezier})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_28})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    position = nw.new_node(Nodes.InputPosition)
    
    vector_rotate = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': position, 'Axis': (1.0000, 1.0000, 1.0000), 'Angle': 5.7125})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': vector_rotate, 'Scale': 0.8800, 'Detail': 5.6200, 'Roughness': 0.5350})
    
    subtract_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.4700, 0.5600, 0.4900)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_3 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract_1.outputs["Vector"], 1: (2.0000, 2.0000, 2.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_3.outputs["Vector"], 1: (0.3900, 0.3900, 0.3900)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_4.outputs["Vector"]})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_6, 'Offset': reroute_7})
    
    spline_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_2.outputs["Factor"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 1.0000), (0.4427, 0.4688), (0.9962, 0.1563)])
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_2, 1: 0.6300}, attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': set_position, 'Radius': multiply_5})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0500})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_circle_1.outputs["Curve"]})
    
    curve_to_mesh_6 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': set_curve_radius_1, 'Profile Curve': reroute_8})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh_6, 'Material': surface.shaderfunc_to_material(shader_bark)})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_28})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_13})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 4})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': endpoint_selection})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_13})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent}, attrs={'axis': 'Y'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 1.0000), (0.5229, 0.8646), (1.0000, 0.2500)])
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': float_curve})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_4, 'Selection': reroute_1, 'Instance': reroute, 'Rotation': align_euler_to_vector, 'Scale': reroute_5})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    id = nw.new_node(Nodes.InputID)
    
    degrees = nw.new_node(Nodes.Math, input_kwargs={0: 138.0000, 1: 1.0000}, attrs={'operation': 'DEGREES'})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: id, 1: degrees}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_6})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': reroute_14, 'Rotation': reroute_3})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': 2.1400})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': rotate_instances_1, 'Rotation': combine_xyz_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': rotate_instances_2})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': realize_instances, 'Length': 0.0900},
        attrs={'mode': 'LENGTH'})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_1.outputs["Factor"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 1.0000), (0.5115, 0.6458), (1.0000, 0.1823)])
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_7})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve, 'Radius': reroute_2})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_curve_radius})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Geometry', None)])
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Geometry"]})
    
    curve_tangent_2 = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector_2 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent_2}, attrs={'axis': 'Y'})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_2})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    spline_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_3.outputs["Factor"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.3490), (0.4885, 0.8125), (1.0000, 0.5833)])
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_3, 1: 0.4600}, attrs={'operation': 'MULTIPLY'})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_8})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_17, 'Instance': reroute_11, 'Rotation': reroute_23, 'Scale': reroute_10})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points_1, 'Material': surface.shaderfunc_to_material(shader_leaf01)})
    
    id_1 = nw.new_node(Nodes.InputID)
    
    degrees_1 = nw.new_node(Nodes.Math, input_kwargs={0: 137.8000, 1: 1.0000}, attrs={'operation': 'DEGREES'})
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: id_1, 1: degrees_1}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_9})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_4})
    
    rotate_instances_3 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': set_material_1, 'Rotation': reroute_16})
    
    curve_tangent_1 = nw.new_node(Nodes.CurveTangent)
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': -7.1000, 'Y': 1.7700, 'Z': 0.0600})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: curve_tangent_1, 1: combine_xyz_1})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': add.outputs["Vector"]}, attrs={'axis': 'Y'})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_1})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': 1.3600})
    
    rotate_instances_4 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': rotate_instances_3, 'Rotation': reroute_12, 'Pivot Point': combine_xyz_3})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_4.outputs["Vector"]})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': rotate_instances_4, 'Offset': reroute_29})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_24, set_position_1]})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': join_geometry, 'Translation': (-0.0200, 0.0000, 0.0100)})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': transform})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_33})
    
    curve_tangent_3 = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector_3 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent_3}, attrs={'axis': 'Y'})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_3})
    
    spline_parameter_5 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_5 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_5.outputs["Factor"]})
    node_utils.assign_curve(float_curve_5.mapping.curves[0], [(0.0000, 1.0000), (0.5229, 0.8646), (1.0000, 0.2500)])
    
    multiply_10 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_5, 1: 1.6000}, attrs={'operation': 'MULTIPLY'})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': set_position_3, 'Selection': reroute_36, 'Instance': reroute_34, 'Rotation': reroute_32, 'Scale': multiply_10})
    
    id_2 = nw.new_node(Nodes.InputID)
    
    degrees_2 = nw.new_node(Nodes.Math, input_kwargs={0: 137.8000, 1: 1.0000}, attrs={'operation': 'DEGREES'})
    
    multiply_11 = nw.new_node(Nodes.Math, input_kwargs={0: id_2, 1: degrees_2}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_11})
    
    rotate_instances_5 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': instance_on_points_2, 'Rotation': combine_xyz_5})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': 1.0000})
    
    rotate_instances_6 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': rotate_instances_5, 'Rotation': combine_xyz_6})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_circle.outputs["Curve"]})
    
    curve_to_mesh_5 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': rotate_instances_6, 'Profile Curve': reroute_15})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_3, curve_to_mesh_5]})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': join_geometry_1})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': realize_instances_1}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_leaf01, selection=selection)
    surface.add_material(obj, shader_bark, selection=selection)
apply(bpy.context.active_object)
