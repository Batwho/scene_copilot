import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_beads', singleton=False, type='ShaderNodeTree')
def nodegroup_beads(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    geometry = nw.new_node(Nodes.NewGeometry)
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Scale', 10.0000),
            ('NodeSocketFloat', 'Distortion', 21.0000),
            ('NodeSocketFloatFactor', 'Roughness', 0.2000),
            ('NodeSocketFloat', 'Dark Beads', 0.9400)])
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: geometry.outputs["Random Per Island"], 1: group_input.outputs["Dark Beads"]},
        attrs={'operation': 'MULTIPLY'})
    
    snap = nw.new_node(Nodes.Math, input_kwargs={0: multiply}, attrs={'operation': 'SNAP'})
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Rotation': geometry.outputs["Random Per Island"]})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': mapping, 'Scale': group_input.outputs["Scale"], 'Distortion': group_input.outputs["Distortion"], 'Detail': 15.0000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture.outputs["Color"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0543, 0.0217, 0.0082, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.9964
    colorramp.color_ramp.elements[1].color = [0.4883, 0.2250, 0.1624, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: snap, 6: colorramp.outputs["Color"], 7: (0.0000, 0.0000, 0.0000, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Roughness': group_input.outputs["Roughness"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'BSDF': principled_bsdf}, attrs={'is_active_output': True})

def shader_string_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Detail': 15.0000, 'Roughness': 1.0000})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Height': noise_texture.outputs["Fac"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.2803, 0.2803, 0.2803, 1.0000), 'Normal': bump})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_beads_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_beads().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Seed', 0.0000),
            ('NodeSocketFloatDistance', 'Size', 1.0000),
            ('NodeSocketFloat', 'Displacement Strength', 1.0000),
            ('NodeSocketFloatDistance', 'Bead Amount', 0.1000),
            ('NodeSocketFloat', 'Bead Size', 2.3000),
            ('NodeSocketFloatDistance', 'Band Thickness', 0.0075),
            ('NodeSocketInt', 'Beads Resolution', 32),
            ('NodeSocketInt', 'String Resolution', 200)])
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input.outputs["String Resolution"], 'Radius': group_input.outputs["Size"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["Seed"], 'Scale': 1.0000, 'Detail': 1.0000, 'Roughness': 0.0750},
        attrs={'noise_dimensions': '4D'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (0.5000, 0.5000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Displacement Strength"]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (0.5000, 0.5000, 0.0000), 'Scale': reroute_6},
        attrs={'operation': 'SCALE'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': scale.outputs["Vector"]})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': curve_circle.outputs["Curve"], 'Offset': reroute_4})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Bead Amount"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_position, 'Length': reroute}, attrs={'mode': 'LENGTH'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Beads Resolution"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    divide = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute_3, 1: group_input.outputs["Bead Size"]},
        attrs={'operation': 'DIVIDE'})
    
    uv_sphere = nw.new_node(Nodes.MeshUVSphere, input_kwargs={'Segments': reroute_10, 'Rings': reroute_10, 'Radius': divide})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': uv_sphere.outputs["Mesh"], 'Name': 'uv_map', 3: uv_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': store_named_attribute, 'Material': surface.shaderfunc_to_material(shader_beads_material)})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_material})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': resample_curve, 'Instance': set_shade_smooth})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Radius': group_input.outputs["Band Thickness"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position, 'Profile Curve': curve_circle_1.outputs["Curve"]})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': surface.shaderfunc_to_material(shader_string_material)})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_1})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points, reroute_7]})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': join_geometry, 'Translation': (0.0000, 0.0000, 0.0430)})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': transform})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': realize_instances}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_beads_material, selection=selection)
apply(bpy.context.active_object)
