import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup__g_e_n_hand', singleton=False, type='GeometryNodeTree')
def nodegroup__g_e_n_hand(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Hand Width', 0.5000),
            ('NodeSocketInt', 'Finger Amount', 5),
            ('NodeSocketFloat', 'Finger Length', 1.5000),
            ('NodeSocketFloat', 'Finger Spread', 0.5000),
            ('NodeSocketFloat', 'Scale', 0.3500)])
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Hand Width"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input.outputs["Hand Width"]})
    
    mesh_line = nw.new_node(Nodes.MeshLine,
        input_kwargs={'Count': group_input.outputs["Finger Amount"], 'Start Location': combine_xyz_7, 'Offset': combine_xyz_6},
        attrs={'mode': 'END_POINTS'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Finger Length"]})
    
    mesh_line_1 = nw.new_node(Nodes.MeshLine, input_kwargs={'Count': 3, 'Offset': combine_xyz}, attrs={'mode': 'END_POINTS'})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': mesh_line, 'Instance': mesh_line_1})
    
    index_1 = nw.new_node(Nodes.Index)
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Finger Amount"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Finger Spread"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': index_1, 2: subtract, 3: multiply_1, 4: group_input.outputs["Finger Spread"]})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range.outputs["Result"]})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': instance_on_points_3, 'Rotation': combine_xyz_5})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Scale"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute, 'Y': reroute, 'Z': reroute})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': rotate_instances, 'Scale': combine_xyz_1})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': transform})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup__u_t_l_curve_to_mesh_u_v', singleton=False, type='GeometryNodeTree')
def nodegroup__u_t_l_curve_to_mesh_u_v(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloatDistance', 'Radius', 1.1000),
            ('NodeSocketInt', 'Resolution', 32),
            ('NodeSocketBool', 'Fill Caps', True)])
    
    set_curve_tilt = nw.new_node(Nodes.SetCurveTilt, input_kwargs={'Curve': group_input.outputs["Geometry"], 'Tilt': 1.5708})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_curve_tilt, 2: spline_parameter_1.outputs["Factor"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Radius': group_input.outputs["Radius"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': curve_circle.outputs["Curve"], 2: spline_parameter_1.outputs["Factor"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute.outputs["Geometry"], 'Profile Curve': capture_attribute_1.outputs["Geometry"], 'Fill Caps': group_input.outputs["Fill Caps"]})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute_1.outputs[2], 'Y': capture_attribute.outputs[2]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_to_mesh, 'Name': 'UV', 3: combine_xyz_5},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': store_named_attribute}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup__g_e_n_arm', singleton=False, type='GeometryNodeTree')
def nodegroup__g_e_n_arm(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Air Speed', 0.5000),
            ('NodeSocketFloat', 'Arm Length', 1.0000),
            ('NodeSocketFloat', 'Air Influence', 0.5000),
            ('NodeSocketFloat', 'Offset', 0.0000),
            ('NodeSocketFloat', 'Air Scale', 0.7500),
            ('NodeSocketFloat', 'Noise Offset', 0.0000)])
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Arm Length"]})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_6})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_2, 'Count': 6})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 0})
    
    op_not = nw.new_node(Nodes.BooleanMath, input_kwargs={0: endpoint_selection}, attrs={'operation': 'NOT'})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    scene_time_1 = nw.new_node('GeometryNodeInputSceneTime')
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: scene_time_1.outputs["Seconds"], 1: group_input.outputs["Air Speed"]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: multiply}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["Offset"], 'Y': group_input.outputs["Offset"], 'Z': multiply_1})
    
    subtract = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: combine_xyz_5}, attrs={'operation': 'SUBTRACT'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': subtract.outputs["Vector"], 'W': group_input.outputs["Noise Offset"], 'Scale': group_input.outputs["Air Scale"], 'Detail': 1.8000, 'Roughness': 0.2500},
        attrs={'noise_dimensions': '4D'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Vector': noise_texture.outputs["Color"], 9: (-2.0000, -2.0000, -2.0000), 10: (2.0000, 2.0000, 2.0000)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range_4 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': spline_parameter.outputs["Factor"], 4: group_input.outputs["Arm Length"]})
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': map_range_4.outputs["Result"], 2: group_input.outputs["Arm Length"], 4: group_input.outputs["Air Influence"]})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: map_range.outputs["Vector"], 'Scale': map_range_3.outputs["Result"]},
        attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': resample_curve_3, 'Selection': op_not, 'Offset': scale.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position}, attrs={'is_active_output': True})

def shader_striped_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, attrs={'samples': 64})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': ambient_occlusion.outputs["AO"]})
    colorramp.color_ramp.elements[0].position = 0.7955
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UV'})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'uv_map'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: attribute.outputs["Fac"], 6: attribute_1.outputs["Color"], 7: attribute.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': 3.9600, 'Detail': 0.0000, 'Detail Scale': 0.0000, 'Detail Roughness': 0.0000},
        attrs={'wave_type': 'RINGS', 'rings_direction': 'SPHERICAL'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture.outputs["Fac"]})
    colorramp_1.color_ramp.interpolation = "CONSTANT"
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.4756, 1.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.4591
    colorramp_1.color_ramp.elements[1].color = [0.3445, 1.0000, 0.0000, 1.0000]
    
    bright_contrast = nw.new_node('ShaderNodeBrightContrast', input_kwargs={'Color': colorramp_1.outputs["Color"], 'Bright': -0.9000})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp.outputs["Color"], 6: bright_contrast, 7: colorramp_1.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_1.outputs[2], 'Subsurface Color': (0.6339, 0.0000, 0.8000, 1.0000), 'Specular': 1.0000, 'Roughness': 0.2545})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_checkered_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, attrs={'samples': 64})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': ambient_occlusion.outputs["AO"]})
    colorramp.color_ramp.elements[0].position = 0.7955
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UV'})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'uv_map'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: attribute.outputs["Fac"], 6: attribute_1.outputs["Color"], 7: attribute.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    checker_texture = nw.new_node(Nodes.CheckerTexture, input_kwargs={'Vector': mix.outputs[2], 'Scale': 28.2400})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': checker_texture.outputs["Fac"]})
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [0.8501, 1.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 0.0000, 0.0160, 1.0000]
    
    bright_contrast = nw.new_node('ShaderNodeBrightContrast', input_kwargs={'Color': colorramp_1.outputs["Color"], 'Bright': -0.9000})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp.outputs["Color"], 6: bright_contrast, 7: colorramp_1.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_1.outputs[2], 'Subsurface Color': (0.6339, 0.0000, 0.8000, 1.0000), 'Specular': 1.0000, 'Roughness': 0.2545})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_magic_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, attrs={'samples': 64})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': ambient_occlusion.outputs["AO"]})
    colorramp.color_ramp.elements[0].position = 0.7955
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UV'})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'uv_map'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: attribute.outputs["Fac"], 6: attribute_1.outputs["Color"], 7: attribute.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    magic_texture = nw.new_node(Nodes.MagicTexture, input_kwargs={'Vector': mix.outputs[2], 'Scale': 3.5200, 'Distortion': 5.8000})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': magic_texture.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.2273
    colorramp_1.color_ramp.elements[0].color = [0.8501, 1.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.6364
    colorramp_1.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    bright_contrast = nw.new_node('ShaderNodeBrightContrast', input_kwargs={'Color': colorramp_1.outputs["Color"], 'Bright': -0.9000})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp.outputs["Color"], 6: bright_contrast, 7: colorramp_1.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_1.outputs[2], 'Subsurface Color': (0.6339, 0.0000, 0.8000, 1.0000), 'Specular': 1.0000, 'Roughness': 0.2545})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_2 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketString', '_1', 'Body Settings'),
            ('NodeSocketFloatDistance', 'Radius', 1.1000),
            ('NodeSocketFloat', 'Height', 0.0000),
            ('NodeSocketString', '_2', 'Arm Settings'),
            ('NodeSocketFloatDistance', 'Arm Thickness', 0.2000),
            ('NodeSocketFloat', 'Arm Length', 1.0000),
            ('NodeSocketFloatFactor', 'Arm Alignment', 0.5000),
            ('NodeSocketString', '_3', 'Air Settings'),
            ('NodeSocketFloat', 'Air Scale', 0.7500),
            ('NodeSocketFloat', 'Air Influence', 0.5000),
            ('NodeSocketFloat', 'Air Speed', 0.5000),
            ('NodeSocketFloat', 'Noise Offset', 0.0000),
            ('NodeSocketString', '_4', 'Style Settings'),
            ('NodeSocketInt', 'Resolution', 16),
            ('NodeSocketBool', 'Smooth Shading', False),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_magic_material)    
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input_2.outputs["Height"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_3})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line})
    
    endpoint_selection_1 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 2, 'End Size': 0})
    
    op_not = nw.new_node(Nodes.BooleanMath, input_kwargs={0: endpoint_selection_1}, attrs={'operation': 'NOT'})
    
    position_2 = nw.new_node(Nodes.InputPosition)
    
    scene_time = nw.new_node('GeometryNodeInputSceneTime')
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: scene_time.outputs["Seconds"], 1: group_input_2.outputs["Air Speed"]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_2.outputs["Air Influence"], 1: 2.0000},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: multiply_1}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_2})
    
    subtract = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_2, 1: combine_xyz_4}, attrs={'operation': 'SUBTRACT'})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: group_input_2.outputs["Air Scale"]}, attrs={'operation': 'MULTIPLY'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': subtract.outputs["Vector"], 'W': group_input_2.outputs["Noise Offset"], 'Scale': multiply_3, 'Detail': 0.0000, 'Roughness': 0.0000},
        attrs={'noise_dimensions': '4D'})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Vector': noise_texture_1.outputs["Color"], 9: (-1.0000, -1.0000, -1.0000)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: map_range_1.outputs["Vector"], 'Scale': group_input_2.outputs["Air Influence"]},
        attrs={'operation': 'SCALE'})
    
    position_3 = nw.new_node(Nodes.InputPosition)
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position_3})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': separate_xyz_1.outputs["Z"], 2: group_input_2.outputs["Height"], 3: 0.2500, 4: 1.2500},
        attrs={'interpolation_type': 'SMOOTHERSTEP'})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: scale.outputs["Vector"], 'Scale': map_range_2.outputs["Result"]},
        attrs={'operation': 'SCALE'})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': resample_curve, 'Selection': op_not, 'Offset': scale_1.outputs["Vector"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_1})
    
    index = nw.new_node(Nodes.Index)
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={2: index, 3: 4}, attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    subtract_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_2.outputs["Radius"], 1: 0.2000},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': subtract_1})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_2, 'End': combine_xyz_1})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': reroute, 'Selection': equal, 'Instance': curve_line_1})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': realize_instances})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 0})
    
    gen_arm = nw.new_node(nodegroup__g_e_n_arm().name,
        input_kwargs={'Air Speed': group_input_2.outputs["Air Speed"], 'Arm Length': group_input_2.outputs["Arm Length"], 'Air Influence': group_input_2.outputs["Air Influence"], 'Offset': 6.8000, 'Air Scale': group_input_2.outputs["Air Scale"], 'Noise Offset': group_input_2.outputs["Noise Offset"]})
    
    position = nw.new_node(Nodes.InputPosition)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': separate_xyz.outputs["Z"]})
    
    subtract_2 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: combine_xyz}, attrs={'operation': 'SUBTRACT'})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Factor': group_input_2.outputs["Arm Alignment"], 'Vector': subtract_2.outputs["Vector"]},
        attrs={'axis': 'Z'})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_1, 'Selection': endpoint_selection, 'Instance': gen_arm, 'Rotation': align_euler_to_vector})
    
    endpoint_selection_2 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    gen_arm_1 = nw.new_node(nodegroup__g_e_n_arm().name,
        input_kwargs={'Air Speed': group_input_2.outputs["Air Speed"], 'Arm Length': group_input_2.outputs["Arm Length"], 'Air Influence': group_input_2.outputs["Air Influence"], 'Offset': 22.0000, 'Air Scale': group_input_2.outputs["Air Scale"], 'Noise Offset': group_input_2.outputs["Noise Offset"]})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_1, 'Selection': endpoint_selection_2, 'Instance': gen_arm_1, 'Rotation': align_euler_to_vector})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points_1, instance_on_points_2]})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': join_geometry_1})
    
    set_spline_type_1 = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': realize_instances_1}, attrs={'spline_type': 'BEZIER'})
    
    set_handle_type_1 = nw.new_node(Nodes.SetHandleType, input_kwargs={'Curve': set_spline_type_1})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_handle_type_1})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    endpoint_selection_4 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    uv_sphere = nw.new_node(Nodes.MeshUVSphere,
        input_kwargs={'Segments': group_input_2.outputs["Resolution"], 'Rings': group_input_2.outputs["Resolution"], 'Radius': group_input_2.outputs["Arm Thickness"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': uv_sphere.outputs["Mesh"], 'Name': 'uv_map', 3: uv_sphere.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': store_named_attribute})
    
    instance_on_points_4 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_4, 'Selection': endpoint_selection_4, 'Instance': set_shade_smooth})
    
    endpoint_selection_5 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'End Size': 0})
    
    instance_on_points_5 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_4, 'Selection': endpoint_selection_5, 'Instance': set_shade_smooth})
    
    endpoint_selection_3 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    gen_hand = nw.new_node(nodegroup__g_e_n_hand().name, input_kwargs={'Hand Width': group_input_2.outputs["Arm Thickness"]})
    
    curve_handle_positions = nw.new_node('GeometryNodeInputCurveHandlePositions', input_kwargs={'Relative': True})
    
    project = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: curve_handle_positions.outputs["Right"], 1: curve_handle_positions.outputs["Left"]},
        attrs={'operation': 'PROJECT'})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': project.outputs["Vector"]}, attrs={'axis': 'Z'})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_3, 'Selection': endpoint_selection_3, 'Instance': gen_hand, 'Rotation': align_euler_to_vector_1})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_3})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': realize_instances_2})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': mesh_to_curve, 'Count': 3})
    
    set_spline_type = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': resample_curve_1}, attrs={'spline_type': 'BEZIER'})
    
    set_handle_type = nw.new_node(Nodes.SetHandleType, input_kwargs={'Curve': set_spline_type})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 1.2400, 'Roughness': 0.5167})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Vector': noise_texture.outputs["Color"], 9: (-1.0000, -1.0000, 0.0000), 10: (1.0000, 1.0000, 0.0000)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 4: 0.3300})
    
    scale_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: map_range.outputs["Vector"], 'Scale': map_range_3.outputs["Result"]},
        attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_handle_type, 'Offset': scale_2.outputs["Vector"]})
    
    utl_curve_to_mesh_uv = nw.new_node(nodegroup__u_t_l_curve_to_mesh_u_v().name,
        input_kwargs={'Geometry': set_position, 'Radius': 0.0200, 'Resolution': group_input_2.outputs["Resolution"]})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [instance_on_points_4, instance_on_points_5, utl_curve_to_mesh_uv]})
    
    utl_curve_to_mesh_uv_1 = nw.new_node(nodegroup__u_t_l_curve_to_mesh_u_v().name,
        input_kwargs={'Geometry': set_handle_type_1, 'Radius': group_input_2.outputs["Arm Thickness"], 'Resolution': group_input_2.outputs["Resolution"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [join_geometry_2, utl_curve_to_mesh_uv_1]})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': join_geometry})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': reroute, 'Count': 20})
    
    set_spline_type_2 = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': resample_curve_2}, attrs={'spline_type': 'BEZIER'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_spline_type_2})
    
    utl_curve_to_mesh_uv_2 = nw.new_node(nodegroup__u_t_l_curve_to_mesh_u_v().name,
        input_kwargs={'Geometry': reroute_6, 'Radius': group_input_2.outputs["Radius"], 'Resolution': group_input_2.outputs["Resolution"]})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [merge_by_distance, utl_curve_to_mesh_uv_2]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_3, 'Material': group_input_2.outputs["Material"]})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth,
        input_kwargs={'Geometry': set_material, 'Shade Smooth': group_input_2.outputs["Smooth Shading"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_shade_smooth_1}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
#    surface.add_material(obj, shader_magic_material, selection=selection)
    surface.add_material(obj, shader_checkered_material, selection=selection)
#    surface.add_material(obj, shader_striped_material, selection=selection)

apply(bpy.context.active_object)
bpy.context.active_object.modifiers["geometry_nodes"]["Input_17"] = bpy.data.materials["shader_checkered_material"]

