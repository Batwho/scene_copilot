import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_vis_b_free(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    diffuse_bsdf = nw.new_node(Nodes.DiffuseBSDF, input_kwargs={'Color': (0.6229, 0.0439, 0.0470, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': diffuse_bsdf}, attrs={'is_active_output': True})

def shader_vis_b_align(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    diffuse_bsdf = nw.new_node(Nodes.DiffuseBSDF, input_kwargs={'Color': (0.6229, 0.2715, 0.2366, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': diffuse_bsdf}, attrs={'is_active_output': True})

def shader_vis_b_vect(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    diffuse_bsdf = nw.new_node(Nodes.DiffuseBSDF, input_kwargs={'Color': (0.2881, 0.3153, 0.1075, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': diffuse_bsdf}, attrs={'is_active_output': True})

def shader_vis_b_auto(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    diffuse_bsdf = nw.new_node(Nodes.DiffuseBSDF, input_kwargs={'Color': (1.0000, 0.7934, 0.2986, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': diffuse_bsdf}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_is_bezier_point', singleton=False, type='GeometryNodeTree')
def nodegroup_is_bezier_point(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    handle_type_selection_8 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'FREE'})
    
    handle_type_selection_9 = nw.new_node('GeometryNodeCurveHandleTypeSelection')
    
    op_or = nw.new_node(Nodes.BooleanMath,
        input_kwargs={0: handle_type_selection_8, 1: handle_type_selection_9},
        attrs={'operation': 'OR'})
    
    handle_type_selection_10 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'VECTOR'})
    
    op_or_1 = nw.new_node(Nodes.BooleanMath, input_kwargs={0: op_or, 1: handle_type_selection_10}, attrs={'operation': 'OR'})
    
    handle_type_selection_11 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'ALIGN'})
    
    op_or_2 = nw.new_node(Nodes.BooleanMath, input_kwargs={0: op_or_1, 1: handle_type_selection_11}, attrs={'operation': 'OR'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Boolean': op_or_2}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_z_vis_bezier_handles', singleton=False, type='GeometryNodeTree')
def nodegroup_z_vis_bezier_handles(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_2 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Enable', True),
            ('NodeSocketBool', 'Selection', True),
            ('NodeSocketFloat', 'Size', 0.3000),
            ('NodeSocketFloatDistance', 'Radius', 0.0200)])
    
    is_viewport = nw.new_node(Nodes.IsViewport)
    
    op_and = nw.new_node(Nodes.BooleanMath, input_kwargs={0: group_input_2.outputs["Enable"], 1: is_viewport})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_2.outputs["Curve"]})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    curve_handle_positions_1 = nw.new_node('GeometryNodeInputCurveHandlePositions')
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_handle_positions_1.outputs["Left"]})
    
    capture_attribute_2 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_25, 1: reroute_24},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    is_bezier_point = nw.new_node(nodegroup_is_bezier_point().name)
    
    op_and_1 = nw.new_node(Nodes.BooleanMath, input_kwargs={0: group_input_2.outputs["Selection"], 1: is_bezier_point})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': op_and_1})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (0.0000, 0.0000, 0.0000)})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_line})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': capture_attribute_2.outputs["Geometry"], 'Selection': reroute_65, 'Instance': reroute_19})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_1})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': endpoint_selection})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_2.outputs["Attribute"]})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances, 'Selection': reroute_14, 'Position': reroute_18})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_handle_positions_1.outputs["Right"]})
    
    capture_attribute_3 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_26, 1: reroute_23},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_line})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': capture_attribute_3.outputs["Geometry"], 'Selection': reroute_65, 'Instance': reroute_21})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_2})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': endpoint_selection})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_3.outputs["Attribute"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': realize_instances_1, 'Selection': reroute_13, 'Position': reroute_11})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_1})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_64, reroute_63]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': group_input_2.outputs["Radius"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': join_geometry_2, 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh, 'Shade Smooth': False})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_vis_b_auto)})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_1})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    cube_2 = nw.new_node(Nodes.MeshCube)
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_2.outputs["Mesh"], 'Name': 'uv_map', 3: cube_2.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    dual_mesh_2 = nw.new_node(Nodes.DualMesh, input_kwargs={'Mesh': store_named_attribute})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': set_position, 'Selection': reroute_15, 'Instance': dual_mesh_2, 'Scale': group_input_2.outputs["Size"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_2.outputs["Curve"]})
    
    handle_type_selection = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'mode': {'LEFT'}})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_2, 4: handle_type_selection},
        attrs={'data_type': 'BOOLEAN'})
    
    index_6 = nw.new_node(Nodes.Index)
    
    sample_index_6 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 5: capture_attribute.outputs[4], 'Index': index_6},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points_3, 'Selection': sample_index_6.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_auto)})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    handle_type_selection_1 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'VECTOR', 'mode': {'LEFT'}})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_7, 4: handle_type_selection_1},
        attrs={'data_type': 'BOOLEAN'})
    
    index_7 = nw.new_node(Nodes.Index)
    
    sample_index_7 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 5: capture_attribute_1.outputs[4], 'Index': index_7},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_material_2, 'Selection': sample_index_7.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_vect)})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    handle_type_selection_2 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'ALIGN', 'mode': {'LEFT'}})
    
    capture_attribute_4 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_9, 4: handle_type_selection_2},
        attrs={'data_type': 'BOOLEAN'})
    
    index_4 = nw.new_node(Nodes.Index)
    
    sample_index_4 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_4.outputs["Geometry"], 5: capture_attribute_4.outputs[4], 'Index': index_4},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_material_3, 'Selection': sample_index_4.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_align)})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    handle_type_selection_3 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'FREE', 'mode': {'LEFT'}})
    
    capture_attribute_5 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_10, 4: handle_type_selection_3},
        attrs={'data_type': 'BOOLEAN'})
    
    index_5 = nw.new_node(Nodes.Index)
    
    sample_index_5 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_5.outputs["Geometry"], 5: capture_attribute_5.outputs[4], 'Index': index_5},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_5 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_material_4, 'Selection': sample_index_5.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_free)})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_13})
    
    instance_on_points_4 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': set_position_1, 'Selection': reroute_12, 'Instance': dual_mesh_2, 'Scale': group_input_2.outputs["Size"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_2.outputs["Curve"]})
    
    handle_type_selection_4 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'mode': {'RIGHT'}})
    
    capture_attribute_6 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_8, 4: handle_type_selection_4},
        attrs={'data_type': 'BOOLEAN'})
    
    index_3 = nw.new_node(Nodes.Index)
    
    sample_index_3 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_6.outputs["Geometry"], 5: capture_attribute_6.outputs[4], 'Index': index_3},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_6 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points_4, 'Selection': sample_index_3.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_auto)})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    handle_type_selection_5 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'VECTOR', 'mode': {'RIGHT'}})
    
    capture_attribute_7 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_4, 4: handle_type_selection_5},
        attrs={'data_type': 'BOOLEAN'})
    
    index_2 = nw.new_node(Nodes.Index)
    
    sample_index_2 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_7.outputs["Geometry"], 5: capture_attribute_7.outputs[4], 'Index': index_2},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_7 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_material_6, 'Selection': sample_index_2.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_vect)})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    handle_type_selection_7 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'ALIGN', 'mode': {'RIGHT'}})
    
    capture_attribute_8 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_5, 4: handle_type_selection_7},
        attrs={'data_type': 'BOOLEAN'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    sample_index_1 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_8.outputs["Geometry"], 5: capture_attribute_8.outputs[4], 'Index': index_1},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_8 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_material_7, 'Selection': sample_index_1.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_align)})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    handle_type_selection_6 = nw.new_node('GeometryNodeCurveHandleTypeSelection', attrs={'handle_type': 'FREE', 'mode': {'RIGHT'}})
    
    capture_attribute_9 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': reroute_6, 4: handle_type_selection_6},
        attrs={'data_type': 'BOOLEAN'})
    
    index = nw.new_node(Nodes.Index)
    
    sample_index = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': capture_attribute_9.outputs["Geometry"], 5: capture_attribute_9.outputs[4], 'Index': index},
        attrs={'data_type': 'BOOLEAN', 'clamp': True})
    
    set_material_9 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_material_8, 'Selection': sample_index.outputs[4], 'Material': surface.shaderfunc_to_material(shader_vis_b_free)})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_5, set_material_9]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_27, join_geometry]})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_1})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: op_and, 15: reroute_28})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Gizmos': switch.outputs[6]}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    bezier_segment = nw.new_node(Nodes.CurveBezierSegment, input_kwargs={'End Handle': (0.5000, -0.5000, 0.0000)})
    
    zvis_bezier_handles = nw.new_node(nodegroup_z_vis_bezier_handles().name, input_kwargs={'Curve': bezier_segment})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [zvis_bezier_handles, bezier_segment]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
apply(bpy.context.active_object)