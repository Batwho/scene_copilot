import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_stair_generator', singleton=False, type='GeometryNodeTree')
def nodegroup_stair_generator(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketInt', 'Stair Count', 10),
            ('NodeSocketFloat', 'Stair Width', 0.9144),
            ('NodeSocketBool', 'Include Foundation', True),
            ('NodeSocketFloat', 'Foundation Width', 0.9000),
            ('NodeSocketMaterial', 'Foundation Material', None),
            ('NodeSocketFloat', 'Rise', 0.1778),
            ('NodeSocketFloat', 'Run', 0.2794),
            ('NodeSocketFloat', 'Nosing', 0.0250),
            ('NodeSocketFloat', 'Tread Thickness', 0.0250),
            ('NodeSocketMaterial', 'Tread Material', None),
            ('NodeSocketBool', 'Include Risers', True),
            ('NodeSocketBool', 'Include Top Riser', False),
            ('NodeSocketFloat', 'Riser Thickness', 0.0120),
            ('NodeSocketMaterial', 'Riser Material', None),
            ('NodeSocketBool', 'Include Bannister', False),
            ('NodeSocketBool', 'Bannister on RIght', True),
            ('NodeSocketFloat', 'Bannister Height', 0.9000),
            ('NodeSocketGeometry', 'Bannister Profile Curve', None),
            ('NodeSocketFloat', 'Bannister Offset', 0.1000),
            ('NodeSocketMaterial', 'Bannister Material', None),
            ('NodeSocketGeometry', 'Support Object', None),
            ('NodeSocketInt', 'Support Count', 2),
            ('NodeSocketFloatFactor', 'Support Inset', 0.9000),
            ('NodeSocketMaterial', 'Support Material', None)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Stair Count"]})
    
    mesh_line_1 = nw.new_node(Nodes.MeshLine, input_kwargs={'Count': reroute})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Stair Width"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Run"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Tread Thickness"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_8, 'Y': reroute_7, 'Z': reroute_9})
    
    cube = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': combine_xyz_1})
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube.outputs["Mesh"], 'Name': 'uv_map', 3: cube.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': mesh_line_1, 'Instance': store_named_attribute_2})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Run"]})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Nosing"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: reroute_11}, attrs={'operation': 'SUBTRACT'})
    
    index = nw.new_node(Nodes.Index)
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: subtract, 1: index}, attrs={'operation': 'MULTIPLY'})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Rise"]})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: reroute_12}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply, 'Z': multiply_1})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': instance_on_points, 'Position': combine_xyz})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Tread Material"]})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_29})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': reroute_18, 'Material': reroute_32})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Include Risers"]})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Stair Count"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: group_input.outputs["Include Top Riser"]})
    
    mesh_line = nw.new_node(Nodes.MeshLine, input_kwargs={'Count': add})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["Stair Width"], 'Y': group_input.outputs["Riser Thickness"], 'Z': group_input.outputs["Rise"]})
    
    cube_1 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': combine_xyz_2})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_1.outputs["Mesh"], 'Name': 'uv_map', 3: cube_1.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': mesh_line, 'Instance': store_named_attribute})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_1})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Run"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Nosing"]})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_3, 1: reroute_2}, attrs={'operation': 'SUBTRACT'})
    
    index_2 = nw.new_node(Nodes.Index)
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_1, 1: index_2}, attrs={'operation': 'MULTIPLY'})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_3, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_2 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_2, 1: divide}, attrs={'operation': 'SUBTRACT'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Riser Thickness"]})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_5, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_2, 1: divide_1})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: add_1, 1: reroute_2})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Rise"]})
    
    index_1 = nw.new_node(Nodes.Index)
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: index_1}, attrs={'operation': 'MULTIPLY'})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_19, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3, 1: divide_2}, attrs={'operation': 'SUBTRACT'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Tread Thickness"]})
    
    divide_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_6, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_4 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_3, 1: divide_3}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': add_2, 'Z': subtract_4})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_17, 'Position': combine_xyz_3})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_13, 15: set_position_1})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Riser Material"]})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_41})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': switch.outputs[6], 'Material': reroute_40})
    
    reroute_86 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Include Bannister"]})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_86})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_44})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_43})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_35})
    
    reroute_92 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Stair Width"]})
    
    reroute_93 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Bannister on RIght"]})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: reroute_93, 4: -1, 5: 1}, attrs={'input_type': 'INT'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_92, 1: switch_1.outputs[1]}, attrs={'operation': 'MULTIPLY'})
    
    divide_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_4, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_91 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Bannister Offset"]})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_91, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_5, 1: switch_1.outputs[1]}, attrs={'operation': 'MULTIPLY'})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: divide_4, 1: multiply_6})
    
    reroute_96 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Run"]})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_96})
    
    subtract_5 = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000, 1: reroute_28}, attrs={'operation': 'SUBTRACT'})
    
    reroute_90 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Bannister Height"]})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_90})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_3, 'Y': subtract_5, 'Z': reroute_24})
    
    reroute_95 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Nosing"]})
    
    subtract_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_96, 1: reroute_95}, attrs={'operation': 'SUBTRACT'})
    
    reroute_89 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Stair Count"]})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_89})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_6, 1: reroute_22}, attrs={'operation': 'MULTIPLY'})
    
    subtract_7 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_7, 1: reroute_28}, attrs={'operation': 'SUBTRACT'})
    
    reroute_97 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Rise"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_97})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: reroute_22}, attrs={'operation': 'MULTIPLY'})
    
    add_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_8, 1: reroute_24})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_3, 'Y': subtract_7, 'Z': add_4})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_6, 'End': combine_xyz_5})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_line})
    
    reroute_94 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Bannister Profile Curve"]})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_94})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': reroute_34, 'Profile Curve': reroute_25, 'Fill Caps': True})
    
    reroute_88 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Bannister Material"]})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_88})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_33})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': curve_to_mesh, 'Material': reroute_20})
    
    reroute_87 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Support Inset"]})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_87})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_39})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_38})
    
    subtract_8 = nw.new_node(Nodes.Math, input_kwargs={0: 1.0000, 1: reroute_37}, attrs={'operation': 'SUBTRACT'})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': reroute_34, 2: subtract_8, 3: reroute_37})
    
    reroute_84 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Support Count"]})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_84})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_46})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': trim_curve, 'Count': reroute_30})
    
    reroute_85 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Support Object"]})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_85})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_45})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_42})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_50})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': resample_curve, 'Instance': reroute_49})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Support Material"]})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_47})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': instance_on_points_2, 'Material': reroute_48})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_2, set_material_3]})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_36, 15: join_geometry_1})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Include Foundation"]})
    
    reroute_74 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_67})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_74})
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_69})
    
    cube_2 = nw.new_node(Nodes.MeshCube)
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_2.outputs["Mesh"], 'Name': 'uv_map', 3: cube_2.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    set_position_3 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': store_named_attribute_1, 'Offset': (0.0000, 0.0000, 0.5000)})
    
    geometry_to_instance = nw.new_node('GeometryNodeGeometryToInstance', input_kwargs={'Geometry': set_position_3})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Stair Count"]})
    
    switch_4 = nw.new_node(Nodes.Switch, input_kwargs={4: reroute_57, 5: reroute_57}, attrs={'input_type': 'INT'})
    
    duplicate_elements = nw.new_node(Nodes.DuplicateElements,
        input_kwargs={'Geometry': geometry_to_instance, 'Amount': switch_4.outputs[1]},
        attrs={'domain': 'INSTANCE'})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': duplicate_elements.outputs["Geometry"]})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_73})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Foundation Width"]})
    
    reroute_76 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_58})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_76})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Run"]})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Nosing"]})
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_55})
    
    subtract_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_56, 1: reroute_70}, attrs={'operation': 'SUBTRACT'})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract_9})
    
    reroute_77 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_62})
    
    add_5 = nw.new_node(Nodes.Math, input_kwargs={0: duplicate_elements.outputs["Duplicate Index"], 1: 1.0000})
    
    reroute_78 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_5})
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_78})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Rise"]})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_53})
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_60})
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_80, 1: reroute_81}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_61, 'Y': reroute_77, 'Z': multiply_9})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances,
        input_kwargs={'Instances': reroute_72, 'Scale': combine_xyz_7, 'Local Space': False})
    
    reroute_79 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_78})
    
    multiply_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_79, 1: reroute_62}, attrs={'operation': 'MULTIPLY'})
    
    reroute_82 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_62})
    
    subtract_10 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_10, 1: reroute_82}, attrs={'operation': 'SUBTRACT'})
    
    divide_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_70, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add_6 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_10, 1: divide_5})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Riser Thickness"]})
    
    add_7 = nw.new_node(Nodes.Math, input_kwargs={0: add_6, 1: reroute_59})
    
    position = nw.new_node(Nodes.InputPosition)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Tread Thickness"]})
    
    divide_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_64, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    reroute_83 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': divide_6})
    
    subtract_11 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Z"], 1: reroute_83}, attrs={'operation': 'SUBTRACT'})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_60})
    
    subtract_12 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_11, 1: reroute_63}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': add_7, 'Z': subtract_12})
    
    translate_instances = nw.new_node(Nodes.TranslateInstances,
        input_kwargs={'Instances': scale_instances, 'Translation': combine_xyz_8, 'Local Space': False})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': translate_instances})
    
    union = nw.new_node(Nodes.MeshBoolean,
        input_kwargs={'Mesh 2': realize_instances, 'Self Intersection': True},
        attrs={'operation': 'UNION'})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Foundation Material"]})
    
    reroute_75 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_66})
    
    reroute_68 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_75})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_68})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': union.outputs["Mesh"], 'Material': reroute_71})
    
    switch_3 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_54, 15: set_material_4})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [set_material_1, set_material, switch_2.outputs[6], switch_3.outputs[6]]})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Rise"]})
    
    reroute_99 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_52})
    
    reroute_100 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_99})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Tread Thickness"]})
    
    reroute_98 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_51})
    
    divide_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_98, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_100, 1: divide_7})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': add_8})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': join_geometry, 'Offset': combine_xyz_4})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_2}, attrs={'is_active_output': True})

def shader_risers(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion)
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': ambient_occlusion.outputs["AO"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_material_005(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.3108, 0.2722, 0.2318, 1.0000), 'Metallic': 1.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_material_004(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    musgrave_texture = nw.new_node(Nodes.MusgraveTexture)
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.3333, 6: (0.0572, 0.0130, 0.0012, 1.0000), 7: musgrave_texture},
        attrs={'data_type': 'RGBA', 'blend_type': 'MULTIPLY'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': mix.outputs[2], 'Roughness': 0.8394})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_material_003(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': (0.0495, 0.0495, 0.0495, 1.0000)})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    stairgenerator = nw.new_node(nodegroup_stair_generator().name, input_kwargs={'Stair Count': 5})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': stairgenerator}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_material_003, selection=selection)
    surface.add_material(obj, shader_material_004, selection=selection)
    surface.add_material(obj, shader_material_005, selection=selection)
    surface.add_material(obj, shader_risers, selection=selection)
apply(bpy.context.active_object)