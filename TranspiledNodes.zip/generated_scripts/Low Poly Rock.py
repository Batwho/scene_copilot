import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_rock(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.1500, 0.1377, 0.1350, 1.0000), 'Roughness': 0.6000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    mesh_line = nw.new_node(Nodes.MeshLine, input_kwargs={'Count': 5, 'Offset': (0.0000, 0.0000, 0.0000)})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': 1.2000})
    
    group_input_1 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketInt', 'Random Seed', 53),
            ('NodeSocketFloat', 'Edges Damages Intensity', 0.4600)])
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={'Seed': group_input_1.outputs["Random Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.4000, 0.4000, 0.4000), 1: (3.0000, 3.0000, 3.0000), 'Seed': group_input_1.outputs["Random Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_line, 'Instance': ico_sphere.outputs["Mesh"], 'Rotation': random_value.outputs["Value"], 'Scale': random_value_1.outputs["Value"]})
    
    intersect = nw.new_node(Nodes.MeshBoolean, input_kwargs={'Mesh 2': instance_on_points}, attrs={'operation': 'INTERSECT'})
    
    mesh_to_volume = nw.new_node('GeometryNodeMeshToVolume', input_kwargs={'Mesh': intersect.outputs["Mesh"], 'Voxel Amount': 8.0000})
    
    volume_to_mesh = nw.new_node(Nodes.VolumeToMesh, input_kwargs={'Volume': mesh_to_volume, 'Threshold': 0.1000})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    blur_attribute = nw.new_node(Nodes.BlurAttribute, input_kwargs={2: position_1, 'Iterations': 2}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': volume_to_mesh, 'Position': blur_attribute.outputs[2]})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    position = nw.new_node(Nodes.InputPosition)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': position, 'Scale': 1.0000, 'Detail': 5.0000, 'Roughness': 1.0000})
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: noise_texture.outputs["Fac"], 1: group_input_1.outputs["Edges Damages Intensity"]},
        attrs={'operation': 'SUBTRACT'})
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal, 'Scale': subtract}, attrs={'operation': 'SCALE'})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_1, 'Offset': scale.outputs["Vector"]})
    
    intersect_1 = nw.new_node(Nodes.MeshBoolean,
        input_kwargs={'Mesh 2': [set_position, intersect.outputs["Mesh"]]},
        attrs={'operation': 'INTERSECT'})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': intersect_1.outputs["Mesh"], 'Material': surface.shaderfunc_to_material(shader_rock)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_material}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_rock, selection=selection)
apply(bpy.context.active_object)
