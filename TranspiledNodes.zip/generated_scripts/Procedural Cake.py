import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_plate(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    bevel = nw.new_node('ShaderNodeBevel', input_kwargs={'Radius': 0.0100})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0000, 0.0000, 0.0000, 1.0000), 'Roughness': 0.2190, 'Normal': bevel})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_cream(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'decocreamcolor'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': attribute.outputs["Color"], 'Subsurface': 0.0300},
        attrs={'subsurface_method': 'BURLEY'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_cake(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate_1 = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate_1.outputs["Object"]})
    
    mapping_1 = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': reroute})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': mapping_1})
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'cakeheight'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: attribute.outputs["Fac"], 1: -0.5000})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Z"], 1: add}, attrs={'operation': 'SUBTRACT'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': subtract})
    colorramp.color_ramp.elements[0].position = 0.4139
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.4441
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mapping_2 = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': reroute, 'Scale': (1.0000, 1.0000, 0.1000)})
    
    length = nw.new_node(Nodes.VectorMath, input_kwargs={0: mapping_2}, attrs={'operation': 'LENGTH'})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': length.outputs["Value"], 2: 1.8000})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'cakeradius'})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: attribute_1.outputs["Fac"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: divide, 1: -0.5500})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: add_1}, attrs={'operation': 'SUBTRACT'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': subtract_1})
    colorramp_1.color_ramp.elements[0].position = 0.5257
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.5529
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: colorramp_1.outputs["Color"]},
        attrs={'blend_type': 'SCREEN', 'data_type': 'RGBA'})
    
    texture_coordinate_2 = nw.new_node(Nodes.TextureCoord)
    
    mapping_3 = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate_2.outputs["Object"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping_3, 'Scale': 10.9000, 'Detail': 10.0000, 'Roughness': 0.0000})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping_3, 'Scale': 20.0000, 'Detail': 10.0000, 'Roughness': 0.0000})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: noise_texture.outputs["Fac"], 7: noise_texture_2.outputs["Fac"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': mix_6.outputs[2]})
    colorramp_2.color_ramp.interpolation = "B_SPLINE"
    colorramp_2.color_ramp.elements[0].position = 0.4290
    colorramp_2.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_1.outputs[2], 7: colorramp_2.outputs["Color"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    mix_3 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_2.outputs[2], 7: mix_2.outputs[2]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_3.outputs[2], 7: mix_3.outputs[2]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: attribute.outputs["Fac"], 1: -0.5000})
    
    subtract_2 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Z"], 1: add_2}, attrs={'operation': 'SUBTRACT'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': attribute.outputs["Fac"], 1: 0.5000, 2: 2.0000, 4: 0.4000})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: subtract_2, 1: map_range_1.outputs["Result"]})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': add_3})
    colorramp_3.color_ramp.elements.new(0)
    colorramp_3.color_ramp.elements[0].position = 0.2054
    colorramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 0.2538
    colorramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_3.color_ramp.elements[2].position = 0.2991
    colorramp_3.color_ramp.elements[2].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: attribute.outputs["Fac"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    add_4 = nw.new_node(Nodes.Math, input_kwargs={0: attribute.outputs["Fac"], 1: multiply})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Z"], 1: add_4}, attrs={'operation': 'SUBTRACT'})
    
    subtract_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: subtract_3, 1: map_range_1.outputs["Result"]},
        attrs={'operation': 'SUBTRACT'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': subtract_4})
    colorramp_4.color_ramp.elements.new(0)
    colorramp_4.color_ramp.elements[0].position = 0.1994
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.2538
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_4.color_ramp.elements[2].position = 0.3082
    colorramp_4.color_ramp.elements[2].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_12 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_3.outputs["Color"], 7: colorramp_4.outputs["Color"]},
        attrs={'blend_type': 'SCREEN', 'data_type': 'RGBA'})
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_12.outputs[2], 7: colorramp_2.outputs["Color"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_7.outputs[2], 7: mix_7.outputs[2]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_9.outputs[2], 7: mix_9.outputs[2]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    attribute_2 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'spongecolor'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': attribute_2.outputs["Color"]})
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate.outputs["Generated"]})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mapping, 'Scale': 15.0000, 'Detail': 10.3000})
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={6: reroute_1, 7: noise_texture_1.outputs["Fac"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Hue': 0.6000, 'Saturation': 1.5000, 'Color': reroute_1})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': mapping, 'Scale': 15.0000}, attrs={'feature': 'SMOOTH_F1'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': mapping, 'Scale': 30.0000}, attrs={'feature': 'SMOOTH_F1'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={6: voronoi_texture.outputs["Distance"], 7: voronoi_texture_1.outputs["Distance"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.1000, 'Height': mix.outputs[2]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_5.outputs[2], 'Subsurface': 0.1761, 'Subsurface Color': hue_saturation_value, 'Subsurface IOR': 0.3000, 'Roughness': 0.7417, 'Normal': bump},
        attrs={'subsurface_method': 'BURLEY'})
    
    attribute_4 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'creaminsidecolor'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': attribute_4.outputs["Color"]})
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 15.0000, 'Detail': 10.3000, 'Distortion': 1.0000})
    
    mix_10 = nw.new_node(Nodes.Mix,
        input_kwargs={6: reroute_3, 7: noise_texture_4.outputs["Fac"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    hue_saturation_value_3 = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Hue': 0.6000, 'Saturation': 1.5000, 'Color': reroute_3})
    
    noise_texture_3 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping, 'Scale': 0.3000, 'Detail': 10.3000, 'Distortion': 0.5000})
    
    mix_11 = nw.new_node(Nodes.Mix, input_kwargs={6: noise_texture_3.outputs["Fac"]}, attrs={'data_type': 'RGBA'})
    
    bevel = nw.new_node('ShaderNodeBevel', input_kwargs={'Radius': 0.0400})
    
    bump_1 = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': 0.6000, 'Distance': 0.1000, 'Height': mix_11.outputs[2], 'Normal': bevel})
    
    principled_bsdf_2 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_10.outputs[2], 'Subsurface': 0.3000, 'Subsurface Color': hue_saturation_value_3, 'Roughness': 0.1314, 'Normal': bump_1},
        attrs={'subsurface_method': 'BURLEY'})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': mix_8.outputs[2], 1: principled_bsdf, 2: principled_bsdf_2})
    
    attribute_3 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'covercreamcolor'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': attribute_3.outputs["Color"]})
    
    hue_saturation_value_1 = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Hue': 0.6000, 'Saturation': 1.5000, 'Color': reroute_2})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': reroute_2, 'Subsurface': 0.1248, 'Subsurface Color': hue_saturation_value_1, 'Roughness': 0.1314, 'Normal': bump_1},
        attrs={'subsurface_method': 'BURLEY'})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': mix_4.outputs[2], 1: mix_shader_1, 2: principled_bsdf_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketColor', 'Cover Cream Color ', (1.0000, 0.5906, 0.5029, 0.0000)),
            ('NodeSocketColor', 'Sponge Cake Color', (1.0000, 0.5333, 0.3467, 0.0000)),
            ('NodeSocketColor', 'Cream inside Color', (1.0000, 1.0000, 1.0000, 0.0000)),
            ('NodeSocketColor', 'DecoCream Color', (1.0000, 1.0000, 1.0000, 0.0000)),
            ('NodeSocketFloat', 'Cake cut', 1.0000),
            ('NodeSocketFloat', 'Cake height', 0.7000),
            ('NodeSocketFloat', 'Cake radius', 1.3000),
            ('NodeSocketBool', 'Topping', True),
            ('NodeSocketFloat', 'Topping quantity', 24.0000),
            ('NodeSocketFloat', 'Topping position', 0.9000),
            ('NodeSocketBool', 'DecoCream Bottom', True),
            ('NodeSocketFloat', 'CreamBot quantity', 46.0000),
            ('NodeSocketFloat', 'CreamBot size', 0.8000),
            ('NodeSocketBool', 'DecoCream Top', True),
            ('NodeSocketFloat', 'CreamTop quantity', 48.0000),
            ('NodeSocketFloat', 'CreamTop size', 0.7000),
            ('NodeSocketBool', 'Plate', True),
            ('NodeSocketFloat', 'Plate size', 0.3000),
            ('NodeSocketFloat', 'Plate thickness', 0.0500)])
    
    mix_5 = nw.new_node(Nodes.Mix, input_kwargs={0: group_input.outputs["Cake cut"], 2: 0.0500, 3: 1.0000})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_5.outputs["Result"]})
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: 6.6000})
    
    arc = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Resolution': 32, 'Radius': 0.0010, 'Sweep Angle': mix.outputs["Result"]})
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 2: 3.0000, 3: 64.0000})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': arc.outputs["Curve"], 'Count': mix_1.outputs["Result"]})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Cake height"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_1})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 50})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.0000, 1.0000), (0.4018, 1.0000), (0.7432, 1.0000), (0.9396, 0.9397), (0.9940, 0.7284), (1.0000, 0.0000)])
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Cake radius"]})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve, 1: reroute_1}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_1})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': resample_curve, 'Offset': combine_xyz_2})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_line_1, set_position]})
    
    curve_to_mesh_2 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': join_geometry_1, 'Fill Caps': True})
    
    merge_by_distance_1 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': curve_to_mesh_2, 'Distance': 0.0100})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': merge_by_distance_1})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': resample_curve_1, 'Profile Curve': mesh_to_curve, 'Fill Caps': True})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': curve_to_mesh_1, 'Distance': 0.0100})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': merge_by_distance, 'Material': surface.shaderfunc_to_material(shader_cake)})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input.outputs["Topping position"], 2: group_input.outputs["Cake radius"], 3: 0.2500})
    
    mix_3 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute_8, 3: mix_7.outputs["Result"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8, 1: mix_3.outputs["Result"]}, attrs={'operation': 'SUBTRACT'})
    
    mix_4 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: 6.3300})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: mix_4.outputs["Result"], 1: -0.3000})
    
    arc_1 = nw.new_node('GeometryNodeCurveArc', input_kwargs={'Radius': subtract, 'Start Angle': 0.1745, 'Sweep Angle': add})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Cake height"], 1: 0.9700},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_2})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': arc_1.outputs["Curve"], 'Offset': combine_xyz_3})
    
    mix_6 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: group_input.outputs["Topping quantity"]})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_position_1, 'Count': mix_6.outputs["Result"]})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': resample_curve_2, 'Count': mix_6.outputs["Result"]})
    
    collection_info = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': bpy.data.collections['Topping_instance'], 'Separate Children': True, 'Reset Children': True})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points.outputs["Rotation"], 'Rotate By': (0.0000, 0.0000, 1.5708)})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': collection_info, 'Pick Instance': True, 'Rotation': rotate_euler})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["Topping"], 15: instance_on_points})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    mix_12 = nw.new_node(Nodes.Mix, input_kwargs={0: 1.0000, 2: group_input.outputs["Cake radius"], 3: -0.1000})
    
    mix_8 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute_9, 3: mix_12.outputs["Result"]})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_9, 1: mix_8.outputs["Result"]}, attrs={'operation': 'SUBTRACT'})
    
    mix_9 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: 6.3300})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: mix_9.outputs["Result"], 1: -0.1500})
    
    arc_2 = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Radius': subtract_1, 'Start Angle': 0.0873, 'Sweep Angle': add_1})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': arc_2.outputs["Curve"]})
    
    mix_11 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: group_input.outputs["CreamBot quantity"]})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_position_2, 'Count': mix_11.outputs["Result"]})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': resample_curve_3, 'Count': mix_11.outputs["Result"]})
    
    collection_info_1 = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': bpy.data.collections['DecoCream_instance'], 'Separate Children': True, 'Reset Children': True})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotation': curve_to_points_1.outputs["Rotation"]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["CreamBot size"]})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_10, 'Y': reroute_10, 'Z': reroute_10})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': collection_info_1, 'Pick Instance': True, 'Rotation': rotate_euler_1, 'Scale': combine_xyz_4})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_1})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': realize_instances, 'Material': surface.shaderfunc_to_material(shader_cream)})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["DecoCream Bottom"], 15: set_material_4})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    mix_15 = nw.new_node(Nodes.Mix, input_kwargs={0: 1.0000, 2: group_input.outputs["Cake radius"], 3: 0.1500})
    
    mix_10 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute_11, 3: mix_15.outputs["Result"]})
    
    subtract_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_11, 1: mix_10.outputs["Result"]}, attrs={'operation': 'SUBTRACT'})
    
    mix_13 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: 6.3300})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: mix_13.outputs["Result"], 1: -0.1500})
    
    arc_3 = nw.new_node('GeometryNodeCurveArc',
        input_kwargs={'Radius': subtract_2, 'Start Angle': 0.1396, 'Sweep Angle': add_2})
    
    subtract_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Cake height"], 1: 0.1000},
        attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract_3})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': arc_3.outputs["Curve"], 'Offset': combine_xyz_6})
    
    mix_14 = nw.new_node(Nodes.Mix, input_kwargs={0: reroute, 3: group_input.outputs["CreamTop quantity"]})
    
    resample_curve_4 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_position_3, 'Count': mix_14.outputs["Result"]})
    
    curve_to_points_2 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': resample_curve_4, 'Count': mix_14.outputs["Result"]})
    
    collection_info_2 = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': bpy.data.collections['DecoCream_instance'], 'Separate Children': True, 'Reset Children': True})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler, input_kwargs={'Rotation': curve_to_points_2.outputs["Rotation"]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["CreamTop size"]})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_12, 'Y': reroute_12, 'Z': reroute_12})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_2.outputs["Points"], 'Instance': collection_info_2, 'Pick Instance': True, 'Rotation': rotate_euler_2, 'Scale': combine_xyz_5})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_2})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': realize_instances_1, 'Material': surface.shaderfunc_to_material(shader_cream)})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["DecoCream Top"], 15: set_material_3})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [switch_1.outputs[6], switch.outputs[6]]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_1, switch_2.outputs[6], join_geometry_2]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Plate thickness"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: group_input.outputs["Plate size"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 100, 'Radius': add_3})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': curve_line, 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': surface.shaderfunc_to_material(shader_plate)})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': normal})
    
    split_edges = nw.new_node(Nodes.SplitEdges, input_kwargs={'Mesh': set_material, 'Selection': separate_xyz.outputs["Z"]})
    
    realize_instances_3 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': split_edges})
    
    set_position_4 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': realize_instances_3, 'Offset': (0.0000, 0.0000, 0.0100)})
    
    switch_3 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["Plate"], 15: set_position_4})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': switch_3.outputs[6]})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [join_geometry, set_shade_smooth_1]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Cake height"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Cake radius"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': join_geometry_3, 'Cake height': reroute_2, 'Cake radius': reroute_3, 'Cover Cream Color ': group_input.outputs["Cover Cream Color "], 'Sponge Color': group_input.outputs["Sponge Cake Color"], 'Cream inside Color': group_input.outputs["Cream inside Color"], 'Decorate Cream Color': group_input.outputs["DecoCream Color"]},
        attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_cake, selection=selection)
    surface.add_material(obj, shader_cream, selection=selection)
    surface.add_material(obj, shader_plate, selection=selection)