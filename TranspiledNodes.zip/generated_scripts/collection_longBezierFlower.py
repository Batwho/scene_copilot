import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_a_s_t_rotate_x_y_z', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_rotate_x_y_z(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Direction', 0),
            ('NodeSocketString', '#', '0=X, 1=Y and 2=Z')])
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Direction"]})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2, 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 90.0000
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={0: equal, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    equal_1 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2}, attrs={'operation': 'EQUAL'})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={0: equal_1, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    equal_2 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2, 1: 2.0000}, attrs={'operation': 'EQUAL'})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: equal_2, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': switch.outputs["Output"], 'Y': switch_2.outputs["Output"], 'Z': switch_1.outputs["Output"]})
    
    divide = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_3, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Rotation': divide.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': transform}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_index_selection', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_index_selection(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    index_2 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: 2.0000}, attrs={'operation': 'MODULO'})
    
    less_equal = nw.new_node(Nodes.Compare, input_kwargs={0: modulo}, attrs={'operation': 'LESS_EQUAL'})
    
    greater_equal = nw.new_node(Nodes.Compare, input_kwargs={0: modulo, 1: 1.0000}, attrs={'operation': 'GREATER_EQUAL'})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketInt', '%', 2)])
    
    modulo_1 = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: group_input.outputs["%"]}, attrs={'operation': 'MODULO'})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={2: modulo_1}, attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_1 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 1},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_2 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 2},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_3 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 3},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    equal_4 = nw.new_node(Nodes.Compare,
        input_kwargs={1: 1.0000, 2: modulo_1, 3: 4},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Even Selection': less_equal, 'Odd Selection': greater_equal, '1st': equal, '2nd': equal_1, '3rd': equal_2, '4th': equal_3, '5th': equal_4},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_bi_directional_bezier', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_bi_directional_bezier(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 16),
            ('NodeSocketFloat', 'Center', 0.0000),
            ('NodeSocketFloat', 'Scale', 1.0000),
            ('NodeSocketFloat', 'Start X', 0.0000),
            ('NodeSocketFloat', 'Start Y', 0.0000),
            ('NodeSocketFloat', 'Middle X', 0.0000),
            ('NodeSocketFloat', 'Middle Y', 0.0000),
            ('NodeSocketFloat', 'End X', 0.0000),
            ('NodeSocketFloat', 'End Y', 0.0000),
            ('NodeSocketInt', 'Direction', 0)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Scale"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000, 1: reroute}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["Start X"], 'Y': group_input.outputs["Start Y"], 'Z': subtract})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["Middle X"], 'Y': group_input.outputs["Middle Y"], 'Z': group_input.outputs["Center"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["End X"], 'Y': group_input.outputs["End Y"], 'Z': reroute})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Start': combine_xyz_2, 'Middle': combine_xyz_1, 'End': combine_xyz})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': quadratic_bezier, 2: spline_parameter.outputs["Length"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Direction"]})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2, 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 90.0000
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={0: equal, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    equal_1 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2}, attrs={'operation': 'EQUAL'})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={0: equal_1, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    equal_2 = nw.new_node(Nodes.Compare, input_kwargs={0: reroute_2, 1: 2.0000}, attrs={'operation': 'EQUAL'})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: equal_2, 3: reroute_1}, attrs={'input_type': 'FLOAT'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': switch.outputs["Output"], 'Y': switch_2.outputs["Output"], 'Z': switch_1.outputs["Output"]})
    
    divide = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_3, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 'Rotation': divide.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': transform, 'Length': capture_attribute.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_mono_directional_bezier', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_mono_directional_bezier(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 16),
            ('NodeSocketVectorEuler', 'Start', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Center', 0.0000),
            ('NodeSocketFloat', 'Middle X', 0.0000),
            ('NodeSocketFloat', 'Middle Y', 0.0000),
            ('NodeSocketFloat', 'Length', 1.0000),
            ('NodeSocketFloat', 'End X', 0.0000),
            ('NodeSocketFloat', 'End Y', 0.0000),
            ('NodeSocketInt', 'Direction', 0)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Center"], 1: 2.0000})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute, 1: add}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["Middle X"], 'Y': group_input.outputs["Middle Y"], 'Z': divide})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input.outputs["End X"], 'Y': group_input.outputs["End Y"], 'Z': reroute})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Start': group_input.outputs["Start"], 'Middle': combine_xyz_1, 'End': combine_xyz})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': quadratic_bezier, 2: spline_parameter.outputs["Length"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: spline_parameter.outputs["Factor"]})
    
    ast_rotate_xyz = nw.new_node(nodegroup_a_s_t_rotate_x_y_z().name,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Direction': group_input.outputs["Direction"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': ast_rotate_xyz, 'Length': capture_attribute.outputs[2], 'Factor': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup("nodegroup_a_s_t_abhays_round_curve", singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_abhays_round_curve(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 64),
            ('NodeSocketFloatFactor', 'Length', 1.0000),
            ('NodeSocketFloatDistance', 'Radius', 1.0000),
            ('NodeSocketBool', 'Fill', False),
            ('NodeSocketInt', 'Cut', 0),
            ('NodeSocketFloat', 'Rotation', 6.2832),
            ('NodeSocketFloat', 'Edge Scale', 1.0000),
            ('NodeSocketFloat', 'Even Index Z offset', 0.0000)])
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    ast_mono_directional_bezier = nw.new_node(nodegroup_a_s_t_mono_directional_bezier().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Length': reroute_4})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: group_input.outputs["Cut"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute_4, 1: spline_parameter.outputs["Factor"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute, 1: group_input.outputs["Rotation"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1}, attrs={'operation': 'SINE'})
    
    sine_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1}, attrs={'operation': 'SINE', 'use_clamp': True})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: greater_than, 2: sine, 3: sine_1}, attrs={'input_type': 'FLOAT'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: switch_1.outputs["Output"], 1: reroute}, attrs={'operation': 'SUBTRACT'})
    
    greater_than_1 = nw.new_node(Nodes.Compare, input_kwargs={0: group_input.outputs["Cut"], 1: 1.0000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    cosine = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2}, attrs={'operation': 'COSINE'})
    
    cosine_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2}, attrs={'operation': 'COSINE', 'use_clamp': True})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={0: greater_than_1, 2: cosine, 3: cosine_1}, attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': subtract, 'Y': switch_2.outputs["Output"]})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': ast_mono_directional_bezier.outputs["Curve"], 'Offset': combine_xyz})
    
    ast_index_selection = nw.new_node(nodegroup_a_s_t_index_selection().name)
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Even Index Z offset"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_position, 'Selection': ast_index_selection.outputs["Even Selection"], 'Offset': combine_xyz_1})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': set_position_1, 'Scale': group_input.outputs["Radius"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': transform})
    
    scale_elements = nw.new_node(Nodes.ScaleElements,
        input_kwargs={'Geometry': curve_to_mesh, 'Selection': ast_index_selection.outputs["Even Selection"], 'Scale': group_input.outputs["Edge Scale"], 'Axis': (0.0000, 0.0000, 0.0000)},
        attrs={'domain': 'EDGE'})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': scale_elements})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': merge_by_distance})
    
    fill_curve = nw.new_node(Nodes.FillCurve, input_kwargs={'Curve': mesh_to_curve}, attrs={'mode': 'NGONS'})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: group_input.outputs["Fill"], 14: mesh_to_curve, 15: fill_curve})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Curve': switch.outputs[6], 'Length': ast_mono_directional_bezier.outputs["Length"], 'Mesh': merge_by_distance},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_before_after', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_before_after(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloatFactor', 'Fac', 0.5000),
            ('NodeSocketFloat', 'Before', 0.0000),
            ('NodeSocketFloat', 'After', 1.0000)])
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input.outputs["Fac"], 6: group_input.outputs["Before"], 7: group_input.outputs["After"]},
        attrs={'data_type': 'RGBA'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Vecter': mix.outputs[2]}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_pollen_3', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_pollen_3(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 16),
            ('NodeSocketInt', 'Resolution_1', 6),
            ('NodeSocketFloat', 'Length', 1.0000),
            ('NodeSocketFloat', 'delete before Bloom ', 0.5000),
            ('NodeSocketFloat', 'Radius', 0.1000),
            ('NodeSocketFloatFactor', 'Trim', 0.7500),
            ('NodeSocketFloat', 'To Min', -1.0000),
            ('NodeSocketFloat', 'To Max', 0.1500),
            ('NodeSocketFloatDistance', 'Spore Radius', 0.0200),
            ('NodeSocketInt', 'Spore Subdivisions', 1),
            ('NodeSocketMaterial', 'Spore', None),
            ('NodeSocketMaterial', 'Stem', None),
            ('NodeSocketFloat', 'Spread', 1.0000)])
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_3, 1: 1.1500}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Start': (0.0000, 0.0000, 0.0000), 'Middle': (0.0000, 0.0000, 0.0000), 'End': combine_xyz_2})
    
    position = nw.new_node(Nodes.InputPosition)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: separate_xyz.outputs["Z"], 1: reroute_3})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': spline_parameter.outputs["Factor"], 2: group_input.outputs["Spread"], 3: group_input.outputs["To Min"], 4: group_input.outputs["To Max"]})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': map_range.outputs["Result"]})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': quadratic_bezier, 'Selection': greater_than, 'Offset': combine_xyz_3})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_3, 1: group_input.outputs["Trim"]}, attrs={'operation': 'MULTIPLY'})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': set_position, 2: multiply_1})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': trim_curve, 'Count': group_input.outputs["Resolution"]})
    
    set_spline_type = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': resample_curve}, attrs={'spline_type': 'BEZIER'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': spline_parameter.outputs["Length"]})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': set_spline_type, 2: reroute})
    
    set_handle_type = nw.new_node(Nodes.SetHandleType, input_kwargs={'Curve': capture_attribute.outputs["Geometry"]})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere,
        input_kwargs={'Radius': group_input.outputs["Spore Radius"], 'Subdivisions': group_input.outputs["Spore Subdivisions"]})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Scale': (1.0000, 1.0000, 2.0000)})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["delete before Bloom "]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    absolute = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4}, attrs={'operation': 'ABSOLUTE'})
    
    less_equal = nw.new_node(Nodes.Compare, input_kwargs={0: absolute, 1: 0.2500}, attrs={'operation': 'LESS_EQUAL'})
    
    delete_geometry_1 = nw.new_node(Nodes.DeleteGeometry, input_kwargs={'Geometry': transform_geometry, 'Selection': less_equal})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Rotation': curve_tangent}, attrs={'axis': 'Z'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': set_handle_type, 'Selection': endpoint_selection, 'Instance': delete_geometry_1, 'Rotation': align_euler_to_vector})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points, 'Material': group_input.outputs["Spore"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Radius"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2, 1: 0.0300}, attrs={'operation': 'MULTIPLY'})
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input.outputs["Resolution_1"], 'Radius': multiply_2})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': curve_circle.outputs["Curve"], 2: reroute})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_handle_type, 'Profile Curve': capture_attribute_1.outputs["Geometry"]})
    
    delete_geometry = nw.new_node(Nodes.DeleteGeometry, input_kwargs={'Geometry': curve_to_mesh, 'Selection': less_equal})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': delete_geometry, 'Material': group_input.outputs["Stem"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_1, set_material]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute_1.outputs[2], 'Y': capture_attribute.outputs[2]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': join_geometry_1, 'UV': combine_xyz, 'spore': ico_sphere.outputs["UV Map"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_circular_distribution', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_circular_distribution(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Petal count', 9),
            ('NodeSocketFloatDistance', 'Radius', 1.0000),
            ('NodeSocketFloat', 'Petal Scale', 1.0000),
            ('NodeSocketFloat', 'Tilt per Petal', 1.0000),
            ('NodeSocketFloatFactor', 'Rotate Petals', 0.5000),
            ('NodeSocketFloatFactor', 'Twist', 0.5000),
            ('NodeSocketFloat', 'Randomise', 0.0000),
            ('NodeSocketInt', 'Seed', 0)])
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input.outputs["Petal count"], 'Radius': group_input.outputs["Radius"]})
    
    curve_tangent_1 = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent_1}, attrs={'pivot_axis': 'Z'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Randomise"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: 0.0000, 1: reroute}, attrs={'operation': 'SUBTRACT'})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={2: subtract, 3: reroute, 'Seed': group_input.outputs["Seed"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Petal Scale"], 1: random_value.outputs[1]})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_circle.outputs["Curve"], 'Instance': group_input.outputs["Geometry"], 'Rotation': align_euler_to_vector_1, 'Scale': add})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Petal count"], 1: group_input.outputs["Tilt per Petal"]},
        attrs={'operation': 'MULTIPLY'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: random_value.outputs[1]})
    
    ast_before_after = nw.new_node(nodegroup_a_s_t_before_after().name,
        input_kwargs={'Fac': group_input.outputs["Rotate Petals"], 'Before': -90.0000, 'After': 90.0000})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: ast_before_after, 1: random_value.outputs[1]})
    
    ast_before_after_1 = nw.new_node(nodegroup_a_s_t_before_after().name,
        input_kwargs={'Fac': group_input.outputs["Twist"], 'After': 180.0000})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: ast_before_after_1, 1: random_value.outputs[1]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': add_1, 'Y': add_2, 'Z': add_3})
    
    divide = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_2, 'Rotation': divide.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': rotate_instances_1}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_artifical_plastic_stem', singleton=False, type='ShaderNodeTree')
def nodegroup_artifical_plastic_stem(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloatFactor', 'Subsurface', 0.0000),
            ('NodeSocketFloatFactor', 'Specular', 0.5000),
            ('NodeSocketFloatFactor', 'Sheen', 0.0000),
            ('NodeSocketFloatFactor', 'BumpStrength', 0.0922),
            ('NodeSocketFloat', 'Scale', 1.0000)])
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["Vector"], 'Scale': group_input.outputs["Scale"]},
        attrs={'operation': 'SCALE'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': scale.outputs["Vector"], 'Scale': 401.1000})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Color"]})
    colorramp_2.color_ramp.elements[0].position = 0.0000
    colorramp_2.color_ramp.elements[0].color = [0.0015, 0.0000, 0.0388, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [0.1770, 0.2738, 0.0283, 1.0000]
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 22.4000})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Color"]})
    colorramp_3.color_ramp.elements[0].position = 0.1204
    colorramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 1.0000
    colorramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump_1 = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': group_input.outputs["BumpStrength"], 'Height': colorramp_2.outputs["Color"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': colorramp_2.outputs["Color"], 'Subsurface': group_input.outputs["Subsurface"], 'Specular': group_input.outputs["Specular"], 'Roughness': colorramp_3.outputs["Color"], 'Sheen': group_input.outputs["Sheen"], 'Normal': bump_1},
        attrs={'subsurface_method': 'BURLEY'})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': colorramp_2.outputs["Color"], 'Normal': bump_1})
    
    mix_shader = nw.new_node(Nodes.MixShader,
        input_kwargs={'Fac': colorramp_2.outputs["Color"], 1: principled_bsdf, 2: translucent_bsdf})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Shader': mix_shader}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_palm_lanceolate', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_palm_lanceolate(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketIntUnsigned', 'Resolution', 15),
            ('NodeSocketInt', 'Direction', 0),
            ('NodeSocketFloat', 'Length', 1.0000),
            ('NodeSocketFloat', 'Width', 1.0000),
            ('NodeSocketFloat', 'Randomise', 0.0000),
            ('NodeSocketFloat', 'Distortion', 0.0000),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_long_flower_leaf_material)
            ('NodeSocketFloat', 'Middle X', 0.0000),
            ('NodeSocketFloat', 'Middle Y', 0.0000),
            ('NodeSocketFloat', 'Center', 0.0000),
            ('NodeSocketFloat', 'End X', 0.0000),
            ('NodeSocketFloat', 'End Y', 0.0000)])
    
    ast_mono_directional_bezier = nw.new_node(nodegroup_a_s_t_mono_directional_bezier().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Center': group_input.outputs["Center"], 'Middle X': group_input.outputs["Middle X"], 'Middle Y': group_input.outputs["Middle Y"], 'Length': group_input.outputs["Length"], 'End X': group_input.outputs["End X"], 'End Y': group_input.outputs["End Y"], 'Direction': group_input.outputs["Direction"]})
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["Randomise"], 'Scale': 1.0000, 'Distortion': group_input.outputs["Distortion"]},
        attrs={'noise_dimensions': '4D'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_4.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: spline_parameter.outputs["Factor"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position_2 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': ast_mono_directional_bezier.outputs["Curve"], 'Offset': multiply.outputs["Vector"]})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.1000), (0.4193, 0.5000), (1.0000, 0.0000)])
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: float_curve, 1: group_input.outputs["Width"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius_2 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': set_position_2, 'Radius': multiply_1})
    
    divide = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Resolution"], 1: 5.0000},
        attrs={'operation': 'DIVIDE'})
    
    ast_bi_directional_bezier = nw.new_node(nodegroup_a_s_t_bi_directional_bezier().name, input_kwargs={'Resolution': divide, 'Scale': 0.1000})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius_2, 'Profile Curve': ast_bi_directional_bezier.outputs["Curve"]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': group_input.outputs["Material"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': ast_mono_directional_bezier.outputs["Length"], 'Y': ast_bi_directional_bezier.outputs["Length"]})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_1, 1: (2.5000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': multiply_2.outputs["Vector"], 'Rotation': (3.1416, 0.0000, 1.5708)},
        attrs={'rotation_type': 'EULER_XYZ'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Mesh': set_material, 'UV': vector_rotate},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_curve_to_circular_mesh_skinning', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_curve_to_circular_mesh_skinning(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Resolution', 32),
            ('NodeSocketFloatDistance', 'Radius', 1.0000),
            ('NodeSocketBool', 'Fill Caps', True),
            ('NodeSocketBool', 'Shade Smooth', True),
            ('NodeSocketString', 'UVMap', 'UVMap')])
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': group_input.outputs["Curve"], 2: spline_parameter.outputs["Length"]})
    
    ast_abhay_s_round_curve = nw.new_node(nodegroup_a_s_t_abhays_round_curve().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution"], 'Radius': group_input.outputs["Radius"]})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute.outputs["Geometry"], 'Profile Curve': ast_abhay_s_round_curve.outputs["Curve"], 'Fill Caps': group_input.outputs["Fill Caps"]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth,
        input_kwargs={'Geometry': curve_to_mesh_1, 'Shade Smooth': group_input.outputs["Shade Smooth"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute.outputs[2], 'Y': ast_abhay_s_round_curve.outputs["Length"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': set_shade_smooth, 'Name': group_input.outputs["UVMap"], 3: combine_xyz},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': store_named_attribute})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Mesh': merge_by_distance, 'UV': combine_xyz},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_pollen_tube_3', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_pollen_tube_3(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloatFactor', 'Fac', 1.0000),
            ('NodeSocketFloat', 'Length', 1.0500),
            ('NodeSocketFloat', 'Radius', 0.1000),
            ('NodeSocketInt', 'Pollen count', 9),
            ('NodeSocketFloatFactor', 'Trim', 0.7500),
            ('NodeSocketFloat', 'To Min', -0.8700),
            ('NodeSocketFloat', 'Spore Radius *', 0.2000),
            ('NodeSocketInt', 'Seed', 6),
            ('NodeSocketIntUnsigned', 'Resolution (L)', 16),
            ('NodeSocketInt', 'Resolution (P)', 6),
            ('NodeSocketFloat', 'Scale pollens', 1.0000),
            ('NodeSocketMaterial', 'Spore', None),
            ('NodeSocketMaterial', 'Stem', None),
            ('NodeSocketFloat', 'Spread', 1.0000)])
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Fac"]})
    
    ast_before_after = nw.new_node(nodegroup_a_s_t_before_after().name,
        input_kwargs={'Fac': reroute_8, 'Before': 0.0750, 'After': 0.1500})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Radius"], 1: group_input.outputs["Spore Radius *"]},
        attrs={'operation': 'MULTIPLY'})
    
    ast_pollen_3 = nw.new_node(nodegroup_a_s_t_pollen_3().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution (L)"], 'Resolution_1': group_input.outputs["Resolution (P)"], 'Length': group_input.outputs["Length"], 'delete before Bloom ': reroute_8, 'Radius': group_input.outputs["Radius"], 'Trim': group_input.outputs["Trim"], 'To Min': group_input.outputs["To Min"], 'To Max': ast_before_after, 'Spore Radius': multiply, 'Spore': group_input.outputs["Spore"], 'Stem': group_input.outputs["Stem"], 'Spread': group_input.outputs["Spread"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    ast_before_after_1 = nw.new_node(nodegroup_a_s_t_before_after().name, input_kwargs={'Fac': reroute_3, 'Before': 0.5000})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: ast_before_after_1, 1: 0.1000}, attrs={'operation': 'SUBTRACT'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Seed"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: reroute, 1: 1.0000})
    
    ast_circular_distribution = nw.new_node(nodegroup_a_s_t_circular_distribution().name,
        input_kwargs={'Geometry': ast_pollen_3.outputs["Geometry"], 'Petal count': group_input.outputs["Pollen count"], 'Radius': 0.0100, 'Petal Scale': 0.8000, 'Tilt per Petal': 0.0000, 'Rotate Petals': 0.4950, 'Twist': subtract, 'Randomise': 0.0500, 'Seed': add})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': ast_circular_distribution, 'Translation': (0.0000, 0.0000, 0.1500)})
    
    ast_circular_distribution_1 = nw.new_node(nodegroup_a_s_t_circular_distribution().name,
        input_kwargs={'Geometry': ast_pollen_3.outputs["Geometry"], 'Petal count': group_input.outputs["Pollen count"], 'Radius': 0.0100, 'Petal Scale': 0.9750, 'Tilt per Petal': 0.0000, 'Rotate Petals': 0.5100, 'Twist': ast_before_after_1, 'Randomise': 0.0250, 'Seed': reroute})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [transform, ast_circular_distribution_1]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Scale pollens"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': join_geometry_1, 'Scale': reroute_1})
    
    logarithm = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1}, attrs={'operation': 'LOGARITHM'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': logarithm})
    
    translate_instances = nw.new_node(Nodes.TranslateInstances, input_kwargs={'Instances': scale_instances, 'Translation': combine_xyz})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': translate_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': set_shade_smooth, 'UV': ast_pollen_3.outputs["UV"], 'spore': ast_pollen_3.outputs["spore"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_a_s_t_pollen_tube_2', singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_pollen_tube_2(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketInt', 'Resolution', 24),
            ('NodeSocketIntUnsigned', 'Points', 6),
            ('NodeSocketFloat', 'Height', 1.0000),
            ('NodeSocketFloat', 'Radius', 0.2500),
            ('NodeSocketFloatAngle', 'Twist', 0.0000),
            ('NodeSocketFloat', 'Max Radius', 1.2500),
            ('NodeSocketBool', 'Shade Smooth', False),
            ('NodeSocketMaterial', 'Material', None),
            ('NodeSocketBool', 'Smoothness (Heavy)', False)])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Height"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line, 'Count': group_input.outputs["Resolution"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0312), (0.3731, 0.0625), (0.7500, 0.1500), (0.8394, 0.4313), (0.9689, 0.5562), (1.0000, 1.0000)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve, 'Radius': float_curve})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': spline_parameter.outputs["Length"]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': set_curve_radius, 2: reroute_10})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Radius"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: reroute_1, 1: group_input.outputs["Max Radius"]},
        attrs={'operation': 'MULTIPLY'})
    
    star = nw.new_node('GeometryNodeCurveStar',
        input_kwargs={'Points': group_input.outputs["Points"], 'Inner Radius': reroute, 'Outer Radius': multiply, 'Twist': group_input.outputs["Twist"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: reroute_2}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': star.outputs["Curve"], 'Selection': star.outputs["Outer Points"], 'Offset': combine_xyz_1})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': set_position, 2: reroute_10})
    
    set_spline_type = nw.new_node(Nodes.SplineType,
        input_kwargs={'Curve': capture_attribute.outputs["Geometry"]},
        attrs={'spline_type': 'BEZIER'})
    
    set_handle_type = nw.new_node(Nodes.SetHandleType, input_kwargs={'Curve': set_spline_type})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': set_handle_type, 'Count': 64, 'Length': 0.0500},
        attrs={'mode': 'LENGTH'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input.outputs["Smoothness (Heavy)"], 14: capture_attribute.outputs["Geometry"], 15: resample_curve_1})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute_1.outputs["Geometry"], 'Profile Curve': switch.outputs[6]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Shade Smooth"]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh, 'Shade Smooth': reroute_6})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': group_input.outputs["Material"]})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute_1.outputs[2], 'Y': capture_attribute.outputs[2]})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_curve_radius})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': set_material, 'UV': combine_xyz_2, 'Curve(with radius)': reroute_11},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup("nodegroup_a_s_t_abhays_noise", singleton=False, type='GeometryNodeTree')
def nodegroup_a_s_t_abhays_noise(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Factor', (1.0000, 1.0000, 1.0000)),
            ('NodeSocketFloat', 'W', 0.0000),
            ('NodeSocketFloat', 'Scale', 2.0000),
            ('NodeSocketFloat', 'Detail', 2.0000),
            ('NodeSocketFloatFactor', 'Roughness', 0.0000),
            ('NodeSocketFloat', 'Distortion', 0.0000)])
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["W"], 'Scale': group_input.outputs["Scale"], 'Detail': group_input.outputs["Detail"], 'Roughness': group_input.outputs["Roughness"], 'Distortion': group_input.outputs["Distortion"]},
        attrs={'noise_dimensions': '4D'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_1.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: group_input.outputs["Factor"]},
        attrs={'operation': 'MULTIPLY'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Vector': multiply.outputs["Vector"]}, attrs={'is_active_output': True})

def shader_long_flower_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute_3 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'spore_uv'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: attribute_3.outputs["Fac"], 1: 0.0001}, attrs={'operation': 'GREATER_THAN'})
    
    attribute_2 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'pollen_uv'})
    
    greater_than_1 = nw.new_node(Nodes.Math, input_kwargs={0: attribute_2.outputs["Fac"], 1: 0.0001}, attrs={'operation': 'GREATER_THAN'})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'flower_uv'})
    
    greater_than_2 = nw.new_node(Nodes.Math, input_kwargs={0: attribute_1.outputs["Fac"], 1: 0.0001}, attrs={'operation': 'GREATER_THAN'})
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'stem_uv'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than_2, 4: attribute.outputs["Vector"], 5: attribute_1.outputs["Vector"]},
        attrs={'data_type': 'VECTOR'})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than_1, 4: mix.outputs[1], 5: attribute_2.outputs["Vector"]},
        attrs={'data_type': 'VECTOR'})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than, 4: mix_1.outputs[1], 5: attribute_3.outputs["Vector"]},
        attrs={'data_type': 'VECTOR'})
    
    group = nw.new_node(nodegroup_artifical_plastic_stem().name,
        input_kwargs={'Vector': mix_2.outputs[1], 'Subsurface': 0.0100, 'Specular': 0.0100, 'BumpStrength': 0.2500, 'Scale': 0.2500})
    
    geometry = nw.new_node(Nodes.NewGeometry)
    
    hue = nw.new_node(Nodes.Mix, input_kwargs={3: 1.0000}, label='Hue')
    
    saturation = nw.new_node(Nodes.Mix, input_kwargs={3: 2.0000}, label='Saturation')
    
    brightness = nw.new_node(Nodes.Mix, input_kwargs={0: 0.6500, 3: 2.0000}, label='brightness')
    
    wave_texture = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': mix_2.outputs[1], 'Scale': 1.0000, 'Detail': 0.0000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture.outputs["Color"]})
    colorramp.color_ramp.interpolation = "B_SPLINE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0250, 0.2413, 0.3800, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.5878, 0.9541, 1.0000, 1.0000]
    
    hue_saturation_value_1 = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': hue.outputs["Result"], 'Saturation': saturation.outputs["Result"], 'Value': brightness.outputs["Result"], 'Color': colorramp.outputs["Color"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': hue_saturation_value_1})
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Saturation': 1.2500, 'Value': 2.0000, 'Color': reroute})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': hue_saturation_value})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mix_2.outputs[1], 'Scale': 100.0000})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: wave_texture.outputs["Fac"], 1: noise_texture.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2500, 'Height': multiply})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': reroute, 'Sheen': 1.0000, 'Normal': bump})
    
    mix_shader_3 = nw.new_node(Nodes.MixShader,
        input_kwargs={'Fac': geometry.outputs["Backfacing"], 1: translucent_bsdf, 2: principled_bsdf_1})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than_2, 1: group, 2: mix_shader_3})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_2.outputs[1]})
    
    wave_texture_1 = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': reroute_2, 'Scale': 0.5000, 'Detail': 0.0000},
        attrs={'bands_direction': 'Y'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture_1.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.1000
    colorramp_1.color_ramp.elements[0].color = [0.0248, 0.1364, 0.3000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.9909
    colorramp_1.color_ramp.elements[1].color = [0.3208, 0.8657, 1.0000, 1.0000]
    
    hue_saturation_value_2 = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': hue.outputs["Result"], 'Saturation': saturation.outputs["Result"], 'Value': brightness.outputs["Result"], 'Color': colorramp_1.outputs["Color"]})
    
    principled_bsdf_2 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': hue_saturation_value_2, 'Specular': 0.1000, 'Roughness': 1.0000})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than_1, 1: mix_shader, 2: principled_bsdf_2})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    wave_texture_2 = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': reroute_1, 'Detail': 0.0000})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture_2.outputs["Color"]})
    colorramp_2.color_ramp.elements[0].position = 0.4864
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.4556, 1.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [0.2144, 0.8278, 1.0000, 1.0000]
    
    hue_saturation_value_3 = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': hue.outputs["Result"], 'Saturation': saturation.outputs["Result"], 'Value': brightness.outputs["Result"], 'Color': colorramp_2.outputs["Color"]})
    
    principled_bsdf_3 = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': hue_saturation_value_3})
    
    mix_shader_2 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than, 1: mix_shader_1, 2: principled_bsdf_3})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_2}, attrs={'is_active_output': True})

def shader_long_flower_leaf_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    geometry_1 = nw.new_node(Nodes.NewGeometry)
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': geometry_1.outputs["Backfacing"]})
    colorramp_4.color_ramp.elements[0].position = 0.0000
    colorramp_4.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 1.0000
    colorramp_4.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'leaf_uv'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': attribute.outputs["Vector"]})
    
    wave_texture_2 = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': reroute, 'Scale': 20.5700, 'Distortion': 5.0000})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': wave_texture_2.outputs["Color"]})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_4})
    colorramp_3.color_ramp.interpolation = "EASE"
    colorramp_3.color_ramp.elements[0].position = 0.0000
    colorramp_3.color_ramp.elements[0].color = [0.4617, 0.8648, 0.0000, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 1.0000
    colorramp_3.color_ramp.elements[1].color = [0.0484, 0.8009, 0.0000, 1.0000]
    
    bump_1 = nw.new_node(Nodes.Bump, input_kwargs={'Height': wave_texture_2.outputs["Color"]})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': colorramp_3.outputs["Color"], 'Normal': bump_1})
    
    wave_texture_1 = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': reroute, 'Scale': 20.0000, 'Distortion': 2.5000})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': wave_texture_1.outputs["Color"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_3})
    colorramp_1.color_ramp.interpolation = "EASE"
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [0.2711, 0.8648, 0.0057, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.5000
    colorramp_1.color_ramp.elements[1].color = [0.0000, 0.3889, 0.0054, 1.0000]
    
    ambient_occlusion = nw.new_node(Nodes.AmbientOcclusion, input_kwargs={'Color': colorramp_1.outputs["Color"]})
    
    wave_texture = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': reroute, 'Distortion': 2.5000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture.outputs["Color"]})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.2508, 0.8000, 0.0053, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.5000
    colorramp.color_ramp.elements[1].color = [0.0000, 0.3000, 0.0042, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={6: ambient_occlusion.outputs["Color"], 7: colorramp.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_2})
    colorramp_2.color_ramp.elements[0].position = 0.5000
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2500, 'Height': reroute_1})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Specular': reroute_3, 'Roughness': colorramp_2.outputs["Color"], 'Normal': bump})
    
    mix_shader = nw.new_node(Nodes.MixShader,
        input_kwargs={'Fac': colorramp_4.outputs["Color"], 1: translucent_bsdf, 2: principled_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def shader_long_flower_material_001(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute_3 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'spore_uv'})
    
    greater_than = nw.new_node(Nodes.Math, input_kwargs={0: attribute_3.outputs["Fac"], 1: 0.0001}, attrs={'operation': 'GREATER_THAN'})
    
    attribute_2 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'pollen_uv'})
    
    greater_than_1 = nw.new_node(Nodes.Math, input_kwargs={0: attribute_2.outputs["Fac"], 1: 0.0001}, attrs={'operation': 'GREATER_THAN'})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'flower_uv'})
    
    greater_than_2 = nw.new_node(Nodes.Math, input_kwargs={0: attribute_1.outputs["Fac"], 1: 0.0001}, attrs={'operation': 'GREATER_THAN'})
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'stem_uv'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than_2, 4: attribute.outputs["Vector"], 5: attribute_1.outputs["Vector"]},
        attrs={'data_type': 'VECTOR'})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than_1, 4: mix.outputs[1], 5: attribute_2.outputs["Vector"]},
        attrs={'data_type': 'VECTOR'})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: greater_than, 4: mix_1.outputs[1], 5: attribute_3.outputs["Vector"]},
        attrs={'data_type': 'VECTOR'})
    
    group = nw.new_node(nodegroup_artifical_plastic_stem().name,
        input_kwargs={'Vector': mix_2.outputs[1], 'Subsurface': 0.0100, 'Specular': 0.0100, 'BumpStrength': 0.2500, 'Scale': 0.2500})
    
    geometry = nw.new_node(Nodes.NewGeometry)
    
    hue = nw.new_node(Nodes.Mix, input_kwargs={0: 0.6333, 3: 1.0000}, label='Hue')
    
    saturation = nw.new_node(Nodes.Mix, input_kwargs={0: 0.7500, 3: 2.0000}, label='Saturation')
    
    brightness = nw.new_node(Nodes.Mix, input_kwargs={0: 0.2333, 3: 2.0000}, label='brightness')
    
    wave_texture = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': mix_2.outputs[1], 'Scale': 1.0000, 'Detail': 0.0000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture.outputs["Color"]})
    colorramp.color_ramp.interpolation = "B_SPLINE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0250, 0.2413, 0.3800, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [0.5878, 0.9541, 1.0000, 1.0000]
    
    hue_saturation_value_1 = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': hue.outputs["Result"], 'Saturation': saturation.outputs["Result"], 'Value': brightness.outputs["Result"], 'Color': colorramp.outputs["Color"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': hue_saturation_value_1})
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Saturation': 1.2500, 'Value': 2.0000, 'Color': reroute})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': hue_saturation_value})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mix_2.outputs[1], 'Scale': 100.0000})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: wave_texture.outputs["Fac"], 1: noise_texture.outputs["Color"]},
        attrs={'operation': 'MULTIPLY'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.2500, 'Height': multiply})
    
    principled_bsdf_1 = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': reroute, 'Sheen': 1.0000, 'Normal': bump})
    
    mix_shader_3 = nw.new_node(Nodes.MixShader,
        input_kwargs={'Fac': geometry.outputs["Backfacing"], 1: translucent_bsdf, 2: principled_bsdf_1})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than_2, 1: group, 2: mix_shader_3})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_2.outputs[1]})
    
    wave_texture_1 = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': reroute_2, 'Scale': 0.5000, 'Detail': 0.0000},
        attrs={'bands_direction': 'Y'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture_1.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.1000
    colorramp_1.color_ramp.elements[0].color = [0.0248, 0.1364, 0.3000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.9909
    colorramp_1.color_ramp.elements[1].color = [0.3208, 0.8657, 1.0000, 1.0000]
    
    hue_saturation_value_2 = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': hue.outputs["Result"], 'Saturation': saturation.outputs["Result"], 'Value': brightness.outputs["Result"], 'Color': colorramp_1.outputs["Color"]})
    
    principled_bsdf_2 = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': hue_saturation_value_2, 'Specular': 0.1000, 'Roughness': 1.0000})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than_1, 1: mix_shader, 2: principled_bsdf_2})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    wave_texture_2 = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': reroute_1, 'Detail': 0.0000})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': wave_texture_2.outputs["Color"]})
    colorramp_2.color_ramp.elements[0].position = 0.4864
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.4556, 1.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [0.2144, 0.8278, 1.0000, 1.0000]
    
    hue_saturation_value_3 = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': hue.outputs["Result"], 'Saturation': saturation.outputs["Result"], 'Value': brightness.outputs["Result"], 'Color': colorramp_2.outputs["Color"]})
    
    principled_bsdf_3 = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': hue_saturation_value_3})
    
    mix_shader_2 = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than, 1: mix_shader_1, 2: principled_bsdf_3})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_2}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Seed', 0),
            ('NodeSocketInt', 'Flower sper spot', 6),
            ('NodeSocketString', 'Stem UV', 'stem_uv'),
            ('NodeSocketString', 'Flowers UV', 'flower_uv'),
            ('NodeSocketString', 'pollen tubes UV', 'pollen_uv'),
            ('NodeSocketString', 'Spores UV', 'spore_uv'),
            ('NodeSocketString', 'Leaf UV', 'leaf_uv'),
            ('NodeSocketMaterial', 'Main Material', None), #surface.shaderfunc_to_material(shader_long_flower_material)
            ('NodeSocketMaterial', 'Leaf Material', None), #surface.shaderfunc_to_material(shader_long_flower_leaf_material)
            ('NodeSocketString', '_1', 'Stem Controls'),
            ('NodeSocketInt', 'Stem Count', 5),
            ('NodeSocketInt', 'Skinning Resolution', 6),
            ('NodeSocketVector', 'Spread Threshold', (3.0000, 3.0000, 1.0000)),
            ('NodeSocketFloat', 'Noise Scale', 1.0000),
            ('NodeSocketFloatFactor', 'Roughness', 0.0000),
            ('NodeSocketFloat', 'Stem Interpolation', 2.0000),
            ('NodeSocketFloatDistance', 'Radius', 0.0200),
            ('NodeSocketString', '_2', 'Flower Controls'),
            ('NodeSocketInt', 'Count', 5),
            ('NodeSocketInt', 'Resolution_1', 4),
            ('NodeSocketIntUnsigned', 'Petals, pollens Count', 6),
            ('NodeSocketFloatFactor', 'Radius_1', 0.5000),
            ('NodeSocketFloat', 'Height', 1.0000),
            ('NodeSocketString', '_3', 'Small flowers'),
            ('NodeSocketFloatFactor', 'Factor', 0.5000),
            ('NodeSocketInt', 'Resolution_2', 4),
            ('NodeSocketIntUnsigned', 'Points', 6),
            ('NodeSocketFloatFactor', 'Radius_2', 0.5000),
            ('NodeSocketFloat', 'Height_1', 0.5000),
            ('NodeSocketString', '_4', 'Leaves Controls'),
            ('NodeSocketInt', 'Count_1', 10),
            ('NodeSocketIntUnsigned', 'Resolution_3', 16),
            ('NodeSocketFloat', 'Length', 1.0000),
            ('NodeSocketFloat', 'Width', 1.0000),
            ('NodeSocketFloat', 'Bend', -0.3700),
            ('NodeSocketFloat', 'Center', -1.0000),
            ('NodeSocketFloat', 'tip Direction', 0.3300)])
    
    reverse_curve = nw.new_node(Nodes.ReverseCurve, input_kwargs={'Curve': group_input.outputs["Geometry"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': reverse_curve, 'Count': 32, 'Length': 0.0500},
        attrs={'mode': 'LENGTH'})
    
    duplicate_elements = nw.new_node(Nodes.DuplicateElements,
        input_kwargs={'Geometry': resample_curve, 'Amount': group_input.outputs["Stem Count"]},
        attrs={'domain': 'SPLINE'})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': duplicate_elements.outputs["Geometry"], 2: spline_parameter.outputs["Factor"]})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: spline_parameter.outputs["Length"]})
    
    power = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_parameter.outputs["Factor"], 1: 2.7183},
        attrs={'operation': 'POWER'})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Seed"], 1: 5.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    multiply_add = nw.new_node(Nodes.Math,
        input_kwargs={0: duplicate_elements.outputs["Duplicate Index"], 1: group_input.outputs["Stem Interpolation"], 2: reroute_12},
        attrs={'operation': 'MULTIPLY_ADD'})
    
    ast_abhay_s_noise = nw.new_node(nodegroup_a_s_t_abhays_noise().name,
        input_kwargs={'Factor': power, 'W': multiply_add, 'Scale': group_input.outputs["Noise Scale"], 'Roughness': group_input.outputs["Roughness"]})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: ast_abhay_s_noise, 1: group_input.outputs["Spread Threshold"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Offset': multiply_1.outputs["Vector"]})
    
    logarithm = nw.new_node(Nodes.Math,
        input_kwargs={0: spline_parameter.outputs["Factor"], 1: 2.7183},
        attrs={'operation': 'LOGARITHM'})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': set_position, 'Radius': logarithm})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': set_curve_radius, 2: 0.7500, 3: 0.9750})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Factor"]})
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: reroute_13, 2: 0.1000, 3: 0.0500})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': trim_curve, 'Length': mix.outputs["Result"]},
        attrs={'mode': 'LENGTH'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Flower sper spot"]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    duplicate_elements_1 = nw.new_node(Nodes.DuplicateElements,
        input_kwargs={'Geometry': curve_to_points.outputs["Points"], 'Amount': reroute_10})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={0: group_input.outputs["Radius_2"], 2: 0.0010, 3: 0.5000})
    
    ast_pollen_tube_2 = nw.new_node(nodegroup_a_s_t_pollen_tube_2().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution_2"], 'Points': group_input.outputs["Points"], 'Height': group_input.outputs["Height_1"], 'Radius': mix_2.outputs["Result"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Height_1"], 1: 0.1000})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: mix_2.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    ast_pollen_tube_3 = nw.new_node(nodegroup_a_s_t_pollen_tube_3().name,
        input_kwargs={'Length': add, 'Radius': multiply_2, 'Pollen count': group_input.outputs["Points"], 'To Min': 0.0400, 'Spore Radius *': 0.1000, 'Seed': group_input.outputs["Seed"], 'Resolution (L)': 8, 'Resolution (P)': 3, 'Spore': surface.shaderfunc_to_material(shader_long_flower_material), 'Stem': surface.shaderfunc_to_material(shader_long_flower_material), 'Spread': 1.4000})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [ast_pollen_tube_2.outputs["Geometry"], ast_pollen_tube_3.outputs["Geometry"]]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': join_geometry_1})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': capture_attribute.outputs[2]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.2500), (0.8500, 0.1250), (1.0000, 0.0000)])
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': duplicate_elements_1.outputs["Geometry"], 'Instance': set_shade_smooth, 'Rotation': curve_to_points.outputs["Rotation"], 'Scale': float_curve})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Seed"]})
    
    random_value_3 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 80.0000, 3: 90.0000, 'Seed': reroute_11})
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: random_value_3.outputs[1], 1: 90.0000}, attrs={'operation': 'RADIANS'})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={2: -3.1416, 3: 3.1416, 'Seed': reroute_11})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: 360.0000, 1: reroute_10}, attrs={'operation': 'DIVIDE'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: duplicate_elements_1.outputs["Duplicate Index"], 1: divide},
        attrs={'operation': 'MULTIPLY'})
    
    radians_1 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3, 1: 90.0000}, attrs={'operation': 'RADIANS'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': radians, 'Y': random_value.outputs[1], 'Z': radians_1})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': instance_on_points, 'Rotation': combine_xyz})
    
    ast_curve_to_circular_mesh_skinning = nw.new_node(nodegroup_a_s_t_curve_to_circular_mesh_skinning().name,
        input_kwargs={'Curve': set_curve_radius, 'Resolution': group_input.outputs["Skinning Resolution"], 'Radius': group_input.outputs["Radius"], 'Fill Caps': False, 'UVMap': 'stem_uv'})
    
    flip_faces = nw.new_node(Nodes.FlipFaces, input_kwargs={'Mesh': ast_curve_to_circular_mesh_skinning.outputs["Mesh"]})
    
    multiply_4 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: ast_curve_to_circular_mesh_skinning.outputs["UV"], 1: (5.0000, 0.5000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': flip_faces, 'Name': group_input.outputs["Stem UV"], 3: multiply_4.outputs["Vector"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    merge_by_distance_1 = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': store_named_attribute})
    
    trim_curve_1 = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': set_curve_radius, 2: 0.6250, 3: 0.7500})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': trim_curve_1, 'Count': group_input.outputs["Count"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Flower sper spot"]})
    
    duplicate_elements_2 = nw.new_node(Nodes.DuplicateElements,
        input_kwargs={'Geometry': curve_to_points_1.outputs["Points"], 'Amount': reroute_8})
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={0: group_input.outputs["Radius_1"], 2: 0.0100, 3: 0.2500})
    
    ast_pollen_tube_2_1 = nw.new_node(nodegroup_a_s_t_pollen_tube_2().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution_1"], 'Points': group_input.outputs["Petals, pollens Count"], 'Height': group_input.outputs["Height"], 'Radius': mix_1.outputs["Result"], 'Max Radius': 5.0000, 'Shade Smooth': True, 'Smoothness (Heavy)': True})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Height"], 1: 0.3500})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: mix_1.outputs["Result"], 1: 0.0250})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: mix_1.outputs["Result"], 1: 10.0000}, attrs={'operation': 'MULTIPLY'})
    
    ast_pollen_tube_3_1 = nw.new_node(nodegroup_a_s_t_pollen_tube_3().name,
        input_kwargs={'Length': add_1, 'Radius': add_2, 'Pollen count': group_input.outputs["Petals, pollens Count"], 'Trim': 0.2500, 'To Min': multiply_5, 'Seed': group_input.outputs["Seed"], 'Resolution (L)': 10, 'Resolution (P)': 3, 'Spread': 1.1000})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [ast_pollen_tube_2_1.outputs["Geometry"], ast_pollen_tube_3_1.outputs["Geometry"]]})
    
    merge_by_distance = nw.new_node(Nodes.MergeByDistance, input_kwargs={'Geometry': join_geometry_2, 'Distance': 0.0050})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': capture_attribute.outputs[2]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.5000), (0.8500, 0.0500), (1.0000, 0.0000)])
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': duplicate_elements_2.outputs["Geometry"], 'Instance': merge_by_distance, 'Rotation': curve_to_points_1.outputs["Rotation"], 'Scale': float_curve_1})
    
    random_value_2 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 80.0000, 3: 90.0000, 'Seed': group_input.outputs["Seed"]})
    
    radians_2 = nw.new_node(Nodes.Math, input_kwargs={0: random_value_2.outputs[1], 1: 90.0000}, attrs={'operation': 'RADIANS'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue, input_kwargs={2: -3.1416, 3: 3.1416, 'Seed': group_input.outputs["Seed"]})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: 360.0000, 1: reroute_8}, attrs={'operation': 'DIVIDE'})
    
    multiply_6 = nw.new_node(Nodes.Math,
        input_kwargs={0: duplicate_elements_2.outputs["Duplicate Index"], 1: divide_1},
        attrs={'operation': 'MULTIPLY'})
    
    radians_3 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_6, 1: 90.0000}, attrs={'operation': 'RADIANS'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': radians_2, 'Y': random_value_1.outputs[1], 'Z': radians_3})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': instance_on_points_1, 'Rotation': combine_xyz_1})
    
    trim_curve_2 = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': set_curve_radius, 2: 0.3500, 3: 0.6000})
    
    curve_to_points_2 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': trim_curve_2, 'Count': group_input.outputs["Count_1"]})
    
    ast_palm_lanceolate = nw.new_node(nodegroup_a_s_t_palm_lanceolate().name,
        input_kwargs={'Resolution': group_input.outputs["Resolution_3"], 'Length': group_input.outputs["Length"], 'Width': group_input.outputs["Width"], 'Randomise': group_input.outputs["Seed"], 'Material': group_input.outputs["Leaf Material"], 'Middle X': group_input.outputs["Bend"], 'Center': group_input.outputs["Center"], 'End X': group_input.outputs["tip Direction"]})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': capture_attribute.outputs[2]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.7500), (0.5000, 0.5000), (1.0000, 0.0000)])
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_2.outputs["Points"], 'Instance': ast_palm_lanceolate.outputs["Mesh"], 'Rotation': curve_to_points_2.outputs["Rotation"], 'Scale': float_curve_2})
    
    index = nw.new_node(Nodes.Index)
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 137.5000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': -30.0000, 'Z': multiply_7})
    
    divide_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: combine_xyz_2, 1: (57.2958, 57.2958, 57.2958)},
        attrs={'operation': 'DIVIDE'})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_2, 'Rotation': divide_2.outputs["Vector"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [rotate_instances, merge_by_distance_1, rotate_instances_1, rotate_instances_2]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': join_geometry})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_pollen_tube_2_1.outputs["UV"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_pollen_tube_2.outputs["UV"]})
    
    add_3 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_2, 1: reroute})
    
    multiply_8 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: add_3.outputs["Vector"], 1: (2.5000, 1.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': realize_instances, 'Name': group_input.outputs["Flowers UV"], 3: multiply_8.outputs["Vector"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_pollen_tube_3_1.outputs["UV"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_pollen_tube_3.outputs["UV"]})
    
    add_4 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_4, 1: reroute_3})
    
    multiply_9 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: add_4.outputs["Vector"], 1: (20.0000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    store_named_attribute_3 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': store_named_attribute_2, 'Name': group_input.outputs["pollen tubes UV"], 3: multiply_9.outputs["Vector"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_pollen_tube_3_1.outputs["spore"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_pollen_tube_3.outputs["spore"]})
    
    add_5 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_7, 1: reroute_5})
    
    store_named_attribute_5 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': store_named_attribute_3, 'Name': group_input.outputs["Spores UV"], 3: add_5.outputs["Vector"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_palm_lanceolate.outputs["UV"]})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': store_named_attribute_5, 'Name': group_input.outputs["Leaf UV"], 3: reroute_1},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': ast_palm_lanceolate.outputs["UV"]})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={4: reroute_6}, attrs={'operation': 'EQUAL', 'data_type': 'VECTOR'})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': store_named_attribute_1, 'Selection': equal, 'Material': group_input.outputs["Main Material"]})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_material})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': realize_instances_1}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_long_flower_material_001, selection=selection)
    surface.add_material(obj, shader_long_flower_leaf_material, selection=selection)

