import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_procedural_clouds', singleton=False, type='ShaderNodeTree')
def nodegroup_procedural_clouds(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Location', 0.0000),
            ('NodeSocketFloat', 'Rotaion Z', 0.0000),
            ('NodeSocketFloatFactor', 'Bump Strength', 0.4000),
            ('NodeSocketColor', 'Base Color', (1.0000, 1.0000, 1.0000, 1.0000)),
            ('NodeSocketColor', 'Subsurface Color', (0.8000, 0.8000, 0.8000, 1.0000))])
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Object"]})
    
    mapping_1 = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': reroute, 'Scale': (0.9800, 0.9800, 0.5800)})
    
    gradient_texture = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_1}, attrs={'gradient_type': 'SPHERICAL'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.7333, 6: reroute, 7: gradient_texture.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Rotaion Z"]}, attrs={'operation': 'RADIANS'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': radians})
    
    mapping_2 = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': mix.outputs[2], 'Rotation': combine_xyz_1})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input.outputs["Location"]})
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': mapping_2, 'Location': combine_xyz, 'Scale': (1.0000, 1.6100, 1.0000)})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping, 'Scale': 1.5800, 'Detail': 7.0000, 'Roughness': 0.7733, 'Distortion': 0.1000},
        attrs={'noise_dimensions': '4D'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp.color_ramp.elements[0].position = 0.5636
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.6727
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': group_input.outputs["Bump Strength"], 'Height': noise_texture.outputs["Fac"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': group_input.outputs["Base Color"], 'Subsurface': 0.0509, 'Subsurface Color': group_input.outputs["Subsurface Color"], 'Specular': 1.0000, 'Roughness': 0.8727, 'Alpha': colorramp.outputs["Color"], 'Normal': bump})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'BSDF': principled_bsdf}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_procedural_volcano_island', singleton=False, type='ShaderNodeTree')
def nodegroup_procedural_volcano_island(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': texture_coordinate.outputs["Object"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    noise_texture_7 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': reroute_5, 'Roughness': 0.6000})
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.4467, 6: reroute_5, 7: noise_texture_7.outputs["Fac"]},
        attrs={'data_type': 'RGBA'})
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'island_scale'})
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': attribute_1.outputs["Fac"], 3: 0.5600, 4: 0.0000})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_3.outputs["Result"]})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_9, 'Y': reroute_9, 'Z': reroute_9})
    
    mapping_8 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': mix_7.outputs[2], 'Location': (-0.1200, -0.1100, 0.0000), 'Scale': combine_xyz_3})
    
    gradient_texture_9 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_8}, attrs={'gradient_type': 'SPHERICAL'})
    
    colorramp_16 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_9.outputs["Color"]})
    colorramp_16.color_ramp.elements[0].position = 0.2291
    colorramp_16.color_ramp.elements[0].color = [2.0000, 2.0000, 2.0000, 1.0000]
    colorramp_16.color_ramp.elements[1].position = 0.2655
    colorramp_16.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mapping_7 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': (0.7000, 0.0000, 0.0000), 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (0.8100, 0.8100, 0.8100)})
    
    gradient_texture_8 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_7})
    
    colorramp_13 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_8.outputs["Color"]})
    colorramp_13.color_ramp.elements[0].position = 0.6982
    colorramp_13.color_ramp.elements[0].color = [2.0000, 2.0000, 2.0000, 1.0000]
    colorramp_13.color_ramp.elements[1].position = 0.7709
    colorramp_13.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': colorramp_13.outputs["Color"]})
    
    mapping_6 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': (0.6500, 0.0000, 0.0000), 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (0.8100, 0.8100, 0.8100)})
    
    gradient_texture_7 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_6})
    
    colorramp_12 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_7.outputs["Color"]})
    colorramp_12.color_ramp.elements[0].position = 0.6582
    colorramp_12.color_ramp.elements[0].color = [2.0000, 2.0000, 2.0000, 1.0000]
    colorramp_12.color_ramp.elements[1].position = 0.7709
    colorramp_12.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'displacement_scale'})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': attribute.outputs["Color"]})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_8, 3: -0.1300, 4: -0.1600})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': map_range_1.outputs["Result"]})
    
    mapping_4 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': combine_xyz_1, 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (0.1800, 0.1800, 0.1800)})
    
    gradient_texture_3 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_4})
    
    colorramp_7 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_3.outputs["Color"]})
    colorramp_7.color_ramp.elements[0].position = 0.0000
    colorramp_7.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_7.color_ramp.elements[1].position = 0.0948
    colorramp_7.color_ramp.elements[1].color = [2.0000, 2.0000, 2.0000, 1.0000]
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    mapping_2 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': (0.0000, 0.0000, -0.8800), 'Scale': (0.1800, 0.1800, 0.1800)})
    
    gradient_texture_1 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_2}, attrs={'gradient_type': 'QUADRATIC_SPHERE'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': gradient_texture_1.outputs["Color"]})
    
    mix_10 = nw.new_node(Nodes.Mix, input_kwargs={0: 0.9403, 6: reroute_2, 7: reroute_1}, attrs={'data_type': 'RGBA'})
    
    noise_texture_3 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mix_10.outputs[2], 'Scale': 173.6000, 'Detail': 7.0000, 'Roughness': 0.8533})
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_3.outputs["Fac"]})
    colorramp_5.color_ramp.elements[0].position = 0.4800
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.4982
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.8200, 6: colorramp_7.outputs["Color"], 7: colorramp_5.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_2, 1: (-0.1400, -0.1700, 0.0000)})
    
    noise_texture_5 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute_2, 'Scale': 8.9600, 'Detail': 6.8000, 'Roughness': 0.7667})
    
    mix_14 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.2000, 6: add.outputs["Vector"], 7: noise_texture_5.outputs["Fac"]},
        attrs={'data_type': 'RGBA'})
    
    gradient_texture_5 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mix_14.outputs[2]}, attrs={'gradient_type': 'RADIAL'})
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': gradient_texture_5.outputs["Color"], 'Scale': 17.7400, 'Roughness': 0.7600})
    
    colorramp_9 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_4.outputs["Color"]})
    colorramp_9.color_ramp.elements[0].position = 0.4945
    colorramp_9.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_9.color_ramp.elements[1].position = 0.6764
    colorramp_9.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_2, 1: (0.0000, 0.0000, -0.6400)})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: add_1.outputs["Vector"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'MULTIPLY'})
    
    gradient_texture_6 = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': multiply.outputs["Vector"]},
        attrs={'gradient_type': 'QUADRATIC_SPHERE'})
    
    colorramp_10 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_6.outputs["Color"]})
    colorramp_10.color_ramp.elements[0].position = 0.0000
    colorramp_10.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_10.color_ramp.elements[1].position = 0.2577
    colorramp_10.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_17 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_9.outputs["Color"], 7: colorramp_10.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LIGHTEN'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_17.outputs[2]})
    
    invert_1 = nw.new_node(Nodes.Invert, input_kwargs={'Color': reroute_3})
    
    colorramp_11 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': invert_1})
    colorramp_11.color_ramp.elements[0].position = 0.9527
    colorramp_11.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_11.color_ramp.elements[1].position = 1.0000
    colorramp_11.color_ramp.elements[1].color = [0.2023, 0.2023, 0.2023, 1.0000]
    
    mapping_5 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': (-0.0400, 0.0000, 0.0000), 'Rotation': (0.0000, 1.5708, 0.0000), 'Scale': (0.1800, 0.1800, 0.1800)})
    
    gradient_texture_4 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_5})
    
    colorramp_8 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_4.outputs["Color"]})
    colorramp_8.color_ramp.elements[0].position = 0.0000
    colorramp_8.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_8.color_ramp.elements[1].position = 0.0536
    colorramp_8.color_ramp.elements[1].color = [2.0000, 2.0000, 2.0000, 1.0000]
    
    mix_12 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.5267, 6: colorramp_8.outputs["Color"], 7: colorramp_5.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    mix_3 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.9800, 6: reroute, 7: gradient_texture_1.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mix_3.outputs[2], 'W': 3.9000, 'Scale': 25.6000, 'Detail': 7.0000, 'Roughness': 1.0000},
        attrs={'noise_dimensions': '4D'})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    colorramp_3.color_ramp.elements[0].position = 0.5018
    colorramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 0.6764
    colorramp_3.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketColor', 'Mountains Mid Color', (0.4198, 0.3445, 0.2894, 1.0000)),
            ('NodeSocketColor', 'Mountains Mid Color 2', (0.0309, 0.0213, 0.0109, 1.0000)),
            ('NodeSocketColor', 'Mountains Top Color', (0.1213, 0.0809, 0.0414, 1.0000)),
            ('NodeSocketColor', 'Mountains Top Color 2', (0.3656, 0.2984, 0.2366, 1.0000)),
            ('NodeSocketColor', 'Peaks Snow Color', (1.0000, 1.0000, 1.0000, 1.0000)),
            ('NodeSocketColor', 'Hills Color', (0.5476, 0.4071, 0.2796, 1.0000)),
            ('NodeSocketColor', 'Trees Color', (0.1746, 0.3185, 0.1812, 1.0000)),
            ('NodeSocketColor', 'Trees Color 2', (0.0314, 0.0929, 0.0392, 1.0000)),
            ('NodeSocketColor', 'Water Color', (0.2289, 0.4294, 0.8347, 1.0000)),
            ('NodeSocketColor', 'Volcanos Lava Color', (1.0000, 0.0560, 0.0000, 1.0000)),
            ('NodeSocketFloat', 'Lava Emission Value', 150.0000),
            ('NodeSocketFloat', 'Lava Pouring Scale', 6.5800),
            ('NodeSocketFloatFactor', 'Bump Strength', 0.4733)])
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_3.outputs["Color"], 6: group_input.outputs["Mountains Mid Color"], 7: group_input.outputs["Mountains Mid Color 2"]},
        attrs={'data_type': 'RGBA'})
    
    mix_13 = nw.new_node(Nodes.Mix,
        input_kwargs={0: mix_12.outputs[2], 6: mix_4.outputs[2], 7: group_input.outputs["Mountains Top Color"]},
        attrs={'data_type': 'RGBA'})
    
    mix_16 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_11.outputs["Color"], 6: mix_13.outputs[2], 7: group_input.outputs["Mountains Top Color 2"]},
        attrs={'data_type': 'RGBA'})
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: mix_9.outputs[2], 6: mix_16.outputs[2], 7: group_input.outputs["Peaks Snow Color"]},
        attrs={'data_type': 'RGBA'})
    
    mix_19 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_12.outputs["Color"], 6: mix_8.outputs[2], 7: group_input.outputs["Hills Color"]},
        attrs={'data_type': 'RGBA'})
    
    noise_texture_6 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute, 'Scale': 2.1300, 'Detail': 9.9000, 'Roughness': 0.8800})
    
    colorramp_15 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_6.outputs["Fac"]})
    colorramp_15.color_ramp.elements[0].position = 0.3164
    colorramp_15.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_15.color_ramp.elements[1].position = 0.7673
    colorramp_15.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_22 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_15.outputs["Color"], 6: group_input.outputs["Trees Color"], 7: group_input.outputs["Trees Color 2"]},
        attrs={'data_type': 'RGBA'})
    
    mix_20 = nw.new_node(Nodes.Mix,
        input_kwargs={0: reroute_4, 6: mix_19.outputs[2], 7: mix_22.outputs[2]},
        attrs={'data_type': 'RGBA'})
    
    mix_23 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_16.outputs["Color"], 6: mix_20.outputs[2], 7: group_input.outputs["Water Color"]},
        attrs={'data_type': 'RGBA'})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': colorramp_16.outputs["Color"]})
    
    colorramp_19 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_7})
    colorramp_19.color_ramp.elements[0].position = 0.0000
    colorramp_19.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_19.color_ramp.elements[1].position = 1.0000
    colorramp_19.color_ramp.elements[1].color = [0.6691, 0.6691, 0.6691, 1.0000]
    
    colorramp_20 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_7})
    colorramp_20.color_ramp.elements[0].position = 0.0000
    colorramp_20.color_ramp.elements[0].color = [0.0625, 0.0625, 0.0625, 1.0000]
    colorramp_20.color_ramp.elements[1].position = 1.0000
    colorramp_20.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    colorramp_18 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': reroute_7})
    colorramp_18.color_ramp.elements[0].position = 0.0000
    colorramp_18.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_18.color_ramp.elements[1].position = 1.0000
    colorramp_18.color_ramp.elements[1].color = [0.3062, 0.3062, 0.3062, 1.0000]
    
    mapping_1 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': (0.0000, 0.0000, -0.8800), 'Scale': (1.0000, 1.0000, 0.1900)})
    
    wave_texture = nw.new_node(Nodes.WaveTexture, input_kwargs={'Vector': mapping_1, 'Scale': 1.8100})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0867, 6: reroute, 7: wave_texture.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute, 'W': 12.0900, 'Scale': 9.3400, 'Detail': 8.0000, 'Roughness': 0.6000},
        attrs={'noise_dimensions': '4D'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.1567, 6: mix_2.outputs[2], 7: noise_texture.outputs["Fac"]},
        attrs={'data_type': 'RGBA'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix.outputs[2], 'Scale': group_input.outputs["Lava Pouring Scale"]},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.0185
    colorramp.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_8, 3: -0.8800, 4: -0.8900})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_2.outputs["Result"]})
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': combine_xyz_2, 'Scale': (0.1400, 0.1400, 0.1400)})
    
    gradient_texture = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping}, attrs={'gradient_type': 'QUADRATIC_SPHERE'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.0354
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: colorramp_1.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_8, 3: -1.8500, 4: -2.4000})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range.outputs["Result"]})
    
    mapping_3 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': reroute, 'Location': combine_xyz, 'Scale': (2.9100, 2.9100, 2.9100)})
    
    gradient_texture_2 = nw.new_node(Nodes.GradientTexture, input_kwargs={'Vector': mapping_3}, attrs={'gradient_type': 'SPHERICAL'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_2.outputs["Color"]})
    colorramp_4.color_ramp.elements[0].position = 0.0000
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.2545
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.8867, 6: colorramp_4.outputs["Color"], 7: colorramp_5.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_1.outputs[2], 7: mix_6.outputs[2]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LIGHTEN'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: mix_5.outputs[2], 1: group_input.outputs["Lava Emission Value"]},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mix_3.outputs[2], 'Scale': 24.3000, 'Detail': 7.0000, 'Roughness': 0.8533})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    colorramp_2.color_ramp.elements[0].position = 0.3964
    colorramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 0.5891
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_11 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.8000, 6: colorramp_2.outputs["Color"], 7: mix_9.outputs[2]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LIGHTEN'})
    
    mix_15 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.9133, 6: mix_11.outputs[2], 7: reroute_3},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    colorramp_6 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_6.color_ramp.elements[0].position = 0.0590
    colorramp_6.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_6.color_ramp.elements[1].position = 0.1765
    colorramp_6.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Color': colorramp_6.outputs["Color"]})
    
    mix_18 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_15.outputs[2], 7: invert},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': reroute_6, 'Scale': 71.0000})
    
    colorramp_14 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_1.outputs["Distance"]})
    colorramp_14.color_ramp.elements[0].position = 0.0000
    colorramp_14.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_14.color_ramp.elements[1].position = 0.8473
    colorramp_14.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_21 = nw.new_node(Nodes.Mix,
        input_kwargs={0: reroute_4, 6: mix_18.outputs[2], 7: colorramp_14.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    noise_texture_8 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': reroute_6, 'Scale': 99.4000, 'Roughness': 0.0000})
    
    colorramp_17 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_8.outputs["Fac"]})
    colorramp_17.color_ramp.elements[0].position = 0.0000
    colorramp_17.color_ramp.elements[0].color = [0.3123, 0.3123, 0.3123, 1.0000]
    colorramp_17.color_ramp.elements[1].position = 1.0000
    colorramp_17.color_ramp.elements[1].color = [0.1450, 0.1450, 0.1450, 1.0000]
    
    mix_25 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.9000, 6: colorramp_17.outputs["Color"], 7: (0.0000, 0.0000, 0.0000, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    mix_24 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_16.outputs["Color"], 6: mix_21.outputs[2], 7: mix_25.outputs[2]},
        attrs={'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': group_input.outputs["Bump Strength"], 'Height': mix_24.outputs[2]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_23.outputs[2], 'Metallic': colorramp_19.outputs["Color"], 'Specular': colorramp_20.outputs["Color"], 'Roughness': colorramp_18.outputs["Color"], 'Emission': group_input.outputs["Volcanos Lava Color"], 'Emission Strength': multiply_1, 'Normal': bump})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Shader': principled_bsdf}, attrs={'is_active_output': True})

def shader_clouds(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_procedural_clouds().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_vulcano_island(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group = nw.new_node(nodegroup_procedural_volcano_island().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Mountains Randomize', 1.0000),
            ('NodeSocketFloat', 'Hills Randomize', 1.0000),
            ('NodeSocketFloat', 'Cliffs Randomize', 1.0000),
            ('NodeSocketFloat', 'Volcano Erosion Randomize', 1.0000),
            ('NodeSocketFloat', 'Displacement Scale', 0.5000),
            ('NodeSocketFloat', 'Clouds Height', 0.7000),
            ('NodeSocketFloat', 'Island Scale', 0.2150),
            ('NodeSocketInt', 'Subdivision Level', 7)])
    
    subdivision_surface = nw.new_node(Nodes.SubdivisionSurface,
        input_kwargs={'Mesh': group_input.outputs["Geometry"], 'Level': group_input.outputs["Subdivision Level"], 'Edge Crease': 1.0000})
    
    position = nw.new_node(Nodes.InputPosition)
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: position_1, 1: (0.6700, 0.5300, 0.6700)},
        attrs={'operation': 'MULTIPLY'})
    
    gradient_texture = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': multiply.outputs["Vector"]},
        attrs={'gradient_type': 'QUADRATIC_SPHERE'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture.outputs["Color"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.7636
    colorramp.color_ramp.elements[1].color = [0.5089, 0.5089, 0.5089, 1.0000]
    
    gradient_texture_1 = nw.new_node(Nodes.GradientTexture, attrs={'gradient_type': 'SPHERICAL'})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_1.outputs["Color"]})
    colorramp_3.color_ramp.elements[0].position = 0.7855
    colorramp_3.color_ramp.elements[0].color = [0.6024, 0.6024, 0.6024, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 1.0000
    colorramp_3.color_ramp.elements[1].color = [0.2375, 0.2375, 0.2375, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: colorramp_3.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["Volcano Erosion Randomize"], 'Scale': 1.2400, 'Detail': 8.0000, 'Roughness': 0.7400},
        attrs={'noise_dimensions': '4D'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    colorramp_4.color_ramp.elements[0].position = 0.4655
    colorramp_4.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.5745
    colorramp_4.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0500, 6: mix_1.outputs[2], 7: colorramp_4.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    noise_texture_3 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': position_1, 'W': 12.0900, 'Scale': 5.0400, 'Detail': 8.0000, 'Roughness': 0.4333},
        attrs={'noise_dimensions': '4D'})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.1600, 6: position_1, 7: noise_texture_3.outputs["Fac"]},
        attrs={'data_type': 'RGBA'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix_4.outputs[2], 'Scale': 8.0000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_5.color_ramp.elements[0].position = 0.0327
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.0582
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_3 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0400, 6: mix_2.outputs[2], 7: colorramp_5.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["Mountains Randomize"], 'Scale': 0.6600, 'Detail': 8.0000, 'Roughness': 0.5133},
        attrs={'noise_dimensions': '4D'})
    
    colorramp_6 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_4.outputs["Fac"]})
    colorramp_6.color_ramp.elements[0].position = 0.4900
    colorramp_6.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_6.color_ramp.elements[1].position = 0.9382
    colorramp_6.color_ramp.elements[1].color = [0.4575, 0.4575, 0.4575, 1.0000]
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_3.outputs[2], 7: colorramp_6.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LIGHTEN'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix_4.outputs[2], 'Scale': 10.0000},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_7 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_1.outputs["Distance"]})
    colorramp_7.color_ramp.elements[0].position = 0.0327
    colorramp_7.color_ramp.elements[0].color = [0.0038, 0.0038, 0.0038, 1.0000]
    colorramp_7.color_ramp.elements[1].position = 0.0582
    colorramp_7.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    gradient_texture_2 = nw.new_node(Nodes.GradientTexture, attrs={'gradient_type': 'SPHERICAL'})
    
    colorramp_8 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_2.outputs["Color"]})
    colorramp_8.color_ramp.elements[0].position = 0.0000
    colorramp_8.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_8.color_ramp.elements[1].position = 1.0000
    colorramp_8.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_7.outputs["Color"], 7: colorramp_8.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LIGHTEN'})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.2000, 6: mix_5.outputs[2], 7: mix_7.outputs[2]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    noise_texture_5 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'W': group_input.outputs["Hills Randomize"], 'Scale': 0.9500, 'Detail': 8.0000},
        attrs={'noise_dimensions': '4D'})
    
    colorramp_9 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_5.outputs["Fac"]})
    colorramp_9.color_ramp.elements[0].position = 0.4000
    colorramp_9.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_9.color_ramp.elements[1].position = 0.6218
    colorramp_9.color_ramp.elements[1].color = [0.0356, 0.0356, 0.0356, 1.0000]
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_6.outputs[2], 7: colorramp_9.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LIGHTEN'})
    
    noise_texture_6 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': position_1, 'W': group_input.outputs["Cliffs Randomize"], 'Scale': 5.0400, 'Detail': 8.0000, 'Roughness': 0.4333},
        attrs={'noise_dimensions': '4D'})
    
    colorramp_11 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_6.outputs["Fac"]})
    colorramp_11.color_ramp.elements[0].position = 0.3491
    colorramp_11.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_11.color_ramp.elements[1].position = 1.0000
    colorramp_11.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_10 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.3600, 6: position_1, 7: colorramp_11.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: mix_10.outputs[2], 1: (-0.1200, -0.1200, 0.0000)})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Island Scale"]})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_2, 3: 0.6500, 4: 0.0000})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_1.outputs["Result"]})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_1, 'Y': reroute_1, 'Z': reroute_1})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: add.outputs["Vector"], 1: combine_xyz_2},
        attrs={'operation': 'MULTIPLY'})
    
    gradient_texture_3 = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': multiply_1.outputs["Vector"]},
        attrs={'gradient_type': 'SPHERICAL'})
    
    colorramp_10 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': gradient_texture_3.outputs["Color"]})
    colorramp_10.color_ramp.elements[0].position = 0.0582
    colorramp_10.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_10.color_ramp.elements[1].position = 0.1673
    colorramp_10.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_8.outputs[2], 7: colorramp_10.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Displacement Scale"]})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute, 3: 1.9400, 4: 2.3600})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: mix_9.outputs[2], 1: map_range.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_2})
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: combine_xyz})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': subdivision_surface, 'Position': add_1.outputs["Vector"]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_position})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_vulcano_island)})
    
    grid_2 = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 10.1400, 'Size Y': 10.1400, 'Vertices X': 6, 'Vertices Y': 6})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid_2.outputs["Mesh"], 'Name': 'uv_map', 3: grid_2.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input.outputs["Clouds Height"]})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': store_named_attribute, 'Offset': combine_xyz_1})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_position_3, 'Material': surface.shaderfunc_to_material(shader_clouds)})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material, set_material_1]})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': join_geometry, 2: reroute})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': capture_attribute.outputs["Geometry"], 2: reroute_2})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Displacement Scale': capture_attribute.outputs[2], 'Island Scale': capture_attribute_1.outputs[2]},
        attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_vulcano_island, selection=selection)
    surface.add_material(obj, shader_clouds, selection=selection)
apply(bpy.context.active_object)