import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



def shader_bulb_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    fresnel = nw.new_node(Nodes.Fresnel)
    
    color_ramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': fresnel})
    color_ramp_2.color_ramp.elements[0].position = 0.0091
    color_ramp_2.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp_2.color_ramp.elements[1].position = 0.9955
    color_ramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: color_ramp_2.outputs["Color"], 1: 10.0000}, attrs={'operation': 'MULTIPLY'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (1.0000, 0.9000, 0.7000, 1.0000), 'Emission Strength': multiply},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS', 'distribution': 'MULTI_GGX'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_cable_material(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 200.0000, 'Detail': 15.0000})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Color"]})
    color_ramp.color_ramp.elements[0].position = 0.0000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 1.0000
    color_ramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.5000, 'Height': color_ramp.outputs["Color"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0000, 0.0000, 0.0000, 1.0000), 'Emission Strength': 0.0000, 'Normal': bump},
        attrs={'subsurface_method': 'RANDOM_WALK_FIXED_RADIUS', 'distribution': 'MULTI_GGX'})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketBool', 'Show Cable', True),
            ('NodeSocketFloat', 'Cable Size', 0.0100),
            ('NodeSocketMaterial', 'Cable Material', None),
            ('NodeSocketInt', 'Bulp Curve Divides', 0),
            ('NodeSocketInt', 'Bulp Resolution', 16),
            ('NodeSocketFloat', 'Bulp Size Min', 0.0500),
            ('NodeSocketFloat', 'Bulp Size Max', 1.0000),
            ('NodeSocketMaterial', 'Bulb Material', None),
            ('NodeSocketCollection', 'Custom Bulp Object', None),
            ('NodeSocketVector', 'Random Rotation Max', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketInt', 'Random Seed', 0),
            ('NodeSocketBool', 'Shade Smooth', True)])
    
    collection_info = nw.new_node(Nodes.CollectionInfo,
        input_kwargs={'Collection': group_input_5.outputs["Custom Bulp Object"], 'Separate Children': True, 'Reset Children': True})
    
    domain_size = nw.new_node(Nodes.DomainSize, input_kwargs={'Geometry': collection_info}, attrs={'component': 'INSTANCES'})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: domain_size.outputs["Instance Count"]}, attrs={'data_type': 'INT'})
    
    domain_size_1 = nw.new_node(Nodes.DomainSize, input_kwargs={'Geometry': group_input_5.outputs["Geometry"]})
    
    greater_than_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: domain_size_1.outputs["Point Count"], 1: 0.0000},
        attrs={'operation': 'GREATER_THAN'})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': group_input_5.outputs["Geometry"]})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={1: greater_than_1, 14: group_input_5.outputs["Geometry"], 15: mesh_to_curve})
    
    subdivide_curve = nw.new_node(Nodes.SubdivideCurve,
        input_kwargs={'Curve': switch_2.outputs[6], 'Cuts': group_input_5.outputs["Bulp Curve Divides"]})
    
    divide = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_5.outputs["Bulp Resolution"], 1: 2.0000},
        attrs={'operation': 'DIVIDE'})
    
    uv_sphere = nw.new_node(Nodes.MeshUVSphere,
        input_kwargs={'Segments': group_input_5.outputs["Bulp Resolution"], 'Rings': divide, 'Radius': 0.0500})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': uv_sphere.outputs["Mesh"], 'Material': group_input_5.outputs["Bulb Material"]})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input_5.outputs["Random Rotation Max"], 1: (-1.0000, -1.0000, -1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: multiply.outputs["Vector"], 1: group_input_5.outputs["Random Rotation Max"], 'Seed': group_input_5.outputs["Random Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': random_value_1.outputs["Value"]})
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["X"]}, attrs={'operation': 'RADIANS'})
    
    radians_1 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"]}, attrs={'operation': 'RADIANS'})
    
    radians_2 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Z"]}, attrs={'operation': 'RADIANS'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': radians, 'Y': radians_1, 'Z': radians_2})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: group_input_5.outputs["Bulp Size Min"], 3: group_input_5.outputs["Bulp Size Max"], 'Seed': group_input_5.outputs["Random Seed"]})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': subdivide_curve, 'Instance': set_material_1, 'Rotation': combine_xyz, 'Scale': random_value.outputs[1]})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': subdivide_curve, 'Instance': collection_info, 'Pick Instance': True, 'Rotation': combine_xyz, 'Scale': random_value.outputs[1]})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: greater_than, 14: instance_on_points_1, 15: instance_on_points_2})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_5.outputs["Bulp Resolution"], 1: 2.0000},
        attrs={'operation': 'MULTIPLY'})
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': multiply_1, 'Radius': group_input_5.outputs["Cable Size"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': subdivide_curve, 'Profile Curve': curve_circle.outputs["Curve"]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': group_input_5.outputs["Cable Material"]})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_5.outputs["Show Cable"], 15: set_material})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [switch.outputs[6], switch_1.outputs[6]]})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth,
        input_kwargs={'Geometry': join_geometry, 'Shade Smooth': group_input_5.outputs["Shade Smooth"]})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_shade_smooth})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': realize_instances}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_cable_material, selection=selection)
    surface.add_material(obj, shader_bulb_material, selection=selection)
apply(bpy.context.active_object)