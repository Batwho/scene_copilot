import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface


mat = bpy.data.materials.new(name = "Leaf")
mat.use_nodes = True
#initialize Leaf node group
def leaf_node_group():

    leaf = mat.node_tree
    #start with a clean node tree
    for node in leaf.nodes:
        leaf.nodes.remove(node)
    #initialize leaf nodes
    #node Principled BSDF
    principled_bsdf = leaf.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.800000011920929
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Normal
    principled_bsdf.inputs[22].default_value = (0.0, 0.0, 0.0)
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Translucent BSDF
    translucent_bsdf = leaf.nodes.new("ShaderNodeBsdfTranslucent")
    translucent_bsdf.name = "Translucent BSDF"
    #Normal
    translucent_bsdf.inputs[1].default_value = (0.0, 0.0, 0.0)
    
    #node Material Output
    material_output = leaf.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Hue Saturation Value
    hue_saturation_value = leaf.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Hue
    hue_saturation_value.inputs[0].default_value = 0.49000000953674316
    #Saturation
    hue_saturation_value.inputs[1].default_value = 1.0
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Mix Shader.001
    mix_shader_001 = leaf.nodes.new("ShaderNodeMixShader")
    mix_shader_001.name = "Mix Shader.001"
    #Fac
    mix_shader_001.inputs[0].default_value = 0.5
    
    #node Attribute
    attribute = leaf.nodes.new("ShaderNodeAttribute")
    attribute.name = "Attribute"
    attribute.attribute_name = "UV"
    attribute.attribute_type = 'GEOMETRY'
    attribute.outputs[0].hide = True
    attribute.outputs[2].hide = True
    attribute.outputs[3].hide = True
    
    #node Separate XYZ.001
    separate_xyz_001 = leaf.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz_001.name = "Separate XYZ.001"
    separate_xyz_001.outputs[2].hide = True
    
    #node Map Range
    map_range = leaf.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = -0.5
    #From Max
    map_range.inputs[2].default_value = 1.0
    #To Min
    map_range.inputs[3].default_value = 0.0
    #To Max
    map_range.inputs[4].default_value = 1.0
    
    #node ColorRamp
    colorramp = leaf.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.5, 0.5, 0.5, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.5)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    
    #node Attribute.001
    attribute_001 = leaf.nodes.new("ShaderNodeAttribute")
    attribute_001.name = "Attribute.001"
    attribute_001.hide = True
    attribute_001.attribute_name = "Color"
    attribute_001.attribute_type = 'GEOMETRY'
    attribute_001.outputs[1].hide = True
    attribute_001.outputs[2].hide = True
    attribute_001.outputs[3].hide = True
    
    #node Mix
    mix = leaf.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    
    #Set locations
    principled_bsdf.location = (8064.1123046875, 271.0951232910156)
    translucent_bsdf.location = (8147.5048828125, 386.5243225097656)
    material_output.location = (8721.5078125, 464.3583984375)
    hue_saturation_value.location = (7805.68115234375, 584.3585205078125)
    mix_shader_001.location = (8360.0, 340.0)
    attribute.location = (6580.0, 160.0)
    separate_xyz_001.location = (6760.0, 160.0)
    map_range.location = (6960.0, 380.0)
    colorramp.location = (7120.0, 440.0)
    attribute_001.location = (7400.0, 360.0)
    mix.location = (7400.0, 320.0)
    
    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    translucent_bsdf.width, translucent_bsdf.height = 140.0, 100.0
    material_output.width, material_output.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    mix_shader_001.width, mix_shader_001.height = 140.0, 100.0
    attribute.width, attribute.height = 140.0, 100.0
    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    attribute_001.width, attribute_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    
    #initialize leaf links
    #attribute.Vector -> separate_xyz_001.Vector
    leaf.links.new(attribute.outputs[1], separate_xyz_001.inputs[0])
    #separate_xyz_001.Y -> map_range.Value
    leaf.links.new(separate_xyz_001.outputs[1], map_range.inputs[0])
    #map_range.Result -> colorramp.Fac
    leaf.links.new(map_range.outputs[0], colorramp.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    leaf.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #translucent_bsdf.BSDF -> mix_shader_001.Shader
    leaf.links.new(translucent_bsdf.outputs[0], mix_shader_001.inputs[1])
    #principled_bsdf.BSDF -> mix_shader_001.Shader
    leaf.links.new(principled_bsdf.outputs[0], mix_shader_001.inputs[2])
    #mix.Result -> hue_saturation_value.Color
    leaf.links.new(mix.outputs[2], hue_saturation_value.inputs[4])
    #colorramp.Color -> mix.A
    leaf.links.new(colorramp.outputs[0], mix.inputs[6])
    #attribute_001.Color -> mix.B
    leaf.links.new(attribute_001.outputs[0], mix.inputs[7])
    #hue_saturation_value.Color -> translucent_bsdf.Color
    leaf.links.new(hue_saturation_value.outputs[0], translucent_bsdf.inputs[0])
    #mix_shader_001.Shader -> material_output.Surface
    leaf.links.new(mix_shader_001.outputs[0], material_output.inputs[0])
    return leaf

leaf = leaf_node_group()


mat = bpy.data.materials.new(name = "Leaves")
mat.use_nodes = True
#initialize Leaves node group
def leaves_node_group():

    leaves = mat.node_tree
    #start with a clean node tree
    for node in leaves.nodes:
        leaves.nodes.remove(node)
    #initialize leaves nodes
    #node Translucent BSDF
    translucent_bsdf = leaves.nodes.new("ShaderNodeBsdfTranslucent")
    translucent_bsdf.name = "Translucent BSDF"
    
    #node Attribute
    attribute = leaves.nodes.new("ShaderNodeAttribute")
    attribute.name = "Attribute"
    attribute.attribute_name = "Color"
    attribute.attribute_type = 'GEOMETRY'
    
    #node Texture Coordinate
    texture_coordinate = leaves.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False
    
    #node Noise Texture
    noise_texture = leaves.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 4.0
    #Detail
    noise_texture.inputs[3].default_value = 4.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.30000001192092896
    #Distortion
    noise_texture.inputs[5].default_value = 1.0
    
    #node Principled BSDF
    principled_bsdf = leaves.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'BURLEY'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.8000000715255737, 0.8000000715255737, 0.8000000715255737, 1.0)
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.44727271795272827
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 1.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Mix Shader.001
    mix_shader_001 = leaves.nodes.new("ShaderNodeMixShader")
    mix_shader_001.name = "Mix Shader.001"
    #Fac
    mix_shader_001.inputs[0].default_value = 0.5
    
    #node Math
    math = leaves.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'GREATER_THAN'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.44999998807907104
    
    #node Material Output
    material_output = leaves.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Mix Shader
    mix_shader = leaves.nodes.new("ShaderNodeMixShader")
    mix_shader.name = "Mix Shader"
    
    #node Mix
    mix = leaves.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MULTIPLY'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1.0
    
    #node Bump
    bump = leaves.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Strength
    bump.inputs[0].default_value = 0.5
    #Distance
    bump.inputs[1].default_value = 0.20000000298023224
    #Normal
    bump.inputs[3].default_value = (0.0, 0.0, 0.0)
    
    #node Transparent BSDF
    transparent_bsdf = leaves.nodes.new("ShaderNodeBsdfTransparent")
    transparent_bsdf.name = "Transparent BSDF"
    #Color
    transparent_bsdf.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    
    #node Hue Saturation Value
    hue_saturation_value = leaves.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Hue
    hue_saturation_value.inputs[0].default_value = 0.5
    #Saturation
    hue_saturation_value.inputs[1].default_value = 1.0
    #Value
    hue_saturation_value.inputs[2].default_value = 3.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    
    #Set locations
    translucent_bsdf.location = (6444.36328125, 406.7685546875)
    attribute.location = (5393.01025390625, 175.1435546875)
    texture_coordinate.location = (5400.0, -20.0)
    noise_texture.location = (5560.0, -20.0)
    principled_bsdf.location = (6342.8828125, 303.65838623046875)
    mix_shader_001.location = (6702.5263671875, 406.7685546875)
    math.location = (6420.0, -320.0)
    material_output.location = (7188.6923828125, 354.79705810546875)
    mix_shader.location = (7010.0654296875, 356.8975524902344)
    mix.location = (5870.1689453125, 256.99798583984375)
    bump.location = (5875.26220703125, 60.0)
    transparent_bsdf.location = (6700.0, 500.0001525878906)
    hue_saturation_value.location = (6120.0, 420.0)
    
    #Set dimensions
    translucent_bsdf.width, translucent_bsdf.height = 140.0, 100.0
    attribute.width, attribute.height = 140.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    mix_shader_001.width, mix_shader_001.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    material_output.width, material_output.height = 140.0, 100.0
    mix_shader.width, mix_shader.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    transparent_bsdf.width, transparent_bsdf.height = 140.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    
    #initialize leaves links
    #noise_texture.Fac -> bump.Height
    leaves.links.new(noise_texture.outputs[0], bump.inputs[2])
    #texture_coordinate.Object -> noise_texture.Vector
    leaves.links.new(texture_coordinate.outputs[3], noise_texture.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    leaves.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #mix.Result -> hue_saturation_value.Color
    leaves.links.new(mix.outputs[2], hue_saturation_value.inputs[4])
    #transparent_bsdf.BSDF -> mix_shader.Shader
    leaves.links.new(transparent_bsdf.outputs[0], mix_shader.inputs[1])
    #bump.Normal -> principled_bsdf.Normal
    leaves.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #bump.Normal -> translucent_bsdf.Normal
    leaves.links.new(bump.outputs[0], translucent_bsdf.inputs[1])
    #noise_texture.Fac -> math.Value
    leaves.links.new(noise_texture.outputs[0], math.inputs[0])
    #math.Value -> mix_shader.Fac
    leaves.links.new(math.outputs[0], mix_shader.inputs[0])
    #attribute.Color -> mix.B
    leaves.links.new(attribute.outputs[0], mix.inputs[7])
    #noise_texture.Fac -> mix.A
    leaves.links.new(noise_texture.outputs[0], mix.inputs[6])
    #mix_shader.Shader -> material_output.Surface
    leaves.links.new(mix_shader.outputs[0], material_output.inputs[0])
    #translucent_bsdf.BSDF -> mix_shader_001.Shader
    leaves.links.new(translucent_bsdf.outputs[0], mix_shader_001.inputs[1])
    #principled_bsdf.BSDF -> mix_shader_001.Shader
    leaves.links.new(principled_bsdf.outputs[0], mix_shader_001.inputs[2])
    #mix_shader_001.Shader -> mix_shader.Shader
    leaves.links.new(mix_shader_001.outputs[0], mix_shader.inputs[2])
    #hue_saturation_value.Color -> translucent_bsdf.Color
    leaves.links.new(hue_saturation_value.outputs[0], translucent_bsdf.inputs[0])
    return leaves

leaves = leaves_node_group()




mat = bpy.data.materials.new(name = "Bark")
mat.use_nodes = True
#initialize Voronoi_Crackle node group
def voronoi_crackle_node_group():

    voronoi_crackle = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Voronoi_Crackle")
    
    #initialize voronoi_crackle nodes
    #node Voronoi Texture.002
    voronoi_texture_002 = voronoi_crackle.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_002.name = "Voronoi Texture.002"
    voronoi_texture_002.distance = 'EUCLIDEAN'
    voronoi_texture_002.feature = 'F2'
    voronoi_texture_002.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture_002.inputs[2].default_value = 5.0
    #Randomness
    voronoi_texture_002.inputs[5].default_value = 1.0
    
    #node Math.005
    math_005 = voronoi_crackle.nodes.new("ShaderNodeMath")
    math_005.name = "Math.005"
    math_005.operation = 'SUBTRACT'
    math_005.use_clamp = False
    
    #node Voronoi Texture.003
    voronoi_texture_003 = voronoi_crackle.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_003.name = "Voronoi Texture.003"
    voronoi_texture_003.distance = 'EUCLIDEAN'
    voronoi_texture_003.feature = 'F1'
    voronoi_texture_003.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture_003.inputs[2].default_value = 5.0
    #Randomness
    voronoi_texture_003.inputs[5].default_value = 1.0
    
    #node Vector Math.006
    vector_math_006 = voronoi_crackle.nodes.new("ShaderNodeVectorMath")
    vector_math_006.name = "Vector Math.006"
    vector_math_006.operation = 'SUBTRACT'
    
    #node Reroute.002
    reroute_002 = voronoi_crackle.nodes.new("NodeReroute")
    reroute_002.name = "Reroute.002"
    #node Group Input
    group_input = voronoi_crackle.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    #voronoi_crackle inputs
    #input Vector
    voronoi_crackle.inputs.new('NodeSocketVector', "Vector")
    voronoi_crackle.inputs[0].default_value = (0.0, 0.0, 0.0)
    voronoi_crackle.inputs[0].min_value = -3.4028234663852886e+38
    voronoi_crackle.inputs[0].max_value = 3.4028234663852886e+38
    voronoi_crackle.inputs[0].attribute_domain = 'POINT'
    voronoi_crackle.inputs[0].hide_value = True
    
    
    
    #node Group Output
    group_output = voronoi_crackle.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    #voronoi_crackle outputs
    #output Fac
    voronoi_crackle.outputs.new('NodeSocketFloat', "Fac")
    voronoi_crackle.outputs[0].default_value = 0.0
    voronoi_crackle.outputs[0].min_value = -3.4028234663852886e+38
    voronoi_crackle.outputs[0].max_value = 3.4028234663852886e+38
    voronoi_crackle.outputs[0].attribute_domain = 'POINT'
    
    #output Color
    voronoi_crackle.outputs.new('NodeSocketColor', "Color")
    voronoi_crackle.outputs[1].default_value = (0.0, 0.0, 0.0, 0.0)
    voronoi_crackle.outputs[1].attribute_domain = 'POINT'
    
    #output Position
    voronoi_crackle.outputs.new('NodeSocketVector', "Position")
    voronoi_crackle.outputs[2].default_value = (0.0, 0.0, 0.0)
    voronoi_crackle.outputs[2].min_value = -3.4028234663852886e+38
    voronoi_crackle.outputs[2].max_value = 3.4028234663852886e+38
    voronoi_crackle.outputs[2].attribute_domain = 'POINT'
    
    #output Vector
    voronoi_crackle.outputs.new('NodeSocketVector', "Vector")
    voronoi_crackle.outputs[3].default_value = (0.0, 0.0, 0.0)
    voronoi_crackle.outputs[3].min_value = -3.4028234663852886e+38
    voronoi_crackle.outputs[3].max_value = 3.4028234663852886e+38
    voronoi_crackle.outputs[3].attribute_domain = 'POINT'
    
    
    
    
    #Set locations
    voronoi_texture_002.location = (-8.45050048828125, 152.7005615234375)
    math_005.location = (211.54949951171875, 172.7005615234375)
    voronoi_texture_003.location = (-8.45050048828125, -107.2994384765625)
    vector_math_006.location = (211.54949951171875, -147.2994384765625)
    reroute_002.location = (-211.54949951171875, -172.70068359375)
    group_input.location = (-427.8158264160156, -132.44692993164062)
    group_output.location = (401.5495300292969, 0.0)
    
    #Set dimensions
    voronoi_texture_002.width, voronoi_texture_002.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    voronoi_texture_003.width, voronoi_texture_003.height = 140.0, 100.0
    vector_math_006.width, vector_math_006.height = 140.0, 100.0
    reroute_002.width, reroute_002.height = 16.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    
    #initialize voronoi_crackle links
    #math_005.Value -> group_output.Fac
    voronoi_crackle.links.new(math_005.outputs[0], group_output.inputs[0])
    #vector_math_006.Vector -> group_output.Vector
    voronoi_crackle.links.new(vector_math_006.outputs[0], group_output.inputs[3])
    #voronoi_texture_003.Color -> group_output.Color
    voronoi_crackle.links.new(voronoi_texture_003.outputs[1], group_output.inputs[1])
    #voronoi_texture_003.Position -> group_output.Position
    voronoi_crackle.links.new(voronoi_texture_003.outputs[2], group_output.inputs[2])
    #group_input.Vector -> reroute_002.Input
    voronoi_crackle.links.new(group_input.outputs[0], reroute_002.inputs[0])
    #voronoi_texture_002.Distance -> math_005.Value
    voronoi_crackle.links.new(voronoi_texture_002.outputs[0], math_005.inputs[0])
    #voronoi_texture_003.Distance -> math_005.Value
    voronoi_crackle.links.new(voronoi_texture_003.outputs[0], math_005.inputs[1])
    #voronoi_texture_003.Position -> vector_math_006.Vector
    voronoi_crackle.links.new(voronoi_texture_003.outputs[2], vector_math_006.inputs[0])
    #reroute_002.Output -> voronoi_texture_002.Vector
    voronoi_crackle.links.new(reroute_002.outputs[0], voronoi_texture_002.inputs[0])
    #reroute_002.Output -> voronoi_texture_003.Vector
    voronoi_crackle.links.new(reroute_002.outputs[0], voronoi_texture_003.inputs[0])
    #reroute_002.Output -> vector_math_006.Vector
    voronoi_crackle.links.new(reroute_002.outputs[0], vector_math_006.inputs[1])
    return voronoi_crackle

voronoi_crackle = voronoi_crackle_node_group()

#initialize Bark node group
def bark_node_group():

    bark = mat.node_tree
    #start with a clean node tree
    for node in bark.nodes:
        bark.nodes.remove(node)
    #initialize bark nodes
    #node Frame
    frame = bark.nodes.new("NodeFrame")
    frame.label = "Texture Size"
    frame.name = "Frame"
    frame.use_custom_color = True
    frame.color = (0.6000000238418579, 0.06652987748384476, 0.0989021435379982)
    frame.label_size = 20
    frame.shrink = True
    
    #node Material Output
    material_output = bark.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    
    #node Material Output.001
    material_output_001 = bark.nodes.new("ShaderNodeOutputMaterial")
    material_output_001.name = "Material Output.001"
    material_output_001.is_active_output = False
    material_output_001.target = 'EEVEE'
    #Displacement
    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Displacement
    displacement = bark.nodes.new("ShaderNodeDisplacement")
    displacement.name = "Displacement"
    displacement.space = 'OBJECT'
    #Midlevel
    displacement.inputs[1].default_value = 0.5
    #Scale
    displacement.inputs[2].default_value = 0.009999999776482582
    #Normal
    displacement.inputs[3].default_value = (0.0, 0.0, 0.0)
    
    #node Principled BSDF
    principled_bsdf = bark.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)
    
    #node Map Range.002
    map_range_002 = bark.nodes.new("ShaderNodeMapRange")
    map_range_002.name = "Map Range.002"
    map_range_002.clamp = True
    map_range_002.data_type = 'FLOAT'
    map_range_002.interpolation_type = 'SMOOTHSTEP'
    #From Min
    map_range_002.inputs[1].default_value = 0.0
    #From Max
    map_range_002.inputs[2].default_value = 1.0
    #To Min
    map_range_002.inputs[3].default_value = 0.5
    #To Max
    map_range_002.inputs[4].default_value = 1.0
    
    #node White Noise Texture
    white_noise_texture = bark.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture.name = "White Noise Texture"
    white_noise_texture.noise_dimensions = '2D'
    
    #node Map Range.006
    map_range_006 = bark.nodes.new("ShaderNodeMapRange")
    map_range_006.name = "Map Range.006"
    map_range_006.clamp = True
    map_range_006.data_type = 'FLOAT'
    map_range_006.interpolation_type = 'SMOOTHERSTEP'
    #From Min
    map_range_006.inputs[1].default_value = 0.0
    #From Max
    map_range_006.inputs[2].default_value = 0.5
    #To Min
    map_range_006.inputs[3].default_value = 0.8999999761581421
    #To Max
    map_range_006.inputs[4].default_value = 1.0
    
    #node Math.014
    math_014 = bark.nodes.new("ShaderNodeMath")
    math_014.name = "Math.014"
    math_014.operation = 'MINIMUM'
    math_014.use_clamp = False
    
    #node Math.003
    math_003 = bark.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'ADD'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 0.07999999821186066
    
    #node Math.002
    math_002 = bark.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    
    #node Separate XYZ
    separate_xyz = bark.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"
    
    #node Map Range
    map_range = bark.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = 0.0
    #From Max
    map_range.inputs[2].default_value = 0.11000001430511475
    #To Min
    map_range.inputs[3].default_value = 0.0
    #To Max
    map_range.inputs[4].default_value = 1.0
    
    #node Map Range.001
    map_range_001 = bark.nodes.new("ShaderNodeMapRange")
    map_range_001.name = "Map Range.001"
    map_range_001.clamp = True
    map_range_001.data_type = 'FLOAT'
    map_range_001.interpolation_type = 'SMOOTHSTEP'
    #From Min
    map_range_001.inputs[1].default_value = 0.0
    #From Max
    map_range_001.inputs[2].default_value = 0.10000000149011612
    #To Min
    map_range_001.inputs[3].default_value = 0.0
    #To Max
    map_range_001.inputs[4].default_value = 1.0
    
    #node Math.001
    math_001 = bark.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'MULTIPLY'
    math_001.use_clamp = True
    
    #node Math.004
    math_004 = bark.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MULTIPLY'
    math_004.use_clamp = True
    
    #node Wave Texture
    wave_texture = bark.nodes.new("ShaderNodeTexWave")
    wave_texture.name = "Wave Texture"
    wave_texture.bands_direction = 'X'
    wave_texture.rings_direction = 'X'
    wave_texture.wave_profile = 'SIN'
    wave_texture.wave_type = 'BANDS'
    #Scale
    wave_texture.inputs[1].default_value = 2.0
    #Distortion
    wave_texture.inputs[2].default_value = 7.419999122619629
    #Detail
    wave_texture.inputs[3].default_value = 4.0
    #Detail Scale
    wave_texture.inputs[4].default_value = 1.6800000667572021
    #Detail Roughness
    wave_texture.inputs[5].default_value = 0.5
    #Phase Offset
    wave_texture.inputs[6].default_value = 0.0
    
    #node Noise Texture.002
    noise_texture_002 = bark.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    #Scale
    noise_texture_002.inputs[2].default_value = 5.0
    #Detail
    noise_texture_002.inputs[3].default_value = 5.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.5
    #Distortion
    noise_texture_002.inputs[5].default_value = 0.0
    
    #node Reroute.001
    reroute_001 = bark.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Reroute.004
    reroute_004 = bark.nodes.new("NodeReroute")
    reroute_004.name = "Reroute.004"
    #node Reroute.002
    reroute_002_1 = bark.nodes.new("NodeReroute")
    reroute_002_1.name = "Reroute.002"
    #node Reroute.003
    reroute_003 = bark.nodes.new("NodeReroute")
    reroute_003.name = "Reroute.003"
    #node Reroute
    reroute = bark.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Group.001
    group_001 = bark.nodes.new("ShaderNodeGroup")
    group_001.name = "Group.001"
    group_001.node_tree = voronoi_crackle
    
    #node Math.012
    math_012 = bark.nodes.new("ShaderNodeMath")
    math_012.name = "Math.012"
    math_012.operation = 'ADD'
    math_012.use_clamp = False
    
    #node Math.013
    math_013 = bark.nodes.new("ShaderNodeMath")
    math_013.name = "Math.013"
    math_013.operation = 'MULTIPLY'
    math_013.use_clamp = False
    
    #node Mix.002
    mix_002 = bark.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'DARKEN'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.5
    
    #node Noise Texture
    noise_texture = bark.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 8.0
    #Detail
    noise_texture.inputs[3].default_value = 6.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0
    
    #node Vector Math.001
    vector_math_001 = bark.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'MULTIPLY'
    #Vector_001
    vector_math_001.inputs[1].default_value = (6.0, 1.0, 1.0)
    
    #node Mix
    mix = bark.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'LINEAR_LIGHT'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.20000000298023224
    
    #node Reroute.005
    reroute_005 = bark.nodes.new("NodeReroute")
    reroute_005.name = "Reroute.005"
    #node Bump
    bump = bark.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Strength
    bump.inputs[0].default_value = 0.6000000238418579
    #Distance
    bump.inputs[1].default_value = 0.10000000149011612
    #Normal
    bump.inputs[3].default_value = (0.0, 0.0, 0.0)
    
    #node Map Range.007
    map_range_007 = bark.nodes.new("ShaderNodeMapRange")
    map_range_007.name = "Map Range.007"
    map_range_007.clamp = True
    map_range_007.data_type = 'FLOAT'
    map_range_007.interpolation_type = 'LINEAR'
    #From Min
    map_range_007.inputs[1].default_value = 0.25
    #From Max
    map_range_007.inputs[2].default_value = 1.0
    #To Min
    map_range_007.inputs[3].default_value = 1.0
    #To Max
    map_range_007.inputs[4].default_value = 0.6000000238418579
    
    #node Reroute.006
    reroute_006 = bark.nodes.new("NodeReroute")
    reroute_006.name = "Reroute.006"
    #node Math.011
    math_011 = bark.nodes.new("ShaderNodeMath")
    math_011.name = "Math.011"
    math_011.operation = 'MAXIMUM'
    math_011.use_clamp = False
    
    #node Mix.004
    mix_004 = bark.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MULTIPLY'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 0.5
    
    #node ColorRamp
    colorramp = bark.nodes.new("ShaderNodeValToRGB")
    colorramp.name = "ColorRamp"
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'EASE'
    
    #initialize color ramp elements
    colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
    colorramp_cre_0 = colorramp.color_ramp.elements[0]
    colorramp_cre_0.position = 0.0
    colorramp_cre_0.alpha = 1.0
    colorramp_cre_0.color = (0.17279909551143646, 0.060811273753643036, 0.013731011189520359, 1.0)

    colorramp_cre_1 = colorramp.color_ramp.elements.new(0.05818181112408638)
    colorramp_cre_1.alpha = 1.0
    colorramp_cre_1.color = (0.029556844383478165, 0.009134061634540558, 0.008023194968700409, 1.0)

    colorramp_cre_2 = colorramp.color_ramp.elements.new(0.3472727835178375)
    colorramp_cre_2.alpha = 1.0
    colorramp_cre_2.color = (0.19720348715782166, 0.0705798864364624, 0.01386511605232954, 1.0)

    colorramp_cre_3 = colorramp.color_ramp.elements.new(0.5063637495040894)
    colorramp_cre_3.alpha = 1.0
    colorramp_cre_3.color = (0.15172812342643738, 0.05214367434382439, 0.013742955401539803, 1.0)

    colorramp_cre_4 = colorramp.color_ramp.elements.new(0.6981821060180664)
    colorramp_cre_4.alpha = 1.0
    colorramp_cre_4.color = (0.30362755060195923, 0.09793724864721298, 0.02112484723329544, 1.0)

    colorramp_cre_5 = colorramp.color_ramp.elements.new(1.0)
    colorramp_cre_5.alpha = 1.0
    colorramp_cre_5.color = (0.4641856253147125, 0.1480797529220581, 0.03233911469578743, 1.0)

    
    #node Hue Saturation Value
    hue_saturation_value = bark.nodes.new("ShaderNodeHueSaturation")
    hue_saturation_value.name = "Hue Saturation Value"
    #Hue
    hue_saturation_value.inputs[0].default_value = 0.4950000047683716
    #Saturation
    hue_saturation_value.inputs[1].default_value = 0.699999988079071
    #Value
    hue_saturation_value.inputs[2].default_value = 1.0
    #Fac
    hue_saturation_value.inputs[3].default_value = 1.0
    
    #node Map Range.004
    map_range_004 = bark.nodes.new("ShaderNodeMapRange")
    map_range_004.name = "Map Range.004"
    map_range_004.clamp = True
    map_range_004.data_type = 'FLOAT'
    map_range_004.interpolation_type = 'SMOOTHSTEP'
    #From Min
    map_range_004.inputs[1].default_value = 0.0
    #From Max
    map_range_004.inputs[2].default_value = 1.0
    #To Min
    map_range_004.inputs[3].default_value = 0.5
    #To Max
    map_range_004.inputs[4].default_value = 1.0
    
    #node Math.006
    math_006 = bark.nodes.new("ShaderNodeMath")
    math_006.name = "Math.006"
    math_006.operation = 'ADD'
    math_006.use_clamp = False
    #Value_001
    math_006.inputs[1].default_value = 0.07999999821186066
    
    #node White Noise Texture.001
    white_noise_texture_001 = bark.nodes.new("ShaderNodeTexWhiteNoise")
    white_noise_texture_001.name = "White Noise Texture.001"
    white_noise_texture_001.noise_dimensions = '2D'
    
    #node Separate XYZ.001
    separate_xyz_001 = bark.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz_001.name = "Separate XYZ.001"
    
    #node Math.007
    math_007 = bark.nodes.new("ShaderNodeMath")
    math_007.name = "Math.007"
    math_007.operation = 'MULTIPLY'
    math_007.use_clamp = False
    
    #node Map Range.003
    map_range_003 = bark.nodes.new("ShaderNodeMapRange")
    map_range_003.name = "Map Range.003"
    map_range_003.clamp = True
    map_range_003.data_type = 'FLOAT'
    map_range_003.interpolation_type = 'LINEAR'
    #From Min
    map_range_003.inputs[1].default_value = 0.0
    #From Max
    map_range_003.inputs[2].default_value = 0.11000001430511475
    #To Min
    map_range_003.inputs[3].default_value = 0.0
    #To Max
    map_range_003.inputs[4].default_value = 1.0
    
    #node Map Range.005
    map_range_005 = bark.nodes.new("ShaderNodeMapRange")
    map_range_005.name = "Map Range.005"
    map_range_005.clamp = True
    map_range_005.data_type = 'FLOAT'
    map_range_005.interpolation_type = 'SMOOTHSTEP'
    #From Min
    map_range_005.inputs[1].default_value = 0.0
    #From Max
    map_range_005.inputs[2].default_value = 0.10000000149011612
    #To Min
    map_range_005.inputs[3].default_value = 0.0
    #To Max
    map_range_005.inputs[4].default_value = 1.0
    
    #node Math.008
    math_008 = bark.nodes.new("ShaderNodeMath")
    math_008.name = "Math.008"
    math_008.operation = 'MULTIPLY'
    math_008.use_clamp = True
    
    #node Math.009
    math_009 = bark.nodes.new("ShaderNodeMath")
    math_009.name = "Math.009"
    math_009.operation = 'MULTIPLY'
    math_009.use_clamp = True
    
    #node Group
    group = bark.nodes.new("ShaderNodeGroup")
    group.name = "Group"
    group.node_tree = voronoi_crackle
    
    #node Vector Math.004
    vector_math_004 = bark.nodes.new("ShaderNodeVectorMath")
    vector_math_004.name = "Vector Math.004"
    vector_math_004.operation = 'SCALE'
    #Scale
    vector_math_004.inputs[3].default_value = 1.399999976158142
    
    #node Vector Math.003
    vector_math_003 = bark.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'MULTIPLY'
    #Vector_001
    vector_math_003.inputs[1].default_value = (1.0, 3.0, 1.0)
    
    #node Attribute
    attribute = bark.nodes.new("ShaderNodeAttribute")
    attribute.name = "Attribute"
    attribute.attribute_name = "UV"
    attribute.attribute_type = 'GEOMETRY'
    
    #node Vector Math.002
    vector_math_002 = bark.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'SCALE'
    #Scale
    vector_math_002.inputs[3].default_value = 0.20000000298023224
    
    #Set parents
    vector_math_002.parent = frame
    
    #Set locations
    frame.location = (6089.64208984375, 246.0953826904297)
    material_output.location = (12117.107421875, 915.1417846679688)
    material_output_001.location = (12118.3828125, 779.8644409179688)
    displacement.location = (11788.1171875, 607.2277221679688)
    principled_bsdf.location = (11449.953125, 954.74609375)
    map_range_002.location = (8230.845703125, -40.7587890625)
    white_noise_texture.location = (8232.845703125, -276.5487365722656)
    map_range_006.location = (9791.44140625, 443.451171875)
    math_014.location = (9791.44140625, 763.451171875)
    math_003.location = (8231.4404296875, 123.4512710571289)
    math_002.location = (8391.4404296875, 123.4512710571289)
    separate_xyz.location = (8071.4404296875, 123.4512710571289)
    map_range.location = (8231.4404296875, 383.45135498046875)
    map_range_001.location = (8551.4404296875, 63.451271057128906)
    math_001.location = (8731.4404296875, 183.4513702392578)
    math_004.location = (8891.4404296875, 183.4513702392578)
    wave_texture.location = (9266.5751953125, -56.548728942871094)
    noise_texture_002.location = (9271.4404296875, 163.45126342773438)
    reroute_001.location = (9039.0595703125, -108.94316101074219)
    reroute_004.location = (10331.3359375, 559.2113037109375)
    reroute_002_1.location = (7845.93994140625, -471.0455017089844)
    reroute_003.location = (8371.1708984375, -471.0455017089844)
    reroute.location = (7437.59765625, -114.86396789550781)
    group_001.location = (7651.4404296875, 43.451271057128906)
    math_012.location = (9791.44140625, 603.451171875)
    math_013.location = (10105.1611328125, 598.3756103515625)
    mix_002.location = (10499.0126953125, 763.451171875)
    noise_texture.location = (6391.4404296875, 203.45126342773438)
    vector_math_001.location = (6391.4404296875, 403.45135498046875)
    mix.location = (6571.4404296875, 403.45135498046875)
    reroute_005.location = (6897.203125, 378.26251220703125)
    bump.location = (10978.236328125, 223.45126342773438)
    map_range_007.location = (10978.236328125, 503.451171875)
    reroute_006.location = (10460.8359375, 530.3558349609375)
    math_011.location = (9551.4423828125, 543.451171875)
    mix_004.location = (10698.236328125, 897.3375244140625)
    colorramp.location = (10898.236328125, 1097.15625)
    hue_saturation_value.location = (11161.4033203125, 1094.7503662109375)
    map_range_004.location = (8219.349609375, 820.8107299804688)
    math_006.location = (8225.3505859375, 981.1453247070312)
    white_noise_texture_001.location = (8221.3505859375, 585.0206298828125)
    separate_xyz_001.location = (8069.23583984375, 977.4527587890625)
    math_007.location = (8389.236328125, 977.4527587890625)
    map_range_003.location = (8229.236328125, 1237.4527587890625)
    map_range_005.location = (8569.236328125, 857.4527587890625)
    math_008.location = (8749.236328125, 957.4527587890625)
    math_009.location = (8909.236328125, 957.4527587890625)
    group.location = (7669.23583984375, 937.4527587890625)
    vector_math_004.location = (7469.4921875, 807.0469970703125)
    vector_math_003.location = (5716.67138671875, 274.66278076171875)
    attribute.location = (5560.0, 279.9999694824219)
    vector_math_002.location = (-64.8193359375, 17.355880737304688)
    
    #Set dimensions
    frame.width, frame.height = 200.0, 188.8000030517578
    material_output.width, material_output.height = 140.0, 100.0
    material_output_001.width, material_output_001.height = 140.0, 100.0
    displacement.width, displacement.height = 140.0, 100.0
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    map_range_002.width, map_range_002.height = 140.0, 100.0
    white_noise_texture.width, white_noise_texture.height = 140.0, 100.0
    map_range_006.width, map_range_006.height = 140.0, 100.0
    math_014.width, math_014.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    separate_xyz.width, separate_xyz.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    map_range_001.width, map_range_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    wave_texture.width, wave_texture.height = 150.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    reroute_004.width, reroute_004.height = 16.0, 100.0
    reroute_002_1.width, reroute_002_1.height = 16.0, 100.0
    reroute_003.width, reroute_003.height = 16.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    group_001.width, group_001.height = 140.0, 100.0
    math_012.width, math_012.height = 140.0, 100.0
    math_013.width, math_013.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    vector_math_001.width, vector_math_001.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    reroute_005.width, reroute_005.height = 16.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    map_range_007.width, map_range_007.height = 140.0, 100.0
    reroute_006.width, reroute_006.height = 16.0, 100.0
    math_011.width, math_011.height = 140.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    colorramp.width, colorramp.height = 240.0, 100.0
    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
    map_range_004.width, map_range_004.height = 140.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    white_noise_texture_001.width, white_noise_texture_001.height = 140.0, 100.0
    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
    math_007.width, math_007.height = 140.0, 100.0
    map_range_003.width, map_range_003.height = 140.0, 100.0
    map_range_005.width, map_range_005.height = 140.0, 100.0
    math_008.width, math_008.height = 140.0, 100.0
    math_009.width, math_009.height = 140.0, 100.0
    group.width, group.height = 140.0, 100.0
    vector_math_004.width, vector_math_004.height = 140.0, 100.0
    vector_math_003.width, vector_math_003.height = 140.0, 100.0
    attribute.width, attribute.height = 140.0, 100.0
    vector_math_002.width, vector_math_002.height = 140.0, 100.0
    
    #initialize bark links
    #separate_xyz.Y -> math_003.Value
    bark.links.new(separate_xyz.outputs[1], math_003.inputs[0])
    #map_range_001.Result -> math_001.Value
    bark.links.new(map_range_001.outputs[0], math_001.inputs[1])
    #map_range.Result -> math_001.Value
    bark.links.new(map_range.outputs[0], math_001.inputs[0])
    #math_001.Value -> math_004.Value
    bark.links.new(math_001.outputs[0], math_004.inputs[0])
    #vector_math_001.Vector -> mix.A
    bark.links.new(vector_math_001.outputs[0], mix.inputs[6])
    #noise_texture.Color -> mix.B
    bark.links.new(noise_texture.outputs[1], mix.inputs[7])
    #math_002.Value -> map_range_001.Value
    bark.links.new(math_002.outputs[0], map_range_001.inputs[0])
    #math_003.Value -> math_002.Value
    bark.links.new(math_003.outputs[0], math_002.inputs[0])
    #vector_math_002.Vector -> vector_math_001.Vector
    bark.links.new(vector_math_002.outputs[0], vector_math_001.inputs[0])
    #map_range_002.Result -> math_002.Value
    bark.links.new(map_range_002.outputs[0], math_002.inputs[1])
    #vector_math_002.Vector -> noise_texture.Vector
    bark.links.new(vector_math_002.outputs[0], noise_texture.inputs[0])
    #group_001.Position -> white_noise_texture.Vector
    bark.links.new(group_001.outputs[2], white_noise_texture.inputs[0])
    #white_noise_texture.Value -> math_004.Value
    bark.links.new(white_noise_texture.outputs[0], math_004.inputs[1])
    #group.Fac -> map_range_003.Value
    bark.links.new(group.outputs[0], map_range_003.inputs[0])
    #group.Vector -> separate_xyz_001.Vector
    bark.links.new(group.outputs[3], separate_xyz_001.inputs[0])
    #separate_xyz_001.Y -> math_006.Value
    bark.links.new(separate_xyz_001.outputs[1], math_006.inputs[0])
    #map_range_005.Result -> math_008.Value
    bark.links.new(map_range_005.outputs[0], math_008.inputs[1])
    #map_range_003.Result -> math_008.Value
    bark.links.new(map_range_003.outputs[0], math_008.inputs[0])
    #math_008.Value -> math_009.Value
    bark.links.new(math_008.outputs[0], math_009.inputs[0])
    #math_007.Value -> map_range_005.Value
    bark.links.new(math_007.outputs[0], map_range_005.inputs[0])
    #math_006.Value -> math_007.Value
    bark.links.new(math_006.outputs[0], math_007.inputs[0])
    #group.Color -> map_range_004.Value
    bark.links.new(group.outputs[1], map_range_004.inputs[0])
    #map_range_004.Result -> math_007.Value
    bark.links.new(map_range_004.outputs[0], math_007.inputs[1])
    #group.Position -> white_noise_texture_001.Vector
    bark.links.new(group.outputs[2], white_noise_texture_001.inputs[0])
    #white_noise_texture_001.Value -> math_009.Value
    bark.links.new(white_noise_texture_001.outputs[0], math_009.inputs[1])
    #math_009.Value -> math_011.Value
    bark.links.new(math_009.outputs[0], math_011.inputs[0])
    #math_004.Value -> math_011.Value
    bark.links.new(math_004.outputs[0], math_011.inputs[1])
    #reroute_006.Output -> bump.Height
    bark.links.new(reroute_006.outputs[0], bump.inputs[2])
    #reroute_006.Output -> map_range_007.Value
    bark.links.new(reroute_006.outputs[0], map_range_007.inputs[0])
    #math_011.Value -> math_012.Value
    bark.links.new(math_011.outputs[0], math_012.inputs[0])
    #noise_texture_002.Fac -> math_012.Value
    bark.links.new(noise_texture_002.outputs[0], math_012.inputs[1])
    #wave_texture.Color -> map_range_006.Value
    bark.links.new(wave_texture.outputs[0], map_range_006.inputs[0])
    #reroute_001.Output -> wave_texture.Vector
    bark.links.new(reroute_001.outputs[0], wave_texture.inputs[0])
    #math_012.Value -> math_013.Value
    bark.links.new(math_012.outputs[0], math_013.inputs[0])
    #map_range_006.Result -> math_013.Value
    bark.links.new(map_range_006.outputs[0], math_013.inputs[1])
    #reroute_004.Output -> mix_002.A
    bark.links.new(reroute_004.outputs[0], mix_002.inputs[6])
    #mix_002.Result -> mix_004.A
    bark.links.new(mix_002.outputs[2], mix_004.inputs[6])
    #map_range.Result -> math_014.Value
    bark.links.new(map_range.outputs[0], math_014.inputs[1])
    #map_range_003.Result -> math_014.Value
    bark.links.new(map_range_003.outputs[0], math_014.inputs[0])
    #math_014.Value -> mix_002.B
    bark.links.new(math_014.outputs[0], mix_002.inputs[7])
    #map_range_007.Result -> principled_bsdf.Roughness
    bark.links.new(map_range_007.outputs[0], principled_bsdf.inputs[9])
    #mix_004.Result -> colorramp.Fac
    bark.links.new(mix_004.outputs[2], colorramp.inputs[0])
    #noise_texture_002.Fac -> mix_004.B
    bark.links.new(noise_texture_002.outputs[0], mix_004.inputs[7])
    #colorramp.Color -> hue_saturation_value.Color
    bark.links.new(colorramp.outputs[0], hue_saturation_value.inputs[4])
    #hue_saturation_value.Color -> principled_bsdf.Base Color
    bark.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
    #reroute_006.Output -> displacement.Height
    bark.links.new(reroute_006.outputs[0], displacement.inputs[0])
    #reroute_005.Output -> vector_math_004.Vector
    bark.links.new(reroute_005.outputs[0], vector_math_004.inputs[0])
    #vector_math_004.Vector -> group.Vector
    bark.links.new(vector_math_004.outputs[0], group.inputs[0])
    #group_001.Fac -> map_range.Value
    bark.links.new(group_001.outputs[0], map_range.inputs[0])
    #group_001.Color -> map_range_002.Value
    bark.links.new(group_001.outputs[1], map_range_002.inputs[0])
    #group_001.Vector -> separate_xyz.Vector
    bark.links.new(group_001.outputs[3], separate_xyz.inputs[0])
    #reroute.Output -> group_001.Vector
    bark.links.new(reroute.outputs[0], group_001.inputs[0])
    #bump.Normal -> principled_bsdf.Normal
    bark.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #reroute_005.Output -> reroute.Input
    bark.links.new(reroute_005.outputs[0], reroute.inputs[0])
    #reroute_003.Output -> reroute_001.Input
    bark.links.new(reroute_003.outputs[0], reroute_001.inputs[0])
    #reroute.Output -> reroute_002_1.Input
    bark.links.new(reroute.outputs[0], reroute_002_1.inputs[0])
    #reroute_001.Output -> noise_texture_002.Vector
    bark.links.new(reroute_001.outputs[0], noise_texture_002.inputs[0])
    #reroute_002_1.Output -> reroute_003.Input
    bark.links.new(reroute_002_1.outputs[0], reroute_003.inputs[0])
    #math_013.Value -> reroute_004.Input
    bark.links.new(math_013.outputs[0], reroute_004.inputs[0])
    #reroute_004.Output -> reroute_006.Input
    bark.links.new(reroute_004.outputs[0], reroute_006.inputs[0])
    #mix.Result -> reroute_005.Input
    bark.links.new(mix.outputs[2], reroute_005.inputs[0])
    #attribute.Vector -> vector_math_003.Vector
    bark.links.new(attribute.outputs[1], vector_math_003.inputs[0])
    #vector_math_003.Vector -> vector_math_002.Vector
    bark.links.new(vector_math_003.outputs[0], vector_math_002.inputs[0])
    #displacement.Displacement -> material_output.Displacement
    bark.links.new(displacement.outputs[0], material_output.inputs[2])
    #principled_bsdf.BSDF -> material_output_001.Surface
    bark.links.new(principled_bsdf.outputs[0], material_output_001.inputs[0])
    #principled_bsdf.BSDF -> material_output.Surface
    bark.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
    return bark

bark = bark_node_group()




@node_utils.to_nodegroup('nodegroup_voronoi_crackle', singleton=False, type='ShaderNodeTree')
def nodegroup_voronoi_crackle(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000))])
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Vector"]})
    
    voronoi_texture_2 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': reroute_2}, attrs={'feature': 'F2'})
    
    voronoi_texture_3 = nw.new_node(Nodes.VoronoiTexture, input_kwargs={'Vector': reroute_2})
    
    subtract = nw.new_node(Nodes.Math,
        input_kwargs={0: voronoi_texture_2.outputs["Distance"], 1: voronoi_texture_3.outputs["Distance"]},
        attrs={'operation': 'SUBTRACT'})
    
    subtract_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: voronoi_texture_3.outputs["Position"], 1: reroute_2},
        attrs={'operation': 'SUBTRACT'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Fac': subtract, 'Color': voronoi_texture_3.outputs["Color"], 'Position': voronoi_texture_3.outputs["Position"], 'Vector': subtract_1.outputs["Vector"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_leaf', singleton=False, type='GeometryNodeTree')
def nodegroup_leaf(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    grid = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 0.4000, 'Vertices X': 2, 'Vertices Y': 5})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid.outputs["Mesh"], 'Name': 'uv_map', 3: grid.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    position_8 = nw.new_node(Nodes.InputPosition)
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position_8})
    
    absolute = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"]}, attrs={'operation': 'ABSOLUTE'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': absolute, 3: 1.0000, 4: -0.8900},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: separate_xyz.outputs["X"], 1: map_range.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': multiply, 'Y': separate_xyz.outputs["Y"], 'Z': separate_xyz.outputs["Z"]})
    
    set_position_7 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': store_named_attribute, 'Position': combine_xyz_2})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_position_7, 'Material': surface.shaderfunc_to_material(shader_leaf)})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': 0.5000})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: combine_xyz_1})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_material, 'Position': add.outputs["Vector"]})
    
    subtract = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: combine_xyz_1}, attrs={'operation': 'SUBTRACT'})
    
    capture_attribute_3 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_position_1, 1: subtract.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': capture_attribute_3.outputs["Geometry"], 'Attribute': capture_attribute_3.outputs["Attribute"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_branch_gen', singleton=False, type='GeometryNodeTree')
def nodegroup_branch_gen(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_3 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketBool', 'Angle_Based', True),
            ('NodeSocketFloat', 'Split_angle', 19.6200),
            ('NodeSocketInt', 'Resolution', 8),
            ('NodeSocketFloat', 'Branch_Length', 1.5000),
            ('NodeSocketInt', 'Branch_Count', 12),
            ('NodeSocketInt', 'Seed', 389)])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input_3.outputs["Branch_Length"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_3.outputs["Branch_Count"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line, 'Count': reroute_11})
    
    spline_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': spline_parameter_3.outputs["Factor"], 1: 0.1500, 2: 0.2000, 4: 0.3000})
    
    position = nw.new_node(Nodes.InputPosition)
    
    integer = nw.new_node(Nodes.Integer)
    integer.integer = 0
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={1: (10.0000, 10.0000, 10.0000), 'ID': integer, 'Seed': group_input_3.outputs["Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: random_value.outputs["Value"]})
    
    noise_displace = nw.new_node(nodegroup_noise_displace().name,
        input_kwargs={'Geometry': resample_curve, 'Fac': map_range_3.outputs["Result"], 'Vector': add.outputs["Vector"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': spline_parameter_3.outputs["Factor"]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_12, 3: 0.5000, 4: 0.1000})
    
    set_curve_radius_2 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': noise_displace, 'Radius': map_range_1.outputs["Result"]})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_curve_radius_2, 2: map_range_1.outputs["Result"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute.outputs["Geometry"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (0.1000, 0.0000, 0.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': reroute_8, 'Profile Curve': curve_line_1})
    
    boolean = nw.new_node(Nodes.Boolean, attrs={'boolean': True})
    
    edge_angle = nw.new_node(Nodes.InputEdgeAngle)
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: group_input_3.outputs["Split_angle"]}, attrs={'operation': 'RADIANS'})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: edge_angle.outputs["Unsigned Angle"], 1: radians})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_3.outputs["Angle_Based"], 6: boolean, 7: greater_than},
        attrs={'input_type': 'BOOLEAN'})
    
    split_edges = nw.new_node(Nodes.SplitEdges, input_kwargs={'Mesh': curve_to_mesh, 'Selection': switch.outputs[2]})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': reroute_8})
    
    geometry_proximity = nw.new_node(Nodes.Proximity, input_kwargs={'Target': curve_to_mesh_1}, attrs={'target_element': 'EDGES'})
    
    not_equal = nw.new_node(Nodes.Compare,
        input_kwargs={0: geometry_proximity.outputs["Distance"]},
        attrs={'operation': 'NOT_EQUAL'})
    
    delete_geometry = nw.new_node(Nodes.DeleteGeometry,
        input_kwargs={'Geometry': split_edges, 'Selection': not_equal},
        attrs={'domain': 'EDGE'})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': delete_geometry})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine)
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector, input_kwargs={'Vector': curve_tangent}, attrs={'axis': 'Z'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_to_curve, 'Selection': endpoint_selection, 'Instance': curve_line_2, 'Rotation': align_euler_to_vector})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points})
    
    spline_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_2.outputs["Factor"], 3: 1.0000, 4: 0.0000})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute.outputs[2]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_2.outputs["Result"], 1: reroute_6},
        attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': realize_instances, 'Radius': multiply})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_curve_radius_1})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 4: 0.3000})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    noise_displace_1 = nw.new_node(nodegroup_noise_displace().name,
        input_kwargs={'Geometry': resample_curve_1, 'Fac': map_range.outputs["Result"], 'Vector': position_1})
    
    endpoint_selection_1 = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': noise_displace_1, 4: endpoint_selection_1},
        attrs={'data_type': 'BOOLEAN'})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': capture_attribute_1.outputs["Geometry"], 'Count': 126},
        attrs={'mode': 'EVALUATED'})
    
    set_point_radius = nw.new_node(Nodes.SetPointRadius, input_kwargs={'Points': curve_to_points.outputs["Points"]})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry,
        input_kwargs={'Geometry': set_point_radius, 'Selection': capture_attribute_1.outputs[4]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_curve_radius_2})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_3, noise_displace_1]})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': group_input_3.outputs["Resolution"], 'Radius': 0.0500})
    
    mesh_to_curve_uvs = nw.new_node(nodegroup_mesh_to_curve_u_vs().name,
        input_kwargs={'Geometry': join_geometry, 'Profile_Curve': curve_circle_1.outputs["Curve"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [separate_geometry.outputs["Selection"], mesh_to_curve_uvs.outputs["Mesh"]]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mesh_to_curve_uvs.outputs["UVs"]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Branch': join_geometry_1, 'UVs': reroute_2},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_noise_displace', singleton=False, type='GeometryNodeTree')
def nodegroup_noise_displace(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloatFactor', 'Fac', 0.3233),
            ('NodeSocketVector', 'Vector', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Scale', 2.1000),
            ('NodeSocketFloat', 'Detail', 2.0000),
            ('NodeSocketFloatFactor', 'Roughness', 0.5000),
            ('NodeSocketFloat', 'Distortion', 0.0000)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Geometry"]})
    
    position = nw.new_node(Nodes.InputPosition)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': group_input.outputs["Vector"], 'Scale': group_input.outputs["Scale"], 'Detail': group_input.outputs["Detail"], 'Roughness': group_input.outputs["Roughness"], 'Distortion': group_input.outputs["Distortion"]})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input.outputs["Fac"], 6: position, 7: noise_texture.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LINEAR_LIGHT'})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute, 'Position': mix.outputs[2]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_mesh_to_curve_u_vs', singleton=False, type='GeometryNodeTree')
def nodegroup_mesh_to_curve_u_vs(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketGeometry', 'Profile_Curve', None)])
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': spline_parameter_1.outputs["Length"]})
    
    capture_attribute_4 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': group_input.outputs["Geometry"], 2: reroute})
    
    capture_attribute_3 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': group_input.outputs["Profile_Curve"], 2: reroute})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': capture_attribute_4.outputs["Geometry"], 'Profile Curve': capture_attribute_3.outputs["Geometry"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': capture_attribute_3.outputs[2], 'Y': capture_attribute_4.outputs[2]})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Mesh': curve_to_mesh, 'UVs': combine_xyz_1},
        attrs={'is_active_output': True})

def shader_leaf(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UV'})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': attribute.outputs["Vector"]})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': separate_xyz_1.outputs["Y"], 1: -0.5000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': map_range.outputs["Result"]})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.5000, 0.5000, 0.5000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.5000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'Color'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: attribute_1.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'MULTIPLY'})
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Hue': 0.4900, 'Color': mix.outputs[2]})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': hue_saturation_value})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Specular Tint': 0.5000, 'Roughness': 0.8000})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={1: translucent_bsdf, 2: principled_bsdf})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader_1}, attrs={'is_active_output': True})

def shader_bark(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'UV'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: attribute.outputs["Vector"], 1: (1.0000, 3.0000, 1.0000), 'Scale': 0.5900},
        attrs={'operation': 'MULTIPLY'})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: (6.0000, 1.0000, 1.0000), 'Scale': 0.2000},
        attrs={'operation': 'SCALE'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: scale.outputs["Vector"], 1: (6.0000, 1.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': scale.outputs["Vector"], 'Scale': 8.0000, 'Detail': 6.0000})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.2000, 6: multiply_1.outputs["Vector"], 7: noise_texture.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'LINEAR_LIGHT'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix.outputs[2]})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: reroute_5, 1: (6.0000, 1.0000, 1.0000), 'Scale': 1.4000},
        attrs={'operation': 'SCALE'})
    
    group = nw.new_node(nodegroup_voronoi_crackle().name, input_kwargs={'Vector': scale_1.outputs["Vector"]})
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group.outputs["Fac"], 2: 0.1100})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group.outputs["Vector"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz_1.outputs["Y"], 1: 0.0800})
    
    map_range_4 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group.outputs["Color"], 3: 0.5000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: map_range_4.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    map_range_5 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply_2, 2: 0.1000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_3.outputs["Result"], 1: map_range_5.outputs["Result"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    white_noise_texture_1 = nw.new_node(Nodes.WhiteNoiseTexture,
        input_kwargs={'Vector': group.outputs["Position"]},
        attrs={'noise_dimensions': '2D'})
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_3, 1: white_noise_texture_1.outputs["Value"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    group_1 = nw.new_node(nodegroup_voronoi_crackle().name, input_kwargs={'Vector': reroute})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_1.outputs["Fac"], 2: 0.1100})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_1.outputs["Vector"]})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: separate_xyz.outputs["Y"], 1: 0.0800})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_1.outputs["Color"], 3: 0.5000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: add_1, 1: map_range_2.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply_5, 2: 0.1000},
        attrs={'interpolation_type': 'SMOOTHSTEP'})
    
    multiply_6 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range.outputs["Result"], 1: map_range_1.outputs["Result"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    white_noise_texture = nw.new_node(Nodes.WhiteNoiseTexture,
        input_kwargs={'Vector': group_1.outputs["Position"]},
        attrs={'noise_dimensions': '2D'})
    
    multiply_7 = nw.new_node(Nodes.Math,
        input_kwargs={0: multiply_6, 1: white_noise_texture.outputs["Value"]},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    maximum = nw.new_node(Nodes.Math, input_kwargs={0: multiply_4, 1: multiply_7}, attrs={'operation': 'MAXIMUM'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': reroute_1, 'Detail': 5.0000})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: maximum, 1: noise_texture_2.outputs["Fac"]})
    
    wave_texture = nw.new_node(Nodes.WaveTexture,
        input_kwargs={'Vector': reroute_1, 'Scale': 2.0000, 'Distortion': 7.4200, 'Detail': 4.0000, 'Detail Scale': 1.6800})
    
    map_range_6 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': wave_texture.outputs["Color"], 2: 0.5000, 3: 0.9000},
        attrs={'interpolation_type': 'SMOOTHERSTEP'})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: add_2, 1: map_range_6.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_8})
    
    minimum = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_3.outputs["Result"], 1: map_range.outputs["Result"]},
        attrs={'operation': 'MINIMUM'})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={6: reroute_4, 7: minimum}, attrs={'data_type': 'RGBA', 'blend_type': 'DARKEN'})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={6: mix_2.outputs[2], 7: noise_texture_2.outputs["Fac"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'MULTIPLY'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': mix_4.outputs[2]})
    colorramp.color_ramp.interpolation = "EASE"
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements.new(0)
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.1728, 0.0608, 0.0137, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.0582
    colorramp.color_ramp.elements[1].color = [0.0296, 0.0091, 0.0080, 1.0000]
    colorramp.color_ramp.elements[2].position = 0.3473
    colorramp.color_ramp.elements[2].color = [0.1972, 0.0706, 0.0139, 1.0000]
    colorramp.color_ramp.elements[3].position = 0.5064
    colorramp.color_ramp.elements[3].color = [0.1517, 0.0521, 0.0137, 1.0000]
    colorramp.color_ramp.elements[4].position = 0.6982
    colorramp.color_ramp.elements[4].color = [0.3036, 0.0979, 0.0211, 1.0000]
    colorramp.color_ramp.elements[5].position = 1.0000
    colorramp.color_ramp.elements[5].color = [0.4642, 0.1481, 0.0323, 1.0000]
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Hue': 0.4950, 'Saturation': 0.7000, 'Color': colorramp.outputs["Color"]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    map_range_7 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_6, 1: 0.2500, 3: 1.0000, 4: 0.6000})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Strength': 0.6000, 'Distance': 0.1000, 'Height': reroute_6})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': hue_saturation_value, 'Specular Tint': 0.5000, 'Roughness': map_range_7.outputs["Result"], 'Normal': bump})
    
    displacement = nw.new_node(Nodes.Displacement, input_kwargs={'Height': reroute_6, 'Scale': 0.0100})
    
    material_output = nw.new_node(Nodes.MaterialOutput,
        input_kwargs={'Surface': principled_bsdf, 'Displacement': displacement},
        attrs={'is_active_output': True})

def shader_leaves(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 4.0000, 'Detail': 4.0000, 'Roughness': 0.3000, 'Distortion': 1.0000})
    
    greater_than = nw.new_node(Nodes.Math,
        input_kwargs={0: noise_texture.outputs["Fac"], 1: 0.4500},
        attrs={'operation': 'GREATER_THAN'})
    
    transparent_bsdf = nw.new_node(Nodes.TransparentBSDF)
    
    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'Color'})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: noise_texture.outputs["Fac"], 7: attribute.outputs["Color"]},
        attrs={'data_type': 'RGBA', 'blend_type': 'MULTIPLY'})
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue, input_kwargs={'Value': 3.0000, 'Color': mix.outputs[2]})
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': 0.5000, 'Distance': 0.2000, 'Height': noise_texture.outputs["Fac"]})
    
    translucent_bsdf = nw.new_node(Nodes.TranslucentBSDF, input_kwargs={'Color': hue_saturation_value, 'Normal': bump})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Subsurface Color': (0.8000, 0.8000, 0.8000, 1.0000), 'Specular Tint': 0.5000, 'Roughness': 0.4473, 'Sheen': 1.0000, 'Normal': bump},
        attrs={'subsurface_method': 'BURLEY'})
    
    mix_shader_1 = nw.new_node(Nodes.MixShader, input_kwargs={1: translucent_bsdf, 2: principled_bsdf})
    
    mix_shader = nw.new_node(Nodes.MixShader, input_kwargs={'Fac': greater_than, 1: transparent_bsdf, 2: mix_shader_1})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': mix_shader}, attrs={'is_active_output': True})

def geometry_fantasy_tree_gen(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_1 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Base Count', 15),
            ('NodeSocketInt', 'Tree Seed', 230),
            ('NodeSocketInt', 'Trunk Resolution', 64),
            ('NodeSocketInt', 'Resolution', 32),
            ('NodeSocketFloatFactor', 'Tree Distortion', 0.3917),
            ('NodeSocketFloatFactor', 'Distortion Roughness', 0.5000),
            ('NodeSocketVector', 'Trunk Noise', (0.0000, -0.5600, 8.9300)),
            ('NodeSocketString', 'Branches', 'Branches Settigns Below '),
            ('NodeSocketBool', 'Angle Based', True),
            ('NodeSocketFloat', 'Split Angle', 19.6200),
            ('NodeSocketFloat', 'Branch_Length', 1.5000),
            ('NodeSocketInt', 'Branch_Count', 12),
            ('NodeSocketInt', 'Branch Seed', 389),
            ('NodeSocketBool', 'Leaves', False),
            ('NodeSocketBool', 'Leaves Block', False),
            ('NodeSocketInt', 'Leaves Seed', 793),
            ('NodeSocketColor', 'Leaves Color', (0.7795, 0.1957, 0.4375, 1.0000)),
            ('NodeSocketFloat', 'Leaves Density', 300.0000),
            ('NodeSocketFloat', 'Leaves Scale', 0.1000),
            ('NodeSocketFloatFactor', 'Leaves Distortion', 0.5000),
            ('NodeSocketVector', 'Leaves Noise', (0.0000, -0.5600, 8.9300)),
            ('NodeSocketBool', 'Vines', False),
            ('NodeSocketFloat', 'Vine Gravity', -4.0000),
            ('NodeSocketInt', 'Vine Seed', 573)])
    
    mesh_circle = nw.new_node(Nodes.MeshCircle, input_kwargs={'Vertices': group_input_1.outputs["Base Count"]})
    
    random_value_1 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-1.0000, -1.0000, 0.0000), 1: (1.0000, 1.0000, 0.0000), 'Seed': group_input_1.outputs["Tree Seed"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': mesh_circle, 'Position': random_value_1.outputs["Value"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (0.0000, 0.0000, 2.0000)})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': set_position_2, 'Instance': resample_curve})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points}, attrs={'legacy_behavior': True})
    
    curve_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    trunk_profie = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': curve_parameter_1.outputs["Factor"]}, label='Trunk Profie')
    node_utils.assign_curve(trunk_profie.mapping.curves[0], [(0.0000, 1.0000), (0.1158, 0.3950), (0.2560, 0.1550), (0.4657, 0.0350), (0.6358, 0.1150), (0.8483, 0.4800), (1.0000, 0.6400)])
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': trunk_profie})
    
    position = nw.new_node(Nodes.InputPosition)
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: position, 1: (0.0000, 0.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: reroute_9, 6: multiply.outputs["Vector"], 7: position},
        attrs={'data_type': 'RGBA'})
    
    set_position_5 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': realize_instances, 'Position': mix_1.outputs[2]})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': set_position_5, 'Count': group_input_1.outputs["Trunk Resolution"]})
    
    set_distortion_limit = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input_1.outputs["Tree Distortion"], 3: 0.2000, 4: 0.8000},
        label='Set Distortion Limit')
    
    position_4 = nw.new_node(Nodes.InputPosition)
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_4, 1: group_input_1.outputs["Trunk Noise"]})
    
    noise_displace = nw.new_node(nodegroup_noise_displace().name,
        input_kwargs={'Geometry': resample_curve_3, 'Fac': set_distortion_limit.outputs["Result"], 'Vector': add.outputs["Vector"], 'Scale': 1.4200, 'Roughness': group_input_1.outputs["Distortion Roughness"]})
    
    position_2 = nw.new_node(Nodes.InputPosition)
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: position_2, 1: (1.0000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    length = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_1.outputs["Vector"], 1: (1.0000, 1.0000, 0.0000)},
        attrs={'operation': 'LENGTH'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': length.outputs["Value"], 3: 1.0000, 4: 0.0000})
    
    random_value_4 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.5500, 3: 1.1000, 'Seed': 13})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_1.outputs["Result"], 1: random_value_4.outputs[1]},
        attrs={'operation': 'MULTIPLY'})
    
    capture_attribute_2 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': noise_displace, 2: multiply_2},
        attrs={'domain': 'CURVE'})
    
    trunk_radius = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': curve_parameter_1.outputs["Factor"]}, label='Trunk Radius')
    node_utils.assign_curve(trunk_radius.mapping.curves[0], [(0.0000, 0.0800), (0.1994, 0.5000), (0.5761, 0.8950), (0.7754, 0.5250), (1.0000, 0.3450)])
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': trunk_radius})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: capture_attribute_2.outputs[2], 1: reroute_16},
        attrs={'operation': 'MULTIPLY'})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': capture_attribute_2.outputs["Geometry"], 'Radius': multiply_3})
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': set_curve_radius, 2: multiply_3})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': group_input_1.outputs["Resolution"], 'Radius': 0.1000})
    
    mesh_to_curve_uvs = nw.new_node(nodegroup_mesh_to_curve_u_vs().name,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 'Profile_Curve': curve_circle.outputs["Curve"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mesh_to_curve_uvs.outputs["Mesh"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    endpoint_selection = nw.new_node(Nodes.EndpointSelection, input_kwargs={'Start Size': 0})
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': capture_attribute_1.outputs["Geometry"], 4: endpoint_selection},
        attrs={'data_type': 'BOOLEAN'})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': capture_attribute.outputs["Geometry"], 'Count': 2})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute.outputs[4]})
    
    separate_geometry = nw.new_node(Nodes.SeparateGeometry,
        input_kwargs={'Geometry': curve_to_points.outputs["Points"], 'Selection': reroute_10})
    
    branch_gen = nw.new_node(nodegroup_branch_gen().name,
        input_kwargs={'Angle_Based': group_input_1.outputs["Angle Based"], 'Split_angle': group_input_1.outputs["Split Angle"], 'Resolution': group_input_1.outputs["Resolution"], 'Branch_Length': group_input_1.outputs["Branch_Length"], 'Branch_Count': group_input_1.outputs["Branch_Count"], 'Seed': group_input_1.outputs["Branch Seed"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': branch_gen.outputs["Branch"]})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={3: 6.2832})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points.outputs["Rotation"], 'Angle': random_value.outputs[1]},
        attrs={'space': 'LOCAL'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: capture_attribute_1.outputs[2], 1: 4.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_4})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': separate_geometry.outputs["Selection"], 'Instance': reroute_1, 'Rotation': rotate_euler, 'Scale': reroute_11})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_1})
    
    separate_components_1 = nw.new_node(Nodes.SeparateComponents, input_kwargs={'Geometry': realize_instances_1})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': separate_components_1.outputs["Mesh"]})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (0.0000, 0.0000, 1.5000)})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': separate_geometry.outputs["Selection"], 'Instance': curve_line_1, 'Rotation': rotate_euler, 'Scale': reroute_11})
    
    realize_instances_3 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_3})
    
    subdivide_curve = nw.new_node(Nodes.SubdivideCurve, input_kwargs={'Curve': realize_instances_3, 'Cuts': 3})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    equal = nw.new_node(Nodes.Compare,
        input_kwargs={0: spline_parameter.outputs["Factor"], 1: 0.5000},
        attrs={'operation': 'EQUAL'})
    
    random_value_5 = nw.new_node(Nodes.RandomValue,
        input_kwargs={2: -0.6000, 3: group_input_1.outputs["Vine Gravity"], 'Seed': group_input_1.outputs["Vine Seed"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': random_value_5.outputs[1]})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': subdivide_curve, 'Selection': equal, 'Offset': combine_xyz})
    
    set_spline_type = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': set_position}, attrs={'spline_type': 'NURBS'})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 6, 'Radius': 0.0050})
    
    mesh_to_curve_uvs_1 = nw.new_node(nodegroup_mesh_to_curve_u_vs().name,
        input_kwargs={'Geometry': set_spline_type, 'Profile_Curve': curve_circle_1.outputs["Curve"]})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_1.outputs["Vines"], 15: mesh_to_curve_uvs_1.outputs["Mesh"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_2, reroute_5, switch_1.outputs[6]]})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry, 'Material': surface.shaderfunc_to_material(shader_bark)})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_3})
    
    separate_components = nw.new_node(Nodes.SeparateComponents, input_kwargs={'Geometry': realize_instances_1})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Subdivisions': 4})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere.outputs["UV Map"]},
        attrs={'domain': 'CORNER', 'data_type': 'FLOAT_VECTOR'})
    
    random_value_2 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.1000, 3: 0.6000, 'Seed': group_input_1.outputs["Leaves Seed"]})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': separate_components.outputs["Point Cloud"], 'Instance': store_named_attribute, 'Scale': random_value_2.outputs[1]})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_2})
    
    position_5 = nw.new_node(Nodes.InputPosition)
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_5, 1: group_input_1.outputs["Leaves Noise"]})
    
    noise_displace_1 = nw.new_node(nodegroup_noise_displace().name,
        input_kwargs={'Geometry': realize_instances_2, 'Fac': group_input_1.outputs["Leaves Distortion"], 'Vector': add_1.outputs["Vector"], 'Scale': 1.0200})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': noise_displace_1})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_shade_smooth})
    
    distribute_points_on_faces = nw.new_node(Nodes.DistributePointsOnFaces,
        input_kwargs={'Mesh': reroute_4, 'Density': group_input_1.outputs["Leaves Density"]},
        attrs={'use_legacy_normal': True})
    
    leaf = nw.new_node(nodegroup_leaf().name)
    
    random_value_6 = nw.new_node(Nodes.RandomValue, input_kwargs={1: (6.2832, 6.2832, 6.2832)}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    random_value_3 = nw.new_node(Nodes.RandomValue, input_kwargs={2: 0.0800, 3: group_input_1.outputs["Leaves Scale"], 'Seed': 1023})
    
    instance_leaves = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': distribute_points_on_faces.outputs["Points"], 'Instance': leaf.outputs["Geometry"], 'Rotation': random_value_6.outputs["Value"], 'Scale': random_value_3.outputs[1]},
        label='Instance_Leaves')
    
    realize_instances_4 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_leaves})
    
    switch = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_1.outputs["Leaves"], 15: realize_instances_4})
    
    set_material_4 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_4, 'Material': surface.shaderfunc_to_material(shader_leaves)})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    scale = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal, 'Scale': -0.0600}, attrs={'operation': 'SCALE'})
    
    set_position_6 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_material_4, 'Offset': scale.outputs["Vector"]})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_1.outputs["Leaves Block"], 15: set_position_6})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_13, switch.outputs[6], switch_2.outputs[6]]})
    
    multiply_5 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: mesh_to_curve_uvs_1.outputs["UVs"], 1: (10.0000, 1.0000, 1.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_5.outputs["Vector"]})
    
    add_2 = nw.new_node(Nodes.VectorMath, input_kwargs={0: branch_gen.outputs["UVs"], 1: mesh_to_curve_uvs.outputs["UVs"]})
    
    add_3 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute, 1: add_2.outputs["Vector"]})
    
    add_4 = nw.new_node(Nodes.VectorMath, input_kwargs={0: leaf.outputs["Attribute"], 1: add_3.outputs["Vector"]})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_4.outputs["Vector"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': join_geometry_1, 'UVs': reroute_7, 'Color': group_input_1.outputs["Leaves Color"]},
        attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_fantasy_tree_gen, selection=selection, attributes=['UV', 'Color'])
#    surface.add_material(obj, shader_leaves, selection=selection)
#    surface.add_material(obj, shader_bark, selection=selection)
#    surface.add_material(obj, shader_leaf, selection=selection)
apply(bpy.context.active_object)