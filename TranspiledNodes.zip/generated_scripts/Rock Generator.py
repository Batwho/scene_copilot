import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_scatter', singleton=False, type='ShaderNodeTree')
def nodegroup_scatter(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Texture Coordinate', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Scale Individual', (1.0000, 1.0000, 1.0000)),
            ('NodeSocketFloat', 'Scale Grid', 5.0000),
            ('NodeSocketFloat', 'Scale Uniform', 1.0000),
            ('NodeSocketFloat', 'W', 0.0000),
            ('NodeSocketFloat', 'Min', 1.0000),
            ('NodeSocketFloat', 'Max', 1.0000),
            ('NodeSocketFloat', 'Randomize Rotation Individual', 0.0000),
            ('NodeSocketFloat', 'Rotation All', 0.0000),
            ('NodeSocketFloat', 'Bias', 0.5000)])
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["Texture Coordinate"], 'Scale': group_input.outputs["Scale Grid"]},
        attrs={'operation': 'SCALE'})
    
    fraction = nw.new_node(Nodes.VectorMath, input_kwargs={0: scale.outputs["Vector"]}, attrs={'operation': 'FRACTION'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': -0.5000, 'Y': -0.5000, 'Z': -0.5000})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: fraction.outputs["Vector"], 1: combine_xyz})
    
    ceil = nw.new_node(Nodes.VectorMath, input_kwargs={0: scale.outputs["Vector"]}, attrs={'operation': 'CEIL'})
    
    white_noise_texture = nw.new_node(Nodes.WhiteNoiseTexture,
        input_kwargs={'Vector': ceil.outputs["Vector"], 'W': group_input.outputs["W"]},
        attrs={'noise_dimensions': '4D'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': white_noise_texture.outputs["Value"], 3: group_input.outputs["Min"], 4: group_input.outputs["Max"]})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: add.outputs["Vector"], 'Scale': map_range.outputs["Result"]},
        attrs={'operation': 'SCALE'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: white_noise_texture.outputs["Value"], 1: group_input.outputs["Randomize Rotation Individual"]},
        attrs={'operation': 'MULTIPLY'})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: multiply, 1: group_input.outputs["Rotation All"]})
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: add_1}, attrs={'operation': 'RADIANS'})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate, input_kwargs={'Vector': scale_1.outputs["Vector"], 'Angle': radians})
    
    scale_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: vector_rotate, 'Scale': group_input.outputs["Scale Uniform"]},
        attrs={'operation': 'SCALE'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: scale_2.outputs["Vector"], 1: group_input.outputs["Scale Individual"], 'Scale': 0.5900},
        attrs={'operation': 'MULTIPLY'})
    
    greater_than = nw.new_node(Nodes.Math,
        input_kwargs={0: white_noise_texture.outputs["Value"], 1: group_input.outputs["Bias"]},
        attrs={'operation': 'GREATER_THAN'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Vector': multiply_1.outputs["Vector"], 'Bias Clamp': greater_than, 'Bias ': white_noise_texture.outputs["Value"], 'Color': white_noise_texture.outputs["Color"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_procedural_scratch_map_simple', singleton=False, type='ShaderNodeTree')
def nodegroup_procedural_scratch_map_simple(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Texture Coordinates', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Location', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Scratches Scale', 30.0000),
            ('NodeSocketFloat', 'Bias', 0.5000),
            ('NodeSocketFloat', 'Randomize', 1.0000),
            ('NodeSocketFloat', 'Randomize Rotation', 9999.0000),
            ('NodeSocketFloatFactor', 'Dots Presence', 1.0000),
            ('NodeSocketFloatFactor', 'Invert', 0.0000)])
    
    add = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["Texture Coordinates"], 1: group_input.outputs["Location"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add.outputs["Vector"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute, 'Scale': 10.8500, 'Detail': 7.0000, 'Roughness': 0.9133, 'Distortion': -0.1800})
    
    mix_11 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.0070, 6: reroute_4, 7: noise_texture_1.outputs["Fac"]},
        attrs={'data_type': 'RGBA'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_11.outputs[2]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Scratches Scale"]})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Randomize"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Randomize Rotation"]})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input.outputs["Bias"], 3: 0.8000})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range.outputs["Result"]})
    
    group_2 = nw.new_node(nodegroup_scatter().name,
        input_kwargs={'Texture Coordinate': reroute_8, 'Scale Individual': (24.2200, 0.4300, 1.0000), 'Scale Grid': reroute_7, 'Scale Uniform': 0.5000, 'W': reroute_31, 'Min': 0.3000, 'Max': 4.3200, 'Randomize Rotation Individual': reroute_2, 'Bias': reroute_1})
    
    gradient_texture_2 = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': group_2.outputs["Vector"]},
        attrs={'gradient_type': 'SPHERICAL'})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_2.outputs["Bias Clamp"]})
    
    mix_14 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: gradient_texture_2.outputs["Color"], 7: reroute_29},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: 1.0280}, attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_31, 1: 99.8500}, attrs={'operation': 'MULTIPLY'})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: 0.0700})
    
    group_3 = nw.new_node(nodegroup_scatter().name,
        input_kwargs={'Texture Coordinate': reroute_22, 'Scale Individual': (24.2200, -0.5200, 1.0000), 'Scale Grid': multiply, 'Scale Uniform': 0.5000, 'W': multiply_1, 'Min': 0.3000, 'Max': 3.6700, 'Randomize Rotation Individual': reroute_14, 'Rotation All': 78.7000, 'Bias': add_1})
    
    gradient_texture_1 = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': group_3.outputs["Vector"]},
        attrs={'gradient_type': 'SPHERICAL'})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_3.outputs["Bias Clamp"]})
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: gradient_texture_1.outputs["Color"], 7: reroute_28},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.1533, 6: mix_14.outputs[2], 7: mix_4.outputs[2]},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: 0.3200}, attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_31, 1: 155.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_11})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    group_5 = nw.new_node(nodegroup_scatter().name,
        input_kwargs={'Texture Coordinate': reroute_20, 'Scale Individual': (24.2200, -0.5200, 1.0000), 'Scale Grid': multiply_2, 'Scale Uniform': 0.5000, 'W': multiply_3, 'Min': 0.3000, 'Max': 3.6700, 'Randomize Rotation Individual': reroute_10, 'Rotation All': 78.7000, 'Bias': reroute_9})
    
    gradient_texture_4 = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': group_5.outputs["Vector"]},
        attrs={'gradient_type': 'SPHERICAL'})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_5.outputs["Bias Clamp"]})
    
    mix_13 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: gradient_texture_4.outputs["Color"], 7: reroute_27},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.3600, 6: mix_6.outputs[2], 7: mix_13.outputs[2]},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_19, 1: 1.3000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_32, 1: 155.7000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_13})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: 0.0500})
    
    group_4 = nw.new_node(nodegroup_scatter().name,
        input_kwargs={'Texture Coordinate': reroute_18, 'Scale Individual': (24.2200, -0.5200, 1.0000), 'Scale Grid': multiply_4, 'Scale Uniform': 0.5000, 'W': multiply_5, 'Min': 0.3000, 'Max': 3.6700, 'Randomize Rotation Individual': reroute_12, 'Rotation All': 78.7000, 'Bias': add_2})
    
    gradient_texture_3 = nw.new_node(Nodes.GradientTexture,
        input_kwargs={'Vector': group_4.outputs["Vector"]},
        attrs={'gradient_type': 'SPHERICAL'})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_4.outputs["Bias Clamp"]})
    
    mix_12 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: gradient_texture_3.outputs["Color"], 7: reroute_26},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.1993, 6: mix_5.outputs[2], 7: mix_12.outputs[2]},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: -0.7500}, attrs={'operation': 'MULTIPLY'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': reroute_5, 'W': reroute_31, 'Scale': multiply_6},
        attrs={'voronoi_dimensions': '4D', 'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_4.color_ramp.elements[0].position = 0.0000
    colorramp_4.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.0026
    colorramp_4.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Scale': multiply_6, 'Detail': 5.0000, 'Roughness': 0.8467, 'Distortion': -0.0900})
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    colorramp_5.color_ramp.elements[0].position = 0.5455
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.6982
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_10 = nw.new_node(Nodes.Mix,
        input_kwargs={0: reroute_25, 6: colorramp_5.outputs["Color"], 7: (0.0000, 0.0000, 0.0000, 1.0000)},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_4.outputs["Color"], 7: mix_10.outputs[2]},
        attrs={'blend_type': 'DARKEN', 'data_type': 'RGBA'})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_8.outputs[2]})
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_7.outputs[2], 7: reroute_23},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': noise_texture_1.outputs["Fac"]})
    
    mix_16 = nw.new_node(Nodes.Mix, input_kwargs={0: 0.0143, 6: reroute_38, 7: reroute_39}, attrs={'data_type': 'RGBA'})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_42})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_44})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_40, 1: 4.0000}, attrs={'operation': 'MULTIPLY'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix_16.outputs[2], 'W': reroute_45, 'Scale': multiply_7},
        attrs={'voronoi_dimensions': '4D'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_1.outputs["Distance"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.1103
    colorramp.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_42})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_40, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    voronoi_texture_2 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix_16.outputs[2], 'W': reroute_43, 'Scale': multiply_8},
        attrs={'voronoi_dimensions': '4D'})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture_2.outputs["Distance"]})
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.0693
    colorramp_1.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: colorramp_1.outputs["Color"]},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    mix_17 = nw.new_node(Nodes.Mix,
        input_kwargs={0: group_input.outputs["Dots Presence"], 6: mix_9.outputs[2], 7: mix_1.outputs[2]},
        attrs={'blend_type': 'ADD', 'data_type': 'RGBA'})
    
    invert = nw.new_node(Nodes.Invert, input_kwargs={'Fac': group_input.outputs["Invert"], 'Color': mix_17.outputs[2]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Height': invert}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_procedural_rock', singleton=False, type='ShaderNodeTree')
def nodegroup_procedural_rock(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    attribute_2 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'rand_scratch'})
    
    group = nw.new_node(nodegroup_procedural_scratch_map_simple().name,
        input_kwargs={'Texture Coordinates': texture_coordinate.outputs["Object"], 'Scratches Scale': 5.0000, 'Randomize': attribute_2.outputs["Fac"]})
    
    colorramp_7 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': group})
    colorramp_7.color_ramp.elements[0].position = 0.0873
    colorramp_7.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_7.color_ramp.elements[1].position = 0.1745
    colorramp_7.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    noise_texture_4 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 0.7900, 'Detail': 6.5000, 'Roughness': 0.5333, 'Distortion': 0.4600})
    
    mix_3 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.6657, 6: texture_coordinate.outputs["Object"], 7: noise_texture_4.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    noise_texture_5 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 2.3700, 'Detail': 12.0000, 'Roughness': 0.5867, 'Distortion': -0.3200})
    
    colorramp_3 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_5.outputs["Fac"]})
    colorramp_3.color_ramp.elements[0].position = 0.4109
    colorramp_3.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_3.color_ramp.elements[1].position = 0.5273
    colorramp_3.color_ramp.elements[1].color = [8.9355, 8.9355, 8.9355, 1.0000]
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': mix_3.outputs[2], 'Scale': colorramp_3.outputs["Color"]},
        attrs={'feature': 'DISTANCE_TO_EDGE'})
    
    colorramp_6 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': voronoi_texture.outputs["Distance"]})
    colorramp_6.color_ramp.elements[0].position = 0.0000
    colorramp_6.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_6.color_ramp.elements[1].position = 0.7345
    colorramp_6.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    attribute_1 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'v_dist'})
    
    colorramp_4 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute_1.outputs["Color"]})
    colorramp_4.color_ramp.elements[0].position = 0.0000
    colorramp_4.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    colorramp_4.color_ramp.elements[1].position = 0.7418
    colorramp_4.color_ramp.elements[1].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    mix_4 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp_6.outputs["Color"], 7: colorramp_4.outputs["Color"]},
        attrs={'blend_type': 'DIFFERENCE', 'data_type': 'RGBA'})
    
    colorramp_5 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': mix_4.outputs[2]})
    colorramp_5.color_ramp.elements[0].position = 0.0000
    colorramp_5.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_5.color_ramp.elements[1].position = 0.3782
    colorramp_5.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    noise_texture_2 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 0.7100, 'Detail': 7.3000, 'Roughness': 0.7667, 'Distortion': 0.2000})
    
    colorramp_2 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_2.outputs["Fac"]})
    colorramp_2.color_ramp.elements[0].position = 0.3055
    colorramp_2.color_ramp.elements[0].color = [0.0686, 0.0686, 0.0686, 1.0000]
    colorramp_2.color_ramp.elements[1].position = 1.0000
    colorramp_2.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_5 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_5.outputs["Color"], 6: colorramp_2.outputs["Color"], 7: (0.0685, 0.0685, 0.0685, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    mapping = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': (0.3300, 0.3300, 0.3300)})
    
    image_texture = nw.new_node(Nodes.ShaderImageTexture,
        input_kwargs={'Vector': mapping},
        attrs={'image': bpy.data.images['cliff-rock-texture.jpg']})
    
    mix_6 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.1667, 6: mix_5.outputs[2], 7: image_texture.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    mix_9 = nw.new_node(Nodes.Mix,
        input_kwargs={0: colorramp_7.outputs["Color"], 6: mix_6.outputs[2], 7: (0.4988, 0.4988, 0.4988, 1.0000)},
        attrs={'data_type': 'RGBA'})
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketColor', 'Color', (1.0000, 0.8303, 0.6310, 1.0000)),
            ('NodeSocketFloatFactor', 'Bump Strength', 0.3333),
            ('NodeSocketFloatFactor', 'Specular', 1.0000)])
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_9.outputs[2], 7: group_input.outputs["Color"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': 0.5000, 'Detail': 7.3000, 'Roughness': 0.7667, 'Distortion': 0.2000})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Color"]})
    colorramp_1.color_ramp.elements[0].position = 0.3964
    colorramp_1.color_ramp.elements[0].color = [0.4245, 0.4245, 0.4245, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.7164
    colorramp_1.color_ramp.elements[1].color = [0.8082, 0.8082, 0.8082, 1.0000]
    
    attribute_3 = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'n_val'})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.7800, 6: attribute_3.outputs["Fac"], 7: mix_4.outputs[2]},
        attrs={'data_type': 'RGBA'})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': image_texture.outputs["Color"]})
    colorramp.color_ramp.elements[0].position = 0.0000
    colorramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_7 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.3667, 6: mix_2.outputs[2], 7: colorramp.outputs["Color"]},
        attrs={'data_type': 'RGBA'})
    
    colorramp_8 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': group})
    colorramp_8.color_ramp.elements[0].position = 0.0000
    colorramp_8.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_8.color_ramp.elements[1].position = 0.4909
    colorramp_8.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_8 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix_7.outputs[2], 7: colorramp_8.outputs["Color"]},
        attrs={'blend_type': 'LIGHTEN', 'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump,
        input_kwargs={'Strength': group_input.outputs["Bump Strength"], 'Height': mix_8.outputs[2]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix.outputs[2], 'Specular': group_input.outputs["Specular"], 'Roughness': colorramp_1.outputs["Color"], 'Transmission': 0.2582, 'Normal': bump})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Shader': principled_bsdf, 'Color': mix.outputs[2], 'Roughness': colorramp_1.outputs["Color"], 'Height': mix_8.outputs[2]},
        attrs={'is_active_output': True})

def shader_procedural_rock(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_1 = nw.new_node(nodegroup_procedural_rock().name)
    
    material_output = nw.new_node(Nodes.MaterialOutput,
        input_kwargs={'Surface': group_1.outputs["Shader"]},
        attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Randomize', 0.0000),
            ('NodeSocketFloat', 'Displace Strength', 1.0000),
            ('NodeSocketFloatFactor', 'Smoothness', 0.0000),
            ('NodeSocketFloatFactor', 'Crease', 0.3000),
            ('NodeSocketFloat', 'Noise Scale', 4.0000),
            ('NodeSocketInt', 'Voronoi Type', 0),
            ('NodeSocketFloat', 'Voronoi Scale', 1.0000),
            ('NodeSocketFloatFactor', 'Noise Roughness', 0.0000),
            ('NodeSocketFloat', 'Noise Distortion', 0.0000),
            ('NodeSocketFloat', 'Noise Output Detail', 0.0000),
            ('NodeSocketInt', 'Subdivision Levels', 3),
            ('NodeSocketFloat', 'Scale Z', 1.0000)])
    
    position = nw.new_node(Nodes.InputPosition)
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["Voronoi Type"], 1: 1.0000, 2: 2.0000, 5: 1.0000},
        attrs={'interpolation_type': 'STEPPED'})
    
    voronoi_texture = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': position, 'W': group_input.outputs["Randomize"], 'Scale': group_input.outputs["Voronoi Scale"], 'Smoothness': group_input.outputs["Smoothness"]},
        attrs={'voronoi_dimensions': '4D', 'feature': 'SMOOTH_F1'})
    
    voronoi_texture_1 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': position, 'W': group_input.outputs["Randomize"], 'Scale': group_input.outputs["Voronoi Scale"], 'Smoothness': group_input.outputs["Smoothness"]},
        attrs={'voronoi_dimensions': '4D', 'feature': 'SMOOTH_F1', 'distance': 'MANHATTAN'})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Voronoi Type"], 3: 1.0000, 8: voronoi_texture.outputs["Position"], 9: voronoi_texture_1.outputs["Position"]},
        attrs={'input_type': 'VECTOR'})
    
    voronoi_texture_2 = nw.new_node(Nodes.VoronoiTexture,
        input_kwargs={'Vector': position, 'W': group_input.outputs["Randomize"], 'Scale': group_input.outputs["Voronoi Scale"], 'Smoothness': group_input.outputs["Smoothness"]},
        attrs={'voronoi_dimensions': '4D', 'feature': 'SMOOTH_F1', 'distance': 'CHEBYCHEV'})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={0: map_range_1.outputs["Result"], 3: 2.0000, 8: switch_3.outputs[3], 9: voronoi_texture_2.outputs["Position"]},
        attrs={'input_type': 'VECTOR'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["Voronoi Type"], 1: 1.0000, 2: 2.0000, 5: 1.0000},
        attrs={'interpolation_type': 'STEPPED'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Voronoi Type"], 2: voronoi_texture.outputs["Distance"], 3: voronoi_texture_1.outputs["Distance"]},
        attrs={'input_type': 'FLOAT'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: map_range.outputs["Result"], 2: switch_1.outputs["Output"], 3: voronoi_texture_2.outputs["Distance"]},
        attrs={'input_type': 'FLOAT'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: switch_2.outputs["Output"], 1: group_input.outputs["Displace Strength"]},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: switch_4.outputs[3], 1: multiply}, attrs={'operation': 'MULTIPLY'})
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: multiply_1.outputs["Vector"]})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Position': add.outputs["Vector"]})
    
    subdivision_surface_1 = nw.new_node(Nodes.SubdivisionSurface,
        input_kwargs={'Mesh': set_position, 'Level': group_input.outputs["Subdivision Levels"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': position})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Randomize"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Noise Scale"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute_2, 'W': reroute_1, 'Scale': reroute, 'Detail': 0.0000, 'Roughness': group_input.outputs["Noise Roughness"], 'Distortion': group_input.outputs["Noise Distortion"]},
        attrs={'noise_dimensions': '4D'})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: noise_texture.outputs["Fac"], 1: 0.1100}, attrs={'operation': 'MULTIPLY'})
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: multiply_2})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': subdivision_surface_1, 'Position': add_1.outputs["Vector"]})
    
    subdivision_surface_2 = nw.new_node(Nodes.SubdivisionSurface, input_kwargs={'Mesh': set_position_1})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 1.0000, 'Y': 1.0000, 'Z': group_input.outputs["Scale Z"]})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': subdivision_surface_2, 'Scale': combine_xyz})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["Voronoi Type"], 1: 1.0000, 2: 2.0000, 5: 1.0000},
        attrs={'interpolation_type': 'STEPPED'})
    
    switch_5 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Voronoi Type"], 3: 1.0000, 10: voronoi_texture.outputs["Color"], 11: voronoi_texture_1.outputs["Color"]},
        attrs={'input_type': 'RGBA'})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={0: map_range_2.outputs["Result"], 3: 2.0000, 10: switch_5.outputs[4], 11: voronoi_texture_2.outputs["Color"]},
        attrs={'input_type': 'RGBA'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': reroute_2, 'W': reroute_1, 'Scale': reroute, 'Detail': group_input.outputs["Noise Output Detail"], 'Roughness': group_input.outputs["Noise Roughness"], 'Distortion': group_input.outputs["Noise Distortion"]},
        attrs={'noise_dimensions': '4D'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Geometry': transform_1, 'Voronoi Position': switch_4.outputs[3], 'Voronoi Distance': multiply, 'Voronoi Color': switch_6.outputs[4], 'Noise Value': noise_texture_1.outputs["Fac"], 'Noise Color': noise_texture_1.outputs["Color"], 'Randomize': group_input.outputs["Randomize"]},
        attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_procedural_rock, selection=selection)
apply(bpy.context.active_object)