import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_feather_high', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_high(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketInt', 'B', 0)])
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': group_input.outputs["Curve"], 3: 0.8858})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': trim_curve, 'Count': 50, 'Length': 0.0050},
        attrs={'mode': 'LENGTH'})
    
    index = nw.new_node(Nodes.Index)
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["B"]})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: index, 3: reroute_3}, attrs={'data_type': 'INT'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch"], 8: (0.1300, 0.0000, 0.0000), 9: (-0.1300, 0.0000, 0.0000)},
        attrs={'input_type': 'VECTOR'})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': switch.outputs[3]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 6})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Switch"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_6 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_1.outputs[1]})
    node_utils.assign_curve(float_curve_6.mapping.curves[0], [(0.0000, 0.0000), (0.2891, 0.4625), (0.6082, 0.6780), (0.8682, 0.7250), (1.0000, 1.0000)])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_6, 3: 0.7600, 4: -2.3008})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_5 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_2.outputs[1]})
    node_utils.assign_curve(float_curve_5.mapping.curves[0], [(0.0000, 0.0000), (0.1691, 0.5625), (0.5636, 0.5862), (0.8543, 0.7220), (0.9182, 0.9710), (1.0000, 1.0000)])
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_5, 3: 0.7700, 4: -2.0308})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range_2.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_2, 2: map_range_1.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_1.outputs["Rotation"], 'Rotate By': reroute},
        attrs={'space': 'LOCAL'})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0200, 0.0000, -0.0100), 1: (-0.0200, 0.0000, 0.0100)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': random_value.outputs["Value"]})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.0991, 0.0675), (0.2945, 1.0000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve, 'Y': float_curve, 'Z': float_curve})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Selection': greater_than, 'Instance': resample_curve, 'Rotation': rotate_euler, 'Scale': reroute_1})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 6.0000, 'Detail': 1.0000})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_1.outputs["Factor"], 4: 0.0300})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: map_range_4.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': instance_on_points_1, 'Offset': multiply_1.outputs["Vector"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 3: 0.3400, 4: 0.1000})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': set_position, 'Radius': map_range.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0050})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle.outputs["Curve"], 'Scale': (1.5000, 2.0000, 1.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': transform_geometry, 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': group_input.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_simple_feather_profile', singleton=False, type='GeometryNodeTree')
def nodegroup_simple_feather_profile(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_primary)
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': group_input.outputs["Curve"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': trim_curve})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.1227, 0.0937), (0.2636, 0.6187), (0.6864, 0.4937), (0.9955, 0.0000)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve, 'Radius': float_curve})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': (-0.2100, 0.0000, 0.0000), 'End': (0.0700, 0.0000, 0.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_line, 'Fill Caps': True})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Material"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': curve_to_mesh, 'Material': reroute_1})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Mesh': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_main', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_main(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketInt', 'B', 0)])
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': group_input.outputs["Curve"], 'Count': 50, 'Length': 0.0100},
        attrs={'mode': 'LENGTH'})
    
    index = nw.new_node(Nodes.Index)
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["B"]})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: index, 3: reroute_3}, attrs={'data_type': 'INT'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch"], 8: (0.1300, 0.0000, 0.0000), 9: (-0.1300, 0.0000, 0.0000)},
        attrs={'input_type': 'VECTOR'})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': switch.outputs[3]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Switch"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_1.outputs[1]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.2891, 0.4625), (0.6082, 0.6780), (0.8682, 0.7250), (0.9455, 0.6863), (1.0000, 1.0000)])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_3, 3: -0.6500, 4: -1.5708})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_2.outputs[1]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 0.0000), (0.1691, 0.5625), (0.6176, 0.6232), (0.8543, 0.7220), (0.9152, 0.9710), (1.0000, 1.0000)])
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_4, 3: 0.7700, 4: -1.2808})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range_2.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_2, 2: map_range_1.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_1.outputs["Rotation"], 'Rotate By': reroute},
        attrs={'space': 'LOCAL'})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0200, 0.0000, -0.0200), 1: (-0.0200, 0.0000, 0.0250)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': random_value.outputs["Value"]})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.0273, 0.2438), (0.1082, 0.6275), (0.2945, 1.0000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve, 'Y': float_curve, 'Z': float_curve})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Selection': greater_than, 'Instance': curve_line_1, 'Rotation': rotate_euler, 'Scale': reroute_1})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 3: 1.0000, 4: 0.3500})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': instance_on_points_1, 'Radius': map_range.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 3, 'Radius': 0.0050})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle.outputs["Curve"], 'Scale': (1.5000, 2.0000, 1.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': transform_geometry, 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': group_input.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_flapping_profile_z', singleton=False, type='GeometryNodeTree')
def nodegroup_flapping_profile_z(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketFloat', 'Value', 1.0000)])
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': group_input.outputs["Value"]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 0.0000), (0.2491, 0.0500), (0.7100, 0.2238), (1.0000, 1.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': float_curve_4}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_last_slap', singleton=False, type='GeometryNodeTree')
def nodegroup_last_slap(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Value', 1.0000),
            ('NodeSocketFloat', 'Value_1', 1.0000)])
    
    map_range_17 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input.outputs["Value"], 3: -0.2500, 4: 0.7500},
        attrs={'clamp': False})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Value_1"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_17.outputs["Result"], 1: reroute_1},
        attrs={'operation': 'MULTIPLY'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': multiply}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_flapping_profile_xy', singleton=False, type='GeometryNodeTree')
def nodegroup_flapping_profile_xy(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketFloat', 'Value', 1.0000)])
    
    float_curve_5 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': group_input.outputs["Value"]})
    node_utils.assign_curve(float_curve_5.mapping.curves[0], [(0.0000, 0.0000), (0.2491, 0.1500), (0.7000, 0.7638), (1.0000, 1.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': float_curve_5}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_flapping_sine', singleton=False, type='GeometryNodeTree')
def nodegroup_flapping_sine(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    featherflapcurve = nw.new_node(nodegroup_feather_flap_curve().name)
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': featherflapcurve, 4: -3.1416})
    
    scenetime = nw.new_node(nodegroup_scene_time().name)
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketFloat', 'Offset Flap', 3.0000)])
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Offset Flap"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: scenetime, 1: reroute_1})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Flap Speed"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: reroute_3}, attrs={'operation': 'MULTIPLY'})
    
    map_range_5 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply, 1: 1.0000, 2: 25.0000, 4: 3.1416},
        attrs={'clamp': False})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_2.outputs["Result"], 1: map_range_5.outputs["Result"]})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: add_1}, attrs={'operation': 'SINE'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': sine}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_idle_noise', singleton=False, type='GeometryNodeTree')
def nodegroup_idle_noise(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Detail': 0.0000})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': noise_texture.outputs["Fac"], 3: 0.2500, 4: 0.7500},
        attrs={'interpolation_type': 'SMOOTHERSTEP'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Result': map_range_2.outputs["Result"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_flap_curve', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_flap_curve(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_2.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.3627, 0.2437), (1.0000, 1.0000)])
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': float_curve}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_high_tail', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_high_tail(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketInt', 'B', 0)])
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': group_input.outputs["Curve"], 3: 0.8858})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': trim_curve, 'Count': 50, 'Length': 0.0050},
        attrs={'mode': 'LENGTH'})
    
    index = nw.new_node(Nodes.Index)
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["B"]})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: index, 3: reroute_3}, attrs={'data_type': 'INT'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch"], 8: (0.1300, 0.0000, 0.0000), 9: (-0.1300, 0.0000, 0.0000)},
        attrs={'input_type': 'VECTOR'})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': switch.outputs[3]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 6})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Switch"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_1.outputs[1]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 1.0000), (0.2891, 0.8725), (0.6082, 0.6780), (0.8682, 0.9513), (1.0000, 1.0000)])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_4, 3: 0.7600, 4: -1.5708})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_2, 2: map_range_1.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_1.outputs["Rotation"], 'Rotate By': reroute},
        attrs={'space': 'LOCAL'})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0200, 0.0000, -0.0500), 1: (-0.0200, 0.0000, 0.0200)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': random_value.outputs["Value"]})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.0991, 0.0675), (0.2945, 1.0000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve, 'Y': float_curve, 'Z': float_curve})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Selection': greater_than, 'Instance': resample_curve, 'Rotation': rotate_euler, 'Scale': reroute_1})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Scale': 6.9000})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_1.outputs["Factor"], 4: 0.0400})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: map_range_4.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': instance_on_points_1, 'Offset': multiply_1.outputs["Vector"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 3: 0.3400, 4: 0.1000})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': set_position, 'Radius': map_range.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0035})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle.outputs["Curve"], 'Scale': (1.5000, 2.0000, 1.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': transform_geometry, 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': group_input.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_bone_to_mesh_high', singleton=False, type='GeometryNodeTree')
def nodegroup_bone_to_mesh_high(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Curve', None)])
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': group_input.outputs["Curve"], 3: 0.9429})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 3: 0.2600, 4: 0.1000})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': trim_curve, 'Radius': map_range_4.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0100})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle.outputs["Curve"], 'Scale': (1.0000, 0.2000, 1.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': transform_geometry, 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': surface.shaderfunc_to_material(shader_wing_bones)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Mesh': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_tail', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_tail(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketInt', 'B', 0)])
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': group_input.outputs["Curve"], 'Count': 50, 'Length': 0.0100},
        attrs={'mode': 'LENGTH'})
    
    index = nw.new_node(Nodes.Index)
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["B"]})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: index, 3: reroute_3}, attrs={'data_type': 'INT'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch"], 8: (0.2000, 0.0000, 0.0000), 9: (-0.2000, 0.0000, 0.0000)},
        attrs={'input_type': 'VECTOR'})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': switch.outputs[3]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Switch"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_1.outputs[1]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 1.0000), (0.2891, 0.8725), (0.6082, 0.6780), (0.8682, 0.7013), (1.0000, 1.0000)])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_3, 3: -0.4200, 4: -1.5708})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: reroute_2, 2: map_range_1.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': curve_to_points_1.outputs["Rotation"], 'Rotate By': reroute},
        attrs={'space': 'LOCAL'})
    
    random_value = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0200, 0.0000, -0.0500), 1: (-0.0200, 0.0000, 0.0700)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': random_value.outputs["Value"]})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.0991, 0.0675), (0.2945, 1.0000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve, 'Y': float_curve, 'Z': float_curve})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Selection': greater_than, 'Instance': curve_line_1, 'Rotation': rotate_euler, 'Scale': reroute_1})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 3: 1.0000, 4: 0.8900})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': instance_on_points_1, 'Radius': map_range.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 3, 'Radius': 0.0050})
    
    transform_geometry = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_circle.outputs["Curve"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': transform_geometry, 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': group_input.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_bone_to_mesh', singleton=False, type='GeometryNodeTree')
def nodegroup_bone_to_mesh(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Curve', None)])
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': group_input.outputs["Curve"], 3: 0.9429})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter.outputs["Factor"], 3: 0.5000, 4: 0.2500})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': trim_curve, 'Radius': map_range_4.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0100})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': surface.shaderfunc_to_material(shader_wing_bones)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Mesh': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_ping_pong_index', singleton=False, type='GeometryNodeTree')
def nodegroup_ping_pong_index(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    pingpong = nw.new_node(Nodes.Math, input_kwargs={0: named_attribute_1.outputs[1]}, attrs={'operation': 'PINGPONG'})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketFloat', 'To Max', 0.2500)])
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["To Max"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': pingpong, 2: 0.5000, 3: multiply, 4: reroute})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Result': map_range_6.outputs["Result"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_simple_feather_tail_profile', singleton=False, type='GeometryNodeTree')
def nodegroup_simple_feather_tail_profile(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_primary)
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': group_input.outputs["Curve"]})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': trim_curve})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.2027, 0.0937), (0.3436, 0.6187), (0.6864, 0.5737), (0.9955, 0.0000)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve, 'Radius': float_curve})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': (-0.0600, 0.0000, 0.0000), 'End': (0.0600, 0.0000, 0.0000)})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_line, 'Fill Caps': True})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Material"]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    set_material = nw.new_node(Nodes.SetMaterial, input_kwargs={'Geometry': curve_to_mesh, 'Material': reroute_1})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Mesh': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_wing_bone_cover', singleton=False, type='GeometryNodeTree')
def nodegroup_wing_bone_cover(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketMaterial', 'Material', None),
            ('NodeSocketBool', 'Switch', False)])
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch"], 4: 1000, 5: 2000},
        attrs={'input_type': 'INT'})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': group_input.outputs["Curve"], 'Count': switch.outputs[1]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': (0.0000, 0.0100, 0.0000), 'End': (0.0000, 0.0150, 0.0700)})
    
    index_1 = nw.new_node(Nodes.Index)
    
    radians = nw.new_node(Nodes.Math, input_kwargs={0: 137.5000}, attrs={'operation': 'RADIANS'})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: index_1, 1: radians}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': group_input.outputs["Rotation"], 'Rotate By': combine_xyz_2, 'Axis': (1.0000, 0.0000, 0.0000)},
        attrs={'space': 'LOCAL'})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': rotate_euler, 'Vector': curve_to_points_1.outputs["Tangent"]},
        attrs={'pivot_axis': 'X', 'axis': 'Z'})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': curve_line, 'Rotation': align_euler_to_vector})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 3, 'Radius': 0.0020})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 3, 'Radius': 0.0010})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input.outputs["Switch"], 4: 1000, 5: 2000, 14: curve_circle.outputs["Curve"], 15: curve_circle_1.outputs["Curve"]})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': instance_on_points_1, 'Profile Curve': switch_1.outputs[6]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh_1, 'Material': group_input.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Mesh': set_material}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_06', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_06(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch Invert', False),
            ('NodeSocketBool', 'Switch To Simple', False),
            ('NodeSocketFloat', 'Feather Scale', 1.0000),
            ('NodeSocketInt', 'Feathers', 19),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketBool', 'Switch to super high', False),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_secondary_covers)
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Curve"]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Feathers"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_1, 'Count': reroute_21})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (-0.2500, 0.0000, 0.0000)})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Rotation"]})
    
    index_4 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math,
        input_kwargs={0: index_4, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo, 2: subtract})
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_15.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.1855, 0.2237), (0.3682, 0.7837), (0.5818, 1.0000), (1.0000, 1.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO'])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_3, 3: -0.1200, 4: -0.2500})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_2, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_1, 2: subtract})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_13.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.7800), (0.4045, 0.9313), (1.0000, 1.0000)])
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 3: -0.1300, 4: 1.1800})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: map_range.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_1.outputs["Result"], 'Z': switch.outputs["Output"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': reroute_8, 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Tangent"]})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': reroute, 'Vector': reroute_3},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': (0.0000, 0.0000, -1.0023)},
        attrs={'space': 'LOCAL'})
    
    value_1 = nw.new_node(Nodes.Value)
    value_1.outputs[0].default_value = 1.1200
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: value_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: value_1, 3: multiply_1},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': switch_3.outputs["Output"]})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': combine_xyz},
        attrs={'space': 'LOCAL'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_1, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_2, 2: subtract})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 1.0000), (0.4045, 0.8013), (1.0000, 0.1917)])
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1}, attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1, 1: 0.1700}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_2, 'Y': multiply_3, 'Z': 1.2500})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_19, 'Instance': store_named_attribute_4, 'Rotation': rotate_euler_2, 'Scale': reroute_22})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': instance_on_points})
    
    feather_main = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_5.outputs["Material"]})
    
    feather_main_1 = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feather_main, feather_main_1]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    simplefeatherprofile = nw.new_node(nodegroup_simple_feather_profile().name,
        input_kwargs={'Curve': reroute_5, 'Material': group_input_5.outputs["Material"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch To Simple"], 14: join_geometry, 15: simplefeatherprofile})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': reroute_4})
    
    feather_high = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_4, 'Material': group_input_5.outputs["Material"]})
    
    feather_high_1 = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_4, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh_high, feather_high, feather_high_1]})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch to super high"], 14: switch_4.outputs[6], 15: join_geometry_1})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_5.outputs["Feather Scale"], 'Y': group_input_5.outputs["Feather Scale"], 'Z': group_input_5.outputs["Feather Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_6.outputs[6], 'Scale': combine_xyz_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_05', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_05(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch Invert', False),
            ('NodeSocketBool', 'Switch To Simple', False),
            ('NodeSocketFloat', 'Feather Scale', 1.0000),
            ('NodeSocketInt', 'Feathers', 19),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketBool', 'Switch to super high', False),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_secondary_covers)
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Curve"]})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': reroute_1, 3: 0.8917})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Feathers"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': trim_curve, 'Count': reroute_21})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (-0.1600, 0.0000, 0.0000)})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    index_4 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math,
        input_kwargs={0: index_4, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo, 2: subtract})
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_15.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.1855, 0.2237), (0.3682, 0.7837), (0.5818, 1.0000), (1.0000, 1.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO'])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_3, 3: -0.1200, 4: -0.2500})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_2, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_1, 2: subtract})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_13.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.7800), (0.4045, 0.9313), (1.0000, 1.0000)])
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 3: -0.1300, 4: 1.1800})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: map_range.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_1.outputs["Result"], 'Z': switch.outputs["Output"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': group_input_5.outputs["Rotation"], 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Tangent"]})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': reroute, 'Vector': reroute_3},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    flapping_sine = nw.new_node(nodegroup_flapping_sine().name,
        input_kwargs={'Flap Speed': group_input_5.outputs["Flap Speed"], 'Offset Flap': 1.0000})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_3.outputs[1], 1: -1.0000, 2: 0.0000, 3: 1.0000, 4: 0.0000})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: flapping_sine, 1: map_range_7.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: reroute_12, 3: multiply_2},
        attrs={'input_type': 'FLOAT'})
    
    index_3 = nw.new_node(Nodes.Index)
    
    subtract_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_5.outputs["Feathers"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    map_range_14 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': index_3, 2: subtract_1})
    
    flapping_profile_xy = nw.new_node(nodegroup_flapping_profile_xy().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: switch_1.outputs["Output"], 1: flapping_profile_xy},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_3})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_5, 1: flapping_profile_xy}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4, 'Y': reroute_11, 'Z': multiply_6})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': combine_xyz_4},
        attrs={'space': 'LOCAL'})
    
    value_1 = nw.new_node(Nodes.Value)
    value_1.outputs[0].default_value = -0.2200
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: value_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: value_1, 3: multiply_7},
        attrs={'input_type': 'FLOAT'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = -0.2500
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: value, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: value, 3: multiply_8},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': switch_3.outputs["Output"], 'Y': switch_2.outputs["Output"], 'Z': 0.3400})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': combine_xyz},
        attrs={'space': 'LOCAL'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_1, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_2, 2: subtract})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 1.0000), (0.4045, 0.8013), (1.0000, 0.1917)])
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1, 1: 0.7600}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve_1, 'Y': multiply_9, 'Z': 1.5000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_19, 'Instance': store_named_attribute_4, 'Rotation': rotate_euler_2, 'Scale': reroute_22})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': instance_on_points})
    
    feather_main = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_5.outputs["Material"]})
    
    feather_main_1 = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feather_main, feather_main_1]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    simplefeatherprofile = nw.new_node(nodegroup_simple_feather_profile().name,
        input_kwargs={'Curve': reroute_5, 'Material': group_input_5.outputs["Material"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch To Simple"], 14: join_geometry, 15: simplefeatherprofile})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': reroute_4})
    
    feather_high = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_4, 'Material': group_input_5.outputs["Material"]})
    
    feather_high_1 = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_4, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh_high, feather_high, feather_high_1]})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch to super high"], 14: switch_4.outputs[6], 15: join_geometry_1})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_5.outputs["Feather Scale"], 'Y': group_input_5.outputs["Feather Scale"], 'Z': group_input_5.outputs["Feather Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_6.outputs[6], 'Scale': combine_xyz_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_04', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_04(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch Invert', False),
            ('NodeSocketBool', 'Switch To Simple', False),
            ('NodeSocketFloat', 'Feather Scale', 1.0000),
            ('NodeSocketInt', 'Feathers', 19),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketBool', 'Switch to super high', False),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_secondary_covers)
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Curve"]})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': reroute_1, 3: 0.8917})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Feathers"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': trim_curve, 'Count': reroute_21})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (-0.1600, 0.0000, 0.0000)})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    index_4 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math,
        input_kwargs={0: index_4, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_7, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo, 2: subtract})
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_15.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.1855, 0.2237), (0.3682, 0.7837), (0.5818, 1.0000), (1.0000, 1.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO'])
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_3, 3: 0.3900, 4: 0.0000})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_2, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_1, 2: subtract})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_13.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.7800), (0.4045, 0.9313), (1.0000, 1.0000)])
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 3: -0.1300, 4: 1.1800})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: map_range.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_1.outputs["Result"], 'Z': switch.outputs["Output"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': group_input_5.outputs["Rotation"], 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Tangent"]})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': reroute, 'Vector': reroute_3},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    flapping_sine = nw.new_node(nodegroup_flapping_sine().name,
        input_kwargs={'Flap Speed': group_input_5.outputs["Flap Speed"], 'Offset Flap': 2.0000})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_3.outputs[1], 1: -1.0000, 2: 0.0000, 3: 1.0000, 4: 0.0000})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: flapping_sine, 1: map_range_7.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: reroute_12, 3: multiply_2},
        attrs={'input_type': 'FLOAT'})
    
    index_3 = nw.new_node(Nodes.Index)
    
    subtract_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_5.outputs["Feathers"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    map_range_14 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': index_3, 2: subtract_1})
    
    flapping_profile_xy = nw.new_node(nodegroup_flapping_profile_xy().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: switch_1.outputs["Output"], 1: flapping_profile_xy},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_3})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_5, 1: flapping_profile_xy}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4, 'Y': reroute_11, 'Z': multiply_6})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': combine_xyz_4},
        attrs={'space': 'LOCAL'})
    
    value_1 = nw.new_node(Nodes.Value)
    value_1.outputs[0].default_value = 0.4700
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: value_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: value_1, 3: multiply_7},
        attrs={'input_type': 'FLOAT'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = -0.0800
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: value, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch Invert"], 2: value, 3: multiply_8},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': switch_3.outputs["Output"], 'Y': switch_2.outputs["Output"], 'Z': -0.7000})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': combine_xyz},
        attrs={'space': 'LOCAL'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_1, 1: group_input_5.outputs["Feathers"]},
        attrs={'operation': 'MODULO'})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_2, 2: subtract})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 1.0000), (0.4045, 0.8013), (1.0000, 0.1917)])
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: float_curve_1, 1: 0.7600}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': float_curve_1, 'Y': multiply_9, 'Z': 1.5000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_19, 'Instance': store_named_attribute_4, 'Rotation': rotate_euler_2, 'Scale': reroute_22})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': instance_on_points})
    
    feather_main = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_5.outputs["Material"]})
    
    feather_main_1 = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feather_main, feather_main_1]})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    simplefeatherprofile = nw.new_node(nodegroup_simple_feather_profile().name,
        input_kwargs={'Curve': reroute_5, 'Material': group_input_5.outputs["Material"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch To Simple"], 14: join_geometry, 15: simplefeatherprofile})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': reroute_4})
    
    feather_high = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_4, 'Material': group_input_5.outputs["Material"]})
    
    feather_high_1 = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_4, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh_high, feather_high, feather_high_1]})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch to super high"], 14: switch_4.outputs[6], 15: join_geometry_1})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_5.outputs["Feather Scale"], 'Y': group_input_5.outputs["Feather Scale"], 'Z': group_input_5.outputs["Feather Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_6.outputs[6], 'Scale': combine_xyz_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_03', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_03(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketBool', 'Switch To Simple', False),
            ('NodeSocketFloat', 'Feather Scale', 1.0000),
            ('NodeSocketFloat', 'Flapping Speed', 0.0000),
            ('NodeSocketInt', 'Feather Count', 19),
            ('NodeSocketBool', 'Switch to super high', False),
            ('NodeSocketFloatFactor', 'Wing Profile', 0.0000),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_primary_covers)
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Curve"]})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': reroute_1, 2: 0.0917, 3: 0.9000})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Feather Count"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': trim_curve, 'Count': reroute_21})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (-0.5000, 0.0000, 0.0000)})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math,
        input_kwargs={0: index_2, 1: group_input_5.outputs["Feather Count"]},
        attrs={'operation': 'MODULO'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo, 2: subtract})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_13.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.1500), (0.4045, 0.8813), (1.0000, 1.0000)])
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_5.outputs["Wing Profile"], 1: 0.5000})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_5.outputs["Wing Profile"], 2: 0.5000})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_1.outputs["Result"], 2: 0.8000, 3: 0.9200})
    
    mix_3 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_2.outputs["Result"], 2: mix_2.outputs["Result"], 3: 0.7000})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 3: -0.4100, 4: mix_3.outputs["Result"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: map_range.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': switch.outputs["Output"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': group_input_5.outputs["Rotation"], 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Tangent"]})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': reroute, 'Vector': reroute_3},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    flapping_sine = nw.new_node(nodegroup_flapping_sine().name, input_kwargs={'Flap Speed': group_input_5.outputs["Flapping Speed"]})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_3.outputs[1], 1: -1.0000, 2: 0.0000, 3: 1.0000, 4: 0.0000})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: flapping_sine, 1: map_range_7.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: reroute_12, 3: multiply_2},
        attrs={'input_type': 'FLOAT'})
    
    index_3 = nw.new_node(Nodes.Index)
    
    subtract_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_5.outputs["Feather Count"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    map_range_14 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': index_3, 2: subtract_1})
    
    flapping_profile_z = nw.new_node(nodegroup_flapping_profile_z().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: switch_1.outputs["Output"], 1: flapping_profile_z},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3, 1: -0.2500}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_3})
    
    last_slap = nw.new_node(nodegroup_last_slap().name, input_kwargs={'Value': multiply_1, 'Value_1': 0.3000})
    
    flapping_profile_z_1 = nw.new_node(nodegroup_flapping_profile_z().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: last_slap, 1: flapping_profile_z_1}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4, 'Y': reroute_11, 'Z': multiply_5})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': combine_xyz_4},
        attrs={'space': 'LOCAL'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = -0.2600
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: value, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: value, 3: multiply_6},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"], 'Z': -0.4700})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': combine_xyz},
        attrs={'space': 'LOCAL'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_1, 1: group_input_5.outputs["Feather Count"]},
        attrs={'operation': 'MODULO'})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_1, 2: subtract})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.9600), (0.4773, 0.8337), (0.8145, 0.7713), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO'])
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.1000, 0.7912), (0.2391, 0.9300), (0.8145, 1.0000), (1.0000, 0.7900)])
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_1.outputs["Result"], 2: float_curve_1, 3: float_curve_3})
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 0.0000), (0.1000, 0.5512), (0.2391, 0.8000), (0.5136, 0.8562), (0.7964, 0.8625), (1.0000, 0.4287)])
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_2.outputs["Result"], 2: mix.outputs["Result"], 3: float_curve_4})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_1.outputs["Result"]})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_8, 'Y': multiply_7, 'Z': 1.0000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_19, 'Instance': store_named_attribute_4, 'Rotation': rotate_euler_2, 'Scale': reroute_22})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': instance_on_points})
    
    feather_main = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_5.outputs["Material"]})
    
    feather_main_1 = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feather_main, feather_main_1]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    simplefeatherprofile = nw.new_node(nodegroup_simple_feather_profile().name,
        input_kwargs={'Curve': reroute_6, 'Material': group_input_5.outputs["Material"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch To Simple"], 14: join_geometry, 15: simplefeatherprofile})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': instance_on_points})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    feather_high = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_7, 'Material': group_input_5.outputs["Material"]})
    
    feather_high_1 = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': reroute_7, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh_high, feather_high, feather_high_1]})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch to super high"], 14: switch_4.outputs[6], 15: join_geometry_1})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_5.outputs["Feather Scale"], 'Y': group_input_5.outputs["Feather Scale"], 'Z': group_input_5.outputs["Feather Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_6.outputs[6], 'Scale': combine_xyz_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_02', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_02(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_5 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketBool', 'Switch To Simple', False),
            ('NodeSocketFloat', 'Feather Scale', 1.0000),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketInt', 'Feather Count', 19),
            ('NodeSocketBool', 'Switch to Super High', False),
            ('NodeSocketFloatFactor', 'Wing Profile', 0.0000),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_secondary)
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Curve"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_5.outputs["Feather Count"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_1, 'Count': reroute_21})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (-0.6700, 0.0000, 0.0000)})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: reroute_4}, attrs={'operation': 'MODULO'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo, 2: subtract})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_13.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.1300), (0.3818, 0.3237), (0.6327, 0.8950), (1.0000, 1.0000)])
    
    map_range_16 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_5.outputs["Wing Profile"], 1: 0.5000})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_5.outputs["Wing Profile"], 2: 0.5000})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_15.outputs["Result"], 2: 1.0200, 3: 1.1400})
    
    mix_3 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_16.outputs["Result"], 2: mix_2.outputs["Result"], 3: 0.7900})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 3: -0.5100, 4: mix_3.outputs["Result"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: map_range.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': switch.outputs["Output"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': group_input_5.outputs["Rotation"], 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Tangent"]})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': reroute, 'Vector': reroute_3},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    flapping_sine = nw.new_node(nodegroup_flapping_sine().name, input_kwargs={'Flap Speed': group_input_5.outputs["Flap Speed"]})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_3.outputs[1], 1: -1.0000, 2: 0.0000, 3: 1.2500, 4: 0.0000})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: flapping_sine, 1: map_range_7.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: reroute_12, 3: multiply_2},
        attrs={'input_type': 'FLOAT'})
    
    index_3 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_3, 1: group_input_5.outputs["Feather Count"]},
        attrs={'operation': 'MODULO'})
    
    subtract_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_5.outputs["Feather Count"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    map_range_14 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_1, 2: subtract_1})
    
    flapping_profile_z = nw.new_node(nodegroup_flapping_profile_z().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: switch_1.outputs["Output"], 1: flapping_profile_z},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3, 1: -0.2000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_3})
    
    last_slap = nw.new_node(nodegroup_last_slap().name, input_kwargs={'Value': multiply_1})
    
    flapping_profile_z_1 = nw.new_node(nodegroup_flapping_profile_z().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: last_slap, 1: flapping_profile_z_1}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4, 'Y': reroute_11, 'Z': multiply_5})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': combine_xyz_7},
        attrs={'space': 'LOCAL'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = -0.1900
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: value, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: value, 3: multiply_6},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"], 'Z': -0.1100})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': combine_xyz},
        attrs={'space': 'LOCAL'})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    named_attribute_4 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_4.outputs[1]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 0.0000), (0.5136, 0.1975), (1.0000, 1.0000)])
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_4, 4: -1.4400})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute.outputs[1], 4: map_range_3.outputs["Result"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_1.outputs["Result"]})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: reroute_5, 3: multiply_7},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    named_attribute_6 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_6 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_6.outputs[1]})
    node_utils.assign_curve(float_curve_6.mapping.curves[0], [(0.0000, 0.0000), (0.5136, 0.1975), (1.0000, 1.0000)])
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_6, 4: 0.2000})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_2.outputs[1], 2: 0.2500, 4: map_range_5.outputs["Result"]})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_3.outputs["Output"], 'Z': map_range_2.outputs["Result"]})
    
    rotate_euler_3 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_2, 'Rotate By': combine_xyz_2},
        attrs={'space': 'LOCAL'})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_1.outputs[1], 1: -0.1000, 2: 0.1000, 4: 3.1416})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: map_range_4.outputs["Result"]}, attrs={'operation': 'SINE'})
    
    named_attribute_5 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_5 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_5.outputs[1]})
    node_utils.assign_curve(float_curve_5.mapping.curves[0], [(0.0000, 0.8400), (0.5136, 0.1975), (1.0000, 1.0000)])
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_5, 4: -0.2300})
    
    map_range_8 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine, 4: map_range_6.outputs["Result"]})
    
    idle_noise = nw.new_node(nodegroup_idle_noise().name)
    
    multiply_8 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_8.outputs["Result"], 1: idle_noise},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_8})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_9, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_5 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_5.outputs["Switch"], 2: reroute_8, 3: multiply_9},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_7 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_9 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_7.outputs[1], 1: -0.1000, 2: 0.1000, 4: 3.1416})
    
    sine_1 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_9.outputs["Result"]}, attrs={'operation': 'SINE'})
    
    named_attribute_8 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_7 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_8.outputs[1]})
    node_utils.assign_curve(float_curve_7.mapping.curves[0], [(0.0000, 0.0000), (0.7364, 0.0000), (0.9409, 0.6337), (1.0000, 1.0000)], handles=['AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO'])
    
    map_range_11 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_7, 1: 0.1100, 2: 0.9500, 3: 0.1400, 4: -0.5500})
    
    map_range_10 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine_1, 4: map_range_11.outputs["Result"]})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_5.outputs["Output"], 'Z': map_range_10.outputs["Result"]})
    
    rotate_euler_4 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_3, 'Rotate By': combine_xyz_4},
        attrs={'space': 'LOCAL'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo_2 = nw.new_node(Nodes.Math, input_kwargs={0: index_1, 1: reroute_4}, attrs={'operation': 'MODULO'})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_2, 2: subtract})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.0000), (0.0191, 0.1563), (0.1773, 0.5425), (0.4045, 0.8213), (0.6864, 0.7725), (1.0000, 0.8075)])
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.0191, 0.1563), (0.0955, 0.5913), (0.3027, 0.8500), (0.7245, 0.9013), (1.0000, 0.4675)])
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_15.outputs["Result"], 2: float_curve_1, 3: float_curve_3})
    
    float_curve_8 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_8.mapping.curves[0], [(0.0000, 0.0000), (0.0771, 0.1543), (0.1545, 0.7713), (0.3545, 1.0000), (0.8227, 0.4313), (1.0000, 0.5375)], handles=['AUTO', 'AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO'])
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: map_range_16.outputs["Result"], 2: mix.outputs["Result"], 3: float_curve_8})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_1.outputs["Result"]})
    
    multiply_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_10, 'Y': multiply_10, 'Z': 1.0000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_19, 'Instance': store_named_attribute_4, 'Rotation': rotate_euler_4, 'Scale': reroute_22})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': instance_on_points})
    
    feather_main = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_5.outputs["Material"]})
    
    feather_main_1 = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feather_main, feather_main_1]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    simplefeatherprofile = nw.new_node(nodegroup_simple_feather_profile().name,
        input_kwargs={'Curve': reroute_6, 'Material': group_input_5.outputs["Material"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch To Simple"], 14: join_geometry, 15: simplefeatherprofile})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': instance_on_points})
    
    feather_high = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_5.outputs["Material"]})
    
    feather_high_1 = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_5.outputs["Material"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh_high, feather_high, feather_high_1]})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_5.outputs["Switch to Super High"], 14: switch_4.outputs[6], 15: join_geometry_1})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_5.outputs["Feather Scale"], 'Y': group_input_5.outputs["Feather Scale"], 'Z': group_input_5.outputs["Feather Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_6.outputs[6], 'Scale': combine_xyz_3})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather_01', singleton=False, type='GeometryNodeTree')
def nodegroup_feather_01(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_4 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketBool', 'Switch', False),
            ('NodeSocketBool', 'Switch To Simple', False),
            ('NodeSocketFloat', 'Feather Scale', 1.0000),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketInt', 'Feather Count', 24),
            ('NodeSocketBool', 'Switch to Super High', False),
            ('NodeSocketFloatFactor', 'Wing Profile', 0.0000),
            ('NodeSocketMaterial', 'Material', None)]) #surface.shaderfunc_to_material(shader_wing_primary)
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Curve"]})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Feather Count"]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_10})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_1, 'Count': reroute_21})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': (-1.0000, 0.0000, 0.0000)})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: reroute_17}, attrs={'operation': 'MODULO'})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_10, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': subtract})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo, 2: reroute_13})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_13.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1591, 0.0500), (0.3864, 0.1750), (0.7845, 0.8813), (1.0000, 1.0000)])
    
    map_range_16 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_4.outputs["Wing Profile"], 1: 0.5000})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_4.outputs["Wing Profile"], 2: 0.5000})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_15.outputs["Result"], 2: 1.1000, 3: 1.1900})
    
    mix_3 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_16.outputs["Result"], 2: mix_2.outputs["Result"], 3: 0.9500})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_2, 3: -0.3700, 4: mix_3.outputs["Result"]})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_4.outputs["Switch"], 2: map_range.outputs["Result"], 3: multiply},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': switch.outputs["Output"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': group_input_4.outputs["Rotation"], 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Tangent"]})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': reroute, 'Vector': reroute_3},
        attrs={'pivot_axis': 'X', 'axis': 'Y'})
    
    flapping_sine = nw.new_node(nodegroup_flapping_sine().name,
        input_kwargs={'Flap Speed': group_input_4.outputs["Flap Speed"], 'Offset Flap': 2.5000})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_3.outputs[1], 1: -1.0000, 2: 0.0000, 3: 1.5000, 4: 0.0000})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: flapping_sine, 1: map_range_7.outputs["Result"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_14, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_4.outputs["Switch"], 2: reroute_12, 3: multiply_2},
        attrs={'input_type': 'FLOAT'})
    
    index_3 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: index_3, 1: group_input_4.outputs["Feather Count"]},
        attrs={'operation': 'MODULO'})
    
    subtract_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_4.outputs["Feather Count"], 1: 1.0000},
        attrs={'operation': 'SUBTRACT'})
    
    map_range_14 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_1, 2: subtract_1})
    
    flapping_profile_xy = nw.new_node(nodegroup_flapping_profile_xy().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: switch_1.outputs["Output"], 1: flapping_profile_xy},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_3, 1: -0.2500}, attrs={'operation': 'MULTIPLY'})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_3})
    
    last_slap = nw.new_node(nodegroup_last_slap().name, input_kwargs={'Value': multiply_1})
    
    flapping_profile_z = nw.new_node(nodegroup_flapping_profile_z().name, input_kwargs={'Value': map_range_14.outputs["Result"]})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: last_slap, 1: flapping_profile_z}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_4, 'Y': reroute_11, 'Z': multiply_5})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector, 'Rotate By': combine_xyz_4},
        attrs={'space': 'LOCAL'})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    named_attribute_4 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_4.outputs[1]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 0.0000), (0.5136, 0.1975), (1.0000, 1.0000)])
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_4, 4: -1.8900})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute.outputs[1], 4: map_range_3.outputs["Result"]})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_1.outputs["Result"]})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_4.outputs["Switch"], 2: reroute_5, 3: multiply_6},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_7 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    named_attribute_8 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_7 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_8.outputs[1]})
    node_utils.assign_curve(float_curve_7.mapping.curves[0], [(0.0000, 0.0000), (0.5136, 0.1975), (1.0000, 1.0000)])
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_7, 4: 0.3000})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_7.outputs[1], 2: 0.2500, 4: map_range_5.outputs["Result"]})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_2.outputs["Result"]})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_2.outputs["Output"], 'Z': reroute_16})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': combine_xyz},
        attrs={'space': 'LOCAL'})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_1.outputs[1], 1: -0.1000, 2: 0.1000, 4: 3.1416})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: map_range_4.outputs["Result"]}, attrs={'operation': 'SINE'})
    
    named_attribute_5 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_5 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_5.outputs[1]})
    node_utils.assign_curve(float_curve_5.mapping.curves[0], [(0.0000, 0.8400), (0.5136, 0.1975), (1.0000, 1.0000)])
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_5, 3: -0.1500, 4: 0.0000})
    
    map_range_8 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine, 4: map_range_6.outputs["Result"]})
    
    idle_noise = nw.new_node(nodegroup_idle_noise().name)
    
    multiply_7 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_8.outputs["Result"], 1: idle_noise},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_7})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_9, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_4.outputs["Switch"], 2: reroute_8, 3: multiply_8},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_9 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_2.outputs[1], 1: -0.1000, 2: 0.1000, 4: 3.1416})
    
    sine_1 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_9.outputs["Result"]}, attrs={'operation': 'SINE'})
    
    named_attribute_6 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve_6 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_6.outputs[1]})
    node_utils.assign_curve(float_curve_6.mapping.curves[0], [(0.0000, 0.0000), (0.7364, 0.0000), (0.9409, 0.6337), (1.0000, 1.0000)], handles=['AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO'])
    
    map_range_11 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_6, 1: 0.1100, 2: 0.9500, 3: 0.1400, 4: -0.4600})
    
    map_range_10 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine_1, 4: map_range_11.outputs["Result"]})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': switch_4.outputs["Output"], 'Z': map_range_10.outputs["Result"]})
    
    rotate_euler_3 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_2, 'Rotate By': combine_xyz_3},
        attrs={'space': 'LOCAL'})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo_2 = nw.new_node(Nodes.Math, input_kwargs={0: index_1, 1: reroute_17}, attrs={'operation': 'MODULO'})
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': modulo_2, 2: subtract})
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.0000), (0.0701, 0.1700), (0.1704, 0.3938), (0.4045, 0.8313), (0.6591, 1.0000), (1.0000, 0.8375)])
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.0891, 0.3060), (0.1818, 0.5038), (0.3825, 0.8913), (0.6591, 0.7600), (1.0000, 1.0000)])
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_15.outputs["Result"], 2: float_curve_1, 3: float_curve_3})
    
    float_curve_8 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_12.outputs["Result"]})
    node_utils.assign_curve(float_curve_8.mapping.curves[0], [(0.0000, 0.0000), (0.0891, 0.4160), (0.1818, 0.5638), (0.3825, 0.7475), (0.5591, 0.6962), (0.7491, 0.8200), (1.0000, 0.8500)])
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: map_range_16.outputs["Result"], 2: mix.outputs["Result"], 3: float_curve_8})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_1.outputs["Result"]})
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4, 1: 1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_4, 'Y': multiply_9, 'Z': 1.0000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_5})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_19, 'Instance': store_named_attribute_4, 'Rotation': rotate_euler_3, 'Scale': reroute_22})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': instance_on_points})
    
    feather_main = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_4.outputs["Material"]})
    
    feather_main_1 = nw.new_node(nodegroup_feather_main().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_4.outputs["Material"], 'B': 24})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feather_main, feather_main_1]})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    simplefeatherprofile = nw.new_node(nodegroup_simple_feather_profile().name,
        input_kwargs={'Curve': reroute_6, 'Material': group_input_4.outputs["Material"]})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_4.outputs["Switch To Simple"], 14: join_geometry, 15: simplefeatherprofile})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': instance_on_points})
    
    feather_high = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': instance_on_points, 'Material': group_input_4.outputs["Material"]})
    
    feather_high_1 = nw.new_node(nodegroup_feather_high().name,
        input_kwargs={'Curve': instance_on_points, 'Switch': True, 'Material': group_input_4.outputs["Material"], 'B': 24})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh_high, feather_high, feather_high_1]})
    
    switch_5 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_4.outputs["Switch to Super High"], 14: switch_3.outputs[6], 15: join_geometry_1})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_4.outputs["Feather Scale"], 'Y': group_input_4.outputs["Feather Scale"], 'Z': group_input_4.outputs["Feather Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_5.outputs[6], 'Scale': combine_xyz_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': realize_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_scene_time', singleton=False, type='GeometryNodeTree')
def nodegroup_scene_time(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    scene_time_1 = nw.new_node('GeometryNodeInputSceneTime')
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'ix'}, attrs={'data_type': 'INT'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: scene_time_1.outputs["Frame"], 1: named_attribute_2.outputs[4]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Value': add}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_wing_flapping_motion', singleton=False, type='GeometryNodeTree')
def nodegroup_wing_flapping_motion(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketFloat', 'Wing Lenght', 0.5000),
            ('NodeSocketBool', 'Switch', False)])
    
    position = nw.new_node(Nodes.InputPosition)
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'pos'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    vector = nw.new_node(Nodes.Vector)
    vector.vector = (-1.0000, 0.0000, -0.1800)
    
    named_attribute_6 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'rot'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    vector_rotate_1 = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': vector, 'Rotation': named_attribute_6.outputs["Attribute"]},
        attrs={'rotation_type': 'EULER_XYZ'})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.4136, 0.7613), (1.0000, 1.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO'])
    
    tanh = nw.new_node(Nodes.Math, input_kwargs={0: float_curve}, attrs={'operation': 'TANH'})
    
    featherflapcurve = nw.new_node(nodegroup_feather_flap_curve().name)
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': featherflapcurve, 4: -3.1416})
    
    scenetime = nw.new_node(nodegroup_scene_time().name)
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: scenetime, 1: 4.5000})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: group_input.outputs["Flap Speed"]}, attrs={'operation': 'MULTIPLY'})
    
    map_range_4 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply, 1: 1.0000, 2: 25.0000, 4: 3.1416},
        attrs={'clamp': False})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_3.outputs["Result"], 1: map_range_4.outputs["Result"]})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: add_1}, attrs={'operation': 'SINE'})
    
    value = nw.new_node(Nodes.Value)
    value.outputs[0].default_value = 1.5000
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: value, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input.outputs["Switch"], 2: multiply_1, 3: reroute},
        attrs={'input_type': 'FLOAT'})
    
    map_range_9 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine, 4: switch.outputs["Output"]}, attrs={'clamp': False})
    
    named_attribute_5 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: 1.0000, 1: group_input.outputs["Wing Lenght"]},
        attrs={'operation': 'MULTIPLY'})
    
    map_range_10 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_5.outputs[1], 1: -1.0000, 2: -0.4000, 3: multiply_2, 4: 0.0000})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_10.outputs["Result"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_1})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: map_range_9.outputs["Result"], 1: reroute_4},
        attrs={'operation': 'MULTIPLY'})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': tanh, 2: 2.0000, 4: multiply_3})
    
    vector_rotate = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': position, 'Center': named_attribute_1.outputs["Attribute"], 'Axis': vector_rotate_1, 'Angle': map_range_2.outputs["Result"]})
    
    set_position_3 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Position': vector_rotate})
    
    featherflapcurve_1 = nw.new_node(nodegroup_feather_flap_curve().name)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': featherflapcurve_1, 4: -3.1416})
    
    scenetime_1 = nw.new_node(nodegroup_scene_time().name)
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Flap Speed"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_10})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: scenetime_1, 1: reroute_9}, attrs={'operation': 'MULTIPLY'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_4})
    
    map_range_5 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_3, 1: 1.0000, 2: 25.0000, 4: 3.1416},
        attrs={'clamp': False})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: map_range_5.outputs["Result"]})
    
    sine_1 = nw.new_node(Nodes.Math, input_kwargs={0: add_2}, attrs={'operation': 'SINE'})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    value_1 = nw.new_node(Nodes.Value)
    value_1.outputs[0].default_value = 0.5000
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': value_1})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_3.outputs[1], 1: -1.0000, 2: 0.0000, 3: reroute_12, 4: 0.0000})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: sine_1, 1: map_range_7.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_5})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_1})
    
    named_attribute_7 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'rot'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    vector_rotate_2 = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': reroute_11, 'Rotation': named_attribute_7.outputs["Attribute"]},
        attrs={'rotation_type': 'EULER_XYZ'})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_3, 'Offset': vector_rotate_2})
    
    map_range_6 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_3, 1: 1.0000, 2: 49.0000, 4: 6.2832},
        attrs={'clamp': False})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_6.outputs["Result"]})
    
    sine_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8}, attrs={'operation': 'SINE'})
    
    named_attribute_4 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    map_range_8 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_4.outputs[1], 1: -1.0000, 2: 0.0000, 3: multiply_6, 4: 0.0000})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_8.outputs["Result"]})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine_2, 1: -1.0000, 3: multiply_7, 4: reroute_7})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_1.outputs["Result"]})
    
    vector_rotate_3 = nw.new_node(Nodes.VectorRotate,
        input_kwargs={'Vector': combine_xyz_2, 'Rotation': named_attribute_7.outputs["Attribute"]},
        attrs={'rotation_type': 'EULER_XYZ'})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_1, 'Offset': vector_rotate_3})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_2}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_wing_idle_motion', singleton=False, type='GeometryNodeTree')
def nodegroup_wing_idle_motion(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Idle Noise', 0.1000),
            ('NodeSocketFloat', 'Wing Lenght', 0.5000)])
    
    featherflapcurve = nw.new_node(nodegroup_feather_flap_curve().name)
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': featherflapcurve, 1: 0.2500, 4: -3.1416})
    
    scenetime = nw.new_node(nodegroup_scene_time().name)
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: scenetime, 1: 6.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    map_range_5 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_3, 1: 1.0000, 2: 25.0000, 4: 3.1416},
        attrs={'clamp': False})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: map_range.outputs["Result"], 1: map_range_5.outputs["Result"]})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: add}, attrs={'operation': 'SINE'})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input.outputs["Idle Noise"], 1: group_input.outputs["Wing Lenght"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_1})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    map_range_7 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_3.outputs[1], 3: 0.0100, 4: reroute_12})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: sine, 1: map_range_7.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    idle_noise = nw.new_node(nodegroup_idle_noise().name)
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': idle_noise})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_2, 1: reroute}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_3})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Offset': combine_xyz_1})
    
    map_range_6 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_3, 1: 1.0000, 2: 49.0000, 4: 6.2832},
        attrs={'clamp': False})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_6.outputs["Result"]})
    
    sine_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_8}, attrs={'operation': 'SINE'})
    
    named_attribute_4 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    map_range_8 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_4.outputs[1], 3: -0.0100, 4: multiply_4})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_8.outputs["Result"]})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_2, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_2})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_6})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': sine_1, 1: -1.0000, 3: multiply_5, 4: reroute_7})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"], 1: reroute}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_6})
    
    set_position_2 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_1, 'Offset': combine_xyz_2})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_2}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_feather', singleton=False, type='ShaderNodeTree')
def nodegroup_feather(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketColor', 'Base Color', (0.8000, 0.0096, 0.0000, 1.0000))])
    
    hue_saturation_value = nw.new_node(Nodes.HueSaturationValue,
        input_kwargs={'Saturation': 0.9000, 'Value': 0.9000, 'Color': group_input.outputs["Base Color"]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': group_input.outputs["Base Color"], 'Subsurface': 0.1409, 'Subsurface Radius': (0.0100, 0.0100, 0.0100), 'Subsurface Color': hue_saturation_value, 'Specular': 0.1455, 'Specular Tint': 0.4409, 'Roughness': 0.5273, 'Sheen': 1.0000})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'BSDF': principled_bsdf}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_legs_b_e_t_a', singleton=False, type='GeometryNodeTree')
def nodegroup_legs_b_e_t_a(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_4 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Position', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Bird Speed', 0.0000),
            ('NodeSocketFloat', 'Max Wing Flapping', 0.5000),
            ('NodeSocketFloat', 'Flapping Speed', 0.5000),
            ('NodeSocketVector', 'Look Ahead', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Tail width', 1.0000),
            ('NodeSocketFloat', 'Tail Lenght', 0.5000),
            ('NodeSocketBool', 'Simple Feather', False),
            ('NodeSocketFloatFactor', 'Tail Profile', 1.0000),
            ('NodeSocketVectorTranslation', 'Offset Tail', (-0.1900, 0.0000, 0.0000)),
            ('NodeSocketBool', 'Switch to super high', True),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_tail_primary)
            ('NodeSocketFloat', 'Scale', 1.0000),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Index', 0)])
    
    curve_to_points_2 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': group_input_4.outputs["Curve"], 'Count': 1})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_4.outputs["Tail width"], 1: group_input_4.outputs["Scale"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_1})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_1})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz, 'End': combine_xyz_2})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 2})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Offset Tail"]})
    
    transform_geometry = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': resample_curve_1, 'Translation': reroute_2})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': transform_geometry, 'Name': 'fac', 4: spline_parameter.outputs["Factor"]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_1})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_2.outputs["Points"], 'Instance': reroute_9})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={3: 100.0000, 5: 500}, attrs={'data_type': 'INT'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input_4.outputs["Index"], 1: random_value.outputs[2]})
    
    store_named_attribute_5 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': instance_on_points_3, 'Name': 'ix', 7: add},
        attrs={'data_type': 'INT', 'domain': 'INSTANCE'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Position"]})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': store_named_attribute_5, 'Position': reroute})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Rotation"]})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': set_position, 'Rotation': reroute_41})
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input_4.outputs["Look Ahead"]})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_4.outputs["Max Wing Flapping"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Max Wing Flapping"]})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_43})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': separate_xyz_2.outputs["Y"], 1: -0.5000, 2: 1.5708, 3: multiply_2, 4: reroute_42})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': rotate_instances, 'Name': 'angle', 4: map_range_2.outputs["Result"]},
        attrs={'domain': 'INSTANCE'})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': store_named_attribute})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': realize_instances, 'Count': 2})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': 12, 'Start': (-0.0900, 0.0000, 0.0000), 'Middle': (-0.1400, 0.0000, -0.1900), 'End': (0.0000, 0.0000, -0.2700)})
    
    instance_rotation = nw.new_node('GeometryNodeInputInstanceRotation')
    
    sample_index = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': store_named_attribute, 3: instance_rotation, 'Index': group_input_4.outputs["Index"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'INSTANCE'})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': sample_index.outputs[2]})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    sample_index_1 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': store_named_attribute, 1: named_attribute_2.outputs[1]},
        attrs={'domain': 'INSTANCE'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': sample_index_1.outputs["Value"], 1: -1.0000, 2: 0.0000, 3: 1.5708, 4: 1.1000})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range.outputs["Result"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': reroute_4, 'Rotate By': combine_xyz_1},
        attrs={'space': 'LOCAL'})
    
    named_attribute_3 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    sample_index_2 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': store_named_attribute, 1: named_attribute_3.outputs[1]},
        attrs={'domain': 'INSTANCE'})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': sample_index_2.outputs["Value"], 2: 0.5000, 3: 0.1000, 4: 1.1408})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_1.outputs["Result"]})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler, 'Rotate By': combine_xyz_3},
        attrs={'space': 'LOCAL'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler_2})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_4.outputs["Scale"], 'Y': group_input_4.outputs["Scale"], 'Z': group_input_4.outputs["Scale"]})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': quadratic_bezier, 'Rotation': reroute_3, 'Scale': combine_xyz_5})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    store_named_attribute_3 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': instance_on_points, 'Name': 'tan', 3: curve_tangent},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_1.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.1045, 0.9375), (0.2909, 0.8125), (0.5000, 0.4188), (0.6682, 0.2375), (0.8091, 0.2375), (0.9591, 0.1562), (1.0000, 0.1000)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': store_named_attribute_3, 'Radius': float_curve})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: group_input_4.outputs["Scale"]}, attrs={'operation': 'MULTIPLY'})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: 0.1000, 1: multiply_3}, attrs={'operation': 'MULTIPLY'})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 8, 'Radius': multiply_4})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    reverse_curve = nw.new_node(Nodes.ReverseCurve, input_kwargs={'Curve': instance_on_points})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reverse_curve, 'Count': 1})
    
    quadratic_bezier_1 = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': 3, 'Start': (0.0000, 0.0000, 0.0000), 'Middle': (0.0800, 0.0000, 0.0700), 'End': (0.1400, 0.0000, -0.0400)})
    
    fillet_curve = nw.new_node(Nodes.FilletCurve,
        input_kwargs={'Curve': quadratic_bezier_1, 'Count': 2, 'Radius': 0.0200, 'Limit Radius': True},
        attrs={'mode': 'POLY'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': fillet_curve})
    
    transform_geometry_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': reroute_6, 'Rotation': (0.0000, 0.0000, 0.4363)})
    
    transform_geometry_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': reroute_6, 'Rotation': (0.0000, 0.0000, -0.4363)})
    
    transform_geometry_4 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': reroute_6, 'Rotation': (0.0000, 2.6372, 3.1416), 'Scale': (0.6500, 0.6500, 0.6500)})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [reroute_6, transform_geometry_1, transform_geometry_2, transform_geometry_4]})
    
    transform_geometry_3 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': join_geometry_2, 'Rotation': (0.0000, 1.6947, 0.0000)})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_4.outputs["Scale"], 'Y': group_input_4.outputs["Scale"], 'Z': group_input_4.outputs["Scale"]})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': transform_geometry_3, 'Scale': combine_xyz_4})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_1})
    
    spline_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_2.outputs["Factor"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 0.5000), (0.2909, 0.8125), (0.5000, 0.4188), (0.6682, 0.2375), (0.8091, 0.2375), (0.9591, 0.1562), (1.0000, 0.1000)])
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': reroute_5, 'Radius': float_curve_1})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: 0.0200, 1: group_input_4.outputs["Scale"]}, attrs={'operation': 'MULTIPLY'})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 8, 'Radius': multiply_5})
    
    transform_geometry_5 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_circle_1.outputs["Curve"]})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius_1, 'Profile Curve': transform_geometry_5, 'Fill Caps': True})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_to_mesh, curve_to_mesh_1]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_1, 'Material': surface.shaderfunc_to_material(shader_beak)})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh})
    
    distribute_points_on_faces = nw.new_node(Nodes.DistributePointsOnFaces, input_kwargs={'Mesh': reroute_8, 'Density': 2500.0000})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': distribute_points_on_faces.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine)
    
    spline_parameter_4 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_4.outputs["Factor"]})
    
    simplefeathertail_profile = nw.new_node(nodegroup_simple_feather_tail_profile().name,
        input_kwargs={'Curve': store_named_attribute_2, 'Material': group_input_4.outputs["Material"]})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'tan'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': distribute_points_on_faces.outputs["Rotation"], 'Factor': 0.9583, 'Vector': named_attribute_1.outputs["Attribute"]},
        attrs={'axis': 'Z'})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector, 'Factor': 0.9421, 'Vector': distribute_points_on_faces.outputs["Normal"]},
        attrs={'pivot_axis': 'Z', 'axis': 'Y'})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector_1, 'Rotate By': (-0.0553, 0.0000, 0.0000)},
        attrs={'space': 'LOCAL'})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_7, 'Instance': simplefeathertail_profile, 'Rotation': rotate_euler_1, 'Scale': (0.4600, 1.0000, 0.0900)})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material, instance_on_points_2]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry_3}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_tail', singleton=False, type='GeometryNodeTree')
def nodegroup_tail(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_23 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Position', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Bird Speed', 0.0000),
            ('NodeSocketFloat', 'Max Wing Flapping', 0.5000),
            ('NodeSocketFloat', 'Flapping Speed', 0.5000),
            ('NodeSocketVector', 'Look Ahead', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Tail width', 1.0000),
            ('NodeSocketFloat', 'Tail Lenght', 0.5000),
            ('NodeSocketBool', 'Simple Feather', False),
            ('NodeSocketFloatFactor', 'Tail Profile', 1.0000),
            ('NodeSocketVectorTranslation', 'Offset Tail', (-0.1900, 0.0000, 0.0000)),
            ('NodeSocketFloatAngle', 'Tail Angle', 0.1745),
            ('NodeSocketBool', 'Switch to super high', True),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_tail_primary)
            ('NodeSocketInt', 'Count', 13),
            ('NodeSocketInt', 'Index', 0),
            ('NodeSocketGeometry', 'Curve', None)])
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': group_input_23.outputs["Curve"], 'Count': 1})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Tail width"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_1})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz, 'End': combine_xyz_2})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 4})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': resample_curve_1, 'Translation': group_input_23.outputs["Offset Tail"]})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': transform_geometry, 'Name': 'fac', 4: spline_parameter.outputs["Factor"]})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': store_named_attribute_1})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={3: 100.0000, 5: 500}, attrs={'data_type': 'INT'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input_23.outputs["Index"], 1: random_value.outputs[2]})
    
    store_named_attribute_5 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': instance_on_points_1, 'Name': 'ix', 7: add},
        attrs={'data_type': 'INT', 'domain': 'INSTANCE'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Position"]})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': store_named_attribute_5, 'Position': reroute})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Rotation"]})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': set_position, 'Rotation': reroute_41})
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input_23.outputs["Look Ahead"]})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_23.outputs["Max Wing Flapping"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Max Wing Flapping"]})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_43})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': separate_xyz_2.outputs["Y"], 1: -1.5708, 2: 1.5708, 3: multiply_1, 4: reroute_42})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': rotate_instances, 'Name': 'angle', 4: map_range_2.outputs["Result"]},
        attrs={'domain': 'INSTANCE'})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': store_named_attribute})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': realize_instances, 'Count': group_input_23.outputs["Count"]})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_23.outputs["Tail Lenght"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_2})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': (0.1800, 0.0000, 0.0000), 'End': combine_xyz_3})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_1.outputs["Factor"]})
    
    instance_rotation = nw.new_node('GeometryNodeInputInstanceRotation')
    
    sample_index = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': store_named_attribute, 3: instance_rotation, 'Index': group_input_23.outputs["Index"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'INSTANCE'})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': sample_index.outputs[2]})
    
    scenetime = nw.new_node(nodegroup_scene_time().name)
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: scenetime, 1: group_input_23.outputs["Flapping Speed"]},
        attrs={'operation': 'MULTIPLY'})
    
    map_range_9 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply_3, 1: 1.0000, 2: 49.0000, 4: 6.2832},
        attrs={'clamp': False})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_9.outputs["Result"]})
    
    cosine = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4}, attrs={'operation': 'COSINE'})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    sample_index_1 = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': store_named_attribute, 1: named_attribute_2.outputs[1]},
        attrs={'domain': 'INSTANCE'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': sample_index_1.outputs["Value"]})
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_5, 1: -1.0000, 2: 0.0000, 3: 2.0000, 4: 0.0000})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: cosine, 1: map_range_4.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    pingpongindex = nw.new_node(nodegroup_ping_pong_index().name, input_kwargs={'To Max': 0.1000})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: pingpongindex, 1: 0.3500})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_4, 1: add_1}, attrs={'operation': 'MULTIPLY'})
    
    pingpongindex_1 = nw.new_node(nodegroup_ping_pong_index().name, input_kwargs={'To Max': 0.1000})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_5, 1: pingpongindex_1})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute.outputs[1], 4: 2.0000})
    
    cosine_1 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_1.outputs["Result"]}, attrs={'operation': 'COSINE'})
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': sample_index_1.outputs["Value"], 1: -1.0000, 3: 1.0000, 4: -0.5000})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_3.outputs["Result"]})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: map_range_3.outputs["Result"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': cosine_1, 3: reroute_3, 4: multiply_6})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': add_2, 'Z': map_range.outputs["Result"]})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': reroute_2, 'Rotate By': combine_xyz_4},
        attrs={'space': 'LOCAL'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': group_input_23.outputs["Tail Angle"]})
    
    rotate_euler_1 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler, 'Rotate By': combine_xyz_6},
        attrs={'space': 'LOCAL'})
    
    rotate_euler_2 = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': rotate_euler_1, 'Rotate By': (0.0000, 0.1868, 0.0000)},
        attrs={'space': 'LOCAL'})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler_2})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'fac'})
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_1.outputs[1]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.3500, 0.5000), (0.5000, 1.0000), (0.6500, 0.5000), (1.0000, 0.0000)])
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': named_attribute_1.outputs[1]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 1.0000), (0.2500, 0.7500), (0.5000, 0.5000), (0.7500, 0.7500), (1.0000, 1.0000)], handles=['AUTO', 'AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: group_input_23.outputs["Tail Profile"], 2: float_curve, 3: float_curve_1})
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': mix.outputs["Result"]})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': map_range_6.outputs["Result"], 'Y': 1.0000, 'Z': 1.0000})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': store_named_attribute_2, 'Rotation': reroute_6, 'Scale': combine_xyz_1})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points})
    
    bonetomesh = nw.new_node(nodegroup_bone_to_mesh().name, input_kwargs={'Curve': reroute_8})
    
    feathertail = nw.new_node(nodegroup_feather_tail().name,
        input_kwargs={'Curve': reroute_8, 'Material': group_input_23.outputs["Material"]})
    
    feathertail_1 = nw.new_node(nodegroup_feather_tail().name,
        input_kwargs={'Curve': reroute_8, 'Switch': True, 'Material': group_input_23.outputs["Material"]})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [bonetomesh, feathertail, feathertail_1]})
    
    simplefeathertail_profile = nw.new_node(nodegroup_simple_feather_tail_profile().name,
        input_kwargs={'Curve': reroute_8, 'Material': group_input_23.outputs["Material"]})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_23.outputs["Simple Feather"], 14: join_geometry_1, 15: simplefeathertail_profile})
    
    bonetomesh_high = nw.new_node(nodegroup_bone_to_mesh_high().name, input_kwargs={'Curve': reroute_8})
    
    feather_high_tail = nw.new_node(nodegroup_feather_high_tail().name,
        input_kwargs={'Curve': reroute_8, 'Material': group_input_23.outputs["Material"]})
    
    feather_high_tail_1 = nw.new_node(nodegroup_feather_high_tail().name,
        input_kwargs={'Curve': reroute_8, 'Switch': True, 'Material': group_input_23.outputs["Material"]})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [bonetomesh_high, feather_high_tail, feather_high_tail_1]})
    
    switch_5 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_23.outputs["Switch to super high"], 14: switch_4.outputs[6], 15: join_geometry_2})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_23.outputs["Tail Lenght"], 'Y': group_input_23.outputs["Tail Lenght"], 'Z': group_input_23.outputs["Tail Lenght"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': switch_5.outputs[6], 'Scale': combine_xyz_5})
    
    realize_instances_1 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': scale_instances})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points, realize_instances_1]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_body_b_e_t_a', singleton=False, type='GeometryNodeTree')
def nodegroup_body_b_e_t_a(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_8 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Position', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloatFactor', 'Profile', 0.0000),
            ('NodeSocketMaterial', 'Body Material', None), #surface.shaderfunc_to_material(shader_body)
            ('NodeSocketMaterial', 'Body Feather', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketFloat', 'Body Scale', 1.0000),
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketFloat', 'Beak scale', 0.0000)])
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': group_input_8.outputs["Curve"], 'Count': 2})
    
    quadratic_bezier = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Start': (-0.3500, 0.0000, 0.0700), 'Middle': (0.0000, 0.0000, -0.0400), 'End': (0.3900, 0.0000, 0.1600)})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': quadratic_bezier})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': reroute_1, 'Count': 26})
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_8.outputs["Profile"], 1: 0.5000})
    
    map_range_3 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_8.outputs["Profile"], 2: 0.5000})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 0.0000), (0.1538, 0.0000), (0.3022, 0.2987), (0.7084, 1.0000), (0.8504, 0.5362), (0.9409, 0.3137), (0.9773, 0.0000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO', 'AUTO'])
    
    spline_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_2.outputs["Factor"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0000), (0.1538, 0.0000), (0.3022, 0.3547), (0.7084, 0.7900), (0.8458, 0.4925), (0.9000, 0.4437), (0.9409, 0.1437), (0.9727, 0.0000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO', 'AUTO', 'AUTO'])
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_3.outputs["Result"], 2: float_curve, 3: float_curve_2})
    
    spline_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_3.outputs["Factor"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.1538, 0.0000), (0.2762, 0.4777), (0.3955, 0.7188), (0.6384, 1.0000), (0.7364, 0.4063), (0.8455, 0.3950), (0.8826, 0.5312), (0.9227, 0.4687), (0.9489, 0.1750), (0.9818, 0.0072), (1.0000, 0.0000)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO', 'AUTO', 'AUTO'])
    
    mix_1 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_4.outputs["Result"], 2: mix.outputs["Result"], 3: float_curve_3})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve, 'Radius': mix_1.outputs["Result"]})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_1.outputs["Factor"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0045, 0.6400), (0.2409, 0.4400), (0.5818, 0.5063), (0.7818, 0.5000), (0.9227, 0.1938), (0.9636, 0.1000), (1.0000, 0.0000)], handles=['AUTO', 'AUTO', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'AUTO', 'AUTO', 'AUTO'])
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': float_curve_1, 3: -1.0000})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': map_range.outputs["Result"], 1: -1.0000, 2: 0.0000, 3: -0.1900, 4: 0.0000})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_1.outputs["Result"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_curve_radius, 'Offset': combine_xyz})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': set_position_1, 'Name': 'tan', 3: curve_tangent},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    spline_parameter_6 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': store_named_attribute_2, 'Name': 'fac2', 4: spline_parameter_6.outputs["Factor"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 48, 'Radius': 0.1500})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': store_named_attribute_1, 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    transform_geometry = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_to_mesh, 'Translation': (-0.1600, 0.0000, -0.1100), 'Scale': (1.2900, 0.9600, 1.0000)})
    
    instance_on_points_4 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': transform_geometry})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': instance_on_points_4, 'Position': group_input_8.outputs["Position"]})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': set_position, 'Rotation': group_input_8.outputs["Rotation"]})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input_8.outputs["Rotation"]})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': separate_xyz.outputs["Y"], 1: -1.0000, 3: -0.2500, 4: 0.2500})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_2.outputs["Result"]})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': rotate_instances, 'Rotation': combine_xyz_1})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': rotate_instances_1, 'Material': group_input_8.outputs["Body Material"]})
    
    distribute_points_on_faces = nw.new_node(Nodes.DistributePointsOnFaces, input_kwargs={'Mesh': rotate_instances_1, 'Density': 2500.0000})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': distribute_points_on_faces.outputs["Points"]})
    
    curve_line = nw.new_node(Nodes.CurveLine)
    
    spline_parameter_4 = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': curve_line, 'Name': 'fac', 4: spline_parameter_4.outputs["Factor"]})
    
    simplefeathertail_profile = nw.new_node(nodegroup_simple_feather_tail_profile().name,
        input_kwargs={'Curve': store_named_attribute, 'Material': None})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'tan'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': distribute_points_on_faces.outputs["Rotation"], 'Factor': 0.9617, 'Vector': named_attribute_1.outputs["Attribute"]},
        attrs={'axis': 'Z'})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector, 'Factor': 0.9421, 'Vector': distribute_points_on_faces.outputs["Normal"]},
        attrs={'pivot_axis': 'Z', 'axis': 'Y'})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': align_euler_to_vector_1, 'Rotate By': (3.4784, 0.0000, 0.0000)},
        attrs={'space': 'LOCAL'})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute, 'Instance': simplefeathertail_profile, 'Rotation': rotate_euler, 'Scale': (0.6900, 0.0700, 0.0900)})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': instance_on_points, 'Material': group_input_8.outputs["Body Feather"]})
    
    map_range_7 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_8.outputs["Profile"], 1: 0.5000})
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_8.outputs["Profile"], 2: 0.5000})
    
    mix_2 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_6.outputs["Result"], 2: 0.0500, 3: 0.0300})
    
    mix_3 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_7.outputs["Result"], 2: mix_2.outputs["Result"], 3: 0.0500})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_3.outputs["Result"]})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_3})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_3, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'Start': combine_xyz_3, 'End': combine_xyz_4})
    
    transform_geometry_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_line_1, 'Translation': (0.2800, 0.0000, -0.0700)})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': transform_geometry_1, 'Count': 2})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': 0.0250, 'Subdivisions': 2})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': ico_sphere.outputs["Mesh"]})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_eyes)})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': set_material_2})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': instance_on_points_1})
    
    set_position_2 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': instance_on_points_3, 'Position': group_input_8.outputs["Position"]})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': set_position_2, 'Rotation': group_input_8.outputs["Rotation"]})
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input_8.outputs["Rotation"]})
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': separate_xyz_1.outputs["Y"], 1: -1.0000, 3: -0.2500, 4: 0.2500})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_5.outputs["Result"]})
    
    rotate_instances_3 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': rotate_instances_2, 'Rotation': combine_xyz_2})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_instances_3})
    
    map_range_10 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_8.outputs["Profile"], 1: 0.5000})
    
    map_range_9 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_8.outputs["Profile"], 2: 0.5000})
    
    mix_5 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_9.outputs["Result"], 2: 0.3700, 3: 0.2500})
    
    mix_4 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_10.outputs["Result"], 2: mix_5.outputs["Result"], 3: 0.4500})
    
    mix_7 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_9.outputs["Result"], 2: -0.0700, 3: -0.1400})
    
    mix_6 = nw.new_node(Nodes.Mix, input_kwargs={0: map_range_10.outputs["Result"], 2: mix_7.outputs["Result"], 3: -0.0300})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix_6.outputs["Result"]})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': mix_4.outputs["Result"], 'Z': reroute_6})
    
    quadratic_bezier_1 = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Start': (0.2500, 0.0000, 0.0100), 'Middle': (0.3400, 0.0000, -0.0100), 'End': combine_xyz_6})
    
    spline_parameter_5 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_4 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': spline_parameter_5.outputs["Factor"]})
    node_utils.assign_curve(float_curve_4.mapping.curves[0], [(0.0000, 1.0000), (0.4818, 0.7600), (1.0000, 0.0000)])
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': quadratic_bezier_1, 'Radius': float_curve_4})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 8, 'Radius': 0.0550})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius_1, 'Profile Curve': curve_circle_1.outputs["Curve"]})
    
    transform_geometry_2 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_to_mesh_1, 'Translation': (0.0000, 0.0000, -0.0900)})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': transform_geometry_2, 'Material': surface.shaderfunc_to_material(shader_beak)})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_3})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_8.outputs["Beak scale"]})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_7, 'Y': reroute_7, 'Z': reroute_7})
    
    instance_on_points_2 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_1.outputs["Points"], 'Instance': reroute_5, 'Scale': combine_xyz_8})
    
    set_position_3 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': instance_on_points_2, 'Position': group_input_8.outputs["Position"]})
    
    rotate_instances_4 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': set_position_3, 'Rotation': group_input_8.outputs["Rotation"]})
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input_8.outputs["Rotation"]})
    
    map_range_8 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': separate_xyz_2.outputs["Y"], 1: -1.0000, 3: -0.2500, 4: 0.2500})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range_8.outputs["Result"]})
    
    rotate_instances_5 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': rotate_instances_4, 'Rotation': combine_xyz_5})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_instances_5})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material_1, set_material, reroute_2, reroute_4]})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ,
        input_kwargs={'X': group_input_8.outputs["Body Scale"], 'Y': group_input_8.outputs["Body Scale"], 'Z': group_input_8.outputs["Body Scale"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': join_geometry, 'Scale': combine_xyz_7})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': scale_instances}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_corner_tilt', singleton=False, type='GeometryNodeTree')
def nodegroup_corner_tilt(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'pos0', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'pos1', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'pos2', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloat', 'Lean On Corners', 1.0000)])
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["pos1"], 1: (1.0000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["pos0"], 1: (1.0000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply.outputs["Vector"], 1: multiply_1.outputs["Vector"]},
        attrs={'operation': 'SUBTRACT'})
    
    length = nw.new_node(Nodes.VectorMath, input_kwargs={0: subtract.outputs["Vector"]}, attrs={'operation': 'LENGTH'})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: 1.0000, 1: length.outputs["Value"]}, attrs={'operation': 'DIVIDE'})
    
    scale = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 'Scale': divide},
        attrs={'operation': 'SCALE'})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["pos2"], 1: (1.0000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_3 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["pos1"], 1: (1.0000, 1.0000, 0.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    subtract_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_2.outputs["Vector"], 1: multiply_3.outputs["Vector"]},
        attrs={'operation': 'SUBTRACT'})
    
    length_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: subtract_1.outputs["Vector"]}, attrs={'operation': 'LENGTH'})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: 1.0000, 1: length_1.outputs["Value"]}, attrs={'operation': 'DIVIDE'})
    
    scale_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract_1.outputs["Vector"], 'Scale': divide_1},
        attrs={'operation': 'SCALE'})
    
    cross_product = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: scale.outputs["Vector"], 1: scale_1.outputs["Vector"]},
        attrs={'operation': 'CROSS_PRODUCT'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': cross_product.outputs["Vector"]})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': separate_xyz.outputs["Z"], 4: group_input.outputs["Lean On Corners"]},
        attrs={'clamp': False})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Result': map_range.outputs["Result"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_main_rotation', singleton=False, type='GeometryNodeTree')
def nodegroup_main_rotation(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'pos 0', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'pos 1', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVector', 'tan 0', (0.0000, 0.0000, 1.0000))])
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Vector': group_input.outputs["tan 0"]},
        attrs={'pivot_axis': 'Z'})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: group_input.outputs["pos 0"], 1: group_input.outputs["pos 1"]},
        attrs={'operation': 'SUBTRACT'})
    
    align_euler_to_vector_2 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': align_euler_to_vector, 'Vector': subtract.outputs["Vector"]},
        attrs={'pivot_axis': 'Y'})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Rotation': align_euler_to_vector_2}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_time__speed', singleton=False, type='GeometryNodeTree')
def nodegroup_time__speed(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    scene_time = nw.new_node('GeometryNodeInputSceneTime')
    
    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Offset Time', 1.0000),
            ('NodeSocketFloat', 'Speed', 100.0000)])
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: scene_time.outputs["Frame"], 1: group_input.outputs["Offset Time"]})
    
    map_range_1 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': add, 2: 250.0000, 4: group_input.outputs["Speed"]},
        attrs={'clamp': False})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Result': map_range_1.outputs["Result"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_wind_structures', singleton=False, type='GeometryNodeTree')
def nodegroup_wind_structures(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_23 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketVector', 'Position', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketVectorEuler', 'Rotation', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketBool', 'Invert', False),
            ('NodeSocketFloat', 'Wing Lenght', 1.0000),
            ('NodeSocketFloat', 'Max Wing Flapping', 0.5000),
            ('NodeSocketBool', 'Simple Wing', False),
            ('NodeSocketFloat', 'Flap Speed', 5.0000),
            ('NodeSocketVectorEuler', 'Look Ahead', (0.0000, 0.0000, 0.0000)),
            ('NodeSocketFloatFactor', 'Manual Flapping', 0.0000),
            ('NodeSocketBool', 'Switch to super high', False),
            ('NodeSocketFloatFactor', 'Wing Profile', 0.0000),
            ('NodeSocketMaterial', 'Material', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketMaterial', 'Material1', None), #surface.shaderfunc_to_material(shader_wing_secondary)
            ('NodeSocketMaterial', 'Material2', None), #surface.shaderfunc_to_material(shader_wing_primary_covers)
            ('NodeSocketMaterial', 'Material3', None), #surface.shaderfunc_to_material(shader_wing_secondary_covers)
            ('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketInt', 'Index', 0)])
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': group_input_23.outputs["Curve"], 'Count': 1})
    
    switch_3 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: -1.0000, 3: 1.0000},
        attrs={'input_type': 'FLOAT'})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_23.outputs["Wing Lenght"], 1: switch_3.outputs["Output"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_6})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_1, 'Count': 4})
    
    index = nw.new_node(Nodes.Index)
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': index, 2: 3.0000})
    
    float_curve_2 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_4.outputs["Result"]})
    node_utils.assign_curve(float_curve_2.mapping.curves[0], [(0.0000, 0.0360), (0.3330, 0.1738), (0.6667, 0.1538), (1.0000, 0.0600)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: float_curve_2, 1: group_input_23.outputs["Wing Lenght"]},
        attrs={'operation': 'MULTIPLY'})
    
    float_curve_3 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': map_range_4.outputs["Result"]})
    node_utils.assign_curve(float_curve_3.mapping.curves[0], [(0.0000, 0.0000), (0.3421, 0.1138), (0.6667, 0.0638), (1.0000, 0.0850)], handles=['AUTO', 'AUTO_CLAMPED', 'AUTO', 'AUTO'])
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: float_curve_3, 1: group_input_23.outputs["Wing Lenght"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply_1, 'Z': multiply_2})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': resample_curve_1, 'Offset': combine_xyz_3})
    
    spline_parameter = nw.new_node(Nodes.SplineParameter)
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': set_position_3, 'Name': 'fac', 4: spline_parameter.outputs["Factor"]})
    
    trim_curve = nw.new_node(Nodes.TrimCurve, input_kwargs={'Curve': store_named_attribute_1, 2: 0.0396})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': trim_curve})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': reroute_7})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={3: 100.0000, 5: 500}, attrs={'data_type': 'INT'})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input_23.outputs["Index"], 1: random_value.outputs[2]})
    
    store_named_attribute_5 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': instance_on_points, 'Name': 'ix', 7: add},
        attrs={'data_type': 'INT', 'domain': 'INSTANCE'})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': store_named_attribute_5, 'Position': group_input_23.outputs["Position"]})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Rotation"]})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': set_position, 'Rotation': reroute_14})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Manual Flapping"]})
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': group_input_23.outputs["Look Ahead"]})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_23.outputs["Max Wing Flapping"], 1: -1.0000},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_23.outputs["Max Wing Flapping"]})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': separate_xyz_2.outputs["Y"], 1: -1.1000, 2: 1.5708, 3: multiply_3, 4: reroute_16})
    
    mix = nw.new_node(Nodes.Mix, input_kwargs={0: reroute_3, 2: map_range_2.outputs["Result"], 3: -0.2000})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': mix.outputs["Result"]})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': rotate_instances, 'Name': 'angle', 4: reroute_6},
        attrs={'domain': 'INSTANCE'})
    
    position = nw.new_node(Nodes.InputPosition)
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': store_named_attribute, 'Name': 'pos', 3: position},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'INSTANCE'})
    
    scenetime = nw.new_node(nodegroup_scene_time().name)
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: scenetime, 1: group_input_23.outputs["Flap Speed"]},
        attrs={'operation': 'MULTIPLY'})
    
    map_range_9 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': multiply_4, 1: 1.0000, 2: 49.0000, 4: 6.2832},
        attrs={'clamp': False})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_9.outputs["Result"]})
    
    sine = nw.new_node(Nodes.Math, input_kwargs={0: reroute_4}, attrs={'operation': 'SINE'})
    
    named_attribute = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute.outputs[1], 1: -1.0000, 2: 0.0000, 3: 1.0000, 4: 0.0000})
    
    multiply_5 = nw.new_node(Nodes.Math, input_kwargs={0: sine, 1: map_range_3.outputs["Result"]}, attrs={'operation': 'MULTIPLY'})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_5})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_5})
    
    multiply_6 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_5, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute, 3: multiply_6},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': switch.outputs["Output"]})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': store_named_attribute_2, 'Rotation': combine_xyz})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_instances_1})
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_23.outputs["Wing Profile"], 1: 0.5000})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': group_input_23.outputs["Wing Profile"], 2: 0.5000})
    
    named_attribute_5 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_10 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_5.outputs[1], 1: -0.0100, 4: -2.2916})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_10.outputs["Result"]})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_11})
    
    multiply_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_11, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_1 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute_10, 3: multiply_7},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_6 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_11 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_6.outputs[1], 1: -0.0100, 3: 0.3400, 4: 0.0000})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_11.outputs["Result"]})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_18, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_2 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute_15, 3: multiply_8},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': switch_1.outputs["Output"], 'Z': switch_2.outputs["Output"]})
    
    named_attribute_7 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_13 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_7.outputs[1], 1: -0.0100, 4: -1.6016})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_13.outputs["Result"]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_19, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_4 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute_12, 3: multiply_9},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_8 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_14 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_8.outputs[1], 1: -0.0100, 3: 0.2200, 4: 0.0000})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_14.outputs["Result"]})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    multiply_10 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_27, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_5 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute_21, 3: multiply_10},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': switch_4.outputs["Output"], 'Z': switch_5.outputs["Output"]})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: map_range_1.outputs["Result"], 6: combine_xyz_4, 7: combine_xyz_5},
        attrs={'data_type': 'RGBA'})
    
    named_attribute_9 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_15 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': named_attribute_9.outputs[1], 1: -0.0100, 4: 0.6184})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_15.outputs["Result"]})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_29})
    
    multiply_11 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_29, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_6 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute_28, 3: multiply_11},
        attrs={'input_type': 'FLOAT'})
    
    named_attribute_10 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range_16 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_10.outputs[1], 1: -0.0100, 3: 0.1500, 4: 0.0000})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_16.outputs["Result"]})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    multiply_12 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_31, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    switch_7 = nw.new_node(Nodes.Switch,
        input_kwargs={0: group_input_23.outputs["Invert"], 2: reroute_30, 3: multiply_12},
        attrs={'input_type': 'FLOAT'})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': switch_6.outputs["Output"], 'Z': switch_7.outputs["Output"]})
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: map_range_6.outputs["Result"], 6: mix_1.outputs[2], 7: combine_xyz_7},
        attrs={'data_type': 'RGBA'})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': reroute_13, 'Rotation': mix_2.outputs[2]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_instances_2})
    
    named_attribute_1 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'angle'})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': named_attribute_1.outputs[1], 1: -1.0000, 2: 0.0000, 3: 0.5000, 4: 0.0000})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': map_range.outputs["Result"]})
    
    rotate_instances_3 = nw.new_node(Nodes.RotateInstances, input_kwargs={'Instances': reroute_9, 'Rotation': combine_xyz_1})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_instances_3})
    
    instance_rotation_1 = nw.new_node('GeometryNodeInputInstanceRotation')
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': reroute_8, 'Name': 'rot', 3: instance_rotation_1},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'INSTANCE'})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_4})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': reroute_1})
    
    wing_flapping_motion = nw.new_node(nodegroup_wing_flapping_motion().name,
        input_kwargs={'Geometry': realize_instances, 'Flap Speed': group_input_23.outputs["Flap Speed"], 'Wing Lenght': group_input_23.outputs["Wing Lenght"], 'Switch': group_input_23.outputs["Invert"]})
    
    wing_idle_motion = nw.new_node(nodegroup_wing_idle_motion().name,
        input_kwargs={'Geometry': wing_flapping_motion, 'Idle Noise': 0.0750, 'Wing Lenght': group_input_23.outputs["Wing Lenght"]})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': wing_idle_motion})
    
    set_spline_type_1 = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': reroute_2}, attrs={'spline_type': 'CATMULL_ROM'})
    
    spline_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    map_range_12 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': spline_parameter_1.outputs["Factor"], 3: 1.0000, 4: 0.5000})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius,
        input_kwargs={'Curve': set_spline_type_1, 'Radius': map_range_12.outputs["Result"]})
    
    curve_circle = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.0100})
    
    transform_geometry = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': curve_circle.outputs["Curve"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': transform_geometry, 'Fill Caps': True})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': curve_to_mesh, 'Material': surface.shaderfunc_to_material(shader_wing_bones)})
    
    named_attribute_2 = nw.new_node(Nodes.NamedAttribute, input_kwargs={'Name': 'rot'}, attrs={'data_type': 'FLOAT_VECTOR'})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': named_attribute_2.outputs["Attribute"]})
    
    feather_01 = nw.new_node(nodegroup_feather_01().name,
        input_kwargs={'Rotation': reroute_24, 'Curve': set_spline_type_1, 'Switch': group_input_23.outputs["Invert"], 'Switch To Simple': group_input_23.outputs["Simple Wing"], 'Feather Scale': group_input_23.outputs["Wing Lenght"], 'Flap Speed': group_input_23.outputs["Flap Speed"], 'Feather Count': 30, 'Switch to Super High': group_input_23.outputs["Switch to super high"], 'Wing Profile': group_input_23.outputs["Wing Profile"], 'Material': group_input_23.outputs["Material"]})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    feather_02 = nw.new_node(nodegroup_feather_02().name,
        input_kwargs={'Rotation': reroute_23, 'Curve': set_spline_type_1, 'Switch': group_input_23.outputs["Invert"], 'Switch To Simple': group_input_23.outputs["Simple Wing"], 'Feather Scale': group_input_23.outputs["Wing Lenght"], 'Flap Speed': group_input_23.outputs["Flap Speed"], 'Feather Count': 25, 'Switch to Super High': group_input_23.outputs["Switch to super high"], 'Wing Profile': group_input_23.outputs["Wing Profile"], 'Material': group_input_23.outputs["Material1"]})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    feather_03 = nw.new_node(nodegroup_feather_03().name,
        input_kwargs={'Rotation': reroute_22, 'Curve': set_spline_type_1, 'Switch': group_input_23.outputs["Invert"], 'Switch To Simple': group_input_23.outputs["Simple Wing"], 'Feather Scale': group_input_23.outputs["Wing Lenght"], 'Flapping Speed': group_input_23.outputs["Flap Speed"], 'Feather Count': 20, 'Switch to super high': group_input_23.outputs["Switch to super high"], 'Wing Profile': group_input_23.outputs["Wing Profile"], 'Material': group_input_23.outputs["Material2"]})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    feather_04 = nw.new_node(nodegroup_feather_04().name,
        input_kwargs={'Rotation': reroute_25, 'Curve': set_spline_type_1, 'Switch Invert': group_input_23.outputs["Invert"], 'Switch To Simple': group_input_23.outputs["Simple Wing"], 'Feather Scale': group_input_23.outputs["Wing Lenght"], 'Feathers': 25, 'Flap Speed': group_input_23.outputs["Flap Speed"], 'Switch to super high': group_input_23.outputs["Switch to super high"], 'Material': group_input_23.outputs["Material3"]})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    feather_05 = nw.new_node(nodegroup_feather_05().name,
        input_kwargs={'Rotation': reroute_26, 'Curve': set_spline_type_1, 'Switch Invert': group_input_23.outputs["Invert"], 'Switch To Simple': group_input_23.outputs["Simple Wing"], 'Feather Scale': group_input_23.outputs["Wing Lenght"], 'Feathers': 25, 'Flap Speed': group_input_23.outputs["Flap Speed"], 'Switch to super high': group_input_23.outputs["Switch to super high"], 'Material': group_input_23.outputs["Material3"]})
    
    switch_10 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_23.outputs["Simple Wing"], 14: feather_05})
    
    switch_11 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_23.outputs["Switch to super high"], 14: switch_10.outputs[6], 15: feather_05})
    
    feather_06 = nw.new_node(nodegroup_feather_06().name,
        input_kwargs={'Rotation': reroute_26, 'Curve': set_spline_type_1, 'Switch Invert': group_input_23.outputs["Invert"], 'Switch To Simple': group_input_23.outputs["Simple Wing"], 'Feather Scale': group_input_23.outputs["Wing Lenght"], 'Feathers': 25, 'Flap Speed': group_input_23.outputs["Flap Speed"], 'Switch to super high': group_input_23.outputs["Switch to super high"], 'Material': group_input_23.outputs["Material3"]})
    
    switch_9 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_23.outputs["Simple Wing"], 14: feather_06})
    
    switch_12 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_23.outputs["Switch to super high"], 14: switch_9.outputs[6], 15: feather_06})
    
    wingbonecover = nw.new_node(nodegroup_wing_bone_cover().name,
        input_kwargs={'Curve': set_spline_type_1, 'Rotation': reroute_24, 'Material': group_input_23.outputs["Material3"], 'Switch': group_input_23.outputs["Switch to super high"]})
    
    switch_8 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_23.outputs["Simple Wing"], 14: wingbonecover})
    
    switch_13 = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_23.outputs["Switch to super high"], 14: switch_8.outputs[6], 15: wingbonecover})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [feather_01, feather_02, feather_03, feather_04, switch_11.outputs[6], switch_12.outputs[6], switch_13.outputs[6]]})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_1})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_material, reroute_20]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': join_geometry}, attrs={'is_active_output': True})

def shader_body_feather_eagle(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.elements[0].position = 0.0000
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 1.0000
    color_ramp.color_ramp.elements[1].color = [0.0810, 0.0653, 0.0379, 1.0000]
    
    group = nw.new_node(nodegroup_feather().name, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_beak(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.7106, 0.2803, 0.0636, 1.0000), 'Roughness': 0.3712})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_eyes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.0000, 0.0000, 0.0000, 1.0000), 'Metallic': 1.0000, 'Roughness': 0.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_wing_bones(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.elements[0].position = 0.2636
    color_ramp.color_ramp.elements[0].color = [0.0161, 0.0077, 0.0016, 1.0000]
    color_ramp.color_ramp.elements[1].position = 1.0000
    color_ramp.color_ramp.elements[1].color = [0.1666, 0.1366, 0.1084, 1.0000]
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': color_ramp.outputs["Color"], 'Specular': 0.1500, 'Roughness': 0.7273})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_wing_tail_primary(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.interpolation = "B_SPLINE"
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.1545
    color_ramp.color_ramp.elements[0].color = [0.0567, 0.0345, 0.0139, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.3364
    color_ramp.color_ramp.elements[1].color = [0.4852, 0.3532, 0.2216, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.6864
    color_ramp.color_ramp.elements[2].color = [1.0000, 0.7307, 0.4599, 1.0000]
    color_ramp.color_ramp.elements[3].position = 0.8591
    color_ramp.color_ramp.elements[3].color = [0.6817, 0.4578, 0.3472, 1.0000]
    color_ramp.color_ramp.elements[4].position = 1.0000
    color_ramp.color_ramp.elements[4].color = [0.3635, 0.2184, 0.1399, 1.0000]
    
    group = nw.new_node(nodegroup_feather().name, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_wing_secondary_covers(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.0636
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.2182
    color_ramp.color_ramp.elements[1].color = [0.1052, 0.0503, 0.0226, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.3818
    color_ramp.color_ramp.elements[2].color = [0.0638, 0.0239, 0.0098, 1.0000]
    color_ramp.color_ramp.elements[3].position = 0.7682
    color_ramp.color_ramp.elements[3].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    group = nw.new_node(nodegroup_feather().name, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_wing_primary_covers(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.0636
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.3182
    color_ramp.color_ramp.elements[1].color = [0.0523, 0.0349, 0.0268, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.4545
    color_ramp.color_ramp.elements[2].color = [0.1079, 0.0385, 0.0146, 1.0000]
    color_ramp.color_ramp.elements[3].position = 0.9045
    color_ramp.color_ramp.elements[3].color = [0.0190, 0.0088, 0.0022, 1.0000]
    
    group = nw.new_node(nodegroup_feather().name, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_wing_secondary(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.2091
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.3545
    color_ramp.color_ramp.elements[1].color = [0.4468, 0.3326, 0.2318, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.3682
    color_ramp.color_ramp.elements[2].color = [0.2692, 0.1279, 0.0403, 1.0000]
    color_ramp.color_ramp.elements[3].position = 0.8136
    color_ramp.color_ramp.elements[3].color = [0.0681, 0.0177, 0.0000, 1.0000]
    
    group = nw.new_node(nodegroup_feather().name, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_wing_primary(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.interpolation = "B_SPLINE"
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.1773
    color_ramp.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.2182
    color_ramp.color_ramp.elements[1].color = [0.4852, 0.3532, 0.2216, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.2545
    color_ramp.color_ramp.elements[2].color = [0.8159, 0.5091, 0.2003, 1.0000]
    color_ramp.color_ramp.elements[3].position = 0.3000
    color_ramp.color_ramp.elements[3].color = [0.2824, 0.1594, 0.0376, 1.0000]
    color_ramp.color_ramp.elements[4].position = 0.3500
    color_ramp.color_ramp.elements[4].color = [0.2880, 0.1481, 0.0619, 1.0000]
    color_ramp.color_ramp.elements[5].position = 0.5909
    color_ramp.color_ramp.elements[5].color = [0.1014, 0.0395, 0.0056, 1.0000]
    color_ramp.color_ramp.elements[6].position = 0.8523
    color_ramp.color_ramp.elements[6].color = [0.0609, 0.0252, 0.0052, 1.0000]
    color_ramp.color_ramp.elements[7].position = 0.9045
    color_ramp.color_ramp.elements[7].color = [0.0000, 0.0000, 0.0000, 1.0000]
    
    group = nw.new_node(nodegroup_feather().name, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': group}, attrs={'is_active_output': True})

def shader_body(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    attribute = nw.new_node(Nodes.Attribute, attrs={'attribute_name': 'fac2'})
    
    color_ramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': attribute.outputs["Color"]})
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements.new(0)
    color_ramp.color_ramp.elements[0].position = 0.0000
    color_ramp.color_ramp.elements[0].color = [1.0000, 1.0000, 1.0000, 1.0000]
    color_ramp.color_ramp.elements[1].position = 0.1318
    color_ramp.color_ramp.elements[1].color = [0.0833, 0.0135, 0.0034, 1.0000]
    color_ramp.color_ramp.elements[2].position = 0.8705
    color_ramp.color_ramp.elements[2].color = [0.0288, 0.0272, 0.0270, 1.0000]
    color_ramp.color_ramp.elements[3].position = 1.0000
    color_ramp.color_ramp.elements[3].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': color_ramp.outputs["Color"]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_1 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketInt', 'Birds', 1),
            ('NodeSocketFloat', 'Offset Curve', 10.0000),
            ('NodeSocketFloat', 'Bird Speed', 50.0000),
            ('NodeSocketFloat', 'Wing Lenght', 1.0000),
            ('NodeSocketFloat', 'Tail Lenght', 1.0000),
            ('NodeSocketFloatFactor', 'Tail Profile', 0.0000),
            ('NodeSocketFloat', 'Flap Movement', 0.5000),
            ('NodeSocketFloat', 'Flapping Speed', 0.0000),
            ('NodeSocketFloatFactor', 'Manual Flapping', 0.0000),
            ('NodeSocketBool', 'Simple Wing', False),
            ('NodeSocketBool', 'Switch to super high', False),
            ('NodeSocketFloatFactor', 'Wing Profile', 0.0000),
            ('NodeSocketMaterial', 'Wing Primary', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketMaterial', 'Wing Secondary', None), #surface.shaderfunc_to_material(shader_wing_secondary)
            ('NodeSocketMaterial', 'Wing Primary Covers', None), #surface.shaderfunc_to_material(shader_wing_primary_covers)
            ('NodeSocketMaterial', 'Wing Secondary Covers', None), #surface.shaderfunc_to_material(shader_wing_secondary_covers)
            ('NodeSocketMaterial', 'Tail', None), #surface.shaderfunc_to_material(shader_wing_tail_primary)
            ('NodeSocketMaterial', 'Body', None), #surface.shaderfunc_to_material(shader_body)
            ('NodeSocketMaterial', 'Body Feather', None), #surface.shaderfunc_to_material(shader_wing_primary)
            ('NodeSocketInt', 'Tail Feathers', 13),
            ('NodeSocketFloat', 'Body Scale', 1.0000),
            ('NodeSocketFloat', 'Beak scale', 1.0000),
            ('NodeSocketFloat', 'Leg Scale', 1.0000),
            ('NodeSocketVectorTranslation', 'Offset Legs', (-0.1400, 0.0000, -0.2100)),
            ('NodeSocketBool', 'Show Curve', True)])
    
    duplicate_elements = nw.new_node(Nodes.DuplicateElements,
        input_kwargs={'Geometry': group_input_1.outputs["Geometry"], 'Amount': group_input_1.outputs["Birds"]},
        attrs={'domain': 'SPLINE'})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    vector_rotate = nw.new_node(Nodes.VectorRotate, input_kwargs={'Vector': curve_tangent, 'Angle': 1.5708})
    
    map_range_6 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input_1.outputs["Offset Curve"], 2: 10.0000, 4: 50.0000},
        attrs={'clamp': False})
    
    map_range_2 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': duplicate_elements.outputs["Duplicate Index"], 2: 25.0000, 4: map_range_6.outputs["Result"]},
        attrs={'clamp': False})
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_2.outputs["Result"]})
    
    multiply = nw.new_node(Nodes.VectorMath, input_kwargs={0: vector_rotate, 1: reroute_81}, attrs={'operation': 'MULTIPLY'})
    
    reroute_86 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply.outputs["Vector"]})
    
    set_position_2 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': duplicate_elements.outputs["Geometry"], 'Offset': reroute_86})
    
    reroute_85 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_2})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    add = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: duplicate_elements.outputs["Duplicate Index"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': add.outputs["Vector"], 'Scale': 0.1400, 'Detail': 0.0000})
    
    subtract = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture.outputs["Color"], 1: (0.5000, 0.5000, 0.5000)},
        attrs={'operation': 'SUBTRACT'})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract.outputs["Vector"], 1: (5.0000, 5.0000, 5.0000)},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': duplicate_elements.outputs["Duplicate Index"]})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_10})
    
    multiply_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: multiply_1.outputs["Vector"], 1: reroute_64},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_74 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_2.outputs["Vector"]})
    
    set_position = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_85, 'Offset': reroute_74})
    
    position = nw.new_node(Nodes.InputPosition)
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_64})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_6, 2: 5.0000}, attrs={'clamp': False})
    
    blur_attribute = nw.new_node(Nodes.BlurAttribute,
        input_kwargs={2: position, 'Iterations': 3, 'Weight': map_range_1.outputs["Result"]},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position, 'Position': blur_attribute.outputs[2]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_1})
    
    reroute_53 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_53})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Bird Speed"]})
    
    time_speed = nw.new_node(nodegroup_time__speed().name, input_kwargs={'Offset Time': 0.0000, 'Speed': reroute_7})
    
    reroute_79 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': time_speed})
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_79})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_10})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    sample_curve = nw.new_node(Nodes.SampleCurve,
        input_kwargs={'Curves': reroute_4, 'Factor': 0.4833, 'Length': reroute_80, 'Curve Index': reroute_66},
        attrs={'mode': 'LENGTH'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': sample_curve.outputs["Position"]})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    time_speed_1 = nw.new_node(nodegroup_time__speed().name, input_kwargs={'Offset Time': 3.0000, 'Speed': reroute_7})
    
    reroute_77 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': time_speed_1})
    
    reroute_78 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_77})
    
    sample_curve_1 = nw.new_node(Nodes.SampleCurve,
        input_kwargs={'Curves': reroute_11, 'Factor': 0.4833, 'Length': reroute_78, 'Curve Index': reroute_66},
        attrs={'mode': 'LENGTH'})
    
    main_rotation = nw.new_node(nodegroup_main_rotation().name,
        input_kwargs={'pos 0': sample_curve_1.outputs["Position"], 'pos 1': sample_curve.outputs["Position"], 'tan 0': sample_curve.outputs["Tangent"]})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_11})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    time_speed_2 = nw.new_node(nodegroup_time__speed().name, input_kwargs={'Offset Time': 10.0000, 'Speed': reroute_7})
    
    reroute_75 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': time_speed_2})
    
    reroute_76 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_75})
    
    sample_curve_4 = nw.new_node(Nodes.SampleCurve,
        input_kwargs={'Curves': reroute_30, 'Factor': 0.4833, 'Length': reroute_76, 'Curve Index': reroute_66},
        attrs={'mode': 'LENGTH'})
    
    cornertilt = nw.new_node(nodegroup_corner_tilt().name,
        input_kwargs={'pos0': sample_curve.outputs["Position"], 'pos1': sample_curve_1.outputs["Position"], 'pos2': sample_curve_4.outputs["Position"], 'Lean On Corners': 4.0000})
    
    rotate_euler = nw.new_node(Nodes.RotateEuler,
        input_kwargs={'Rotation': main_rotation, 'Axis': (-1.0000, 0.0000, 0.0000), 'Angle': cornertilt},
        attrs={'space': 'LOCAL'})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': rotate_euler})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_23})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Wing Lenght"]})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Flap Movement"]})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Simple Wing"]})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Flapping Speed"]})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    main_rotation_1 = nw.new_node(nodegroup_main_rotation().name,
        input_kwargs={'pos 0': sample_curve_4.outputs["Position"], 'pos 1': sample_curve_1.outputs["Position"], 'tan 0': sample_curve_1.outputs["Tangent"]})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': main_rotation_1})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    map_range = nw.new_node(Nodes.MapRange, input_kwargs={'Value': cornertilt, 1: 0.2500})
    
    add_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Manual Flapping"], 1: map_range.outputs["Result"]},
        attrs={'use_clamp': True})
    
    random_value = nw.new_node(Nodes.RandomValue, input_kwargs={2: -0.4000, 3: 0.7300, 'Seed': 40})
    
    reroute_82 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_66})
    
    reroute_84 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_82})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={2: reroute_84}, attrs={'data_type': 'INT'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: random_value.outputs[1], 1: greater_than},
        attrs={'use_clamp': True, 'operation': 'MULTIPLY'})
    
    add_2 = nw.new_node(Nodes.Math, input_kwargs={0: add_1, 1: multiply_3}, attrs={'use_clamp': True})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_2})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_49})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Switch to super high"]})
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Wing Profile"]})
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_53})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_67})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_66})
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_69})
    
    windstructures = nw.new_node(nodegroup_wind_structures().name,
        input_kwargs={'Position': reroute_19, 'Rotation': reroute_24, 'Invert': True, 'Wing Lenght': reroute_36, 'Max Wing Flapping': reroute_39, 'Simple Wing': reroute_37, 'Flap Speed': reroute_38, 'Look Ahead': reroute_29, 'Manual Flapping': reroute_51, 'Switch to super high': reroute_13, 'Wing Profile': reroute_54, 'Material': group_input_1.outputs["Wing Primary"], 'Material1': group_input_1.outputs["Wing Secondary"], 'Material2': group_input_1.outputs["Wing Primary Covers"], 'Material3': group_input_1.outputs["Wing Secondary Covers"], 'Curve': reroute_73, 'Index': reroute_70})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': windstructures})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_16})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_20})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_27})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_49})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_50})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_15})
    
    windstructures_1 = nw.new_node(nodegroup_wind_structures().name,
        input_kwargs={'Position': reroute, 'Rotation': reroute_25, 'Wing Lenght': reroute_32, 'Max Wing Flapping': reroute_35, 'Simple Wing': reroute_33, 'Flap Speed': reroute_34, 'Look Ahead': reroute_28, 'Manual Flapping': reroute_52, 'Switch to super high': reroute_13, 'Wing Profile': reroute_40, 'Material': group_input_1.outputs["Wing Primary"], 'Material1': group_input_1.outputs["Wing Secondary"], 'Material2': group_input_1.outputs["Wing Primary Covers"], 'Material3': group_input_1.outputs["Wing Secondary Covers"], 'Curve': reroute_73, 'Index': reroute_70})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': windstructures_1})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_1, reroute_5]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_1})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_1.outputs["Show Curve"], 15: group_input_1.outputs["Geometry"]})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch.outputs[6]})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_9})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Wing Profile"]})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Body"]})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Body Feather"]})
    
    bodybeta = nw.new_node(nodegroup_body_b_e_t_a().name,
        input_kwargs={'Position': reroute_22, 'Rotation': reroute_42, 'Profile': reroute_55, 'Body Material': reroute_71, 'Body Feather': reroute_72, 'Body Scale': group_input_1.outputs["Body Scale"], 'Curve': reroute_73, 'Beak scale': group_input_1.outputs["Beak scale"]})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': bodybeta})
    
    reroute_68 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_42})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Wing Lenght"], 1: group_input_1.outputs["Tail Lenght"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_4})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Simple Wing"]})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_46})
    
    reroute_83 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_73})
    
    tail = nw.new_node(nodegroup_tail().name,
        input_kwargs={'Position': reroute_41, 'Rotation': reroute_43, 'Bird Speed': group_input_1.outputs["Bird Speed"], 'Max Wing Flapping': group_input_1.outputs["Flap Movement"], 'Flapping Speed': group_input_1.outputs["Flapping Speed"], 'Look Ahead': reroute_45, 'Tail width': 0.0250, 'Tail Lenght': reroute_47, 'Simple Feather': reroute_48, 'Tail Profile': group_input_1.outputs["Tail Profile"], 'Offset Tail': (-0.1700, 0.0000, -0.1100), 'Tail Angle': -0.1065, 'Switch to super high': group_input_1.outputs["Switch to super high"], 'Material': group_input_1.outputs["Tail"], 'Count': group_input_1.outputs["Tail Feathers"], 'Index': reroute_70, 'Curve': reroute_83})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': tail})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_22})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_42})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    multiply_5 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Wing Lenght"], 1: group_input_1.outputs["Tail Lenght"]},
        attrs={'operation': 'MULTIPLY'})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': multiply_5})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_1.outputs["Simple Wing"]})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_61})
    
    multiply_6 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_1.outputs["Body Scale"], 1: group_input_1.outputs["Leg Scale"]},
        attrs={'operation': 'MULTIPLY'})
    
    legsbeta = nw.new_node(nodegroup_legs_b_e_t_a().name,
        input_kwargs={'Position': reroute_58, 'Rotation': reroute_56, 'Bird Speed': group_input_1.outputs["Bird Speed"], 'Max Wing Flapping': group_input_1.outputs["Flap Movement"], 'Flapping Speed': group_input_1.outputs["Flapping Speed"], 'Look Ahead': reroute_57, 'Tail width': 0.0750, 'Tail Lenght': reroute_59, 'Simple Feather': reroute_60, 'Tail Profile': group_input_1.outputs["Tail Profile"], 'Offset Tail': group_input_1.outputs["Offset Legs"], 'Switch to super high': group_input_1.outputs["Switch to super high"], 'Material': group_input_1.outputs["Tail"], 'Scale': multiply_6, 'Curve': reroute_83, 'Index': reroute_82})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': legsbeta})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [reroute_3, reroute_63, reroute_68, reroute_44, reroute_62]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
    surface.add_material(obj, shader_body, selection=selection)
    surface.add_material(obj, shader_wing_primary, selection=selection)
    surface.add_material(obj, shader_wing_secondary, selection=selection)
    surface.add_material(obj, shader_wing_primary_covers, selection=selection)
    surface.add_material(obj, shader_wing_secondary_covers, selection=selection)
    surface.add_material(obj, shader_wing_tail_primary, selection=selection)
    surface.add_material(obj, shader_wing_bones, selection=selection)
    surface.add_material(obj, shader_eyes, selection=selection)
    surface.add_material(obj, shader_beak, selection=selection)
    surface.add_material(obj, shader_body_feather_eagle, selection=selection)
apply(bpy.context.active_object)