import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup_wall_covers', singleton=False, type='GeometryNodeTree')
def nodegroup_wall_covers(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Curve', None),
            ('NodeSocketFloat', 'Wall Heigth', 0.5000),
            ('NodeSocketFloat', 'ADD', 0.1500),
            ('NodeSocketFloatDistance', 'Length Between', 0.6900),
            ('NodeSocketGeometry', 'Instance', None)])
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Curve"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: group_input.outputs["Wall Heigth"], 1: group_input.outputs["ADD"]})
    
    add_1 = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: 0.1500})
    
    combine_xyz_12 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': add_1})
    
    set_position_13 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_1, 'Offset': combine_xyz_12})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Length Between"]})
    
    curve_to_points_5 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': set_position_13, 'Count': 26, 'Length': reroute_42},
        attrs={'mode': 'LENGTH'})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Instance"]})
    
    instance_on_points_8 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_5.outputs["Points"], 'Instance': reroute, 'Rotation': curve_to_points_5.outputs["Rotation"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Instances': instance_on_points_8}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_randomize_position_back', singleton=False, type='GeometryNodeTree')
def nodegroup_randomize_position_back(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Geometry', None)])
    
    normal_5 = nw.new_node(Nodes.InputNormal)
    
    random_value_3 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-0.0200, -0.0200, -0.0200), 1: (0.0200, 0.0200, 0.0200), 3: 0.0200},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal_5, 1: random_value_3.outputs["Value"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position_8 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Offset': multiply.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_8}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_transfer_n_random_r_n_s', singleton=False, type='GeometryNodeTree')
def nodegroup_transfer_n_random_r_n_s(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    random_value_4 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (-0.0400, -0.0200, 0.0000), 1: (0.0400, 0.0200, 0.0000)},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Target', None)])
    
    normal_6 = nw.new_node(Nodes.InputNormal)
    
    index = nw.new_node(Nodes.Index)
    
    sample_index = nw.new_node(Nodes.SampleIndex,
        input_kwargs={'Geometry': group_input.outputs["Target"], 3: normal_6, 'Index': index},
        attrs={'data_type': 'FLOAT_VECTOR', 'clamp': True})
    
    align_euler_to_vector_1 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': random_value_4.outputs["Value"], 'Vector': sample_index.outputs[2]},
        attrs={'pivot_axis': 'Z', 'axis': 'Y'})
    
    random_value_9 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.9500, 0.6600, 0.9500), 1: (1.0400, 1.2000, 1.0400), 2: 0.9500, 3: 1.0400},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    group_output = nw.new_node(Nodes.GroupOutput,
        input_kwargs={'Random_N_Rotation': align_euler_to_vector_1, 'Random_Scale': random_value_9.outputs["Value"]},
        attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_offset_bricks', singleton=False, type='GeometryNodeTree')
def nodegroup_offset_bricks(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Value', 0.5000),
            ('NodeSocketFloat', 'Offset Bottom', 0.0000)])
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input.outputs["Value"]})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_30})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_55, 1: 12.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input.outputs["Offset Bottom"]})
    
    multiply_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_30, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: multiply_1, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': divide})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_1})
    
    quadratic_bezier_1 = nw.new_node(Nodes.QuadraticBezier,
        input_kwargs={'Resolution': multiply, 'Start': combine_xyz_10, 'Middle': combine_xyz_8, 'End': combine_xyz_9})
    
    index_1 = nw.new_node(Nodes.Index)
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: index_1, 1: 2.0000}, attrs={'operation': 'MODULO'})
    
    set_position_7 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': quadratic_bezier_1, 'Selection': modulo, 'Offset': (0.0000, 0.0000, 0.1100)})
    
    modulo_1 = nw.new_node(Nodes.Math, input_kwargs={0: index_1, 1: 3.0000}, attrs={'operation': 'MODULO'})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': modulo_1})
    
    set_position_6 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': set_position_7, 'Selection': reroute_3, 'Offset': (0.0000, 0.0000, -0.2300)})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_6}, attrs={'is_active_output': True})

@node_utils.to_nodegroup('nodegroup_randomize_position_front', singleton=False, type='GeometryNodeTree')
def nodegroup_randomize_position_front(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input = nw.new_node(Nodes.GroupInput, expose_input=[('NodeSocketGeometry', 'Geometry', None)])
    
    normal_5 = nw.new_node(Nodes.InputNormal)
    
    random_value_3 = nw.new_node(Nodes.RandomValue,
        input_kwargs={0: (0.0200, 0.0200, 0.0200), 1: (-0.0200, -0.0200, -0.0200), 3: 0.0200},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    multiply = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal_5, 1: random_value_3.outputs["Value"]},
        attrs={'operation': 'MULTIPLY'})
    
    set_position_8 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': group_input.outputs["Geometry"], 'Offset': multiply.outputs["Vector"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_position_8}, attrs={'is_active_output': True})

def shader_windows_inside_blackness(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    diffuse_bsdf = nw.new_node(Nodes.DiffuseBSDF, input_kwargs={'Color': (0.0000, 0.0000, 0.0000, 1.0000), 'Roughness': 1.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': diffuse_bsdf}, attrs={'is_active_output': True})

def shader_bricks(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    object_info = nw.new_node(Nodes.ObjectInfo_Shader)
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': object_info.outputs["Random"]})
    colorramp.color_ramp.elements[0].position = 0.1879
    colorramp.color_ramp.elements[0].color = [0.6421, 0.6421, 0.6421, 1.0000]
    colorramp.color_ramp.elements[1].position = 1.0000
    colorramp.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: (0.5000, 0.3310, 0.2500, 1.0000)},
        attrs={'blend_type': 'COLOR', 'data_type': 'RGBA'})
    
    texture_coordinate = nw.new_node(Nodes.TextureCoord, attrs={'object': None}) #bpy.data.objects['Brick_noise_empty']
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate.outputs["Object"]})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping, 'Scale': 0.9600, 'Detail': 6.0000, 'Roughness': 1.0000})
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix.outputs[2], 7: noise_texture.outputs["Fac"]},
        attrs={'blend_type': 'OVERLAY', 'data_type': 'RGBA'})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture,
        input_kwargs={'Vector': mapping, 'Scale': 3.1600, 'Detail': 6.0000, 'Roughness': 0.6000})
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture_1.outputs["Fac"]})
    colorramp_1.color_ramp.elements.new(0)
    colorramp_1.color_ramp.elements.new(0)
    colorramp_1.color_ramp.elements[0].position = 0.0000
    colorramp_1.color_ramp.elements[0].color = [0.0000, 0.0000, 0.0000, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 0.5379
    colorramp_1.color_ramp.elements[1].color = [0.5000, 0.5000, 0.5000, 1.0000]
    colorramp_1.color_ramp.elements[2].position = 0.7242
    colorramp_1.color_ramp.elements[2].color = [0.5000, 0.5000, 0.5000, 1.0000]
    colorramp_1.color_ramp.elements[3].position = 1.0000
    colorramp_1.color_ramp.elements[3].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_2 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 0.3000, 6: colorramp_1.outputs["Color"], 7: noise_texture.outputs["Fac"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    bump = nw.new_node(Nodes.Bump, input_kwargs={'Distance': 0.1500, 'Height': mix_2.outputs[2]})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': mix_1.outputs[2], 'Roughness': 1.0000, 'Normal': bump})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_flags(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.8000, 0.0001, 0.0109, 1.0000), 'Subsurface': 0.1879, 'Subsurface Radius': (0.1000, 0.1000, 0.1000), 'Subsurface Color': (0.8000, 0.0192, 0.0000, 1.0000), 'Specular': 1.0000, 'Specular Tint': 0.4303, 'Roughness': 0.6212})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_metal(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF,
        input_kwargs={'Base Color': (0.8096, 0.2696, 0.1130, 1.0000), 'Metallic': 1.0000})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def shader_wood(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    texture_coordinate = nw.new_node(Nodes.TextureCoord)
    
    mapping_1 = nw.new_node(Nodes.Mapping,
        input_kwargs={'Vector': texture_coordinate.outputs["Object"], 'Scale': (1.0000, 9.5000, 1.0000)})
    
    noise_texture = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': mapping_1, 'Detail': 4.0000})
    
    colorramp = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': noise_texture.outputs["Fac"]})
    colorramp.color_ramp.elements[0].position = 0.2455
    colorramp.color_ramp.elements[0].color = [0.1026, 0.0315, 0.0000, 1.0000]
    colorramp.color_ramp.elements[1].position = 0.6788
    colorramp.color_ramp.elements[1].color = [1.0000, 0.7687, 0.6096, 1.0000]
    
    mapping = nw.new_node(Nodes.Mapping, input_kwargs={'Vector': texture_coordinate.outputs["Object"]})
    
    brick_texture = nw.new_node(Nodes.BrickTexture,
        input_kwargs={'Vector': mapping, 'Scale': 2.2600, 'Mortar Size': 0.0100, 'Brick Width': 1.5700, 'Row Height': 0.2300},
        attrs={'squash': 2.8100})
    
    mix = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: colorramp.outputs["Color"], 7: brick_texture.outputs["Color"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    object_info = nw.new_node(Nodes.ObjectInfo_Shader)
    
    colorramp_1 = nw.new_node(Nodes.ColorRamp, input_kwargs={'Fac': object_info.outputs["Random"]})
    colorramp_1.color_ramp.elements[0].position = 0.1879
    colorramp_1.color_ramp.elements[0].color = [0.5730, 0.5730, 0.5730, 1.0000]
    colorramp_1.color_ramp.elements[1].position = 1.0000
    colorramp_1.color_ramp.elements[1].color = [1.0000, 1.0000, 1.0000, 1.0000]
    
    mix_1 = nw.new_node(Nodes.Mix,
        input_kwargs={0: 1.0000, 6: mix.outputs[2], 7: colorramp_1.outputs["Color"]},
        attrs={'blend_type': 'MULTIPLY', 'data_type': 'RGBA'})
    
    principled_bsdf = nw.new_node(Nodes.PrincipledBSDF, input_kwargs={'Base Color': mix_1.outputs[2]})
    
    material_output = nw.new_node(Nodes.MaterialOutput, input_kwargs={'Surface': principled_bsdf}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_4 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Tower Radius', 2.0000),
            ('NodeSocketFloat', 'Tower Height', 2.0000),
            ('NodeSocketInt', 'Tower Corners', 32),
            ('NodeSocketInt', 'Tower Covers', 8),
            ('NodeSocketFloat', 'Offset Tower Position', -0.3800),
            ('NodeSocketBool', 'Towers On / Off', False),
            ('NodeSocketBool', 'Flag On / Off', True),
            ('NodeSocketFloat', 'Flag Height', 4.0000),
            ('NodeSocketFloat', 'Animate Flag Noise', 0.0000),
            ('NodeSocketString', '_1', ''),
            ('NodeSocketFloat', 'Wall Width', 2.0000),
            ('NodeSocketFloat', 'Wall Height', 2.0000),
            ('NodeSocketFloat', 'Wall Offset UP', 0.0000),
            ('NodeSocketFloat', 'Offset Wall Bottom', 0.0000),
            ('NodeSocketString', '_2', ''),
            ('NodeSocketFloat', 'Front Wall ADD', 0.1000),
            ('NodeSocketFloatDistance', 'Front Wall Covers', 0.6900),
            ('NodeSocketFloat', 'Back Wall ADD', 0.1000),
            ('NodeSocketFloatDistance', 'Back Wall Covers', 0.6900),
            ('NodeSocketFloat', 'Brick Depth', 0.1100),
            ('NodeSocketString', '_3', ''),
            ('NodeSocketBool', 'Stairs on / Off', False),
            ('NodeSocketFloatDistance', 'Stairs Width', 2.7800),
            ('NodeSocketFloat', 'Stairs Length', 2.0000),
            ('NodeSocketFloat', 'Handrail Height', 1.1200)])
    
    reroute_95 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Geometry"]})
    
    reroute_96 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_95})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': reroute_96, 'Count': 36, 'Length': 0.2300},
        attrs={'mode': 'LENGTH'})
    
    set_curve_radius_2 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve, 'Radius': 1.0000})
    
    reroute_149 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_curve_radius_2})
    
    reroute_150 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_149})
    
    reroute_42 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_150})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_4.outputs["Towers On / Off"], 15: reroute_42})
    
    reroute_8 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': switch_1.outputs[6]})
    
    reroute_9 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_8})
    
    curve_parameter_2 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_2 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': reroute_9, 2: curve_parameter_2.outputs["Factor"]})
    
    reroute_19 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_2.outputs["Geometry"]})
    
    reroute_109 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    curve_to_points_2 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_109, 'Count': 1})
    
    reroute_116 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_2.outputs["Points"]})
    
    reroute_108 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Tower Height"]})
    
    subtract = nw.new_node(Nodes.Math, input_kwargs={0: reroute_108, 1: 0.1400}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_6 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract})
    
    curve_line = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_6})
    
    reroute_34 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_line})
    
    reroute_112 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_34})
    
    reroute_113 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_112})
    
    reroute_115 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_2.outputs["Rotation"]})
    
    instance_on_points_6 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_116, 'Instance': reroute_113, 'Rotation': reroute_115})
    
    rotate_instances_2 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_6, 'Rotation': (1.5708, 0.0000, 0.0000)})
    
    reroute_97 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Tower Radius"]})
    
    reroute_16 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_97})
    
    reroute_103 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Offset Tower Position"]})
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: reroute_16, 1: reroute_103})
    
    reroute_17 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add})
    
    reroute_21 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: reroute_21, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_5 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply})
    
    translate_instances_3 = nw.new_node(Nodes.TranslateInstances, input_kwargs={'Instances': rotate_instances_2, 'Translation': combine_xyz_5})
    
    reroute_110 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_19})
    
    curve_to_points_3 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_110, 'Count': 2})
    
    reroute_111 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_2.outputs[2]})
    
    map_range_2 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_111})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={0: map_range_2.outputs["Result"], 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    reroute_10 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal})
    
    reroute_114 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_3.outputs["Rotation"]})
    
    instance_on_points_5 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_3.outputs["Points"], 'Selection': reroute_10, 'Instance': reroute_112, 'Rotation': reroute_114})
    
    rotate_instances_3 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_5, 'Rotation': (1.5708, 0.0000, 0.0000)})
    
    reroute_22 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_21})
    
    combine_xyz_4 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_22})
    
    translate_instances_2 = nw.new_node(Nodes.TranslateInstances, input_kwargs={'Instances': rotate_instances_3, 'Translation': combine_xyz_4})
    
    join_geometry_3 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [translate_instances_3, translate_instances_2]})
    
    curve_circle_1 = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input_4.outputs["Tower Corners"], 'Radius': group_input_4.outputs["Tower Radius"]})
    
    transform = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle_1.outputs["Curve"], 'Rotation': (0.0000, 0.0000, 0.7854)})
    
    curve_to_mesh_4 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': join_geometry_3, 'Profile Curve': transform, 'Fill Caps': True})
    
    reroute_51 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh_4})
    
    reroute_41 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_51})
    
    set_material_12 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_41, 'Material': surface.shaderfunc_to_material(shader_wood)})
    
    reroute_20 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_12})
    
    reroute_129 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Flag On / Off"]})
    
    reroute_117 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh_4})
    
    reroute_119 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_117})
    
    reroute_120 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_119})
    
    reroute_130 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_120})
    
    switch_2 = nw.new_node(Nodes.Switch, input_kwargs={1: reroute_129, 15: reroute_130})
    
    normal_9 = nw.new_node(Nodes.InputNormal)
    
    dot_product = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal_9, 1: (0.0000, 0.0000, 1.0000)},
        attrs={'operation': 'DOT_PRODUCT'})
    
    mesh_to_points = nw.new_node(Nodes.MeshToPoints,
        input_kwargs={'Mesh': switch_2.outputs[6], 'Selection': dot_product.outputs["Value"]},
        attrs={'mode': 'FACES'})
    
    reroute_128 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Flag Height"]})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_128})
    
    curve_line_1 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz})
    
    instance_on_points_8 = nw.new_node(Nodes.InstanceOnPoints, input_kwargs={'Points': mesh_to_points, 'Instance': curve_line_1})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': instance_on_points_8}, attrs={'legacy_behavior': True})
    
    reroute_118 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': realize_instances_2})
    
    curve_circle_2 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 6, 'Radius': 0.0500})
    
    curve_to_mesh_8 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': reroute_118, 'Profile Curve': curve_circle_2.outputs["Curve"], 'Fill Caps': True})
    
    reroute_46 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_118})
    
    curve_to_points_5 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_46, 'Count': 1})
    
    ico_sphere = nw.new_node(Nodes.MeshIcoSphere, input_kwargs={'Radius': 0.1100, 'Subdivisions': 2})
    
    store_named_attribute_12 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': ico_sphere.outputs["Mesh"], 'Name': 'UVMap', 3: ico_sphere.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_126 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz})
    
    reroute_127 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_126})
    
    transform_4 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': store_named_attribute_12, 'Translation': reroute_127})
    
    instance_on_points_9 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_5.outputs["Points"], 'Instance': transform_4})
    
    set_shade_smooth_2 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': instance_on_points_9})
    
    set_material_2 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth_2, 'Material': surface.shaderfunc_to_material(shader_metal)})
    
    reroute_47 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_2})
    
    reroute_121 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_46})
    
    curve_to_points_6 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_121, 'Count': 1})
    
    grid = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 2.0000, 'Vertices X': 12, 'Vertices Y': 7})
    
    store_named_attribute_11 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid.outputs["Mesh"], 'Name': 'uv_map', 3: grid.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_188 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_128})
    
    reroute_125 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_188})
    
    subtract_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_125, 1: 0.5700}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': -1.0200, 'Z': subtract_1})
    
    transform_5 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_11, 'Translation': combine_xyz_1, 'Rotation': (1.5708, 0.0000, 0.0000)})
    
    position_3 = nw.new_node(Nodes.InputPosition)
    
    capture_attribute = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': transform_5, 1: position_3},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    instance_on_points_10 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_6.outputs["Points"], 'Instance': capture_attribute.outputs["Geometry"]})
    
    set_shade_smooth_4 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': instance_on_points_10})
    
    realize_instances_3 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_shade_smooth_4}, attrs={'legacy_behavior': True})
    
    position_2 = nw.new_node(Nodes.InputPosition)
    
    position_4 = nw.new_node(Nodes.InputPosition)
    
    reroute_124 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': position_4})
    
    reroute_218 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Animate Flag Noise"]})
    
    reroute_122 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_218})
    
    add_1 = nw.new_node(Nodes.VectorMath, input_kwargs={0: reroute_124, 1: reroute_122})
    
    noise_texture_1 = nw.new_node(Nodes.NoiseTexture, input_kwargs={'Vector': add_1.outputs["Vector"], 'W': 46.2000, 'Scale': 0.6700})
    
    subtract_2 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: noise_texture_1.outputs["Color"], 1: (0.5000, 0.5000, 0.1200)},
        attrs={'operation': 'SUBTRACT'})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': capture_attribute.outputs["Attribute"]})
    
    reroute_123 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': separate_xyz.outputs["X"]})
    
    multiply_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: subtract_2.outputs["Vector"], 1: reroute_123},
        attrs={'operation': 'MULTIPLY'})
    
    add_2 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_2, 1: multiply_1.outputs["Vector"]})
    
    set_position_15 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': realize_instances_3, 'Position': add_2.outputs["Vector"]})
    
    reroute_48 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_15})
    
    set_material_1 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_48, 'Material': surface.shaderfunc_to_material(shader_flags)})
    
    join_geometry_6 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_to_mesh_8, reroute_47, set_material_1]})
    
    reroute_142 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_6})
    
    reroute_151 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Offset UP"]})
    
    reroute_152 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_151})
    
    combine_xyz_9 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_152})
    
    set_position_6 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_149, 'Offset': combine_xyz_9})
    
    reroute_13 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_6})
    
    reroute_26 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_13})
    
    reroute_7 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    reroute_58 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_7})
    
    reroute_57 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_58})
    
    multiply_2 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_4.outputs["Wall Width"], 1: 2.5000},
        attrs={'operation': 'MULTIPLY'})
    
    add_3 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_2, 1: 0.1500})
    
    quadrilateral_4 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral',
        input_kwargs={'Width': 1.2100, 'Height': 0.1900, 'Bottom Width': multiply_2, 'Top Width': add_3, 'Offset': 0.0000},
        attrs={'mode': 'TRAPEZOID'})
    
    curve_to_mesh_9 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': reroute_57, 'Profile Curve': quadrilateral_4, 'Fill Caps': True})
    
    set_shade_smooth_5 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_9, 'Shade Smooth': False})
    
    set_material_9 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth_5, 'Material': surface.shaderfunc_to_material(shader_bricks)})
    
    reroute_59 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_9})
    
    curve_parameter_1 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_1 = nw.new_node(Nodes.CaptureAttribute, input_kwargs={'Geometry': reroute_8, 2: curve_parameter_1.outputs["Factor"]})
    
    reroute_84 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_1.outputs["Geometry"]})
    
    reroute_12 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_84})
    
    reroute_86 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    curve_to_points = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_86, 'Count': 1})
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input_4.outputs["Tower Corners"], 'Radius': reroute_16})
    
    transform_2 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle.outputs["Curve"], 'Rotation': (0.0000, 0.0000, -0.7854)})
    
    resample_curve_4 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': transform_2, 'Length': 0.2300}, attrs={'mode': 'LENGTH'})
    
    reroute_107 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_4})
    
    reroute_11 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_107})
    
    reroute_82 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_11})
    
    reroute_39 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points.outputs["Rotation"]})
    
    instance_on_points_3 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points.outputs["Points"], 'Instance': reroute_82, 'Rotation': reroute_39})
    
    rotate_instances = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_3, 'Rotation': (-1.5708, 0.0000, 0.0000)})
    
    reroute_40 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_17})
    
    reroute_35 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_40})
    
    reroute_36 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_35})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': reroute_36})
    
    reroute_106 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_3})
    
    translate_instances = nw.new_node(Nodes.TranslateInstances, input_kwargs={'Instances': rotate_instances, 'Translation': reroute_106})
    
    reroute_85 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_12})
    
    curve_to_points_1 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_85, 'Count': 2})
    
    reroute_104 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_1.outputs["Points"]})
    
    reroute_83 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_1.outputs[2]})
    
    map_range_1 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_83})
    
    equal_1 = nw.new_node(Nodes.Compare, input_kwargs={0: map_range_1.outputs["Result"], 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    reroute_37 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': equal_1})
    
    reroute_38 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_1.outputs["Rotation"]})
    
    instance_on_points_4 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_104, 'Selection': reroute_37, 'Instance': reroute_11, 'Rotation': reroute_38})
    
    rotate_instances_1 = nw.new_node(Nodes.RotateInstances,
        input_kwargs={'Instances': instance_on_points_4, 'Rotation': (-1.5708, 0.0000, 0.0000)})
    
    multiply_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_35, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_3})
    
    reroute_105 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_2})
    
    translate_instances_1 = nw.new_node(Nodes.TranslateInstances, input_kwargs={'Instances': rotate_instances_1, 'Translation': reroute_105})
    
    join_geometry_2 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [translate_instances, translate_instances_1]})
    
    reroute_87 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_2})
    
    realize_instances = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': reroute_87}, attrs={'legacy_behavior': True})
    
    reroute_100 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': realize_instances})
    
    curve_to_points_7 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_100, 'Count': 4})
    
    combine_xyz_18 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': group_input_4.outputs["Tower Height"]})
    
    curve_line_2 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_18})
    
    align_euler_to_vector_3 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': curve_to_points_7.outputs["Rotation"]},
        attrs={'axis': 'Z'})
    
    instance_on_points_11 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_7.outputs["Points"], 'Instance': curve_line_2, 'Rotation': align_euler_to_vector_3})
    
    curve_circle_3 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 4, 'Radius': 0.1600})
    
    transform_6 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': curve_circle_3.outputs["Curve"], 'Rotation': (0.0000, 0.0000, 0.7854)})
    
    curve_to_mesh_10 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': instance_on_points_11, 'Profile Curve': transform_6, 'Fill Caps': True})
    
    set_shade_smooth_6 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_10, 'Shade Smooth': False})
    
    curve_to_points_9 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': instance_on_points_11, 'Count': 3, 'Length': 0.4000},
        attrs={'mode': 'LENGTH'})
    
    cube_1 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': (0.4000, 0.1300, 0.4000)})
    
    store_named_attribute_9 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_1.outputs["Mesh"], 'Name': 'uv_map', 3: cube_1.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    transform_7 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_9, 'Translation': (0.0000, 0.0000, -0.2400)})
    
    instance_on_points_13 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_9.outputs["Points"], 'Instance': transform_7, 'Rotation': curve_to_points_9.outputs["Rotation"]})
    
    join_geometry_8 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_shade_smooth_6, instance_on_points_13]})
    
    set_material_8 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_8, 'Material': surface.shaderfunc_to_material(shader_bricks)})
    
    reroute_148 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_8})
    
    reroute_98 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_87})
    
    reroute_49 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_98})
    
    reroute_43 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_49})
    
    reroute_50 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_43})
    
    reroute_45 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_50})
    
    reroute_132 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Tower Height"]})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: reroute_132, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_13 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': divide})
    
    set_position_13 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_45, 'Offset': combine_xyz_13})
    
    curve_to_points_10 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': set_position_13, 'Count': 11, 'Length': 0.6000},
        attrs={'mode': 'LENGTH'})
    
    cube_11 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': (0.9200, 0.1300, 0.0900), 'Vertices Y': 3})
    
    store_named_attribute_5 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_11.outputs["Mesh"], 'Name': 'uv_map', 3: cube_11.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_211 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_5})
    
    index_6 = nw.new_node(Nodes.Index)
    
    equal_2 = nw.new_node(Nodes.Compare, input_kwargs={0: index_6, 1: 1.0000, 'Epsilon': 0.0000}, attrs={'operation': 'EQUAL'})
    
    equal_3 = nw.new_node(Nodes.Compare, input_kwargs={0: index_6, 1: 7.0000, 'Epsilon': 0.0000}, attrs={'operation': 'EQUAL'})
    
    add_4 = nw.new_node(Nodes.Math, input_kwargs={0: equal_2, 1: equal_3})
    
    set_position_22 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': reroute_211, 'Selection': add_4, 'Offset': (-0.0500, 0.0000, 0.0000)})
    
    instance_on_points_14 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_10.outputs["Points"], 'Instance': set_position_22, 'Rotation': curve_to_points_10.outputs["Rotation"]})
    
    reroute_137 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_14})
    
    reroute_18 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_45})
    
    reroute_140 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_132})
    
    subtract_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_140, 1: 0.4800}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_20 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract_3})
    
    set_position_17 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_18, 'Offset': combine_xyz_20})
    
    curve_to_points_12 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': set_position_17, 'Count': 11, 'Length': 0.6000},
        attrs={'mode': 'LENGTH'})
    
    cube_10 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': (1.0900, 0.1600, 0.1300), 'Vertices Y': 3})
    
    store_named_attribute_10 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_10.outputs["Mesh"], 'Name': 'uv_map', 3: cube_10.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_210 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_10})
    
    index_5 = nw.new_node(Nodes.Index)
    
    equal_4 = nw.new_node(Nodes.Compare, input_kwargs={0: index_5, 1: 1.0000, 'Epsilon': 0.0000}, attrs={'operation': 'EQUAL'})
    
    equal_5 = nw.new_node(Nodes.Compare, input_kwargs={0: index_5, 1: 7.0000, 'Epsilon': 0.0000}, attrs={'operation': 'EQUAL'})
    
    add_5 = nw.new_node(Nodes.Math, input_kwargs={0: equal_4, 1: equal_5})
    
    set_position_21 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': reroute_210, 'Selection': add_5, 'Offset': (-0.0500, 0.0000, 0.0000)})
    
    instance_on_points_17 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_12.outputs["Points"], 'Instance': set_position_21, 'Rotation': curve_to_points_12.outputs["Rotation"]})
    
    reroute_141 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_17})
    
    reroute_44 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_18})
    
    reroute_145 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_44})
    
    reroute_143 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_140})
    
    divide_1 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_143, 1: 1.5000}, attrs={'operation': 'DIVIDE'})
    
    combine_xyz_21 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': divide_1})
    
    set_position_18 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_145, 'Offset': combine_xyz_21})
    
    curve_tangent = nw.new_node(Nodes.CurveTangent)
    
    capture_attribute_3 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': set_position_18, 1: curve_tangent},
        attrs={'data_type': 'FLOAT_VECTOR'})
    
    resample_curve_5 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': capture_attribute_3.outputs["Geometry"], 'Count': 20, 'Length': 0.3600})
    
    curve_to_mesh_5 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': resample_curve_5})
    
    index = nw.new_node(Nodes.Index)
    
    add_6 = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 1.0000})
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: add_6, 1: 2.0000}, attrs={'operation': 'MODULO'})
    
    mesh_to_points_1 = nw.new_node(Nodes.MeshToPoints, input_kwargs={'Mesh': curve_to_mesh_5, 'Selection': modulo}, attrs={'mode': 'EDGES'})
    
    grid_1 = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 0.5900, 'Size Y': 0.1700})
    
    store_named_attribute_3 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid_1.outputs["Mesh"], 'Name': 'uv_map', 3: grid_1.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    transform_3 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_3, 'Translation': (0.1200, 0.0000, -0.0400), 'Rotation': (0.0000, -1.5708, 0.0000)})
    
    align_euler_to_vector = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Vector': capture_attribute_3.outputs["Attribute"]},
        attrs={'axis': 'Y'})
    
    reroute_189 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector})
    
    instance_on_points_20 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_to_points_1, 'Instance': transform_3, 'Rotation': reroute_189})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': instance_on_points_20})
    
    quadrilateral_10 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0300, 'Height': 0.0300})
    
    curve_to_mesh_17 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': mesh_to_curve, 'Profile Curve': quadrilateral_10})
    
    join_geometry_9 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_137, reroute_141, curve_to_mesh_17]})
    
    set_shade_smooth_3 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': join_geometry_9, 'Shade Smooth': False})
    
    set_material_7 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth_3, 'Material': surface.shaderfunc_to_material(shader_wood)})
    
    reroute_101 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_7})
    
    resample_curve_1 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': reroute_7, 'Count': 195, 'Length': 0.2000},
        attrs={'mode': 'LENGTH'})
    
    reroute_219 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Width"]})
    
    reroute_25 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_219})
    
    reroute_32 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_25})
    
    reroute_27 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_32})
    
    multiply_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_27, 1: 1.9500}, attrs={'operation': 'MULTIPLY'})
    
    quadrilateral = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': multiply_4, 'Height': 1.0000})
    
    transform_1 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': quadrilateral, 'Translation': (0.0000, -0.5000, 0.0000)})
    
    curve_to_mesh_1 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': resample_curve_1, 'Profile Curve': transform_1, 'Fill Caps': True})
    
    normal = nw.new_node(Nodes.InputNormal)
    
    dot_product_1 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: normal, 1: (0.0000, 0.0000, 1.0000)},
        attrs={'operation': 'DOT_PRODUCT'})
    
    reroute_62 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    subtract_4 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_62, 1: 1.0000}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_12 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract_4})
    
    set_position = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': curve_to_mesh_1, 'Selection': dot_product_1.outputs["Value"], 'Offset': combine_xyz_12})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': set_position, 'Shade Smooth': False})
    
    set_material_10 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': surface.shaderfunc_to_material(shader_wood)})
    
    reroute_6 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_10})
    
    reroute_5 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_26})
    
    position_1 = nw.new_node(Nodes.InputPosition)
    
    normal_4 = nw.new_node(Nodes.InputNormal)
    
    multiply_5 = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal_4, 1: reroute_32}, attrs={'operation': 'MULTIPLY'})
    
    add_7 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position_1, 1: multiply_5.outputs["Vector"]})
    
    set_position_5 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_5, 'Position': add_7.outputs["Vector"]})
    
    resample_curve_3 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': set_position_5, 'Count': 36, 'Length': 0.2300},
        attrs={'mode': 'LENGTH'})
    
    reroute_61 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_3})
    
    reroute_91 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_61})
    
    reroute_153 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_91})
    
    reroute_155 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_153})
    
    switch_3 = nw.new_node(Nodes.Switch, input_kwargs={1: group_input_4.outputs["Stairs on / Off"], 15: reroute_155})
    
    curve_to_points_16 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': switch_3.outputs[6], 'Count': 3, 'Length': 1.9600})
    
    index_2 = nw.new_node(Nodes.Index)
    
    modulo_1 = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: 3.0000}, attrs={'operation': 'MODULO'})
    
    equal_6 = nw.new_node(Nodes.Compare, input_kwargs={0: modulo_1, 1: 1.0000}, attrs={'operation': 'EQUAL'})
    
    combine_xyz_10 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input_4.outputs["Stairs Length"]})
    
    curve_line_5 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_10})
    
    curve_parameter_3 = nw.new_node(Nodes.SplineParameter)
    
    capture_attribute_5 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': curve_line_5, 2: curve_parameter_3.outputs["Factor"]})
    
    instance_on_points_21 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_16.outputs["Points"], 'Selection': equal_6, 'Instance': capture_attribute_5.outputs["Geometry"], 'Rotation': curve_to_points_16.outputs["Rotation"]})
    
    reroute_164 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_21})
    
    realize_instances_4 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': reroute_164}, attrs={'legacy_behavior': True})
    
    normal_5 = nw.new_node(Nodes.InputNormal)
    
    reroute_171 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Stairs Width"]})
    
    reroute_170 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_171})
    
    divide_2 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_170, 1: -2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_5 = nw.new_node(Nodes.Math, input_kwargs={0: divide_2, 1: -0.1000}, attrs={'operation': 'SUBTRACT'})
    
    multiply_6 = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal_5, 1: subtract_5}, attrs={'operation': 'MULTIPLY'})
    
    capture_attribute_6 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': realize_instances_4, 1: multiply_6.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CURVE'})
    
    reroute_163 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_5.outputs[2]})
    
    reroute_172 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    reroute_165 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_172})
    
    map_range_5 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_163, 3: reroute_165, 4: 0.0400})
    
    combine_xyz_23 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_5.outputs["Result"]})
    
    set_position_1 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': capture_attribute_6.outputs["Geometry"], 'Offset': combine_xyz_23})
    
    reroute_182 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_6.outputs["Attribute"]})
    
    set_position_10 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_1, 'Offset': reroute_182})
    
    reroute_180 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_10})
    
    reroute_168 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_180})
    
    reroute_216 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Handrail Height"]})
    
    reroute_215 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_216})
    
    combine_xyz_29 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_215})
    
    set_position_3 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_168, 'Offset': combine_xyz_29})
    
    quadrilateral_7 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1200, 'Height': 0.0800})
    
    curve_to_mesh_14 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_3, 'Profile Curve': quadrilateral_7, 'Fill Caps': True})
    
    set_shade_smooth_8 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_14, 'Shade Smooth': False})
    
    reroute_169 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_shade_smooth_8})
    
    curve_to_points_18 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': reroute_180, 'Count': 3, 'Length': 1.0000},
        attrs={'mode': 'LENGTH'})
    
    add_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_216, 1: 0.0100})
    
    combine_xyz_30 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': add_8})
    
    curve_line_3 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_30})
    
    resample_curve_6 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_3, 'Count': 16})
    
    curve_parameter = nw.new_node(Nodes.SplineParameter)
    
    float_curve = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': curve_parameter.outputs["Factor"]})
    node_utils.assign_curve(float_curve.mapping.curves[0], [(0.0000, 1.0000), (0.1188, 1.0000), (0.1997, 0.4417), (0.3936, 0.8375), (0.6970, 0.3667), (0.8515, 0.8042), (0.9273, 0.8125), (1.0000, 0.8175)])
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve_6, 'Radius': float_curve})
    
    curve_circle_4 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 8, 'Radius': 0.0700})
    
    curve_to_mesh_12 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius, 'Profile Curve': curve_circle_4.outputs["Curve"], 'Fill Caps': True})
    
    align_euler_to_vector_4 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': curve_to_points_18.outputs["Normal"]},
        attrs={'axis': 'Z'})
    
    reroute_166 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_4})
    
    instance_on_points_23 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_18.outputs["Points"], 'Instance': curve_to_mesh_12, 'Rotation': reroute_166})
    
    join_geometry_10 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_169, instance_on_points_23]})
    
    curve_to_points_17 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': instance_on_points_21, 'Count': 3, 'Length': 0.2000},
        attrs={'mode': 'LENGTH'})
    
    reroute_159 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    combine_xyz_22 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_159})
    
    curve_line_6 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_22})
    
    reroute_212 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Stairs Width"]})
    
    quadrilateral_8 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.2000, 'Height': reroute_212})
    
    curve_to_mesh_13 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': curve_line_6, 'Profile Curve': quadrilateral_8, 'Fill Caps': True})
    
    set_shade_smooth_9 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_13, 'Shade Smooth': False})
    
    reroute_160 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_shade_smooth_9})
    
    align_euler_to_vector_2 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': curve_to_points_17.outputs["Rotation"]},
        attrs={'axis': 'Z'})
    
    reroute_162 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_2})
    
    reroute_157 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_5.outputs[2]})
    
    reroute_158 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_157})
    
    map_range_4 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_158, 3: 1.0000, 4: 0.0400})
    
    combine_xyz_11 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': map_range_4.outputs["Result"], 'Y': 1.0000, 'Z': 1.0000})
    
    reroute_161 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': combine_xyz_11})
    
    instance_on_points_22 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_17.outputs["Points"], 'Instance': reroute_160, 'Rotation': reroute_162, 'Scale': reroute_161})
    
    reroute_174 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_164})
    
    realize_instances_5 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': reroute_174}, attrs={'legacy_behavior': True})
    
    normal_1 = nw.new_node(Nodes.InputNormal)
    
    reroute_173 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_170})
    
    divide_3 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_173, 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    subtract_6 = nw.new_node(Nodes.Math, input_kwargs={0: divide_3, 1: 0.1000}, attrs={'operation': 'SUBTRACT'})
    
    multiply_7 = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal_1, 1: subtract_6}, attrs={'operation': 'MULTIPLY'})
    
    capture_attribute_4 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': realize_instances_5, 1: multiply_7.outputs["Vector"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CURVE'})
    
    reroute_167 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_163})
    
    reroute_175 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_165})
    
    map_range_6 = nw.new_node(Nodes.MapRange, input_kwargs={'Value': reroute_167, 3: reroute_175, 4: 0.0400})
    
    combine_xyz_24 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': map_range_6.outputs["Result"]})
    
    set_position_7 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': capture_attribute_4.outputs["Geometry"], 'Offset': combine_xyz_24})
    
    reroute_181 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_4.outputs["Attribute"]})
    
    set_position_9 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': set_position_7, 'Offset': reroute_181})
    
    reroute_179 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_position_9})
    
    curve_to_points_19 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': reroute_179, 'Count': 3, 'Length': 1.0000},
        attrs={'mode': 'LENGTH'})
    
    reroute_213 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Handrail Height"]})
    
    reroute_217 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_213})
    
    add_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_217, 1: 0.0100})
    
    combine_xyz_31 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': add_9})
    
    curve_line_4 = nw.new_node(Nodes.CurveLine, input_kwargs={'End': combine_xyz_31})
    
    resample_curve_7 = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': curve_line_4, 'Count': 16})
    
    curve_parameter_4 = nw.new_node(Nodes.SplineParameter)
    
    float_curve_1 = nw.new_node(Nodes.FloatCurve, input_kwargs={'Value': curve_parameter_4.outputs["Factor"]})
    node_utils.assign_curve(float_curve_1.mapping.curves[0], [(0.0000, 1.0000), (0.1188, 1.0000), (0.1997, 0.4417), (0.3936, 0.8375), (0.6970, 0.3667), (0.8515, 0.8042), (0.9273, 0.8125), (1.0000, 0.8175)])
    
    set_curve_radius_1 = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve_7, 'Radius': float_curve_1})
    
    curve_circle_5 = nw.new_node(Nodes.CurveCircle, input_kwargs={'Resolution': 8, 'Radius': 0.0700})
    
    curve_to_mesh_16 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_curve_radius_1, 'Profile Curve': curve_circle_5.outputs["Curve"], 'Fill Caps': True})
    
    align_euler_to_vector_5 = nw.new_node(Nodes.AlignEulerToVector,
        input_kwargs={'Rotation': curve_to_points_19.outputs["Normal"]},
        attrs={'axis': 'Z'})
    
    reroute_177 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': align_euler_to_vector_5})
    
    instance_on_points_24 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_19.outputs["Points"], 'Instance': curve_to_mesh_16, 'Rotation': reroute_177})
    
    reroute_178 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_179})
    
    reroute_214 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_217})
    
    combine_xyz_28 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': reroute_214})
    
    set_position_8 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_178, 'Offset': combine_xyz_28})
    
    quadrilateral_9 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.1700, 'Height': 0.0800})
    
    curve_to_mesh_15 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_8, 'Profile Curve': quadrilateral_9, 'Fill Caps': True})
    
    set_shade_smooth_10 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_15, 'Shade Smooth': False})
    
    reroute_176 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_shade_smooth_10})
    
    join_geometry_12 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points_24, reroute_176]})
    
    join_geometry_11 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [join_geometry_10, instance_on_points_22, join_geometry_12]})
    
    set_material_14 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_11, 'Material': surface.shaderfunc_to_material(shader_bricks)})
    
    reroute_156 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_14})
    
    reroute_193 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_20})
    
    reroute_191 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_193})
    
    reroute_192 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_191})
    
    set_material_3 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': reroute_192, 'Material': surface.shaderfunc_to_material(shader_windows_inside_blackness)})
    
    reroute_190 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_3})
    
    curve_to_points_13 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_153, 'Length': 1.9600}, attrs={'mode': 'LENGTH'})
    
    reroute_194 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_13.outputs["Points"]})
    
    map_range = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input_4.outputs["Wall Height"], 1: 0.5000, 3: 0.1400, 4: 0.5900})
    
    reroute_197 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range.outputs["Result"]})
    
    grid_2 = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 0.1400, 'Size Y': reroute_197})
    
    store_named_attribute_7 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid_2.outputs["Mesh"], 'Name': 'uv_map', 3: grid_2.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    divide_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_4.outputs["Wall Height"], 1: 1.8000},
        attrs={'operation': 'DIVIDE'})
    
    multiply_8 = nw.new_node(Nodes.Math, input_kwargs={0: divide_4, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_25 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 0.0800, 'Y': multiply_8})
    
    transform_11 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_7, 'Translation': combine_xyz_25, 'Rotation': (0.0000, -1.5708, 0.0000)})
    
    transform_12 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': transform_11, 'Translation': (0.0400, -0.0400, 0.0000)})
    
    reroute_154 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_13.outputs["Rotation"]})
    
    reroute_196 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_154})
    
    reroute_198 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_196})
    
    reroute_199 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_198})
    
    instance_on_points_26 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_194, 'Instance': transform_12, 'Rotation': reroute_199})
    
    mesh_to_curve_1 = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': instance_on_points_26})
    
    quadrilateral_13 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0300, 'Height': 0.0300})
    
    curve_to_mesh_19 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': mesh_to_curve_1, 'Profile Curve': quadrilateral_13})
    
    position = nw.new_node(Nodes.InputPosition)
    
    normal_3 = nw.new_node(Nodes.InputNormal)
    
    multiply_9 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_25, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    multiply_10 = nw.new_node(Nodes.VectorMath, input_kwargs={0: normal_3, 1: multiply_9}, attrs={'operation': 'MULTIPLY'})
    
    add_10 = nw.new_node(Nodes.VectorMath, input_kwargs={0: position, 1: multiply_10.outputs["Vector"]})
    
    set_position_4 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_13, 'Position': add_10.outputs["Vector"]})
    
    resample_curve_2 = nw.new_node(Nodes.ResampleCurve,
        input_kwargs={'Curve': set_position_4, 'Count': 36, 'Length': 0.2300},
        attrs={'mode': 'LENGTH'})
    
    reroute_92 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': resample_curve_2})
    
    reroute_93 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_92})
    
    reroute_208 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_93})
    
    curve_to_points_14 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': reroute_208, 'Length': 1.9600}, attrs={'mode': 'LENGTH'})
    
    reroute_203 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_14.outputs["Points"]})
    
    map_range_8 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': group_input_4.outputs["Wall Height"], 1: 0.5000, 3: 0.1400, 4: 0.5900})
    
    reroute_205 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': map_range_8.outputs["Result"]})
    
    grid_3 = nw.new_node(Nodes.MeshGrid, input_kwargs={'Size X': 0.1400, 'Size Y': reroute_205})
    
    store_named_attribute_6 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': grid_3.outputs["Mesh"], 'Name': 'uv_map', 3: grid_3.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    divide_5 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_4.outputs["Wall Height"], 1: 1.8000},
        attrs={'operation': 'DIVIDE'})
    
    multiply_11 = nw.new_node(Nodes.Math, input_kwargs={0: divide_5, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_27 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 0.0800, 'Y': multiply_11})
    
    transform_14 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': store_named_attribute_6, 'Translation': combine_xyz_27, 'Rotation': (0.0000, -1.5708, 0.0000)})
    
    transform_15 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': transform_14, 'Translation': (-0.1800, -0.0400, 0.0000)})
    
    reroute_204 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_points_14.outputs["Rotation"]})
    
    reroute_202 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_204})
    
    reroute_207 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_202})
    
    reroute_206 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_207})
    
    instance_on_points_27 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_203, 'Instance': transform_15, 'Rotation': reroute_206})
    
    mesh_to_curve_2 = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': instance_on_points_27})
    
    quadrilateral_14 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.0300, 'Height': 0.0300})
    
    curve_to_mesh_20 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': mesh_to_curve_2, 'Profile Curve': quadrilateral_14})
    
    reroute_209 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh_20})
    
    join_geometry_15 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [curve_to_mesh_19, reroute_209]})
    
    set_material_11 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_15, 'Material': surface.shaderfunc_to_material(shader_wood)})
    
    reroute_201 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': set_material_11})
    
    reroute_195 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_26})
    
    reroute_200 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_27})
    
    join_geometry_14 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_195, reroute_200]})
    
    set_material_13 = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry_14, 'Material': surface.shaderfunc_to_material(shader_windows_inside_blackness)})
    
    reroute_28 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    reroute_94 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_28})
    
    reroute_31 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Front Wall ADD"]})
    
    reroute_74 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_31})
    
    add_11 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_94, 1: reroute_74})
    
    reroute_2 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_11})
    
    reroute_185 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Offset Wall Bottom"]})
    
    reroute_186 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_185})
    
    offset_bricks = nw.new_node(nodegroup_offset_bricks().name, input_kwargs={'Value': reroute_2, 'Offset Bottom': reroute_186})
    
    curve_to_mesh_2 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': resample_curve_3, 'Profile Curve': offset_bricks})
    
    randomize_position_front = nw.new_node(nodegroup_randomize_position_front().name, input_kwargs={'Geometry': curve_to_mesh_2})
    
    position_5 = nw.new_node(Nodes.InputPosition)
    
    separate_xyz_1 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position_5})
    
    capture_attribute_7 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': randomize_position_front, 2: separate_xyz_1.outputs["Z"]})
    
    reroute_4 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_7.outputs["Geometry"]})
    
    reroute_3 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Brick Depth"]})
    
    reroute_54 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_3})
    
    combine_xyz_15 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': 0.2300, 'Y': reroute_54, 'Z': 0.0700})
    
    cube_3 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': combine_xyz_15, 'Vertices X': 4})
    
    store_named_attribute_1 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_3.outputs["Mesh"], 'Name': 'uv_map', 3: cube_3.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_55 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_1})
    
    reroute_56 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_55})
    
    reroute_79 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_4})
    
    transfern_randomr_n_s = nw.new_node(nodegroup_transfer_n_random_r_n_s().name, input_kwargs={'Target': reroute_79})
    
    reroute_183 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_7.outputs[2]})
    
    map_range_3 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_183, 2: 2.3400, 3: group_input_4.outputs["Offset Wall Bottom"], 4: 0.0000})
    
    multiply_12 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: map_range_3.outputs["Result"], 1: (0.1500, 1.0000, 0.5000)},
        attrs={'operation': 'MULTIPLY'})
    
    add_12 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: transfern_randomr_n_s.outputs["Random_Scale"], 1: multiply_12.outputs["Vector"]})
    
    instance_on_points_1 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_4, 'Instance': reroute_56, 'Rotation': transfern_randomr_n_s.outputs["Random_N_Rotation"], 'Scale': add_12.outputs["Vector"]})
    
    scale_instances = nw.new_node(Nodes.ScaleInstances, input_kwargs={'Instances': instance_on_points_1})
    
    reroute_81 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': scale_instances})
    
    offset_bricks_1 = nw.new_node(nodegroup_offset_bricks().name, input_kwargs={'Value': group_input_4.outputs["Tower Height"]})
    
    curve_to_mesh_3 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': realize_instances, 'Profile Curve': offset_bricks_1})
    
    randomize_position_back = nw.new_node(nodegroup_randomize_position_back().name, input_kwargs={'Geometry': curve_to_mesh_3})
    
    reroute_14 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': randomize_position_back})
    
    reroute_24 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_1})
    
    reroute_146 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_24})
    
    reroute_147 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_14})
    
    transfern_randomr_n_s_1 = nw.new_node(nodegroup_transfer_n_random_r_n_s().name, input_kwargs={'Target': reroute_147})
    
    tower_bricks = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute_14, 'Instance': reroute_146, 'Rotation': transfern_randomr_n_s_1.outputs["Random_N_Rotation"], 'Scale': transfern_randomr_n_s_1.outputs["Random_Scale"]},
        label='tower Bricks')
    
    reroute_15 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': tower_bricks})
    
    reroute_99 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_98})
    
    reroute_52 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Tower Height"]})
    
    add_13 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_52, 1: 0.1500})
    
    combine_xyz_7 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': add_13})
    
    set_position_12 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_99, 'Offset': combine_xyz_7})
    
    reroute_135 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Tower Covers"]})
    
    reroute_136 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_135})
    
    curve_to_points_4 = nw.new_node(Nodes.CurveToPoints, input_kwargs={'Curve': set_position_12, 'Count': reroute_136, 'Length': 0.6900})
    
    combine_xyz_17 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': reroute_54, 'Y': 0.2200, 'Z': 0.3700})
    
    cube_4 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': combine_xyz_17, 'Vertices Y': 3, 'Vertices Z': 4})
    
    store_named_attribute = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_4.outputs["Mesh"], 'Name': 'uv_map', 3: cube_4.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_88 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute})
    
    reroute_102 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_88})
    
    instance_on_points_7 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_4.outputs["Points"], 'Instance': reroute_102, 'Rotation': curve_to_points_4.outputs["Rotation"]})
    
    quadrilateral_1 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.5900, 'Height': 0.2200})
    
    transform_8 = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': quadrilateral_1, 'Rotation': (0.0000, 1.5708, 0.0000)})
    
    subdivide_curve = nw.new_node(Nodes.SubdivideCurve, input_kwargs={'Curve': transform_8, 'Cuts': 2})
    
    index_1 = nw.new_node(Nodes.Index)
    
    equal_7 = nw.new_node(Nodes.Compare, input_kwargs={0: index_1, 1: 10.5000, 'Epsilon': 0.5000}, attrs={'operation': 'EQUAL'})
    
    set_position_11 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': subdivide_curve, 'Selection': equal_7, 'Offset': (0.0000, 0.0000, -0.0800)})
    
    instance_on_points_18 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': mesh_to_points_1, 'Instance': set_position_11, 'Rotation': reroute_189})
    
    quadrilateral_2 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.3400, 'Height': 0.0800})
    
    curve_to_mesh_6 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': instance_on_points_18, 'Profile Curve': quadrilateral_2})
    
    reroute_144 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh_6})
    
    reroute_131 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    subtract_7 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_131, 1: 0.1200}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_14 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract_7})
    
    set_position_14 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_44, 'Offset': combine_xyz_14})
    
    curve_to_points_11 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': set_position_14, 'Count': 11, 'Length': 0.2100},
        attrs={'mode': 'LENGTH'})
    
    cube_9 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': (0.2300, 0.1200, 0.1900)})
    
    store_named_attribute_4 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_9.outputs["Mesh"], 'Name': 'uv_map', 3: cube_9.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    instance_on_points_15 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_11.outputs["Points"], 'Instance': store_named_attribute_4, 'Rotation': curve_to_points_11.outputs["Rotation"]})
    
    reroute_133 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_15})
    
    reroute_134 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Tower Height"]})
    
    subtract_8 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_134, 1: 0.1800}, attrs={'operation': 'SUBTRACT'})
    
    combine_xyz_19 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': subtract_8})
    
    set_position_16 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute_50, 'Offset': combine_xyz_19})
    
    quadrilateral_5 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral',
        input_kwargs={'Width': 0.7300, 'Height': 1.1700, 'Offset': 0.0000, 'Bottom Height': 0.9000, 'Top Height': 0.2200, 'Point 1': (0.0800, -0.3500, 0.0000), 'Point 2': (0.3000, -0.2000, 0.0000), 'Point 3': (0.3000, 0.0200, 0.0000), 'Point 4': (0.0000, 0.0300, 0.0000)},
        attrs={'mode': 'POINTS'})
    
    curve_to_mesh_11 = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': set_position_16, 'Profile Curve': quadrilateral_5, 'Fill Caps': True})
    
    reroute_139 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': curve_to_mesh_11})
    
    curve_to_points_8 = nw.new_node(Nodes.CurveToPoints,
        input_kwargs={'Curve': reroute_43, 'Count': 11, 'Length': 0.3000},
        attrs={'mode': 'LENGTH'})
    
    cube_2 = nw.new_node(Nodes.MeshCube, input_kwargs={'Size': (0.5400, 0.2900, 0.2900)})
    
    store_named_attribute_2 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_2.outputs["Mesh"], 'Name': 'uv_map', 3: cube_2.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    instance_on_points_12 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_8.outputs["Points"], 'Instance': store_named_attribute_2, 'Rotation': curve_to_points_8.outputs["Rotation"]})
    
    reroute_138 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': instance_on_points_12})
    
    join_geometry_7 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [reroute_144, reroute_133, reroute_139, reroute_138]})
    
    set_shade_smooth_1 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': join_geometry_7, 'Shade Smooth': False})
    
    join_geometry_5 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [instance_on_points_7, set_shade_smooth_1]})
    
    reroute_23 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_5})
    
    reroute_78 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    reroute_67 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_78})
    
    reroute_65 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_67})
    
    reroute_76 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Front Wall ADD"]})
    
    reroute_69 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_76})
    
    reroute_77 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Front Wall Covers"]})
    
    reroute_68 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_77})
    
    combine_xyz_16 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input_4.outputs["Brick Depth"], 'Y': 0.2200, 'Z': 0.3700})
    
    cube_5 = nw.new_node(Nodes.MeshCube,
        input_kwargs={'Size': combine_xyz_16, 'Vertices X': 3, 'Vertices Y': 3, 'Vertices Z': 4})
    
    store_named_attribute_8 = nw.new_node(Nodes.StoreNamedAttribute,
        input_kwargs={'Geometry': cube_5.outputs["Mesh"], 'Name': 'uv_map', 3: cube_5.outputs["UV Map"]},
        attrs={'data_type': 'FLOAT_VECTOR', 'domain': 'CORNER'})
    
    reroute_60 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': store_named_attribute_8})
    
    reroute_63 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_60})
    
    wall_covers = nw.new_node(nodegroup_wall_covers().name,
        input_kwargs={'Curve': reroute_91, 'Wall Heigth': reroute_65, 'ADD': reroute_69, 'Length Between': reroute_68, 'Instance': reroute_63})
    
    reroute_66 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_65})
    
    reroute_72 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Back Wall ADD"]})
    
    reroute_71 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_72})
    
    reroute_73 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Back Wall Covers"]})
    
    reroute_70 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_73})
    
    reroute_64 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_60})
    
    wall_covers_1 = nw.new_node(nodegroup_wall_covers().name,
        input_kwargs={'Curve': reroute_93, 'Wall Heigth': reroute_66, 'ADD': reroute_71, 'Length Between': reroute_70, 'Instance': reroute_64})
    
    join_geometry_4 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [wall_covers, wall_covers_1]})
    
    join_geometry_13 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': join_geometry_4})
    
    reroute_75 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_13})
    
    quadrilateral_12 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral',
        input_kwargs={'Width': 0.1900, 'Height': map_range.outputs["Result"]})
    
    combine_xyz_8 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_8})
    
    transform_10 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': quadrilateral_12, 'Translation': combine_xyz_8, 'Rotation': (0.0000, 1.5708, 0.0000)})
    
    subdivide_curve_1 = nw.new_node(Nodes.SubdivideCurve, input_kwargs={'Curve': transform_10, 'Cuts': 2})
    
    index_3 = nw.new_node(Nodes.Index)
    
    equal_8 = nw.new_node(Nodes.Compare, input_kwargs={0: index_3, 1: 7.5000, 'Epsilon': 0.5000}, attrs={'operation': 'EQUAL'})
    
    set_position_19 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': subdivide_curve_1, 'Selection': equal_8, 'Offset': (0.0000, -0.1000, 0.0000)})
    
    instance_on_points_19 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_13.outputs["Points"], 'Instance': set_position_19, 'Rotation': reroute_196})
    
    quadrilateral_3 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.3200, 'Height': 0.0800})
    
    curve_to_mesh_7 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': instance_on_points_19, 'Profile Curve': quadrilateral_3})
    
    set_shade_smooth_7 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_7, 'Shade Smooth': False})
    
    quadrilateral_15 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral',
        input_kwargs={'Width': 0.1900, 'Height': map_range_8.outputs["Result"]})
    
    combine_xyz_26 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_11})
    
    transform_13 = nw.new_node(Nodes.Transform,
        input_kwargs={'Geometry': quadrilateral_15, 'Translation': combine_xyz_26, 'Rotation': (0.0000, 1.5708, 0.0000)})
    
    subdivide_curve_2 = nw.new_node(Nodes.SubdivideCurve, input_kwargs={'Curve': transform_13, 'Cuts': 2})
    
    index_4 = nw.new_node(Nodes.Index)
    
    equal_9 = nw.new_node(Nodes.Compare, input_kwargs={0: index_4, 1: 7.5000, 'Epsilon': 0.5000}, attrs={'operation': 'EQUAL'})
    
    set_position_20 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': subdivide_curve_2, 'Selection': equal_9, 'Offset': (0.0000, -0.1000, 0.0000)})
    
    instance_on_points_25 = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': curve_to_points_14.outputs["Points"], 'Instance': set_position_20, 'Rotation': reroute_202})
    
    quadrilateral_6 = nw.new_node('GeometryNodeCurvePrimitiveQuadrilateral', input_kwargs={'Width': 0.3200, 'Height': 0.0800})
    
    curve_to_mesh_18 = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': instance_on_points_25, 'Profile Curve': quadrilateral_6})
    
    set_shade_smooth_11 = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh_18, 'Shade Smooth': False})
    
    join_geometry_16 = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [set_shade_smooth_7, set_shade_smooth_11]})
    
    reroute_1 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': join_geometry_16})
    
    reroute_29 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Wall Height"]})
    
    reroute_90 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_29})
    
    reroute_33 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': group_input_4.outputs["Back Wall ADD"]})
    
    reroute_89 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_33})
    
    add_14 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_90, 1: reroute_89})
    
    reroute_30 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': add_14})
    
    reroute_187 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute_185})
    
    multiply_13 = nw.new_node(Nodes.Math, input_kwargs={0: reroute_187, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    offset_bricks_2 = nw.new_node(nodegroup_offset_bricks().name, input_kwargs={'Value': reroute_30, 'Offset Bottom': multiply_13})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh, input_kwargs={'Curve': resample_curve_2, 'Profile Curve': offset_bricks_2})
    
    randomize_position_back_1 = nw.new_node(nodegroup_randomize_position_back().name, input_kwargs={'Geometry': curve_to_mesh})
    
    position_6 = nw.new_node(Nodes.InputPosition)
    
    separate_xyz_2 = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': position_6})
    
    capture_attribute_8 = nw.new_node(Nodes.CaptureAttribute,
        input_kwargs={'Geometry': randomize_position_back_1, 2: separate_xyz_2.outputs["Z"]})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_8.outputs["Geometry"]})
    
    reroute_80 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': reroute})
    
    transfern_randomr_n_s_2 = nw.new_node(nodegroup_transfer_n_random_r_n_s().name, input_kwargs={'Target': reroute_80})
    
    reroute_184 = nw.new_node(Nodes.Reroute, input_kwargs={'Input': capture_attribute_8.outputs[2]})
    
    map_range_7 = nw.new_node(Nodes.MapRange,
        input_kwargs={'Value': reroute_184, 2: 2.3400, 3: group_input_4.outputs["Offset Wall Bottom"], 4: 0.0000})
    
    multiply_14 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: map_range_7.outputs["Result"], 1: (0.1500, 1.0000, 0.5000)},
        attrs={'operation': 'MULTIPLY'})
    
    add_15 = nw.new_node(Nodes.VectorMath,
        input_kwargs={0: transfern_randomr_n_s_2.outputs["Random_Scale"], 1: multiply_14.outputs["Vector"]})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute, 'Instance': reroute_55, 'Rotation': transfern_randomr_n_s_2.outputs["Random_N_Rotation"], 'Scale': add_15.outputs["Vector"]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [reroute_81, reroute_15, reroute_23, reroute_75, reroute_1, instance_on_points]})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': join_geometry, 'Material': surface.shaderfunc_to_material(shader_bricks)})
    
    join_geometry_1 = nw.new_node(Nodes.JoinGeometry,
        input_kwargs={'Geometry': [reroute_20, reroute_142, reroute_59, reroute_148, reroute_101, reroute_6, reroute_156, reroute_190, reroute_201, set_material_13, set_material]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': join_geometry_1}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
apply(bpy.context.active_object)
