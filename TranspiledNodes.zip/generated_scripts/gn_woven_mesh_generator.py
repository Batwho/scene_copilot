import bpy
import mathutils
from numpy.random import uniform, normal, randint
from infinigen.core.nodes.node_wrangler import Nodes, NodeWrangler
from infinigen.core.nodes import node_utils
from infinigen.core.util.color import color_category
from infinigen.core import surface



@node_utils.to_nodegroup('nodegroup__g_e_n_zig_zag', singleton=False, type='GeometryNodeTree')
def nodegroup__g_e_n_zig_zag(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_3 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketFloat', 'Size', 1.0000),
            ('NodeSocketFloatDistance', 'Density', 0.0001),
            ('NodeSocketFloat', 'Z Offset', 1.0000),
            ('NodeSocketInt', 'Index Offset', 1)])
    
    multiply = nw.new_node(Nodes.Math, input_kwargs={0: group_input_3.outputs["Size"], 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_3 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': multiply})
    
    combine_xyz_2 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'X': group_input_3.outputs["Size"]})
    
    mesh_line = nw.new_node(Nodes.MeshLine,
        input_kwargs={'Count': group_input_3.outputs["Density"], 'Start Location': combine_xyz_3, 'Offset': combine_xyz_2},
        attrs={'mode': 'END_POINTS'})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': mesh_line})
    
    reroute = nw.new_node(Nodes.Reroute, input_kwargs={'Input': transform})
    
    index = nw.new_node(Nodes.Index)
    
    add = nw.new_node(Nodes.Math, input_kwargs={0: index, 1: 2.0000})
    
    wrap = nw.new_node(Nodes.Math, input_kwargs={0: add, 1: 2.0000, 2: 0.0000}, attrs={'operation': 'WRAP'})
    
    equal = nw.new_node(Nodes.Compare,
        input_kwargs={2: wrap, 3: group_input_3.outputs["Index Offset"]},
        attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    multiply_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_3.outputs["Z Offset"], 1: 0.0100},
        attrs={'operation': 'MULTIPLY'})
    
    multiply_2 = nw.new_node(Nodes.Math, input_kwargs={0: multiply_1, 1: -1.0000}, attrs={'operation': 'MULTIPLY'})
    
    combine_xyz = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Z': multiply_2})
    
    set_position_1 = nw.new_node(Nodes.SetPosition, input_kwargs={'Geometry': reroute, 'Selection': equal, 'Offset': combine_xyz})
    
    instance_on_points = nw.new_node(Nodes.InstanceOnPoints,
        input_kwargs={'Points': reroute, 'Instance': set_position_1, 'Rotation': (0.0000, 0.0000, 1.5708)})
    
    index_2 = nw.new_node(Nodes.Index)
    
    wrap_1 = nw.new_node(Nodes.Math, input_kwargs={0: index_2, 1: 2.0000, 2: 0.0000}, attrs={'operation': 'WRAP'})
    
    equal_1 = nw.new_node(Nodes.Compare, input_kwargs={2: wrap_1, 3: 1}, attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    divide = nw.new_node(Nodes.Math, input_kwargs={0: group_input_3.outputs["Density"], 1: 2.0000}, attrs={'operation': 'DIVIDE'})
    
    multiply_3 = nw.new_node(Nodes.Math,
        input_kwargs={0: divide, 1: group_input_3.outputs["Density"]},
        attrs={'operation': 'MULTIPLY'})
    
    divide_1 = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_3.outputs["Density"], 1: multiply_3},
        attrs={'operation': 'DIVIDE'})
    
    multiply_4 = nw.new_node(Nodes.Math,
        input_kwargs={0: divide_1, 1: group_input_3.outputs["Size"]},
        attrs={'operation': 'MULTIPLY'})
    
    combine_xyz_1 = nw.new_node(Nodes.CombineXYZ, input_kwargs={'Y': multiply_4})
    
    set_position_2 = nw.new_node(Nodes.SetPosition,
        input_kwargs={'Geometry': instance_on_points, 'Selection': equal_1, 'Offset': combine_xyz_1})
    
    realize_instances_2 = nw.new_node(Nodes.RealizeInstances, input_kwargs={'Geometry': set_position_2})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': realize_instances_2}, attrs={'is_active_output': True})

def geometry_nodes(nw: NodeWrangler):
    # Code generated using version 2.6.5 of the node_transpiler

    group_input_3 = nw.new_node(Nodes.GroupInput,
        expose_input=[('NodeSocketGeometry', 'Geometry', None),
            ('NodeSocketFloat', 'Radius', 1.0000),
            ('NodeSocketFloat', 'Depth', 2.0000),
            ('NodeSocketInt', 'Density', 60),
            ('NodeSocketInt', 'Curve Detail', 4),
            ('NodeSocketFloatDistance', 'Wire Thickness', 1.0000),
            ('NodeSocketInt', 'Mesh Resolution', 4),
            ('NodeSocketBool', 'Circular', False),
            ('NodeSocketMaterial', 'Material', None)])
    
    gen_zigzag = nw.new_node(nodegroup__g_e_n_zig_zag().name,
        input_kwargs={'Size': group_input_3.outputs["Radius"], 'Density': group_input_3.outputs["Density"], 'Z Offset': group_input_3.outputs["Depth"]})
    
    transform = nw.new_node(Nodes.Transform, input_kwargs={'Geometry': gen_zigzag, 'Rotation': (0.0000, 0.0000, 1.5708)})
    
    modulo = nw.new_node(Nodes.Math, input_kwargs={0: group_input_3.outputs["Density"], 1: 2.0000}, attrs={'operation': 'MODULO'})
    
    equal = nw.new_node(Nodes.Compare, input_kwargs={2: modulo}, attrs={'operation': 'EQUAL', 'data_type': 'INT'})
    
    switch_1 = nw.new_node(Nodes.Switch, input_kwargs={0: equal, 5: 1}, attrs={'input_type': 'INT'})
    
    gen_zigzag_1 = nw.new_node(nodegroup__g_e_n_zig_zag().name,
        input_kwargs={'Size': group_input_3.outputs["Radius"], 'Density': group_input_3.outputs["Density"], 'Z Offset': group_input_3.outputs["Depth"], 'Index Offset': switch_1.outputs[1]})
    
    join_geometry = nw.new_node(Nodes.JoinGeometry, input_kwargs={'Geometry': [transform, gen_zigzag_1]})
    
    mesh_to_curve = nw.new_node(Nodes.MeshToCurve, input_kwargs={'Mesh': join_geometry})
    
    set_spline_type = nw.new_node(Nodes.SplineType, input_kwargs={'Curve': mesh_to_curve}, attrs={'spline_type': 'BEZIER'})
    
    set_handle_type = nw.new_node(Nodes.SetHandleType, input_kwargs={'Curve': set_spline_type})
    
    multiply = nw.new_node(Nodes.Math,
        input_kwargs={0: group_input_3.outputs["Density"], 1: group_input_3.outputs["Curve Detail"]},
        attrs={'operation': 'MULTIPLY'})
    
    resample_curve = nw.new_node(Nodes.ResampleCurve, input_kwargs={'Curve': set_handle_type, 'Count': multiply, 'Length': 0.0010})
    
    set_curve_radius = nw.new_node(Nodes.SetCurveRadius, input_kwargs={'Curve': resample_curve})
    
    position = nw.new_node(Nodes.InputPosition)
    
    distance = nw.new_node(Nodes.VectorMath, input_kwargs={0: position}, attrs={'operation': 'DISTANCE'})
    
    bounding_box = nw.new_node(Nodes.BoundingBox, input_kwargs={'Geometry': resample_curve})
    
    separate_xyz = nw.new_node(Nodes.SeparateXYZ, input_kwargs={'Vector': bounding_box.outputs["Max"]})
    
    greater_than = nw.new_node(Nodes.Compare, input_kwargs={0: distance.outputs["Value"], 1: separate_xyz.outputs["X"]})
    
    delete_geometry = nw.new_node(Nodes.DeleteGeometry, input_kwargs={'Geometry': set_curve_radius, 'Selection': greater_than})
    
    switch = nw.new_node(Nodes.Switch,
        input_kwargs={1: group_input_3.outputs["Circular"], 14: set_curve_radius, 15: delete_geometry})
    
    curve_circle = nw.new_node(Nodes.CurveCircle,
        input_kwargs={'Resolution': group_input_3.outputs["Mesh Resolution"], 'Radius': group_input_3.outputs["Wire Thickness"]})
    
    curve_to_mesh = nw.new_node(Nodes.CurveToMesh,
        input_kwargs={'Curve': switch.outputs[6], 'Profile Curve': curve_circle.outputs["Curve"], 'Fill Caps': True})
    
    set_shade_smooth = nw.new_node(Nodes.SetShadeSmooth, input_kwargs={'Geometry': curve_to_mesh})
    
    set_material = nw.new_node(Nodes.SetMaterial,
        input_kwargs={'Geometry': set_shade_smooth, 'Material': group_input_3.outputs["Material"]})
    
    group_output = nw.new_node(Nodes.GroupOutput, input_kwargs={'Geometry': set_material}, attrs={'is_active_output': True})



def apply(obj, selection=None, **kwargs):
    surface.add_geomod(obj, geometry_nodes, selection=selection, attributes=[])
apply(bpy.context.active_object)