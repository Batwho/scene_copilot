import git
import os
# import deeplake
from queue import Queue
local = False
if local:
    from dotenv import load_dotenv
    load_dotenv()

from langchain.embeddings.openai import OpenAIEmbeddings
# from langchain.vectorstores import DeepLake
from langchain_community.vectorstores import FAISS 
from langchain_community.embeddings import HuggingFaceEmbeddings
model_name = "/home/zqian/codellama/chat-with-code/sentence_trans"#"sentence-transformers/all-MiniLM-L6-v2"
model_kwargs = {"device": "cuda"}
# openaimodel = "gpt-3.5-turbo-0125" #"gpt-4o-mini-2024-07-18" gpt-4o-2024-08-06
allowed_extensions = ['.py', '.ipynb', '.md']

from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain_community.llms import HuggingFacePipeline
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter,RecursiveCharacterTextSplitter
# from langchain.document_loaders import UnstructuredFileLoader,TextLoader

import localllm

class Embedder:
    def __init__(self, path) -> None:
        # self.git_link = git_link
        # last_name = self.git_link.split('/')[-1]
        # self.clone_path = last_name.split('.')[0]
        # self.deeplake_path = "/home/zqian/codellama/db"
        # self.model = localllm.create_localllm(model_id="meta-llama/Meta-Llama-3.1-8B-Instruct")#ChatOpenAI(model_name=openaimodel)  # switch to 'gpt-4'
        self.hf = HuggingFaceEmbeddings(model_name=model_name)
        self.file_path = path
        # self.openai = OpenAIEmbeddings()
        # self.MyQueue =  Queue(maxsize=10)

    # def add_to_queue(self, value):
    #     if self.MyQueue.full():
    #         self.MyQueue.get()
    #     self.MyQueue.put(value)

    def clone_repo(self):
        # if not os.path.exists(self.clone_path):
        #     # Clone the repository
        #     git.Repo.clone_from(self.git_link, self.clone_path)

    def chunk_files(self):

        loader = TextLoader("test_gpt.txt", encoding = 'UTF-8')
        self.docs = loader.load()
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=10000, chunk_overlap=2500)
        self.texts = text_splitter.split_documents(self.docs)
        self.num_texts = len(self.texts)

    def embed_deeplake(self):
        # db = DeepLake(dataset_path=self.deeplake_path, embedding_function= OpenAIEmbeddings())
        db = DeepLake(dataset_path=self.deeplake_path, embedding_function= self.hf, token='eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJpZCI6ImJhdHdobyIsImFwaV9rZXkiOiI5UUV4X1hkSE02Mk9sYy1sZmM3dGRxWHJxcEY1Y255ZHVFYS1PVzg3MXJ5OGMifQ.')
        db.add_documents(self.texts)
        ## Remove data from the cloned path
        self.delete_directory(self.clone_path)
        return db

    def embed_FAISS(self):
        db = FAISS.from_documents(self.texts, embedding= self.hf)
        # local_db_path = "./scene_rag/"
        # # self.delete_directory(self.clone_path)
        # os.makedirs(local_db_path, exist_ok=True)

        # # Step 6: Save the FAISS index locally
        # db.save_local(local_db_path)
        return db
        
    def load_db(self):
            ## Create and load
        print("loading database for RAG")
        # self.extract_all_files()
        self.chunk_files()
        # self.db = self.embed_deeplake()
        self.db = self.embed_FAISS()

        self.retriever = self.db.as_retriever( 
            # search_type="similarity_score_threshold",
            # search_kwargs={'score_threshold': 0.8}
            search_type="mmr",
            search_kwargs={'k': 20,'fetch_k': 500, 'lambda_mult': 0.5}
        )
        # self.retriever.search_kwargs['distance_metric'] = 'cos'
        # self.retriever.search_kwargs['fetch_k'] = 500
        # self.retriever.search_kwargs['k'] = 5


    def retrieve_results(self, query):
        # chat_history = list(self.MyQueue.queue)
        # qa = ConversationalRetrievalChain.from_llm(self.model, chain_type="stuff", retriever=self.retriever, condense_question_llm = ChatOpenAI(temperature=0, model=openaimodel))
        qa = ConversationalRetrievalChain.from_llm(self.model, chain_type="stuff", retriever=self.retriever)
        result = qa({"question": query, "chat_history": chat_history})
        self.add_to_queue((query, result["answer"]))
        return result['answer']


    def search(self,question):
        return self.retriever.vectorstore.similarity_search(question)

# def find_gin_files(directory):
#     gin_files = []
#     for root, dirs, files in os.walk(directory):
#         for file in files:
#             if file.endswith(".gin"):
#                 gin_files.append(os.path.join(root, file))
#     return gin_files