import bpy
import openai
import re
import os
import sys
import io
from openai import OpenAI
import anthropic


def get_api_key(context, addon_name):
    preferences = context.preferences
    addon_prefs = preferences.addons[addon_name].preferences
    return addon_prefs.api_key


def init_props():
    bpy.types.Scene.gpt4_chat_history = bpy.props.CollectionProperty(type=bpy.types.PropertyGroup)
    # print("test1")
    bpy.types.Scene.gpt4_model = bpy.props.EnumProperty(
    name="GPT Model",
    description="Select the GPT model to use",
    items=[
        ("gpt-4o-2024-08-06", "GPT-4 (powerful, expensive)", "Use GPT-4"),          ###change model from gpt-4 to gpt-4o-2024-08-06
        ("gpt-3.5-turbo-0125", "GPT-3.5 Turbo (less powerful, cheaper)", "Use GPT-3.5 Turbo"),       ###change model from gpt-3.5-turbo to gpt-3.5-turbo-0125
    ],
    default="gpt-3.5-turbo-0125",       ### change the gpt-4 to gpt-3.5...

)
    # print("test2")
    bpy.types.Scene.gpt4_chat_input = bpy.props.StringProperty(
        name="Message",
        description="Enter your message",
        default="",
    )
    bpy.types.Scene.gpt4_button_pressed = bpy.props.BoolProperty(default=False)
    bpy.types.PropertyGroup.type = bpy.props.StringProperty()
    bpy.types.PropertyGroup.content = bpy.props.StringProperty()

def clear_props():
    del bpy.types.Scene.gpt4_chat_history
    del bpy.types.Scene.gpt4_chat_input
    del bpy.types.Scene.gpt4_button_pressed


def cot(system, user):
    system = f"""
        {system}
        Follow these steps:
        1. Think through the problem step by step within the <thinking> tags.
        2. Reflect on your thinking to check for any errors or improvements within the <reflection> tags.
        3. Make any necessary adjustments based on your reflection.
        4. Provide your final, concise answer within the <output> tags.
        Important: The <thinking> and <reflection> sections are for your internal reasoning process only. 
        Do not include any part of the final answer in these sections. 
        The potential related object names should be gathered from those extra context.
        The actual response to the query must be entirely contained within the <output> tags.

        Use the following format for your response:
        <thinking>
        [Your step-by-step reasoning goes here. This is your internal thought process, not the final answer.]
        <reflection>
        [Your reflection on your reasoning, checking for errors or improvements]
        </reflection>
        [Any adjustments to your thinking based on your reflection]
        </thinking>
        <output>
        [Your final, concise answer to the query. This is the only part that will be shown to the next agent.]
        </output>
        """

    
    # messages = [{"role": "system", "content": system}]
    messages= [{"role": "user", "content": user}]

    client = anthropic.Anthropic(api_key='api_key')  

    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1500,
        system=system,
        messages=messages
    )
    # answer = response.content[0].text
    answer = response.content[0].text



    # response = client.chat.completions.create(      ###changed from openai.ChatCompletion

    #     model="gpt-4o-mini-2024-07-18",
    #     messages=messages,
    #     max_tokens=1500,
    # )
    # print("Response is:",response)
    # answer = response.choices[0].message.content
    print("Answer from cot\n",answer)

    # Extract and return output
    match = re.search(r"<output>(.*?)(?:</output>|$)", answer, re.DOTALL)
    return match.group(1).strip() if match else answer



# def rag(question):
#     prompt = """
#     Answer the following question using only the context below. Only include information specifically discussed.
#     question: {question}
#     context: {context}
#     """

#     # System prompt
#     system = "You are an AI expert in Blender, the 3D software, that uses a Chain of Thought (CoT) approach with reflection to answer queries. You will feed your answer to another AI agent who will generate python code based on your answer.\
#         A procedually generated Blender scene file is imported beforehand. Users will request tasks based on this blender scene. The provided additional context is a partial description of this scene in USDA format. "

#     # RAG context
#     context = "\n".join([x["text"] for x in embeddings.search(question)])       ###retrieved context from RAG

#     # RAG with CoT + Self-Reflection
#     return cot(system, prompt.format(question=question, context=context))

# def rag(question):
#     rag_prompt = """

#     Use COT to plan the steps to achieve following task with the context below. Also, include all task related object names in the final output as well.
#     task: {question}
#     context: {context}
#     """
#     # System prompt
#     system = "You are an AI expert in Blender, the 3D software, that uses a Chain of Thought (CoT) approach with reflection to answer queries. You will feed your answer to another AI agent who will generate python code based on your answer.\
#         A procedually generated Blender scene file is imported beforehand. Users will request tasks based on this blender scene. The provided additional context is a partial description of this scene in USDA format. "

#     # RAG context
#     # context = "\n".join([x["text"] for x in embeddings.search(question)])       ###retrieved context from RAG

#     user_prompt= "make camera follow the snake and stop moving after 10 secs"
#     # index_path = "/home/tony/Downloads/BlenderGPT_rag_two_agent_cot/chroma_db_desert_snake"
#     # index_path = "/home/tony/Downloads/BlenderGPT_rag_two_agent_cot/fixed_chroma_db_desert_snake"      #fixed_faiss_index_per_def
#     # retriever_old = load_db(index_path=index_path)
#     retriever = load_multivectordb()

#     relevant_docs = retriever.invoke(user_prompt)
   
#     # Combine retrieved documents into the system prompt
#     retrieved_context = "\n".join([doc.page_content for doc in relevant_docs])

#     # RAG with CoT + Self-Reflection
#     return cot(system, rag_prompt.format(question=user_prompt, context=retrieved_context))


def generate_blender_code(prompt, chat_history, context, system_prompt_1,system_prompt_2,retriever,global_namespace):
    # load_db()

    rag_prompt = """

    Use Chain-of-Thoughts to plan the steps to achieve following task with the context below. 
    task: {question}
    context: {context}
    """
    system = "You are an AI expert in Blender, the 3D software, that uses a Chain of Thought (CoT) approach with reflection to answer queries. You will feed your answer to another AI agent who will generate python code based on your answer.\
        A procedually generated Blender scene file is imported beforehand. Users will request tasks based on this blender scene. The provided additional context is a partial description of this scene in USDA format. "

    relevant_docs = retriever.invoke(prompt)
   
    # Combine retrieved documents into the system prompt
    retrieved_context = "\n".join([doc.page_content for doc in relevant_docs])
# ###Another step to decide whether is COT or generate code
#     if COT:
    cot_returned = cot(system, rag_prompt.format(question=prompt, context=retrieved_context))
#     elif generate code:
#         Abolfazl's code

### edit:change the sky solor
### add:import a bus
#add:can i have a metal tree        Geonode: tree/ Mate node: metal

    # results = docsearch.similarity_search(
    #         "snake",
    #         k=2,
    #     )

    #     for res in results:
    #         print(f"* {res.page_content} [{res.metadata}]")
    #     print("Done RAG part")
    # relevant_docs = retriever.invoke(prompt)
    # print("Retrieved doc:",relevant_docs)
    
    # Combine retrieved documents into the system prompt
    # retrieved_context = "\n".join([doc.page_content for doc in relevant_docs])
    # print("Retrieved: #########################")
    # print(retrieved_context)
    # print("########################")
    # Add the retrieved context to the system message, do not need to use the first to generate object names or anything
    full_system_prompt1 = system_prompt_1 + "\n\n"+cot_returned+"\n" # + retrieved_context
    

    # messages1 = [{"role": "system", "content": full_system_prompt1}]
    messages1 = []
    for messages in chat_history[-5:]:
            if messages.type == "assistant":
                messages1.append({"role": "assistant", "content": "```\n" + messages.content + "\n```"})
            else:
                messages1.append({"role": messages.type.lower(), "content": messages.content})
# ###################################
# ###below should get object names from the cot_returned
#     # Add the current user message
    messages1.append({"role": "user", "content": "Can you please find objects and write a list of string of their name for me that relate to the following task and directions: " + prompt+"\n\n"+cot_returned + " \n. Do not respond with anything that is not Python code. Do not provide explanations"})
    # response1 = openai.ChatCompletion.create(
    #         model="gpt-3.5-turbo-0125",
    #         messages=messages1,
    #         max_tokens=1500,
    # )
    # # response1_first_item = next(response1)  # it's a generator, get the first result
    # # print("first response:",response1_first_item['choices'][0])
    # answer = response1['choices'][0]['message']['content']

    client = anthropic.Anthropic(api_key='api_key')  

    response1 = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1500,
        system=full_system_prompt1,
        messages=messages1
    )
    # answer = response1.content[0].text
    answer = response1.content[0].text

    # # Create an instance of the Anthropics API client
    # response1 = client.chat.completions.create(      ###changed from openai.ChatCompletion

    #     model='gpt-4o-mini-2024-07-18',#"gpt-3.5-turbo-0125",
    #     messages=messages1,
    #     max_tokens=1500,
    # )
    # print("Response is:",response)
    # answer = response1.choices[0].message.content


    print("answer from gpt:",answer)

    # output_buffer = io.StringIO()

    # original_stdout = sys.stdout
    # sys.stdout = output_buffer
    pattern = r'\[.*?\]'
    obj_name_list = re.findall(pattern, answer)
    # print("#########################matched name list:",obj_name_list)
    # print("#########################matched name list:",obj_name_list[0])
#     blender_code = f"""
# import bpy
# import re

# def split_by_symbols(input_string):
#     # Split by any non-alphanumeric character
#     result = re.split(r'[\W_]+', input_string)
#     # Remove empty strings
#     return [item for item in result if item]
# def contains_letter_or_number(input_string):
#     # Check if the string contains any letter (a-z, A-Z) or digit (0-9)
#     pattern = r'[a-zA-Z0-9]'
    
#     # Use re.search to find if the pattern exists in the string
#     return bool(re.search(pattern, input_string))
# output = []
# for input_string in {obj_name_list[0]}:
#     sub_name_list = split_by_symbols(input_string)

#     # Loop through all objects in the current scene
#     for obj in bpy.context.scene.objects:
#         o_name = str(obj.name)
#         found = True
#         for sub_string in sub_name_list:
#             if sub_string not in o_name:
#                 found = False
#             o_name = o_name.replace(sub_string,'',1)
        
#         if found and not contains_letter_or_number(o_name):
#             # Select the object
#             output.append(obj.name)
#             # obj.select_set(True)
# print(output)
#     """
#     exec(blender_code, global_namespace)
#     sys.stdout = original_stdout
#     output_result = output_buffer.getvalue()
#     print("first code result:",output_result)
    #######################################################################
    full_sys_promp2 = system_prompt_2 + '\n' +cot_returned
    # messages = [{"role": "system", "content": full_sys_promp2}]
    messages=[]
    for message in chat_history[-10:]:
        if message.type == "assistant":
            messages.append({"role": "assistant", "content": "```\n" + message.content + "\n```"})
        else:
            messages.append({"role": message.type.lower(), "content": message.content})

    # Add the current user message
    messages.append({"role": "user", "content": "Can you please write Blender code for me that accomplishes the following task: " + prompt+"\n List of related objects in the scene: "+" ".join(obj_name_list[0]) + "Directions:"+cot_returned+"? \n. Do not respond with anything that is not Python code. Do not provide explanations"})


    # response = openai.ChatCompletion.create(
    #     model=context.scene.gpt4_model,
    #     messages=messages,
    #     stream=True,
    #     max_tokens=2500,
    # )
    
    client = anthropic.Anthropic(api_key='api_key')  

    responses = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=2500,
        system=full_sys_promp2,
        messages=messages,
       
    )

    try:
        # collected_events = []
        # completion_text = ''
        # # iterate through the stream of events
        # for event in responses:
        #     if 'role' in event.choices[0].delta:
        #         # skip
        #         continue
        #     # print("one event",event.choices[0])
        #     if event.choices[0].delta and event.choices[0].delta.content: 
                
        #         collected_events.append(event)  # save the event response
        #         event_text = event.choices[0].delta.content
        #         completion_text += event_text  # append the text
        #     # print(completion_text, flush=True, end='\r')
        completion_text = responses.content[0].text
        completion_text = re.findall(r'```(.*?)```', completion_text, re.DOTALL)[0]
        completion_text = re.sub(r'^python', '', completion_text, flags=re.MULTILINE)
        
        return completion_text
    except IndexError:
        return None



    # responses = client.chat.completions.create(      ###changed from openai.ChatCompletion

    #     model=context.scene.gpt4_model,
    #     messages=messages,
    #     stream=True,
    #     max_tokens=2500,
    # )
    
    # try:
    #     collected_events = []
    #     completion_text = ''
    #     # iterate through the stream of events
    #     for event in responses:
    #         if 'role' in event.choices[0].delta:
    #             # skip
    #             continue
    #         # print("one event",event.choices[0])
    #         if event.choices[0].delta and event.choices[0].delta.content: 
                
    #             collected_events.append(event)  # save the event response
    #             event_text = event.choices[0].delta.content
    #             completion_text += event_text  # append the text
    #         # print(completion_text, flush=True, end='\r')
    #     completion_text = re.findall(r'```(.*?)```', completion_text, re.DOTALL)[0]
    #     completion_text = re.sub(r'^python', '', completion_text, flags=re.MULTILINE)
        
    #     return completion_text
    # except IndexError:
    #     return None

def split_area_to_text_editor(context):
    area = context.area
    for region in area.regions:
        if region.type == 'WINDOW':
            override = {'area': area, 'region': region}
            bpy.ops.screen.area_split(override, direction='VERTICAL', factor=0.5)
            break

    new_area = context.screen.areas[-1]
    new_area.type = 'TEXT_EDITOR'
    return new_area