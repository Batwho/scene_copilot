import sys
import os
import bpy
import bpy.props
import re
import pickle


# Add the 'libs' folder to the Python path
libs_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "lib")
if libs_path not in sys.path:
    sys.path.append(libs_path)

import openai

from .utilities import *
from langchain_community.vectorstores import FAISS, Chroma
# from langchain_chroma.vectorstores import Chroma
from langchain.retrievers.multi_vector import MultiVectorRetriever
from langchain.storage import InMemoryByteStore

from langchain_community.embeddings import HuggingFaceEmbeddings

bl_info = {
    "name": "GPT-4 Blender Assistant",
    "blender": (3, 6, 10),
    "category": "Object",
    "author": "",
    "version": (1, 0, 0),
    "location": "3D View > UI > GPT-4 Blender Assistant",
    "description": "Generate Blender Python code using OpenAI's GPT to perform various tasks.",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

system_prompt_1 = """You are an assistant made for the purposes of helping the user with Blender, the 3D software. 
- Respond with your answers in markdown (```). 
- Preferably import entire modules instead of bits. 
- Do not perform destructive operations on the meshes. 
- Do not use cap_ends. Do not do more than what is asked (setting up render settings, adding cameras, etc)
- There is a procedurally generated scene.blend with objects, animations, and cameras in it.
- Respond with a list of string of 'name' from the provided contexts based on the user prompt. This list of string should be objects related to the user prompt.

Example:

user: move all the snake in the scene a bit higher above the ground
assistant:
```
 ["SnakeFactory(1090821408).spawn_placeholder(0)", "SnakeFactory(1090821408).spawn_placeholder(2)", "SnakeFactory_1090821408__spawn_placeholder_1_"]
```
"""
system_prompt_2 = """You are an assistant made for the purposes of helping the user with Blender, the 3D software. 
- Respond with your answers in markdown (```). 
- Preferably import entire modules instead of bits. 
- Do not perform destructive operations on the meshes. 
- Do not use cap_ends. Do not do more than what is asked (setting up render settings, adding cameras, etc)
- Do not respond with anything that is not Python code.
- There is a procedurally generated scene.blend with objects, animations, and cameras in it.
- You will be given a list of object names, which are the exact name of objects in the scene. You should check properties of these objects and primarily use those objects in the scene to generate related code.



Example:

user: move all the snake in the scene a bit higher above the ground ["SnakeFactory(1090821408).spawn_placeholder(0)", "SnakeFactory(1090821408).spawn_placeholder(2)", "SnakeFactory(1090821408).spawn_placeholder(1)"]  
assistant:
```
obj_name = ["SnakeFactory(1090821408).spawn_placeholder(0)", "SnakeFactory(1090821408).spawn_placeholder(2)", "SnakeFactory(1090821408).spawn_placeholder(1)"] 

import bpy

#First, find and locate all related objects
# Loop through all objects in the current scene
for obj in bpy.context.scene.objects:
    if obj.name in obj_name:
        # Select the object
        obj.select_set(True)


#Then, apply further transitions on those objects to follow the user prompt
move_up_by = 1.0

if len(bpy.context.selected_objects) > 0:
    for obj in bpy.context.selected_objects:
        # Move the object up along the Z axis
        obj.location.z += move_up_by
else:
    print("There is no snake in the scene)
```
"""


#only this one will be used to generate the final code
system_prompt = """You are an assistant made for the purposes of helping the user with Blender, the 3D software. 
- Respond with your answers in markdown (```). 
- Preferably import entire modules instead of bits. 
- Do not perform destructive operations on the meshes. 
- Do not use cap_ends. Do not do more than what is asked (setting up render settings, adding cameras, etc)
- Do not respond with anything that is not Python code.
- There is a pregenerated scene.blend with objects, animations, and cameras in the scene. You should primarily use those objects in the scene and generate related code.
- You will be given steps from another Chain-of-Thought agents to help accomplish the user requested task. Generate python codes following the direction.


"""





class GPT4_OT_DeleteMessage(bpy.types.Operator):
    bl_idname = "gpt4.delete_message"
    bl_label = "Delete Message"
    bl_options = {'REGISTER', 'UNDO'}

    message_index: bpy.props.IntProperty()

    def execute(self, context):
        context.scene.gpt4_chat_history.remove(self.message_index)
        return {'FINISHED'}

class GPT4_OT_ShowCode(bpy.types.Operator):
    bl_idname = "gpt4.show_code"
    bl_label = "Show Code"
    bl_options = {'REGISTER', 'UNDO'}

    code: bpy.props.StringProperty(
        name="Code",
        description="The generated code",
        default="",
    )

    def execute(self, context):
        text_name = "GPT4_Generated_Code.py"
        text = bpy.data.texts.get(text_name)
        if text is None:
            text = bpy.data.texts.new(text_name)

        text.clear()
        text.write(self.code)

        text_editor_area = None
        for area in context.screen.areas:
            if area.type == 'TEXT_EDITOR':
                text_editor_area = area
                break

        if text_editor_area is None:
            text_editor_area = split_area_to_text_editor(context)
        
        text_editor_area.spaces.active.text = text

        return {'FINISHED'}

class GPT4_PT_Panel(bpy.types.Panel):
    bl_label = "GPT-4 Blender Assistant"
    bl_idname = "GPT4_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'GPT-4 Assistant'

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)

        column.label(text="Chat history:")
        box = column.box()
        for index, message in enumerate(context.scene.gpt4_chat_history):
            if message.type == 'assistant':
                row = box.row()
                row.label(text="Assistant: ")
                show_code_op = row.operator("gpt4.show_code", text="Show Code")
                show_code_op.code = message.content
                delete_message_op = row.operator("gpt4.delete_message", text="", icon="TRASH", emboss=False)
                delete_message_op.message_index = index
            else:
                row = box.row()
                row.label(text=f"User: {message.content}")
                delete_message_op = row.operator("gpt4.delete_message", text="", icon="TRASH", emboss=False)
                delete_message_op.message_index = index

        column.separator()
        
        column.label(text="GPT Model:")
        column.prop(context.scene, "gpt4_model", text="")       

        column.label(text="Enter your message:")
        column.prop(context.scene, "gpt4_chat_input", text="")
        button_label = "Please wait...(this might take some time)" if context.scene.gpt4_button_pressed else "Execute"
        row = column.row(align=True)
        row.operator("gpt4.send_message", text=button_label)
        row.operator("gpt4.clear_chat", text="Clear Chat")

        column.separator()

class GPT4_OT_ClearChat(bpy.types.Operator):
    bl_idname = "gpt4.clear_chat"
    bl_label = "Clear Chat"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.gpt4_chat_history.clear()
        return {'FINISHED'}

class GPT4_OT_Execute(bpy.types.Operator):
    bl_idname = "gpt4.send_message"
    bl_label = "Send Message"
    bl_options = {'REGISTER', 'UNDO'}

    natural_language_input: bpy.props.StringProperty(
        name="Command",
        description="Enter the natural language command",
        default="",
    )

    def load_db(self):
        embeddings = HuggingFaceEmbeddings(model_name="/home/tony/Downloads/embedder")
        vectorstore = FAISS.load_local("/home/tony/Downloads/BlenderGPT_rag_two_agent_cot/faiss_index_per_def", embeddings, allow_dangerous_deserialization=True)
        retriever = vectorstore.as_retriever(
            search_type="similarity_score_threshold",
            search_kwargs={'score_threshold': 0.85}
            # search_type="mmr",
            # search_kwargs={'k': 7, 'lambda_mult': 0.5}
        )
        return retriever       

    
        
    def load_multivectordb(self):
        load_path = "<FAISS path>"
        def load_from_pickle(filename):
            with open(filename, "rb") as file:
                return pickle.load(file)
        embeddings = HuggingFaceEmbeddings(model_name="embedder")
        id_key = "doc_id"
        # vector_store_path = os.path.join(load_path, "chroma")
        name_db = Chroma(
            collection_name="test_documents",
            persist_directory=load_path, 
            embedding_function=embeddings,
            collection_metadata={"hnsw:space": "l2","hnsw:construction_ef": 1000, "hnsw:search_ef": 2500, "hnsw:M": 100}        #higher search_ef here will make the returning documents more accurate

        )
        # print(name_db.get())
        # print("chroma in loading:",name_db)
        store_dict = load_from_pickle(os.path.join(load_path, "name_retriever_store.pkl"))

        store = InMemoryByteStore()
        store.mset(list(store_dict.items()))

        retriever = MultiVectorRetriever(
            vectorstore=name_db,
            byte_store=store,
            id_key=id_key,
            # search_type='mmr',
            # search_kwargs={'k':20,"lambda_mult": 0.8}
            # search_type='similarity_score_threshold',
            # search_kwargs={'k':20}
        )
        return retriever


    def execute(self, context):
        openai.api_key = get_api_key(context, __name__)
        # if null then set to env key
        if not openai.api_key:
            openai.api_key = os.getenv("OPENAI_API_KEY")

        if not openai.api_key:
            self.report({'ERROR'}, "No API key detected. Please set the API key in the addon preferences.")
            return {'CANCELLED'}

        context.scene.gpt4_button_pressed = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        # retriever = self.load_db()
        retriever = self.load_multivectordb()
        global_namespace = globals().copy()
        ###
        blender_code = generate_blender_code(context.scene.gpt4_chat_input, context.scene.gpt4_chat_history, context, system_prompt_1, system_prompt_2,retriever,global_namespace)
        ###
        message = context.scene.gpt4_chat_history.add()
        message.type = 'user'
        message.content = context.scene.gpt4_chat_input

        # Clear the chat input field
        context.scene.gpt4_chat_input = ""

    
        if blender_code:
            message = context.scene.gpt4_chat_history.add()
            message.type = 'assistant'
            message.content = blender_code

            global_namespace = globals().copy()
    
        try:
            exec(blender_code, global_namespace)
        except Exception as e:
            self.report({'ERROR'}, f"Error executing generated code: {e}")
            context.scene.gpt4_button_pressed = False
            return {'CANCELLED'}

        

        context.scene.gpt4_button_pressed = False
        return {'FINISHED'}


def menu_func(self, context):
    self.layout.operator(GPT4_OT_Execute.bl_idname)

class GPT4AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    api_key: bpy.props.StringProperty(
        name="API Key",
        description="Enter your OpenAI API Key",
        default="",
        subtype="PASSWORD",
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "api_key")

def register():
    bpy.utils.register_class(GPT4AddonPreferences)
    bpy.utils.register_class(GPT4_OT_Execute)
    bpy.utils.register_class(GPT4_PT_Panel)
    bpy.utils.register_class(GPT4_OT_ClearChat)
    bpy.utils.register_class(GPT4_OT_ShowCode)
    bpy.utils.register_class(GPT4_OT_DeleteMessage)


    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)
    init_props()


def unregister():
    bpy.utils.unregister_class(GPT4AddonPreferences)
    bpy.utils.unregister_class(GPT4_OT_Execute)
    bpy.utils.unregister_class(GPT4_PT_Panel)
    bpy.utils.unregister_class(GPT4_OT_ClearChat)
    bpy.utils.unregister_class(GPT4_OT_ShowCode)
    bpy.utils.unregister_class(GPT4_OT_DeleteMessage)

    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    clear_props()


if __name__ == "__main__":
    register()
